var app = angular.module('myApp', ['mc.resizer']);

app.controller('MainCtrl', function($scope) {
  $scope.content = 'Hello World';
});

