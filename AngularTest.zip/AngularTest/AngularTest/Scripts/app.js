﻿var jackApp = angular.module('jackApp', [
  'ngRoute',
  'jackAppControllers'
]);



jackApp.config(['$routeProvider',
  function ($routeProvider) {
      $routeProvider.
          when('/', {
              templateUrl: 'Home/home.html',
              controller: 'homeCtrl'
          }).
        when('/blah', {
            templateUrl: 'Blah/Blah.html',
            controller: 'blahCtrl'
        }).
        when('/reports', {
            templateUrl: 'Reports/reports.html',
            controller: 'reportsCtrl'
        }).
        otherwise({
            redirectTo: '/'
        });
  }]);


var jackAppControllers = angular.module('jackAppControllers', []);

jackAppControllers.controller('jackAppCtrl', ['$scope',
  function ($scope) {

      $scope.jackApp = {};


  }]);




