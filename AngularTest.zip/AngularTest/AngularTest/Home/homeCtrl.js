jackAppControllers.controller('homeCtrl', ['$scope',
  function ($scope) {

      $scope.home = {};

      $scope.home['test'] = "ya baby, home it is";

  }]);