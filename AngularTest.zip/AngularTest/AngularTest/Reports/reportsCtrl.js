jackAppControllers.controller('reportsCtrl', ['$scope',
  function ($scope) {

      $scope.reports = {};

      $scope.reports['test'] = "reports"

  }]);