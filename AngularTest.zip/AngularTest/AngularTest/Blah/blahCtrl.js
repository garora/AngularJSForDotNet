jackAppControllers.controller('blahCtrl', ['$scope',
  function ($scope) {

      $scope.blah = {};

      $scope.blah['test'] = "blah";
  }]);