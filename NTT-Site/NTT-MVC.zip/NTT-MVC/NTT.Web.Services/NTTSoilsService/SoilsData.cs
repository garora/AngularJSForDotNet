﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization; //DataContract
using System.Web;

namespace NTTSoilsService
{
  [DataContract]
  public partial class SoilComponentsData
  {
    private string scdSSAField;
    private string scdSymbolField;
    private string scdNameField;
    private string scdAcresField;
    private string scdPercentField;
    private string scdSlopeField;
    private string scdPHField;
    private string scdStatusField;

    [DataMember]
    public string scdSSA
    {
      get { return this.scdSSAField; }
      set { this.scdSSAField = value; }
    }
    [DataMember]
    public string scdSymbol
    {
      get { return this.scdSymbolField; }
      set { this.scdSymbolField = value; }
    }
    [DataMember]
    public string scdName
    {
      get { return this.scdNameField; }
      set { this.scdNameField = value; }
    }
    [DataMember]
    public string scdAcres
    {
      get { return this.scdAcresField; }
      set { this.scdAcresField = value; }
    }
    [DataMember]
    public string scdPercent
    {
      get { return this.scdPercentField; }
      set { this.scdPercentField = value; }
    }
    [DataMember]
    public string scdSlope
    {
      get { return this.scdSlopeField; }
      set { this.scdSlopeField = value; }
    }
    [DataMember]
    public string scdPH
    {
      get { return this.scdPHField; }
      set { this.scdPHField = value; }
    }
    [DataMember]
    public string scdStatus
    {
      get { return this.scdStatusField; }
      set { this.scdStatusField = value; }
    }
  }

  [DataContract]
  public partial class SoilDetailsData
  {
    private string sddSaversionField;
    private string sddSaverestField;
    private string sddAreasymbolField;
    private string sddAreanameField;
    private string sddMusymField;
    private string sddMunameField;
    private string sddMuseqField;
    private string sddMukeyField;
    private string sddComppct_rField;
    private string sddCompnameField;
    private string sddSlope_rField;
    private string sddCokeyField;
    private string sddHydricratingField;
    private string sddHydgrpField;
    private string sddHzdept_rField;
    private string sddHzdepb_rField;
    private string sddChkeyField;
    private string sddSandtotal_rField;
    private string sddSilttotal_rField;
    private string sddClaytotal_rField;
    private string sddOm_rField;
    private string sddEcec_rField;
    private string sddAwc_rField;
    private string sddKffactField;
    private string sddKwfactField;
    private string sddTexdescField;
    private string sddTextureField;
    private string sddStratextsflagField;
    private string sddRvindicatorField;
    private string sddTexclField;

    [DataMember]
    public string sddSaversion
    {
      get { return this.sddSaversionField; }
      set { this.sddSaversionField = value; }
    }

    [DataMember]
    public string sddSaverest
    {
      get { return this.sddSaverestField; }
      set { this.sddSaverestField = value; }
    }

    [DataMember]
    public string sddAreasymbol
    {
      get { return this.sddAreasymbolField; }
      set { this.sddAreasymbolField = value; }
    }

    [DataMember]
    public string sddAreaname
    {
      get { return this.sddAreanameField; }
      set { this.sddAreanameField = value; }
    }

    [DataMember]
    public string sddMusym
    {
      get { return this.sddMusymField; }
      set { this.sddMusymField = value; }
    }

    [DataMember]
    public string sddMuname
    {
      get { return this.sddMunameField; }
      set { this.sddMunameField = value; }
    }

    [DataMember]
    public string sddMuseq
    {
      get { return this.sddMuseqField; }
      set { this.sddMuseqField = value; }
    }

    [DataMember]
    public string sddMukey
    {
      get { return this.sddMukeyField; }
      set { this.sddMukeyField = value; }
    }

    [DataMember]
    public string sddComppct_r
    {
      get { return this.sddComppct_rField; }
      set { this.sddComppct_rField = value; }
    }

    [DataMember]
    public string sddCompname
    {
      get { return this.sddCompnameField; }
      set { this.sddCompnameField = value; }
    }

    [DataMember]
    public string sddSlope_r
    {
      get { return this.sddSlope_rField; }
      set { this.sddSlope_rField = value; }
    }

    [DataMember]
    public string sddCokey
    {
      get { return this.sddCokeyField; }
      set { this.sddCokeyField = value; }
    }

    [DataMember]
    public string sddHydricrating
    {
      get { return this.sddHydricratingField; }
      set { this.sddHydricratingField = value; }
    }

    [DataMember]
    public string sddHydgrp
    {
      get { return this.sddHydgrpField; }
      set { this.sddHydgrpField = value; }
    }

    [DataMember]
    public string sddHzdept_r
    {
      get { return this.sddHzdept_rField; }
      set { this.sddHzdept_rField = value; }
    }

    [DataMember]
    public string sddHzdepb_r
    {
      get { return this.sddHzdepb_rField; }
      set { this.sddHzdepb_rField = value; }
    }

    [DataMember]
    public string sddChkey
    {
      get { return this.sddChkeyField; }
      set { this.sddChkeyField = value; }
    }

    [DataMember]
    public string sddSandtotal_r
    {
      get { return this.sddSandtotal_rField; }
      set { this.sddSandtotal_rField = value; }
    }

    [DataMember]
    public string sddSilttotal_r
    {
      get { return this.sddSilttotal_rField; }
      set { this.sddSilttotal_rField = value; }
    }

    [DataMember]
    public string sddClaytotal_r
    {
      get { return this.sddClaytotal_rField; }
      set { this.sddClaytotal_rField = value; }
    }

    [DataMember]
    public string sddOm_r
    {
      get { return this.sddOm_rField; }
      set { this.sddOm_rField = value; }
    }

    [DataMember]
    public string sddEcec_r
    {
      get { return this.sddEcec_rField; }
      set { this.sddEcec_rField = value; }
    }

    [DataMember]
    public string sddAwc_r
    {
      get { return this.sddAwc_rField; }
      set { this.sddAwc_rField = value; }
    }

    [DataMember]
    public string sddKffact
    {
      get { return this.sddKffactField; }
      set { this.sddKffactField = value; }
    }

    [DataMember]
    public string sddKwfact
    {
      get { return this.sddKwfactField; }
      set { this.sddKwfactField = value; }
    }

    [DataMember]
    public string sddTexdesc
    {
      get { return this.sddTexdescField; }
      set { this.sddTexdescField = value; }
    }

    [DataMember]
    public string sddTexture
    {
      get { return this.sddTextureField; }
      set { this.sddTextureField = value; }
    }

    [DataMember]
    public string sddStratextsflag
    {
      get { return this.sddStratextsflagField; }
      set { this.sddStratextsflagField = value; }
    }

    [DataMember]
    public string sddRvindicator
    {
      get { return this.sddRvindicatorField; }
      set { this.sddRvindicatorField = value; }
    }

    [DataMember]
    public string sddTexcl
    {
      get { return this.sddTexclField; }
      set { this.sddTexclField = value; }
    }

  }

  [DataContract]
  public partial class SoilAllData
  {
    private List<SoilComponentsData> saComponentsField;
    private List<SoilDetailsData> saDetailsField;

    [DataMember]
    public List<SoilComponentsData> saComponents
    {
      get { return this.saComponentsField; }
      set { this.saComponentsField = value; }
    }
    [DataMember]
    public List<SoilDetailsData> saDetails
    {
      get { return this.saDetailsField; }
      set { this.saDetailsField = value; }
    }
  }

}

