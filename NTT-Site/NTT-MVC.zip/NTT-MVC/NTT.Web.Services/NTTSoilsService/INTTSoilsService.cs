﻿//---------------------------------------------------
//Summary
//NTT Soils Service - NTTSoilsService.
//  Soils data retrieved from queries to: http://sdmdataaccess.nrcs.usda.gov/Tabular/SDMTabularService.asmx
//  Query #1: AOI bounding box coordinates used to return Map Unit Keys
//  Query #2: Map Unit IDs used to return dataset of soils details
//  Summary soils data returned for UI viewing/editing
//  Detail soils data written to XML for input to APEX run processing

//e.g. sBBoxCoordinates = "-123.504,45.38,-123.46,45.41"
//                         (East),(South),(West),(North)         
//                         (XMax),(YMin),(XMin),(YMax)         
//XMin e.g. -122.203 West
//XMax e.g. -121.956 East
//YMin e.g. 43.26 South
//YMax e.g. 43.43 North

//Debug test: F5 from NTTSoilsService.svc.cs page to use the WCF Test Client tool
//Debug start service: F5 from this page and click on the NTTSoilsService.svc link
//---------------------------------------------------
//Revision History
//Rev#  Date     Who   Change history
// 007  01/28/13 HAC   GetCMZ and GetCMZTest53 added;
//                      remove test code.
// 006  02/03/12 HAC   Get parameters from web.config;
//                      add processcommon and loghandler.
// 005  01/13/12 HAC   GetSDMSoilComponents minimum functionality added;
//                      only returns enough information for the Soils/Location tab;
//                      needs error checking and logging and saving details to XML for APEX.
// 004  01/12/12 HAC   GetSDMTestBBoxCoordinates accepts XMax,YMin,XMin,YMax
//                      and returns contents of <MapUnitKeyList>.
// 003  01/11/12 HAC   GetCompanyTest return an class object.
// 002  01/03/12 HAC   GetSDMTestRows returns a row count string of 9 rows found;
//                     GetSDMTestDSetXML returns a dataset as XML;
//                     GetSDMTestBBox returns a string of map unit keys using WebClient (not used);
//                     GetSDMTestBBoxHResponse returns xml of map unit keys using HttpWebRequest (better);
// 001  12/29/11 HAC   Initial C# version.
//---------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace NTTSoilsService
{
  // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService1" in both code and config file together.
  [ServiceContract]
  public interface ISoilComponentService
  {
    [OperationContract]
    List<SoilComponentsData> GetSDMSoilComponents(string sXMax, string sYMin, string sXMin, string sYMax);

    [OperationContract]
    List<SoilDetailsData> GetSDMSoilDetails(string sXMax, string sYMin, string sXMin, string sYMax);

    [OperationContract]
    SoilAllData GetSDMSoilsAll(string sXMax, string sYMin, string sXMin, string sYMax);

    [OperationContract]
    SoilAllData GetSDMSoilsAllCompPct(string sXMax, string sYMin, string sXMin, string sYMax, int nCompPct);

    #region Test Methods

    [OperationContract]
    List<SoilComponentsData> GetSDMTestSoilComponents();

    [OperationContract]
    List<SoilDetailsData> GetSDMTestSoilDetails();

    [OperationContract]
    SoilAllData GetSDMTestSoilsAll();

    [OperationContract]
    SoilAllData GetSDMTestSoilsAllCompPct();

    [OperationContract]
    string GetSDMTestRows();

    [OperationContract]
    string GetSDMTestDSetXML();

    [OperationContract]
    string GetSDMTestBBoxHttpResponse();

    [OperationContract]
    string GetSDMTestBBoxCoordinates(string sXMax,string sYMin,string sXMin,string sYMax);

    [OperationContract]
    string GetSDMTestBBoxRows();

    [OperationContract]
    string GetHello(string value);
    #endregion

  }
}
