//---------------------------------------------------
//Summary
//NTTManagementsService - Web service for APEX mapping.
//---------------------------------------------------
//Revision History
//Rev#  Date     Who   Change history
// 007  02/06/14 HAC   Debug and error logging changes.
// 006  03/04/13 HAC   Add AOpCode and AOpCodeDesc to MappedOperation.
// 005  02/14/13 HAC   Begin working with LMOD data.
// 004  04/12/12 HAC   Add SelectManagement and GetSelectManagementData.
// 003  04/09/12 HAC   Add LPaShowcount to mapped paths; add processing for GetMappedManagementData;
//                      add config file NTTMapManagementFile.
// 002  02/24/12 HAC   Add GetManagementsForSelection and GetOperationsInManagement.
// 001  02/22/12 HAC   Initial version;
//---------------------------------------------------

using System;
using System.Collections.Generic;
using System.Diagnostics; //for StackTrace
using System.IO;
using System.Linq;
using System.Net; //WebClient
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.ServiceModel;
using System.Text;
using System.ServiceModel.Activation;
using System.ServiceModel.Web; //added
using System.Web;
using System.Web.Configuration;
using System.Xml;
using System.Xml.Linq;

using NTT.Web.Services.Component;
using NTT.Web.Services.DBComponent;


namespace NTTManagementsService
{
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Required)]
    public class Managements : IManagements
    {
        private const string sCMZQuery = @"http://geoservices.sc.egov.usda.gov/wai/service.asmx/getGeoAttributeValues?lon=LLOONNGG&lat=LLAATT&attributes=CMZ ID&token=test";

        private const string sQueryTestCMZ = @"http://geoservices.sc.egov.usda.gov/wai/service.asmx/getGeoAttributeValues?lon=-122.662405&lat=45.341185&attributes=CMZ ID&token=test";  //return CMZ 53

        private const string sQueryTestLMODOps = @"http://oms-db2.engr.colostate.edu/rest_files/byroot/operations?format=json";  //return operations in json format

        private const string sQueryTestLMODOpsXML = @"http://oms-db2.engr.colostate.edu/rest_files/byroot/operations?format=xml";  //return operations in xml format

        private const string sQueryTestLMODMgmtsXML = @"http://oms-db2.engr.colostate.edu/rest_files/byroot/managements?format=json&cmz=01&limit=5000";  //return managements in xml format

        private static log4net.ILog _log;
        public static log4net.ILog log
        {
            get
            {
                if (_log == null)
                {
                    _log = log4net.LogManager.GetLogger("Error");
                }

                return _log;
            }
        }

        public string GetCMZ(string sLat, string sLong)
        {
            try
            {
                string moduleName = this.GetType().Name + "." + System.Reflection.MethodBase.GetCurrentMethod().Name;
                log.Info(moduleName + " <<Starting - GetCMZ>>");

                string sQuery = sCMZQuery.Replace("LLAATT", sLat);
                sQuery = sQuery.Replace("LLOONNGG", sLong);

                log.Debug("sQuery: " + sQuery.ToString());

                HttpWebRequest request = WebRequest.Create(sQuery) as HttpWebRequest;

                using (WebResponse response = request.GetResponse())
                {
                    StreamReader stmReader = new StreamReader(response.GetResponseStream());
                    string sTmp = stmReader.ReadToEnd();
                    stmReader.Close();

                    log.Info(moduleName + "<<Ending - GetCMZ>>");

                    return sTmp;
                }
            }
            catch (Exception ex)
            {
                log.Fatal(ex);
                return "Error: " + ex.Message.ToString();
            }
        }

        public List<LMODCmz> GetCmzData()
        {
            try
            {
                string moduleName = this.GetType().Name + "." + System.Reflection.MethodBase.GetCurrentMethod().Name;
                log.Info(moduleName + " <<Starting - GetCmzData>>");

                RusleSkelDBDataContext RSDBcontext = new RusleSkelDBDataContext();
                List<LMODCmz> lmCMZs = new List<LMODCmz>();
                var lmCmzs = (from lm in RSDBcontext.lookup_cmzs orderby lm.cmz_zone select lm);

                if (lmCmzs != null)
                {
                    foreach (var sCms in lmCmzs)
                    {
                        LMODCmz lCm = new LMODCmz();
                        lCm.LCmzId = sCms.cmz_id.ToString();
                        lCm.LCmzZone = sCms.cmz_zone;
                        lCm.LCmzEnabled = sCms.cmz_enabled.ToString();
                        lmCMZs.Add(lCm);
                    }
                }

                log.Info(moduleName + " <<Ending - GetCmzData>>");

                return lmCMZs;
            }
            catch (Exception ex)
            {
                log.Fatal(ex);
                return null;
            }
        }

        public List<LMODManagement> GetManagementsInPath(int nPathId)
        {
            try
            {
                string moduleName = this.GetType().Name + "." + System.Reflection.MethodBase.GetCurrentMethod().Name;
                log.Info(moduleName + "<<Starting - GetManagementsInPath>>");

                RusleSkelDBDataContext RSDBcontext = new RusleSkelDBDataContext();
                List<LMODManagement> lmManagements = new List<LMODManagement>();

                var lmMans = (from lm in RSDBcontext.lookup_managements
                              orderby lm.man_name
                              where lm.path_id == nPathId
                              select lm);
                if (lmMans != null)
                {
                    foreach (var sMas in lmMans)
                    {
                        LMODManagement lMa = new LMODManagement();
                        lMa.LManId = sMas.man_id.ToString();
                        lMa.LManName = sMas.man_name;
                        lMa.LManDuration = sMas.man_duration.ToString();
                        lMa.LManCmzId = sMas.cmz_id.ToString();
                        lMa.LManPathId = sMas.path_id.ToString();
                        lmManagements.Add(lMa);
                    }
                }

                log.Info(moduleName + "<<Ending - GetManagementsInPath>>");
                return lmManagements;
            }
            catch (Exception ex)
            {
                log.Fatal(ex);
                return null;
            }
        }

        public List<LMODManagementOperationDetail> GetOperationsDetailsInManagement(int nManId)
        {
            try
            {
                RusleSkelDBDataContext RSDBcontext = new RusleSkelDBDataContext();
                List<LMODManagementOperationDetail> lmOperationDetails = new List<LMODManagementOperationDetail>();

                log.Info("<<Starting - GetOperationsDetailsInManagement>>");

                //problem: this only selected one row that had a valid crop_id and oper_id
                //var lmOpers = (from mOp in RSDBcontext.lookup_managementoperations
                //               join oP in RSDBcontext.lookup_operations on mOp.oper_id equals oP.oper_id
                //               join cR in RSDBcontext.lookup_crops on mOp.crop_id equals cR.crop_id
                //               orderby mOp.manop_date
                //               where mOp.man_id == nManId
                //               select new { mOp.manop_id, mOp.man_id, mOp.oper_id, mOp.crop_id, oP.oper_name, cR.crop_name }).ToList();
                //               //select new {mOp.manop_id, mOp.man_id, mOp.oper_id, mOp.crop_id, oP.oper_name, cR.crop_name });

                //if (lmOpers != null)
                //{
                //  foreach (var sMas in lmOpers)
                //  {
                //    LMODManagementOperationDetail lMaOp = new LMODManagementOperationDetail();
                //    lMaOp.LManOpId = sMas.manop_id.ToString();
                //    lMaOp.LManOpManId = sMas.man_id.ToString();
                //    lMaOp.LManOpOperId = sMas.oper_id.ToString();
                //    lMaOp.LManOpCropId = sMas.crop_id.ToString();
                //    lMaOp.LManOpOper = sMas.oper_name.ToString();
                //    lMaOp.LManOpCrop = sMas.crop_name.ToString();
                //    lmOperationDetails.Add(lMaOp);
                //  }
                //}

                var lmOps = (from mOp in RSDBcontext.lookup_managementoperations
                                orderby mOp.manop_date
                                where mOp.man_id == nManId
                                select mOp).ToList();

                if (lmOps != null)
                {
                    foreach (var lmO in lmOps)
                    {
                        LMODManagementOperationDetail lMaOp = new LMODManagementOperationDetail();
                        lMaOp.LManOpId = lmO.manop_id;
                        lMaOp.LManOpManId = lmO.man_id;
                        lMaOp.LManOpOperId = lmO.oper_id;
                        lMaOp.LManOpCropId = lmO.crop_id;
                        lMaOp.LManOpDate = lmO.manop_date;
                        //get operation name
                        var oOp = (from oP in RSDBcontext.lookup_operations
                                            where lMaOp.LManOpOperId == oP.oper_id
                                            select oP).Take(1).SingleOrDefault();
                        lMaOp.LManOpOper = oOp.oper_name;
                        //get crop name
                        if (lMaOp.LManOpCropId != null)
                        {
                            if (lMaOp.LManOpCropId > 0)
                            {
                            var cCr = (from cR in RSDBcontext.lookup_crops
                                                where lMaOp.LManOpCropId == cR.crop_id
                                                select cR).Take(1).SingleOrDefault();
                            lMaOp.LManOpCrop = cCr.crop_name;
                            }
                        }
                        lmOperationDetails.Add(lMaOp);
                    }
                }
                string moduleName = this.GetType().Name + "." + System.Reflection.MethodBase.GetCurrentMethod().Name;
                log.Info(moduleName + " <<Ending - GetOperationsDetailsInManagement>>");
                return lmOperationDetails;
            }
            catch (Exception ex)
            {
                log.Fatal(ex);
                return null;
            }
            
        }

        public List<LMODCmz> GetManagements4Selection(int nCmzId) //Todo: change to return correct list type
        {
            try
            {
                string moduleName = this.GetType().Name + "." + System.Reflection.MethodBase.GetCurrentMethod().Name;
                log.Info(moduleName + "<<Starting - GetManagements4Selection>>");

                List<MappedPath> mpPaths = getMappedPaths(nCmzId);
                List<string> mpIDs = (from mp in mpPaths select mp.LPaId).ToList();
                RusleSkelDBDataContext RSDBcontext = new RusleSkelDBDataContext();
                var lmMan = (from lm in RSDBcontext.lookup_managements
                             where (mpIDs.Contains(lm.path_id.ToString()))
                             select lm).ToList();

                log.Debug(moduleName + " lmMan count: " + lmMan.Count().ToString());

                //Todo: change to look for only 'mapped' crop and oper ids

                //foreach (var lM in lmMan)
                //{
                //  var vMan = from mOp in RSDBcontext.lookup_managementoperations
                //             join oP in RSDBcontext.lookup_operations on mOp.oper_id equals oP.oper_id
                //             join cR in RSDBcontext.lookup_crops on mOp.crop_id equals cR.crop_id
                //             where (mOp.man_id == lM.man_id)
                //             select new { mOp.man_id, mOp.oper_id, mOp.crop_id, oPID = oP.oper_id, cRID = cR.crop_id };

                //  foreach (var vM in vMan)
                //  {
                //    LogHandler.WriteToDebugFile(moduleName + string.Format(" mOp.man_id={0}, mOp.oper_id={1}, mOp.crop_id{2}, oPID={3}, cRID={4}{5}", vM.man_id.ToString(), vM.oper_id.ToString(), vM.crop_id.ToString(), vM.oPID.ToString(), vM.cRID.ToString(), Environment.NewLine), 4, 4);
                //  }
                //string sTmp = "";

                //}

                log.Debug(moduleName + "<<Ending - GetManagements4Selection>>");
                return null;
            }
            catch (Exception ex)
            {
                log.Debug(ex);
                return null;
            }
        }

        public List<MappedOperation> GetMappedOperationData()
        {
            try
            {
                ProcessCommon.GetAppSettings();
                string moduleName = System.Reflection.MethodBase.GetCurrentMethod().Name;
                log.Info(moduleName + "<<Starting - GetMappedOperationData>>");

                List<APEXCodesInfo> lstCodes = getTillCodes();

                //string dataPath = HttpContext.Current.Server.MapPath("APEXData");
                string dataPath = ProcessCommon.NTTMapFileLocation;
                if (Directory.Exists(dataPath) == false)
                    throw new ArgumentException("Missing dataPath location: " + dataPath.ToString());
                else
                {
                    List<MappedOperation> returnVals = new List<MappedOperation>();
                    string sFile = string.Format("{0}\\{1}", dataPath, ProcessCommon.NTTMapTillageFile);

                    if (File.Exists(sFile))
                    {
                        using (FileStream fs = new FileStream(sFile, FileMode.Open, FileAccess.Read))
                        {
                            DataContractJsonSerializer noteSer = new DataContractJsonSerializer(typeof(List<MappedOperation>));
                            returnVals = noteSer.ReadObject(fs) as List<MappedOperation>;
                            fs.Close();
                        }

                        //get operation code description - each time for abbrev name
                        foreach (MappedOperation mOper in returnVals)
                        {
                            //if (mOper.AOpCodeDesc == null || mOper.AOpCodeDesc.Length == 0)
                            //{            
                            var aoCode = (from ac in lstCodes where ac.acoCode == mOper.AOpCode select ac).Take(1).SingleOrDefault();
                            if (aoCode != null) mOper.AOpCodeDesc = aoCode.acoNameAbbrev;
                            //  }
                        }

                        log.Debug("GetMappedOperationData returnVals: " + returnVals.Count.ToString());
                        log.Info(moduleName + "<<Ending - GetMappedOperationData>>");

                        return returnVals;
                    }
                    else
                    {
                        throw new ArgumentException("Missing mapped.operations file " + sFile.ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                log.Fatal(ex);
                return null;
            }
        }

        public List<MappedCrop> GetMappedCropData()
        {
            try
            {
                string moduleName = System.Reflection.MethodBase.GetCurrentMethod().Name;
                log.Info(moduleName + "<<Starting - GetMappedCropData>>");

                //string dataPath = HttpContext.Current.Server.MapPath("APEXData");
                string dataPath = ProcessCommon.NTTMapFileLocation;
                if (Directory.Exists(dataPath) == false)
                    throw new ArgumentException("Missing dataPath location: " + dataPath.ToString());
                else
                {
                    List<MappedCrop> returnVals = new List<MappedCrop>();
                    string sFile = string.Format("{0}\\{1}", dataPath, ProcessCommon.NTTMapCropFile);

                    if (File.Exists(sFile))
                    {
                        using (FileStream fs = new FileStream(sFile, FileMode.Open, FileAccess.Read))
                        {
                            DataContractJsonSerializer noteSer = new DataContractJsonSerializer(typeof(List<MappedCrop>));
                            returnVals = noteSer.ReadObject(fs) as List<MappedCrop>;
                            fs.Close();
                        }

                        log.Debug("GetMappedCropData returnVals: " + returnVals.Count.ToString());

                        log.Info(moduleName + "<<Ending - GetMappedCropData>>");
                        return returnVals;
                    }
                    else
                    {
                        throw new ArgumentException("Missing mapped.crops file " + sFile.ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                log.Fatal(ex);
                return null;
            }
        }

        public List<MappedPath> GetMappedPathData(int cmzId)
        {
            try
            {
                string moduleName = System.Reflection.MethodBase.GetCurrentMethod().Name;
                log.Info(moduleName + "<<Starting - moduleName>> cmzId=" + cmzId );
                log.Info(moduleName + "<<Ending - GetMappedPathData>>");

                return getMappedPaths(cmzId);
            }
            catch (Exception ex)
            {
                StackTrace sTrace = new StackTrace();
                log.Fatal(ex);

                return null;
            }
        }

        private List<MappedPath> getMappedPaths(int nCmzId)
        {
            try
            {
                string moduleName = this.GetType().Name + "." + System.Reflection.MethodBase.GetCurrentMethod().Name;
                log.Info(moduleName + "<<Starting - getMappedPaths>>");

                ProcessCommon.GetAppSettings(); 
                string dataPath = ProcessCommon.NTTMapFileLocation;
                if (Directory.Exists(dataPath) == false)
                    throw new ArgumentException("Missing dataPath location: " + dataPath.ToString());
                else
                {
                    List<MappedPath> returnVals = new List<MappedPath>();
                    string sFile = string.Format("{0}\\{1}{2}", dataPath, nCmzId.ToString(), ProcessCommon.NTTMapPathFile);

                    if (File.Exists(sFile))
                    {
                        using (FileStream fs = new FileStream(sFile, FileMode.Open, FileAccess.Read))
                        {
                            DataContractJsonSerializer noteSer = new DataContractJsonSerializer(typeof(List<MappedPath>));
                            returnVals = noteSer.ReadObject(fs) as List<MappedPath>;
                            fs.Close();
                        }

                        log.Debug("GetMappedPathData returnVals: " + returnVals.Count.ToString());

                        log.Info(moduleName + "<<Ending - getMappedPaths>>");
                        return returnVals;
                    }
                    else
                    {
                        throw new ArgumentException("Missing mapped.paths file " + sFile.ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                log.Fatal(ex);

                return null;
            }
        }

        public List<MappedManagement> GetMappedManagementData(int nCmzId)
        {
            try
            {
                string moduleName = this.GetType().Name + "." + System.Reflection.MethodBase.GetCurrentMethod().Name;
                log.Info(moduleName + "<<Starting - GetMappedManagementData>>");
                
                ProcessCommon.GetAppSettings(); 
                //string dataPath = HttpContext.Current.Server.MapPath("APEXData");
                string dataPath = ProcessCommon.NTTMapFileLocation;
                if (Directory.Exists(dataPath) == false)
                    throw new ArgumentException("Missing dataPath location: " + dataPath.ToString());
                else
                {
                    List<MappedManagement> returnVals = new List<MappedManagement>();
                    string sFile = string.Format("{0}\\{1}{2}", dataPath, nCmzId.ToString(), ProcessCommon.NTTMapManagementFile);

                    if (File.Exists(sFile))
                    {
                        using (FileStream fs = new FileStream(sFile, FileMode.Open, FileAccess.Read))
                        {
                            DataContractJsonSerializer noteSer = new DataContractJsonSerializer(typeof(List<MappedManagement>));
                            returnVals = noteSer.ReadObject(fs) as List<MappedManagement>;
                            fs.Close();
                        }

                        log.Debug("GetMappedManagementData returnVals: " + returnVals.Count.ToString());

                        log.Info(moduleName + "<<Ending - GetMappedManagementData>>");
                        return returnVals;
                    }
                    else
                    {
                        throw new ArgumentException("Missing mapped.managements file " + sFile.ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                log.Fatal(ex);

                return null;
            }
        }

        public List<SelectManagement> GetSelectManagementData(int nCmzId)
        {
            StringBuilder sbCropNames = new StringBuilder();
            int nCropCnt = 0;
            string sCropSamename = "";

            string sTmp = "";
            int nInteger;
            bool isInteger;
            try
            {
                string moduleName = this.GetType().Name + "." + System.Reflection.MethodBase.GetCurrentMethod().Name;
                log.Info(moduleName + "<<Starting - GetSelectManagementData>>");

                ProcessCommon.GetAppSettings(); 
                //string dataPath = HttpContext.Current.Server.MapPath("APEXData");
                string dataPath = ProcessCommon.NTTMapFileLocation;
                if (Directory.Exists(dataPath) == false)
                    throw new ArgumentException("Missing dataPath location: " + dataPath.ToString());
                else
                {
                    List<SelectManagement> returnVals = new List<SelectManagement>();
                    List<MappedManagement> returnMMgts = new List<MappedManagement>();
                    string sFile = string.Format("{0}\\{1}{2}", dataPath, nCmzId.ToString(), ProcessCommon.NTTMapManagementFile);

                    if (File.Exists(sFile))
                    {
                        using (FileStream fs = new FileStream(sFile, FileMode.Open, FileAccess.Read))
                        {
                            DataContractJsonSerializer noteSer = new DataContractJsonSerializer(typeof(List<MappedManagement>));
                            returnMMgts = noteSer.ReadObject(fs) as List<MappedManagement>;
                            fs.Close();
                        }

                        log.Debug("GetSelectManagementData returnMMgts: " + returnMMgts.Count.ToString());

                        RusleSkelDBDataContext RSDBcontext = new RusleSkelDBDataContext();

                        foreach (MappedManagement mMgt in returnMMgts)
                        {
                            var lmOps = (from mOp in RSDBcontext.lookup_managementoperations
                                         orderby mOp.manop_date
                                         where mOp.man_id == (Convert.ToInt32(mMgt.LManId))
                                         select mOp).ToList();

                            if (lmOps != null)
                            {
                                List<LMODManagementOperationDetail> lmOperationDetails = new List<LMODManagementOperationDetail>();
                                sbCropNames.Remove(0, sbCropNames.Length);
                                nCropCnt = 0;
                                sCropSamename = "";

                                foreach (var lmO in lmOps)
                                {
                                    LMODManagementOperationDetail lMaOp = new LMODManagementOperationDetail();
                                    lMaOp.LManOpId = lmO.manop_id;
                                    lMaOp.LManOpManId = lmO.man_id;
                                    lMaOp.LManOpOperId = lmO.oper_id;
                                    lMaOp.LManOpCropId = lmO.crop_id;
                                    lMaOp.LManOpDate = lmO.manop_date;
                                    //get operation name
                                    var oOp = (from oP in RSDBcontext.lookup_operations
                                               where lMaOp.LManOpOperId == oP.oper_id
                                               select oP).Take(1).SingleOrDefault();
                                    lMaOp.LManOpOper = oOp.oper_name;
                                    //get crop name
                                    if (lMaOp.LManOpCropId != null)
                                    {
                                        if (lMaOp.LManOpCropId > 0)
                                        {
                                            var cCr = (from cR in RSDBcontext.lookup_crops
                                                       where lMaOp.LManOpCropId == cR.crop_id
                                                       select cR).Take(1).SingleOrDefault();
                                            if (sCropSamename != cCr.crop_name)
                                            {
                                                nCropCnt += 1;
                                                lMaOp.LManOpCrop = cCr.crop_name;
                                                sbCropNames.Append(cCr.crop_name + ",");
                                            }
                                        }
                                    }

                                    lmOperationDetails.Add(lMaOp);
                                }
                            }

                            SelectManagement sMgt = new SelectManagement();
                            sMgt.SManId = mMgt.LManId;
                            sMgt.SManName = mMgt.LManName;
                            sMgt.SManDuration = mMgt.LManDuration;
                            sMgt.SManPathId = mMgt.LManPathId;
                            sMgt.SManCmzId = mMgt.LManCmzId;
                            sMgt.SManCropsNames = sbCropNames.ToString();
                            sMgt.SManCropsNames = sMgt.SManCropsNames.EndsWith(",") ? sMgt.SManCropsNames.Substring(0, sMgt.SManCropsNames.Length - 1) : sMgt.SManCropsNames;
                            sMgt.SManCropsNbr = nCropCnt;

                            sTmp = ""; sTmp = mMgt.LManDuration;
                            ProcessCommon.TestInteger(sTmp, out isInteger, out nInteger);
                            sMgt.SManYears = isInteger == true ? nInteger : 1;
                            sMgt.SManCropsDesc = "Start: xxx End: xxx";
                            returnVals.Add(sMgt);
                        }

                        log.Info(moduleName + "<<Ending - GetSelectManagementData>>");
                        return returnVals;
                    }
                    else
                    {
                        throw new ArgumentException("Missing mapped.managements file " + sFile.ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                log.Fatal(ex);

                return null;
            }
        }

        public List<APEXOperationCode> GetTillageCodesData()
        {
            try
            {
                string moduleName = this.GetType().Name + "." + System.Reflection.MethodBase.GetCurrentMethod().Name;
                log.Info(moduleName + "<<Starting - GetTillageCodesData>>");

                List<APEXCodesInfo> lstCodes = getTillCodes();

                List<APEXOperationCode> returnVals = new List<APEXOperationCode>();
                foreach (APEXCodesInfo lC in lstCodes)
                {
                    APEXOperationCode aC = new APEXOperationCode();
                    aC.AOCId = lC.acoId;
                    aC.AOCCode = lC.acoCode;
                    aC.AOCName = lC.acoNameAbbrev;
                    aC.AOCNameAbbrev = lC.acoNameAbbrev;
                    aC.AOCActive = lC.acoActive;
                    returnVals.Add(aC);
                }

                log.Info(moduleName + "<<Ending - GetTillageCodesData>>");
                return returnVals;
            }
            catch (Exception ex)
            {
                log.Info(ex);

                return null;
            }
        }

        #region LMOD Methods
        #endregion

        #region Test Methods
        public string GetCMZTest53()
        {
            string stest = "";
            try
            {
                string moduleName = this.GetType().Name + "." + System.Reflection.MethodBase.GetCurrentMethod().Name;
                log.Info(moduleName + "<<Starting - GetCMZTest53>>");

                HttpWebRequest request = WebRequest.Create(sQueryTestCMZ) as HttpWebRequest;
                using (WebResponse response = request.GetResponse())
                {
                    StreamReader stmReader = new StreamReader(response.GetResponseStream());
                    stest = stmReader.ReadToEnd();
                    stmReader.Close();
                }

                log.Info(moduleName + "<<Ending - GetCMZTest53>>");

                return stest;

                //cannot return a value using async event - alreay exits before event
                //WebClient wc = new WebClient();
                //wc.DownloadStringCompleted += new DownloadStringCompletedEventHandler(
                //  delegate(object sender1, DownloadStringCompletedEventArgs e1)
                //  {
                //    try
                //    {
                //      if (e1.Error == null)
                //      {
                //        stest = e1.Result.ToString();
                //      }
                //    }
                //    catch (Exception Ex)
                //    { stest = "Error: " + Ex.Message.ToString(); }
                //  });
                //wc.DownloadStringAsync(new Uri(sQueryTestCMZ));
            }
            catch (Exception Ex)
            {
                stest = "Error: " + Ex.Message.ToString();
                return stest;
            }
        }

        public string TestGetLMODOperations()
        {
            try
            {
                string moduleName = this.GetType().Name + "." + System.Reflection.MethodBase.GetCurrentMethod().Name;
                log.Info(moduleName + "<<Starting - TestGetLMODOperations>>");

                //string sQuery = sQueryTestLMODOps;
                string sQuery = sQueryTestLMODOpsXML;
                HttpWebRequest request = WebRequest.Create(sQuery) as HttpWebRequest;

                using (WebResponse response = request.GetResponse())
                {
                    StreamReader stmReader = new StreamReader(response.GetResponseStream());
                    string sTmp = stmReader.ReadToEnd();
                    stmReader.Close();

                    //format content to work with xml parse
                    //remove dtd
                    //remove <metadata ...>
                    //remove <files ...>
                    //remove all '\' characters
                    //keep <lmod_file ...>
                    StringBuilder sbTmp = new StringBuilder();
                    sbTmp.Append("<?xml version=\"1.0\" standalone=\"yes\"?><lmod_set>");
                    int nLocStart = sTmp.IndexOf("<lmod_file");
                    int nLocEnd = sTmp.IndexOf("</files>");
                    int nLocLength = 0;
                    if (nLocStart > 0 && nLocEnd > 0 && nLocStart < nLocEnd)
                    {
                        nLocLength = (sTmp.Length - nLocStart) - (sTmp.Length - nLocEnd);
                        sbTmp.Append(sTmp.Substring(nLocStart, nLocLength));
                        sbTmp.Append("</lmod_set>");
                        XDocument doc = new XDocument();
                        //doc = XDocument.Parse(sTmp.ToString());
                        sbTmp.Replace(@"\", "");
                        doc = XDocument.Parse(sbTmp.ToString());
                        sTmp = "";
                    }
                    else
                    {
                        throw new ArgumentException("Invalid XML format: " + sQuery.ToString());
                    }

                    log.Info(moduleName + "<<Ending - TestGetLMODOperations>>");
                    return sTmp;
                }
            }
            catch (Exception ex)
            {
                log.Fatal(ex);
                return null;
            }
        }

        public string TestGetLMODFromFileOperations()
        {
            string sTmp = "";
            try
            {
                string moduleName = this.GetType().Name + "." + System.Reflection.MethodBase.GetCurrentMethod().Name;
                log.Info(moduleName + "<<Starting - TestGetLMODFromFileOperations>>");

                string dataPath = ProcessCommon.NTTMapFileLocation;
                if (Directory.Exists(dataPath) == false)
                    throw new ArgumentException("Missing dataPath location: " + dataPath.ToString());
                else
                {
                    //string sFile = string.Format("{0}\\{1}", dataPath, "seeLMODOpsXMLFormat.xml"); //edited file that works with parse
                    string sFile = string.Format("{0}\\{1}", dataPath, "LMODOpsXMLFormat.xml"); //saved from query to a file for testing

                    if (File.Exists(sFile))
                    {
                        StreamReader stmReader = new StreamReader(File.Open(sFile, FileMode.Open));
                        sTmp = stmReader.ReadToEnd();
                        stmReader.Close();

                        //format content to work with xml parse
                        //remove dtd
                        //remove <metadata ...>
                        //remove <files ...>
                        //remove all '\' characters
                        //keep <lmod_file ...>
                        StringBuilder sbTmp = new StringBuilder();
                        sbTmp.Append("<?xml version=\"1.0\" standalone=\"yes\"?><lmod_set>");
                        int nLocStart = sTmp.IndexOf("<lmod_file");
                        int nLocEnd = sTmp.IndexOf("</files>");
                        int nLocLength = 0;
                        if (nLocStart > 0 && nLocEnd > 0 && nLocStart < nLocEnd)
                        {
                            nLocLength = (sTmp.Length - nLocStart) - (sTmp.Length - nLocEnd);
                            sbTmp.Append(sTmp.Substring(nLocStart, nLocLength));
                            sbTmp.Append("</lmod_set>");
                            XDocument doc = new XDocument();
                            //doc = XDocument.Parse(sTmp.ToString());
                            sbTmp.Replace(@"\", "");
                            doc = XDocument.Parse(sbTmp.ToString());
                            sTmp = "";
                        }
                        else
                        {
                            throw new ArgumentException("Invalid XML format: " + sFile.ToString());
                        }
                    }
                }

                log.Info(moduleName + "<<Ending - TestGetLMODFromFileOperations>>");
                return sTmp;
            }
            catch (Exception ex)
            {
                log.Fatal(ex);
                return null;
            }
        }

        public string TestGetLMODManagements()
        {
            try
            {
                //getAppSettings();
                string moduleName = this.GetType().Name + "." + System.Reflection.MethodBase.GetCurrentMethod().Name;
                log.Info(moduleName + "<<Starting - TestGetLMODManagements>>");

                //string sQuery = sQueryTestLMODOps;

                const string sQueryTestLMODOps = @"http://quote.yahoo.com/d/quotes.csv?s=YHOO+GOOG+GE+MSFT&f=nl1vkj";  //return csv format

                //string sQuery = sQueryTestLMODMgmtsXML;

                string sQuery = sQueryTestLMODOps;


                HttpWebRequest request = WebRequest.Create(sQuery) as HttpWebRequest;

                using (WebResponse response = request.GetResponse())
                {
                    StreamReader stmReader = new StreamReader(response.GetResponseStream());
                    string sTmp = stmReader.ReadToEnd();
                    stmReader.Close();

                    //format content to work with xml parse
                    //remove dtd
                    //remove <metadata ...>
                    //remove <files ...>
                    //remove all '\' characters
                    //keep <lmod_file ...>
                    StringBuilder sbTmp = new StringBuilder();
                    sbTmp.Append("<?xml version=\"1.0\" standalone=\"yes\"?><lmod_set>");
                    int nLocStart = sTmp.IndexOf("<lmod_file");
                    int nLocEnd = sTmp.IndexOf("</files>");
                    int nLocLength = 0;
                    if (nLocStart > 0 && nLocEnd > 0 && nLocStart < nLocEnd)
                    {
                        nLocLength = (sTmp.Length - nLocStart) - (sTmp.Length - nLocEnd);
                        sbTmp.Append(sTmp.Substring(nLocStart, nLocLength));
                        sbTmp.Append("</lmod_set>");
                        XDocument doc = new XDocument();
                        //doc = XDocument.Parse(sTmp.ToString());
                        sbTmp.Replace(@"\", "");
                        doc = XDocument.Parse(sbTmp.ToString());
                        sTmp = "";
                    }
                    else
                    {
                        throw new ArgumentException("Invalid XML format: " + sQuery.ToString());
                    }

                    log.Info(moduleName + "<<Ending - TestGetLMODManagements>>");
                    return sTmp;
                }
            }
            catch (Exception ex)
            {
                log.Fatal(ex);
                return null;
            }
        }

        public string TestGetLMODFromFileManagements()
        {
            string sTmp = "";
            try
            {
                string moduleName = this.GetType().Name + "." + System.Reflection.MethodBase.GetCurrentMethod().Name;
                log.Info(moduleName + "<<Starting - TestGetLMODFromFileManagements>>");

                string dataPath = ProcessCommon.NTTMapFileLocation;
                if (Directory.Exists(dataPath) == false)
                    throw new ArgumentException("Missing dataPath location: " + dataPath.ToString());
                else
                {
                    string sFile = string.Format("{0}\\{1}", dataPath, "seeManagementsCmz01XMLLimit5000.xml"); //edited file that works with parse
                    //string sFile = string.Format("{0}\\{1}", dataPath, "LMODMgmtsCmz01XMLLimit5000.xml"); //saved from query to a file for testing

                    if (File.Exists(sFile))
                    {
                        StreamReader stmReader = new StreamReader(File.Open(sFile, FileMode.Open));
                        sTmp = stmReader.ReadToEnd();
                        stmReader.Close();

                        //format content to work with xml parse
                        //remove dtd
                        //remove <metadata ...>
                        //remove <files ...>
                        //remove all '\' characters
                        //keep <lmod_file ...>

                        //StringBuilder sbTmp = new StringBuilder();
                        //sbTmp.Append("<?xml version=\"1.0\" standalone=\"yes\"?><lmod_set>");
                        //int nLocStart = sTmp.IndexOf("<lmod_file");
                        //int nLocEnd = sTmp.IndexOf("</files>");
                        //int nLocLength = 0;
                        //if (nLocStart > 0 && nLocEnd > 0 && nLocStart < nLocEnd)
                        //{
                        //  nLocLength = (sTmp.Length - nLocStart) - (sTmp.Length - nLocEnd);
                        //  sbTmp.Append(sTmp.Substring(nLocStart, nLocLength));
                        //  sbTmp.Append("</lmod_set>");

                        XDocument doc = new XDocument();
                        doc = XDocument.Parse(sTmp.ToString());

                        //sbTmp.Replace(@"\", "");
                        //  doc = XDocument.Parse(sbTmp.ToString());
                        sTmp = "";
                        //}
                        //else
                        //{ throw new ArgumentException("Invalid XML format: " + sFile.ToString()); }
                    }
                }

                log.Info(moduleName + "<<Ending - TestGetLMODFromFileManagements>>");
                return sTmp;
            }
            catch (Exception ex)
            {
                log.Fatal(ex);
                return null;
            }
        }

        #endregion

        private List<APEXCodesInfo> getTillCodes()
        {
            string sRtn = "";
            XDocument doc = null;
            try
            {
                string moduleName = this.GetType().Name + "." + System.Reflection.MethodBase.GetCurrentMethod().Name;
                log.Info(moduleName + "<<Starting - getTillCodes>>");

                ProcessCommon.GetAppSettings(); 
                string dataPath = ProcessCommon.NTTMapFileLocation;
                if (Directory.Exists(dataPath) == false)
                    throw new ArgumentException("Missing dataPath location: " + dataPath.ToString());
                else
                {
                    List<APEXOperationCode> returnVals = new List<APEXOperationCode>();
                    string sFile = string.Format("{0}\\{1}", dataPath, ProcessCommon.ApexOpCodesFile);

                    if (File.Exists(sFile))
                    {
                        StreamReader sr = new StreamReader(sFile, false);
                        sr.BaseStream.Seek(0, SeekOrigin.Begin);
                        sRtn = sr.ReadToEnd();
                        sr.Close();

                        doc = new XDocument();
                        doc = XDocument.Parse(sRtn.ToString());
                    }

                    var CodeInfos = (from c in doc.Descendants("AOCData")
                                    select new APEXCodesInfo(c.Element("AOCId").Value, c.Element("AOCCode").Value, c.Element("AOCName").Value, c.Element("AOCNameAbbrev").Value, c.Element("AOCActive").Value));

                    if (CodeInfos == null) { return null; }

                    var SortedList = CodeInfos.OrderBy(r => r.acoNameAbbrev).ToList();

                    log.Info(moduleName + "<<Ending - getTillCodes>>");
                    return SortedList;
                }
            }
            catch (Exception ex)
            {
                log.Fatal(ex);
                return null;
            }
        }

        private string chk4FilePresent(string sPathName, string sFileName)
        {
            string sReturn = "OK";
            string sFile = "";
            try
            {
                string moduleName = this.GetType().Name + "." + System.Reflection.MethodBase.GetCurrentMethod().Name;
                log.Info(moduleName + "<<Starting - chk4FilePresent>>");

                sFile = ProcessCommon.SafeBSlashPathEndString(sPathName) + sFileName.ToString();
                if (!File.Exists(sFile))
                {
                    log.Error(moduleName + "Error: Not found: " + sFile.ToString());
                    sReturn = "Error: Not found: " + sFile.ToString();
                }

                log.Info(moduleName + "<<Ending - chk4FilePresent>>");
            }
            catch (Exception ex)
            {
                log.Fatal(ex);
                sReturn = "Error: " + ex.ToString();
            }

            return sReturn;
        }
    }

    public class APEXCodesInfo
    {
        public string acoId;
        public string acoCode;
        public string acoName;
        public string acoNameAbbrev;
        public string acoActive;

        public APEXCodesInfo(string sacoId, string sacoCode, string sacoName, string sacoNameAbbrev, string sacoActive)
        {
            acoId = sacoId;
            acoCode = sacoCode;
            acoName = sacoName;
            acoNameAbbrev = sacoNameAbbrev;
            acoActive = sacoActive;
        }
    }
}   
