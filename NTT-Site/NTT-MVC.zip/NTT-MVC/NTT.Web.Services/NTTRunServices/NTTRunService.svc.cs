﻿//---------------------------------------------------
//Summary
//NTTRunServices - Web service for APEX Run data and processing.
//---------------------------------------------------
//Revision History
//Rev#  Date     Who   Change history
// 006  02/06/14 HAC   Allow both service and client debugging and logging.
// 005  01/28/14 HAC   Add dynamic end point addresses for soils and managements.
// 004  10/23/13 HAC   Add GetClimateReady processing.
// 003  10/09/13 HAC   Begin including prior AOI run services for APEX processing.
// 002  09/23/13 HAC   Return soil components data in SaveSoilsData.
// 001  08/29/13 HAC   Converted from ASMX service to WCF service.
//---------------------------------------------------
//
//Test Methods
//  TestGetClimateData
//    Static lat/long and from/to dates
//    External test file: aaaaabbbbbcccccc.dat contains JSON test data
//    Finds, opens and verifies file contents
//    Returns 'OK'
//  TestSaveClimateData
//    Static lat/long and from/to dates
//    External test file: aaaaabbbbbcccccc.dat created containing JSON test data
//    Verifies lat/long and from/to dates
//    Calls 'GetClimateHCE' web service to get JSON climate data
//    Verifies valid returned climate data
//    Creates 'ClimateFileInfo' dataset
//    Creates test file containing 'ClimateFileData' (2 datasets) in JSON format
//      Dataset 1: ClimateFileInfo
//      Dataset 2: ScData
//    Returns 'OK'
//

using System;
using System.Collections.Generic;
using System.Diagnostics; //for StackTrace
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.ServiceModel.Web;
using System.Text;
using System.Web;
using System.Web.Configuration;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Serialization;

using NTTRunServices.LogHandlr;
using NTTRunServices.ProcessComn;
using NTTRunServices.NTTManagementsServiceReference;
using NTTRunServices.NTTSoilsServiceReference;

namespace NTTRunServices
{
  // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "NTTRunService" in code, svc and config file together.
  // NOTE: In order to launch WCF Test Client for testing this service, please select NTTRunService.svc or NTTRunService.svc.cs at the Solution Explorer and start debugging.
  public class NTTRunService : INTTRunService
  {
    private static string sMeName = "NTTRunService";
    private System.Collections.Specialized.NameValueCollection configurationAppSettings = System.Configuration.ConfigurationManager.AppSettings;
    private static log4net.ILog _log;
    public static log4net.ILog log
    {
        get
        {
            if (_log == null)
            {
                _log = log4net.LogManager.GetLogger("ApplicationLogDBAppender");
            }

            return _log;
        }
    }

    //private List<SoilComponentsData> lstSCData = new List<SoilComponentsData>();
    //private RunNttFileData rnfData = new RunNttFileData();
    //private List<APEXNttData> lstNttData = new List<APEXNttData>();

    private List<AOISoilCompNames> lstSoilComponents = new List<AOISoilCompNames>();
    private List<AOISoilLayers> lstSoillayrs = new List<AOISoilLayers>();

    public string SaveClimateData(string sGUID, string sLat, string sLong, string sDateFrom, string sDateTo)
    {
      // sGUID file name to be saved
      string sRtn = "OK";
      string sValidDays = "";
      string sTmp = "";
      string sFile = "";

      DateTime dtDateFrom = new DateTime(1900, 1, 1);
      DateTime dtDateTo = new DateTime(1900, 1, 1);
      bool bLatError = false;
      bool bLongError = false;
      bool bDateFromError = false;
      bool bDateToError = false;

      double nLat = 0;
      double nLong = 0;
      double nLatOffset = 0;
      double nLongOffset = 0;
      int nLatOffsetInt = 0;
      int nLongOffsetInt = 0;
      int nRowint = 0;

      int dtDays = 0;

      double nDouble;
      bool isDouble;
      DateTime dtDate;
      bool isDate;

      //List<ScData> lstSData = new List<ScData>();
      try
      {
        getAppSettings();
        log.Info(sMeName + "<<Starting - SaveClimateData>>");

        //check for valid
        if (sGUID.Length < 1) return "Error: Missing GUID value.";

        //check for valid
        // check lat (north/south)        
        if (sLat.Length == 0) bLatError = true;
        if (sLong.Length == 0) bLongError = true;
        if (sDateFrom.Length == 0) bDateFromError = true;
        if (sDateTo.Length == 0) bDateToError = true;
        if (bLatError == true || bLongError == true || bDateFromError == true || bDateToError == true) return "Error: Invalid parameter values.";

        sTmp = ""; sTmp = sDateFrom;
        ProcessCommon.TestDate(sTmp, out isDate, out dtDate);
        if (isDate) { dtDateFrom = dtDate; } else { bDateFromError = true; }
        sTmp = ""; sTmp = sDateTo;
        ProcessCommon.TestDate(sTmp, out isDate, out dtDate);
        if (isDate) { dtDateTo = dtDate; } else { bDateToError = true; }

        sTmp = ""; sTmp = sLat;
        ProcessCommon.TestDouble(sTmp, out isDouble, out nDouble);
        if (isDouble) { nLat = nDouble; } else { bLatError = true; }
        sTmp = ""; sTmp = sLong;
        ProcessCommon.TestDouble(sTmp, out isDouble, out nDouble);
        if (isDouble) { nLong = nDouble; } else { bLongError = true; }
        if (bLatError == true || bLongError == true || bDateFromError == true || bDateToError == true) return "Error: Invalid parameter values.";

        // check lat (north/south)
        if (nLat < ProcessCommon.nSouthBC || nLat > ProcessCommon.nNorthBC) bLatError = true;
        // check long (east/west)
        if (nLong >= ProcessCommon.nEastBC || nLong <= ProcessCommon.nWestBC) bLongError = true;
        // check from date
        if (dtDateFrom.Year < ProcessCommon.nYearStart || dtDateFrom.Year > ProcessCommon.nYearEnd) bDateFromError = true;
        // check to date
        if (dtDateTo.Year < ProcessCommon.nYearStart || dtDateTo.Year > ProcessCommon.nYearEnd) bDateFromError = true;
        if (bDateFromError == false && bDateToError == false)
        {
          if (dtDateTo < dtDateFrom) bDateToError = true;
        }
        if (bLatError == true || bLongError == true || bDateFromError == true || bDateToError == true) return "Error: Invalid Lat/Long/From/To.";

        //test code to implement incremental output 'test' xml files
        if (sGUID.ToString().ToLower() == "test") sGUID = getTestFileNxtSequential();

        //exit if a vaild file exists
        ProcessCommon.sChkGUID = sGUID;
        ProcessCommon.sChkLat = sLat;
        ProcessCommon.sChkLong = sLong;
        ProcessCommon.sChkDateFrom = sDateFrom;
        ProcessCommon.sChkDateTo = sDateTo;
        if (getFileValidExists(sGUID, "climate") == sRtn) return sRtn;

        nLatOffset = (nLat - ProcessCommon.nSouthBC) / ProcessCommon.nCellSize;
        nLongOffset = (nLong - ProcessCommon.nWestBC) / ProcessCommon.nCellSize;
        nLatOffsetInt = Convert.ToInt32(Math.Round(nLatOffset, 0));
        nLongOffsetInt = Convert.ToInt32(Math.Round(nLongOffset, 0));

        nRowint = (ProcessCommon.nNbrRows - nLatOffsetInt) + 1;

        HCEClimateServiceReference.Service1SoapClient hceClimate = new HCEClimateServiceReference.Service1SoapClient(ProcessCommon.sAppEndPointServicesHCE);

        nLat = Convert.ToDouble(sLat);
        nLong = Convert.ToDouble(sLong);
        nLatOffset = (nLat - ProcessCommon.nSouthBC) / ProcessCommon.nCellSize;
        nLongOffset = (nLong - ProcessCommon.nWestBC) / ProcessCommon.nCellSize;
        nLatOffsetInt = Convert.ToInt32(Math.Round(nLatOffset, 0));
        nLongOffsetInt = Convert.ToInt32(Math.Round(nLongOffset, 0));

        nRowint = (ProcessCommon.nNbrRows - nLatOffsetInt) + 1;

        var hceClim = hceClimate.GetClimateHCE(nRowint, nLongOffsetInt, dtDateFrom, dtDateTo);  //this works

        if (hceClim.ToString().StartsWith("Error")) return hceClim.ToString();

        ProcessCommon.LstSData = new List<ScData>();

        JavaScriptSerializer jssData = new JavaScriptSerializer();
        ProcessCommon.LstSData = jssData.Deserialize<List<ScData>>(hceClim.ToString());

        TimeSpan tsDays = dtDateTo - dtDateFrom;
        dtDays = Convert.ToInt32(tsDays.TotalDays) + 1;

        if (dtDays == ProcessCommon.LstSData.Count()) { sValidDays = "true"; } else { sValidDays = "false"; }

        // create internal file info
        ClimateFileInfo cfInfo = new ClimateFileInfo();
        cfInfo.cfiGUID = sGUID;
        cfInfo.cfiLat = sLat;
        cfInfo.cfiLong = sLong;
        cfInfo.cfiDateFrom = sDateFrom;
        cfInfo.cfiDateTo = sDateTo;
        cfInfo.cfiValidDays = sValidDays;
        cfInfo.cfiRecCount = ProcessCommon.LstSData.Count().ToString();
        cfInfo.cfiCreateDate = DateTime.Now.ToShortDateString();

        ClimateFileData cfData = new ClimateFileData();
        cfData.cfdInfo = cfInfo;
        cfData.cfdScData = ProcessCommon.LstSData;

        sFile = ProcessCommon.SafeBSlashPathEndString(ProcessCommon.sNTTClimateFileLocation) + sGUID.ToString() + ".dat";

        if (!Directory.Exists(ProcessCommon.sNTTClimateFileLocation)) { Directory.CreateDirectory(ProcessCommon.sNTTClimateFileLocation); }

        JavaScriptSerializer jssDataout = new JavaScriptSerializer();

        StreamWriter writeFileStream = new StreamWriter(sFile);
        writeFileStream.Write(jssDataout.Serialize(cfData).ToString());

        writeFileStream.Close();
        log.Info(sMeName + "<<Ending - SaveClimateData>>");

        return sRtn;
      }
      catch (Exception ex)
      {
        log.Fatal(ex);
        return "Error: " + ex.Message.ToString();
      }
    }

    public List<SoilComponentsData> SaveSoilsData(string sGUID, string sXMax, string sYMin, string sXMin, string sYMax)
    {
      // sGUID file name to be saved
      string sRtn = "OK";
      string sResult = "";
      string sTmp = "";
      string sTmp1 = "";
      string sFile = "";
      bool bValidContents = true;
      try
      {
        getAppSettings();
        log.Info(sMeName + "<<Starting - SaveSoilsData>>");

        if (ProcessCommon.nAppDebug > 3)
        {
          sTmp1 = String.Format("{0},{1},{2},{3},{4}", sGUID, sXMax, sYMin, sXMin, sYMax);
          log.Debug("Params: " + sTmp1);
        }

        ProcessCommon.LstSCData = new List<SoilComponentsData>();

        //check for valid
        if (sGUID.Length < 1) throw new Exception("Missing GUID value.");

        //check for valid
        // check lat (north/south)        
        if (sXMax.Length == 0) bValidContents = false;
        if (sYMin.Length == 0) bValidContents = false;
        if (sXMin.Length == 0) bValidContents = false;
        if (sYMax.Length == 0) bValidContents = false;
        if (bValidContents == false) throw new Exception("Invalid soils parameter values.");

        //test code to implement incremental output 'test' xml files
        if (sGUID.ToString().ToLower() == "test") sGUID = getTestFileNxtSequential();

        //exit if a vaild file exists
        ProcessCommon.sChkGUID = sGUID;
        ProcessCommon.sChkXMax = sXMax;
        ProcessCommon.sChkYMin = sYMin;
        ProcessCommon.sChkXMin = sXMin;
        ProcessCommon.sChkYMax = sYMax;

        if (getFileValidExists(sGUID, "soil") == sRtn) return ProcessCommon.LstSCData;

        log.Debug("File not found - continue to get soils.");

        SoilComponentServiceClient mapSoilsClient = new SoilComponentServiceClient(ProcessCommon.sAppEndPointServicesSoils);

        //soils all - both components and details
        var sdData = mapSoilsClient.GetSDMSoilsAll(sXMax, sYMin, sXMin, sYMax);

        if (sdData == null) throw new Exception("Soils Service not available.");

        if (sdData.saComponents.Count() == 1 && sdData.saDetails == null) //error condition
        {
          var sCom = (from sC in sdData.saComponents
                     select sC).Take(1).SingleOrDefault();
          throw new Exception(sCom.scdName);
        }

        log.Debug("From GetSDMSoilsAll details rows: " + sdData.saDetails.Count().ToString());
        log.Debug("From GetSDMSoilsAll components rows: " + sdData.saComponents.Count().ToString());

        // create internal file info
        SoilFileInfo sfInfo = new SoilFileInfo();
        sfInfo.sfiGUID = sGUID;
        sfInfo.sfiXMax = sXMax;
        sfInfo.sfiYMin = sYMin;
        sfInfo.sfiXMin = sXMin;
        sfInfo.sfiYMax = sYMax;
        sfInfo.sfiSoilType = "BB";
        sfInfo.sfiRecCount = sdData.saDetails.Count().ToString();
        sfInfo.sfiCreateDate = DateTime.Now.ToShortDateString();

        // create initial component list
        List<SoilComponentsData> lstAllSCData = new List<SoilComponentsData>();
        lstAllSCData = (from scDta in sdData.saComponents
                     select new SoilComponentsData()
                     {
                       scdSSA = scDta.scdSSA,
                       scdSymbol = scDta.scdSymbol,
                       scdName = scDta.scdName,
                       scdAcres = scDta.scdAcres,
                       scdPercent = scDta.scdPercent,
                       scdSlope = scDta.scdSlope,
                       scdPH = scDta.scdPH,
                       scdStatus = scDta.scdStatus,
                     }).ToList();

        // create details
        ProcessCommon.LstSDData = new List<SoilDetailsData>();
        ProcessCommon.LstSDData = (from scDta in sdData.saDetails
                                   select new SoilDetailsData()
                                   {
                                     sddSaversion = scDta.sddSaversion,
                                     sddSaverest = scDta.sddSaverest,
                                     sddAreasymbol = scDta.sddAreasymbol,
                                     sddAreaname = scDta.sddAreaname,
                                     sddMusym = scDta.sddMusym,
                                     sddMuname = scDta.sddMuname,
                                     sddMuseq = scDta.sddMuseq,
                                     sddMukey = scDta.sddMukey,
                                     sddComppct_r = scDta.sddComppct_r,
                                     sddCompname = scDta.sddCompname,
                                     sddSlope_r = scDta.sddSlope_r,
                                     sddCokey = scDta.sddCokey,
                                     sddHydricrating = scDta.sddHydricrating,
                                     sddHydgrp = scDta.sddHydgrp,
                                     sddHzdept_r = scDta.sddHzdept_r,
                                     sddHzdepb_r = scDta.sddHzdepb_r,
                                     sddChkey = scDta.sddChkey,
                                     sddSandtotal_r = scDta.sddSandtotal_r,
                                     sddSilttotal_r = scDta.sddSilttotal_r,
                                     sddClaytotal_r = scDta.sddClaytotal_r,
                                     sddOm_r = scDta.sddOm_r,
                                     sddEcec_r = scDta.sddEcec_r,
                                     sddAwc_r = scDta.sddAwc_r,
                                     sddKffact = scDta.sddKffact,
                                     sddKwfact = scDta.sddKwfact,
                                     sddTexdesc = scDta.sddTexdesc,
                                     sddTexture = scDta.sddTexture,
                                     sddStratextsflag = scDta.sddStratextsflag,
                                     sddRvindicator = scDta.sddRvindicator,
                                     sddTexcl = scDta.sddTexcl
                                   }).ToList();

        //must determine components with valid soils details
        foreach (SoilComponentsData scData in lstAllSCData)
        {
          sResult = getThisSoilDetail(scData);
          //if not valid, remove from list
          if (sResult != sRtn) scData.scdStatus = sResult;
        }

        //remove any invalid component layers
        for (int iNbr = lstAllSCData.Count - 1; iNbr >= 0; iNbr--)
        {
          if (lstAllSCData[iNbr].scdStatus != "") lstAllSCData.RemoveAt(iNbr);
        }

        //make sure there were valid details
        if (ProcessCommon.LstSlayDData.Count == 0 || lstAllSCData.Count == 0) throw new Exception("No valid soils data found.");

        if (ProcessCommon.nAppDebug > 3)
        {
          ProcessCommon.sbLogMessage.Remove(0, ProcessCommon.sbLogMessage.Length);
          ProcessCommon.sbLogMessage.AppendFormat("Soil file components #:{0} details #:{1}", lstAllSCData.Count().ToString(), ProcessCommon.LstSlayDData.Count().ToString());
          log.Debug(sMeName + ProcessCommon.sbLogMessage.ToString());
        }

        sfInfo.sfiRecCount = ProcessCommon.LstSlayDData.Count().ToString();

        SoilFileData sfData = new SoilFileData();
        sfData.sfdInfo = sfInfo;
        sfData.sfdCData = lstAllSCData;
        sfData.sfdDData = ProcessCommon.LstSlayDData;

        sFile = ProcessCommon.SafeBSlashPathEndString(ProcessCommon.sNTTSoilFileLocation) + sGUID.ToString() + ".dat";

        if (!Directory.Exists(ProcessCommon.sNTTSoilFileLocation)) { Directory.CreateDirectory(ProcessCommon.sNTTSoilFileLocation); }

        JavaScriptSerializer jssDataout = new JavaScriptSerializer();

        StreamWriter writeFileStream = new StreamWriter(sFile);
        writeFileStream.Write(jssDataout.Serialize(sfData).ToString());

        writeFileStream.Close();

        log.Info(sMeName + "<<Ending - SaveSoilsData>>");
        return sfData.sfdCData;
      }
      catch (Exception ex)
      {
        log.Fatal(ex);
        // create error info
        SoilComponentsData scInfo = new SoilComponentsData();
        scInfo.scdSSA = "Error";
        scInfo.scdName = "Error: " + ex.Message.ToString();
        ProcessCommon.LstSCData.Add(scInfo);
        return ProcessCommon.LstSCData;
      }
    }

    public string SaveManagementData(MgmtFileData MFData)
    {
      // sGUID file name to be saved
      string sRtn = "OK";
      string sTmp = "";
      string sFile = "";
      bool bValidContents = true;
      string sGUID = "";
      string sCmz = "";
      string sBOrA = "B";
      string sDBOrA = "B";
      try
      {
        getAppSettings();
        log.Info(sMeName + "<<Starting - SaveManagementData>>");

        //always update the file contents - no checking for previously saved valid data
        //later, an 'action' param could be used to 'check', 'update' etc.

        //check for valid
        // check internal file info - just GUID and CMZ for now
        while (sBOrA != "")
        {
          var mMInfo = (from MgmtFileInfo in MFData.mfdInfoBAndA where (MgmtFileInfo.mfiBOrA == sBOrA) select MgmtFileInfo).Take(1).SingleOrDefault();
          if (sGUID == "") sGUID = mMInfo.mfiGUID;
          if (sCmz == "") sCmz = mMInfo.mfiCmz;
          if (sGUID != mMInfo.mfiGUID) bValidContents = false;
          if (sCmz != mMInfo.mfiCmz) bValidContents = false;
          if (sBOrA == "A") sBOrA = "";
          if (sBOrA == "B") sBOrA = "A";
        }
        if (bValidContents == false) return "Error: Invalid management file info values.";

        // check detail data
        while (sDBOrA != "")
        {
          var mDData = (from MgmtDetailsData in MFData.mfdDDataBAndA where (MgmtDetailsData.mddBOrA == sDBOrA) select MgmtDetailsData).Take(1).SingleOrDefault();
          // what can be checked for validity?
          if (sDBOrA == "A") sDBOrA = "";
          if (sDBOrA == "B") sDBOrA = "A";
        }
        if (bValidContents == false) return "Error: Invalid management file detail values.";

        //test code to implement incremental output 'test' xml files
        if (sGUID.ToString().ToLower() == "test") sGUID = getTestFileNxtSequential();

        sFile = ProcessCommon.SafeBSlashPathEndString(ProcessCommon.sNTTManagementFileLocation) + sGUID.ToString() + ".dat";

        //save the data and overwrite if the file exisits
        if (!Directory.Exists(ProcessCommon.sNTTManagementFileLocation)) { Directory.CreateDirectory(ProcessCommon.sNTTManagementFileLocation); }

        JavaScriptSerializer jssDataout = new JavaScriptSerializer();

        StreamWriter writeFileStream = new StreamWriter(sFile);
        writeFileStream.Write(jssDataout.Serialize(MFData).ToString());

        writeFileStream.Close();

        log.Info(sMeName + "<<Ending - SaveManagementData>>");
        return sRtn;
      }
      catch (Exception ex)
      {
          log.Fatal(ex);
        return "Error: " + ex.Message.ToString();
      }
    }

    public RunNttFileData RunApexBaseAndAlt(RunParamsData rpData)
    {
      string sResult = "";
      string sRtn = "OK";
      //string sTmp = "";
      string sRunFile = "";

      string sReturnedHsg = "B"; //default hsg
      try
      {
        getAppSettings();
        log.Info(sMeName + "<<Starting - RunApexBaseAndAlt>>");

        ProcessCommon.RnfData = new RunNttFileData();
        ProcessCommon.LstNttData = new List<APEXNttData>();

        //check for valid
        //files present and valid for climate, soils and managements
        //files APEXLookupData and APEXRunFile present and valid
        //GetClimateReady, GetSubAreaReady, GetManagementReady

        //exit if missing or invaild file
        ProcessCommon.sChkGUID = rpData.rpdGUID;
        ProcessCommon.sChkLat = rpData.rpdClimateLat;
        ProcessCommon.sChkLong = rpData.rpdClimateLong;
        ProcessCommon.sChkDateFrom = rpData.rpdClimateDateFrom;
        ProcessCommon.sChkDateTo = rpData.rpdClimateDateTo;

        if (log.IsDebugEnabled)
        {
            log.DebugFormat("B4 climate: {0},{1},{2},{3},{4}", ProcessCommon.sChkGUID, ProcessCommon.sChkLat, ProcessCommon.sChkLong, ProcessCommon.sChkDateFrom, ProcessCommon.sChkDateTo);
        }
        
        sResult = getFileValidExists(ProcessCommon.sChkGUID, "climate");
        if (sResult != sRtn) throw new Exception(sResult);

        ProcessCommon.sChkXMax = rpData.rpdSoilsXMax;
        ProcessCommon.sChkYMin = rpData.rpdSoilsYMin;
        ProcessCommon.sChkXMin = rpData.rpdSoilsXMin;
        ProcessCommon.sChkYMax = rpData.rpdSoilsYMax;

        if (log.IsDebugEnabled)
        {

          log.DebugFormat("B4 soil: {0},{1},{2},{3}", ProcessCommon.sChkXMax, ProcessCommon.sChkYMin, ProcessCommon.sChkXMin, ProcessCommon.sChkYMax);
        }

        sResult = getFileValidExists(ProcessCommon.sChkGUID, "soil");
        if (sResult != sRtn) throw new Exception(sResult);

        ProcessCommon.sChkCmz = rpData.rpdMgmtCmz;

        if (log.IsDebugEnabled)
        {
          log.DebugFormat("B4 management: {0}", ProcessCommon.sChkCmz);
        }

        //these could be local files - maybe it would be quicker
        ManagementsClient mapManClient = new ManagementsClient(ProcessCommon.sAppEndPointServicesManagements);
        ProcessCommon.LstMPCrops = mapManClient.GetMappedCropData();
        ProcessCommon.LstMPOperations = mapManClient.GetMappedOperationData();

        ProcessCommon.LstChkMFInfoBAndA = rpData.rpdMgmtInfoBAndA;

        sResult = getFileValidExists(ProcessCommon.sChkGUID, "management");
        if (sResult != sRtn) throw new Exception(sResult);

        sResult = getFileValidExists(ProcessCommon.sChkGUID, "lookupcrop");
        if (sResult != sRtn) throw new Exception(sResult);

        //climate processing
        GetClimateReady getClimReady = new GetClimateReady();
        sResult = getClimReady.DoClimateFiles(ProcessCommon.sAPEXRunLocation, ProcessCommon.sAPEXSiteSitFile, ProcessCommon.sAPEXWeatherDlyFile, ProcessCommon.sAPEXWeatherWthFile);
        if (sResult != sRtn)
        {
          log.Debug(sMeName + "<<Failed: DoClimateFiles>>: " + sResult);
          throw new Exception(sResult);
        }
        //subarea processing
        GetSubAreaReady getSubAReady = new GetSubAreaReady();
        sReturnedHsg = getSubAReady.DoSoilFiles(ProcessCommon.sAPEXRunLocation, ProcessCommon.sAPEXSubAreaSubFile, ProcessCommon.sAPEXSoil2110File, ProcessCommon.sAPEXSoilFieldFile);
        if (sReturnedHsg.StartsWith("Error"))
        {
          log.Debug(sMeName + "<<Failed: DoSoilFiles>>: " + sReturnedHsg);
          throw new Exception(sReturnedHsg);
        }
        //management processing
        GetManagementReady getMgmtReady = new GetManagementReady();
        sResult = getMgmtReady.DoManagementFiles(ProcessCommon.sAPEXRunLocation, ProcessCommon.sAPEXManagementOpcFile, sReturnedHsg);
        if (sResult.StartsWith("Error"))
        {
          log.Debug(sMeName + "<<Failed: DoManagementFiles>>: " + sResult);
          throw new Exception(sResult);
        }

        //APEX processing
        //Create a new process info structure.
        sRunFile = ProcessCommon.SafeBSlashPathEndString(ProcessCommon.sAPEXRunLocation) + ProcessCommon.sAPEXRunFile.ToString();
        System.Diagnostics.ProcessStartInfo psi = new System.Diagnostics.ProcessStartInfo(sRunFile);
        Process p = System.Diagnostics.Process.Start(psi);
        //Wait for the process to end.
        p.WaitForExit();

        sResult = chk4FilePresent(ProcessCommon.sAPEXRunLocation, ProcessCommon.sAPEXOutBaseNttFile);
        if (sResult != sRtn) { throw new Exception(sResult); }

        sResult = chk4FilePresent(ProcessCommon.sAPEXRunLocation, ProcessCommon.sAPEXOutAltNttFile);
        if (sResult != sRtn) { throw new Exception(sResult); }

        //get ntt files
        GetOutputNTTFile getOutputNtt = new GetOutputNTTFile();
        sResult = getOutputNtt.GetNTTFile(ProcessCommon.sAPEXRunLocation, ProcessCommon.sAPEXOutBaseNttFile, ProcessCommon.sAPEXOutAltNttFile);

        if (sResult != sRtn) throw new Exception(sResult);

        if (log.IsDebugEnabled)
        {
          int nCntB = 0; int nCntA = 0;
          var BQry = (from nB in ProcessCommon.LstNttData where nB.AndBOrA == "B" select ++nCntB).ToList();
          var AQry = (from nA in ProcessCommon.LstNttData where nA.AndBOrA == "A" select ++nCntA).ToList();
          log.DebugFormat("Run results-BCount: {0} ACount: ,{1}\n", nCntB.ToString(), nCntA.ToString());
        }

        //run results
        ProcessCommon.RnfData.RnfDataBAndA = ProcessCommon.LstNttData;

        log.Info(sMeName + "<<Ending - RunApexBaseAndAlt>>");
        return ProcessCommon.RnfData;
      }
      catch (Exception ex)
      {
        log.Debug(ex);
        // create error info
        ProcessCommon.RnfData = new RunNttFileData();
        ProcessCommon.LstNttData = new List<APEXNttData>();        
        APEXNttData anData = new APEXNttData();
        anData.AndBOrA = "Error";
        anData.AndSUB = "Error: " + ex.Message.ToString();
        ProcessCommon.LstNttData.Add(anData);

        ProcessCommon.RnfData.RnfDataBAndA = ProcessCommon.LstNttData;
        return ProcessCommon.RnfData;
      }
    }

    #region Test Methods
    public string GetHello()
    {
      string stest = "Hello";
      try
      { }
      catch (Exception Ex)
      { stest = "Error: " + Ex.Message.ToString(); }
      return stest;
    }

    public string GetHelloSettings()
    {
      string stest = "Hello Settings";
      try
      {
        getAppSettings();
        log.Info(sMeName + "<<Starting - GetHelloSettings>>");

        log.Info(sMeName + "<<Ending - GetHelloSettings>>");
        return "OK";
      
      }
      catch (Exception Ex)
      { stest = "Error: " + Ex.Message.ToString(); }
      return stest;
    }

    public string TestSaveClimateData()
    {
      //test values dev environment w/ small database
      string sGUID = "aaaaabbbbbcccccc";
      string sLat = "45.269";  //OR Clackamas Estacada 2 SE
      string sLong = "-122.319";
      string sDateFrom = "01/01/2001";
      string sDateTo = "02/02/2001";

      //test values full database
      //string sGUID = "ffffffuuuuullllll";
      //string sLat = "45.269";  //OR Clackamas Estacada 2 SE
      //string sLong = "-122.319";
      //string sDateFrom = "01/01/1960";
      //string sDateTo = "12/31/2006";

      // sGUID file name to be saved
      int nCnt = 0;
      string sRtn = "OK";
      string sValidDays = "";
      string sTmp = "";
      string sFile = "";
      //bool bValid = true;
      //System.IO.StreamWriter objTextW = null;
      //string sNTTNutClimateLocation = "";

      DateTime dtDateFrom = new DateTime(1900, 1, 1);
      DateTime dtDateTo = new DateTime(1900, 1, 1);
      double nNbr = 0;
      bool bLatError = false;
      bool bLongError = false;
      bool bDateFromError = false;
      bool bDateToError = false;

      double nLat = 0;
      double nLong = 0;
      double nLatOffset = 0;
      double nLongOffset = 0;
      int nLatOffsetInt = 0;
      int nLongOffsetInt = 0;
      int nRowint = 0;

      int dtDays = 0;

      int nFileCount = 1;
      string sFileCount = "";
      string sTestFile = "";
      string sTstFile = "";
      string sTCount = "";

      double nDouble;
      bool isDouble;
      DateTime dtDate;
      bool isDate;

      List<ScData> lstSData = new List<ScData>();

      try
      {
        getAppSettings();
        log.Info(sMeName + "<<Starting - TestSaveClimateData>>");

        //check for valid
        if (sGUID.Length < 1) return "Error: Missing GUID value.";

        //check for valid
        // check lat (north/south)        
        if (sLat.Length == 0) bLatError = true;
        if (sLong.Length == 0) bLongError = true;
        if (sDateFrom.Length == 0) bDateFromError = true;
        if (sDateTo.Length == 0) bDateToError = true;
        if (bLatError == true || bLongError == true || bDateFromError == true || bDateToError == true) return "Error: Invalid parameter values.";

        sTmp = ""; sTmp = sDateFrom;
        ProcessCommon.TestDate(sTmp, out isDate, out dtDate);
        if (isDate) { dtDateFrom = dtDate; } else { bDateFromError = true; }
        sTmp = ""; sTmp = sDateTo;
        ProcessCommon.TestDate(sTmp, out isDate, out dtDate);
        if (isDate) { dtDateTo = dtDate; } else { bDateToError = true; }

        sTmp = ""; sTmp = sLat;
        ProcessCommon.TestDouble(sTmp, out isDouble, out nDouble);
        if (isDouble) { nLat = nDouble; } else { bLatError = true; }
        sTmp = ""; sTmp = sLong;
        ProcessCommon.TestDouble(sTmp, out isDouble, out nDouble);
        if (isDouble) { nLong = nDouble; } else { bLongError = true; }
        if (bLatError == true || bLongError == true || bDateFromError == true || bDateToError == true) return "Error: Invalid parameter values.";

        // check lat (north/south)
        if (nLat < ProcessCommon.nSouthBC || nLat > ProcessCommon.nNorthBC) bLatError = true;
        // check long (east/west)
        if (nLong >= ProcessCommon.nEastBC || nLong <= ProcessCommon.nWestBC) bLongError = true;
        // check from date
        if (dtDateFrom.Year < ProcessCommon.nYearStart || dtDateFrom.Year > ProcessCommon.nYearEnd) bDateFromError = true;
        // check to date
        if (dtDateTo.Year < ProcessCommon.nYearStart || dtDateTo.Year > ProcessCommon.nYearEnd) bDateFromError = true;
        if (bDateFromError == false && bDateToError == false)
        {
          if (dtDateTo < dtDateFrom) bDateToError = true;
        }
        if (bLatError == true || bLongError == true || bDateFromError == true || bDateToError == true) return "Error: Invalid Lat/Long/From/To.";

        nLatOffset = (nLat - ProcessCommon.nSouthBC) / ProcessCommon.nCellSize;
        nLongOffset = (nLong - ProcessCommon.nWestBC) / ProcessCommon.nCellSize;
        nLatOffsetInt = Convert.ToInt32(Math.Round(nLatOffset, 0));
        nLongOffsetInt = Convert.ToInt32(Math.Round(nLongOffset, 0));

        nRowint = (ProcessCommon.nNbrRows - nLatOffsetInt) + 1;

        HCEClimateServiceReference.Service1SoapClient hceClimate = new HCEClimateServiceReference.Service1SoapClient(ProcessCommon.sAppEndPointServicesHCE);

        //test without parameters
        //var hceClim = hceClimate.TestClimateHCEJson();  //this works

        //test with test values
        nLat = Convert.ToDouble(sLat);
        nLong = Convert.ToDouble(sLong);
        nLatOffset = (nLat - ProcessCommon.nSouthBC) / ProcessCommon.nCellSize;
        nLongOffset = (nLong - ProcessCommon.nWestBC) / ProcessCommon.nCellSize;
        nLatOffsetInt = Convert.ToInt32(Math.Round(nLatOffset, 0));
        nLongOffsetInt = Convert.ToInt32(Math.Round(nLongOffset, 0));

        nRowint = (ProcessCommon.nNbrRows - nLatOffsetInt) + 1;

        var hceClim = hceClimate.GetClimateHCE(nRowint, nLongOffsetInt, dtDateFrom, dtDateTo);  //this works

        if (hceClim.ToString().StartsWith("Error")) return hceClim.ToString();

        JavaScriptSerializer jssData = new JavaScriptSerializer();
        lstSData = jssData.Deserialize<List<ScData>>(hceClim.ToString());

        TimeSpan tsDays = dtDateTo - dtDateFrom;
        dtDays = Convert.ToInt32(tsDays.TotalDays) + 1;

        if (dtDays == lstSData.Count()) { sValidDays = "true"; } else { sValidDays = "false"; }

        // create internal file info
        ClimateFileInfo cfInfo = new ClimateFileInfo();
        cfInfo.cfiGUID = sGUID;
        cfInfo.cfiLat = sLat;
        cfInfo.cfiLong = sLong;
        cfInfo.cfiDateFrom = sDateFrom;
        cfInfo.cfiDateTo = sDateTo;
        cfInfo.cfiValidDays = sValidDays;
        cfInfo.cfiRecCount = lstSData.Count().ToString();
        cfInfo.cfiCreateDate = DateTime.Now.ToShortDateString();

        ClimateFileData cfData = new ClimateFileData();
        cfData.cfdInfo = cfInfo;
        cfData.cfdScData = lstSData;

        sFile = ProcessCommon.SafeBSlashPathEndString(ProcessCommon.sNTTClimateFileLocation) + sGUID.ToString() + ".dat";

        if (!Directory.Exists(ProcessCommon.sNTTClimateFileLocation)) { Directory.CreateDirectory(ProcessCommon.sNTTClimateFileLocation); }

        JavaScriptSerializer jssDataout = new JavaScriptSerializer();

        StreamWriter writeFileStream = new StreamWriter(sFile);
        writeFileStream.Write(jssDataout.Serialize(cfData).ToString());

        writeFileStream.Close();

        log.Info(sMeName + "<<Ending - TestSaveClimateData>>");
        return "OK";
      }
      catch (Exception ex)
      {
          log.Fatal(ex);
        return "Error: " + ex.Message.ToString();
      }
    }

    public string TestGetClimateData()
    {
      //test values
      string sGUID = "aaaaabbbbbcccccc";
      string sLat = "45.269";  //OR Clackamas Estacada 2 SE
      string sLong = "-122.319";
      string sDateFrom = "01/01/2001";
      string sDateTo = "02/02/2001";

      double nLat = 0;
      double nLong = 0;
      double nLatOffset = 0;
      double nLongOffset = 0;
      int nLatOffsetInt = 0;
      int nLongOffsetInt = 0;
      int nRowint = 0;

      // sGUID file name to be saved
      string sTmp = "";
      string sFile = "";
      bool bValidContents = true;

      List<ScData> lstSData = new List<ScData>();

      try
      {
        getAppSettings();
        log.Info(sMeName + "<<Starting - TestGetClimateData>>");

        //just check parsing contents of saved test file
        sFile = ProcessCommon.SafeBSlashPathEndString(ProcessCommon.sNTTClimateFileLocation) + sGUID.ToString() + ".dat";
        if (!File.Exists(sFile)) return "Error: File not found: " + sFile;

        StreamReader readFileStream = new StreamReader(sFile);
        readFileStream.BaseStream.Seek(0, SeekOrigin.Begin);
        sTmp = readFileStream.ReadToEnd();
        readFileStream.Close();

        ClimateFileData cfData = new ClimateFileData();
        try
        {
          JavaScriptSerializer jssData = new JavaScriptSerializer();
          cfData = jssData.Deserialize<ClimateFileData>(sTmp);
        }
        catch
        {
          throw new Exception("Error: Invalid climate data file format.");
        }

        nLat = Convert.ToDouble(sLat);
        nLong = Convert.ToDouble(sLong);
        nLatOffset = (nLat - ProcessCommon.nSouthBC) / ProcessCommon.nCellSize;
        nLongOffset = (nLong - ProcessCommon.nWestBC) / ProcessCommon.nCellSize;
        nLatOffsetInt = Convert.ToInt32(Math.Round(nLatOffset, 0));
        nLongOffsetInt = Convert.ToInt32(Math.Round(nLongOffset, 0));

        nRowint = (ProcessCommon.nNbrRows - nLatOffsetInt) + 1;

        //validate file contents
        if (cfData.cfdInfo.cfiGUID != sGUID) bValidContents = false;
        if (cfData.cfdInfo.cfiLat != sLat) bValidContents = false;
        if (cfData.cfdInfo.cfiLong != sLong) bValidContents = false;
        if (cfData.cfdInfo.cfiDateFrom != sDateFrom) bValidContents = false;
        if (cfData.cfdInfo.cfiDateTo != sDateTo) bValidContents = false;
        if (cfData.cfdInfo.cfiRecCount != cfData.cfdScData.Count().ToString()) bValidContents = false;

        log.Info(sMeName + "<<Ending - TestGetClimateData>>");
        if (bValidContents == false)
        { return "Error: File contents not valid."; }
        else
        { return "OK"; }
      }
      catch (Exception ex)
      {
          log.Fatal(ex);
        return "Error: " + ex.Message.ToString();
      }
    }   

    public string TestSaveSoilsData()
    {
      //test values dev environmen
      string sGUID = "aaaaabbbbbcccccc";
      //string sXMax = "-123.504";
      //string sYMin = "45.38";
      //string sXMin = "-123.46";
      //string sYMax = "45.41";
      /*Ohio - Defiance
       * XMin = -84.326141756042361
       * XMax = -84.314106356257639
       * YMin = 41.2680696763643
       * YMax = 41.275392371506406
       * Ordinate order must be 'minx, miny, maxx, maxy
       */
      string sXMax = "-84.314106356257639";
      string sYMin = "41.2680696763643";
      string sXMin = "-84.326141756042361";
      string sYMax = "41.275392371506406";

      string sResult = "";
      string sRtn = "OK";
      string sFile = "";
      try
      {
        getAppSettings();
        log.Info(sMeName + "<<Starting - TestSaveSoilsData>>");

        SoilComponentServiceClient mapSoilsClient = new SoilComponentServiceClient(ProcessCommon.sAppEndPointServicesSoils);

        //soils all - both components and details
        var sdData = mapSoilsClient.GetSDMTestSoilsAll();

        // create internal file info
        SoilFileInfo sfInfo = new SoilFileInfo();
        sfInfo.sfiGUID = sGUID;
        sfInfo.sfiXMax = sXMax;
        sfInfo.sfiYMin = sYMin;
        sfInfo.sfiXMin = sXMin;
        sfInfo.sfiYMax = sYMax;
        sfInfo.sfiSoilType = "BB";
        sfInfo.sfiRecCount = "0";
        sfInfo.sfiCreateDate = DateTime.Now.ToShortDateString();

        // create components
        List<SoilComponentsData> lstAllSCData = new List<SoilComponentsData>();
        lstAllSCData = (from scDta in sdData.saComponents
                     select new SoilComponentsData()
                     {
                       scdSSA = scDta.scdSSA,
                       scdSymbol = scDta.scdSymbol,
                       scdName = scDta.scdName,
                       scdAcres = scDta.scdAcres,
                       scdPercent = scDta.scdPercent,
                       scdSlope = scDta.scdSlope,
                       scdPH = scDta.scdPH,
                       scdStatus = scDta.scdStatus,
                     }).ToList();

        // create details
        ProcessCommon.LstSDData = new List<SoilDetailsData>();
        ProcessCommon.LstSDData = (from scDta in sdData.saDetails
                     select new SoilDetailsData()
                     {
                       sddSaversion = scDta.sddSaversion,
                       sddSaverest = scDta.sddSaverest,
                       sddAreasymbol = scDta.sddAreasymbol,
                       sddAreaname = scDta.sddAreaname,
                       sddMusym = scDta.sddMusym,
                       sddMuname = scDta.sddMuname,
                       sddMuseq = scDta.sddMuseq,
                       sddMukey = scDta.sddMukey,
                       sddComppct_r = scDta.sddComppct_r,
                       sddCompname = scDta.sddCompname,
                       sddSlope_r = scDta.sddSlope_r,
                       sddCokey = scDta.sddCokey,
                       sddHydricrating = scDta.sddHydricrating,
                       sddHydgrp = scDta.sddHydgrp,
                       sddHzdept_r = scDta.sddHzdept_r,
                       sddHzdepb_r = scDta.sddHzdepb_r,
                       sddChkey = scDta.sddChkey,
                       sddSandtotal_r = scDta.sddSandtotal_r,
                       sddSilttotal_r = scDta.sddSilttotal_r,
                       sddClaytotal_r = scDta.sddClaytotal_r,
                       sddOm_r = scDta.sddOm_r,
                       sddEcec_r = scDta.sddEcec_r,
                       sddAwc_r = scDta.sddAwc_r,
                       sddKffact = scDta.sddKffact,
                       sddKwfact = scDta.sddKwfact,
                       sddTexdesc = scDta.sddTexdesc,
                       sddTexture = scDta.sddTexture,
                       sddStratextsflag = scDta.sddStratextsflag,
                       sddRvindicator = scDta.sddRvindicator,
                       sddTexcl = scDta.sddTexcl
                     }).ToList();

        //must determine components with valid soils details
        foreach (SoilComponentsData scData in lstAllSCData)
        {
          sResult = getThisSoilDetail(scData);
          //if not valid, remove from list
          if (sResult != sRtn) scData.scdStatus = sResult;
        }

        //remove any invalid component layers
        for (int iNbr = lstAllSCData.Count - 1; iNbr >= 0; iNbr--)
        {
          if (lstAllSCData[iNbr].scdStatus != "") lstAllSCData.RemoveAt(iNbr);
        }

        //make sure there were valid details
        if (ProcessCommon.LstSlayDData.Count == 0 || lstAllSCData.Count == 0) throw new Exception("No valid soils data found.");

        sfInfo.sfiRecCount = ProcessCommon.LstSlayDData.Count().ToString();

        SoilFileData sfData = new SoilFileData();
        sfData.sfdInfo = sfInfo;
        sfData.sfdCData = lstAllSCData;
        sfData.sfdDData = ProcessCommon.LstSlayDData;

        sFile = ProcessCommon.SafeBSlashPathEndString(ProcessCommon.sNTTSoilFileLocation) + sGUID.ToString() + ".dat";

        if (!Directory.Exists(ProcessCommon.sNTTSoilFileLocation)) { Directory.CreateDirectory(ProcessCommon.sNTTSoilFileLocation); }

        JavaScriptSerializer jssDataout = new JavaScriptSerializer();

        StreamWriter writeFileStream = new StreamWriter(sFile);
        writeFileStream.Write(jssDataout.Serialize(sfData).ToString());

        writeFileStream.Close();

        log.Info(sMeName + "<<Ending - TestSaveSoilsData>>");
        return "OK";
      }
      catch (Exception ex)
      {
          log.Fatal(ex);
        return "Error: " + ex.Message.ToString();
      }
    }

    public string TestGetSoilsData()
    {
      //test values
      string sGUID = "aaaaabbbbbcccccc";
      //string sXMax = "-123.504";
      //string sYMin = "45.38";
      //string sXMin = "-123.46";
      //string sYMax = "45.41";
      /*Ohio - Defiance
       * XMin = -84.326141756042361
       * XMax = -84.314106356257639
       * YMin = 41.2680696763643
       * YMax = 41.275392371506406
       * Ordinate order must be 'minx, miny, maxx, maxy
       */
      string sXMax = "-84.314106356257639";
      string sYMin = "41.2680696763643";
      string sXMin = "-84.326141756042361";
      string sYMax = "41.275392371506406";

      // sGUID file name to be saved
      string sTmp = "";
      string sFile = "";
      bool bValidContents = true;
      try
      {
        getAppSettings();
        log.Info(sMeName + "<<Starting - TestGetSoilsData>>");

        //just check parsing contents of saved test file
        sFile = ProcessCommon.SafeBSlashPathEndString(ProcessCommon.sNTTSoilFileLocation) + sGUID.ToString() + ".dat";
        if (!File.Exists(sFile)) return "Error: File not found: " + sFile;

        StreamReader readFileStream = new StreamReader(sFile);
        readFileStream.BaseStream.Seek(0, SeekOrigin.Begin);
        sTmp = readFileStream.ReadToEnd();
        readFileStream.Close();

        SoilFileData sfData = new SoilFileData();
        try
        {
          JavaScriptSerializer jssData = new JavaScriptSerializer();
          sfData = jssData.Deserialize<SoilFileData>(sTmp);
        }
        catch (Exception ex)
        {
          throw new Exception("Error: Invalid soil data file format.");
        }

        //validate file contents
        if (sfData.sfdInfo.sfiGUID != sGUID) bValidContents = false;
        if (sfData.sfdInfo.sfiXMax != sXMax) bValidContents = false;
        if (sfData.sfdInfo.sfiYMin != sYMin) bValidContents = false;
        if (sfData.sfdInfo.sfiXMin != sXMin) bValidContents = false;
        if (sfData.sfdInfo.sfiYMax != sYMax) bValidContents = false;
        if (sfData.sfdInfo.sfiRecCount != sfData.sfdDData.Count().ToString()) bValidContents = false;

        log.Info(sMeName + "<<Ending - TestGetSoilsData>>");
        if (bValidContents == false)
        { return "Error: File contents not valid."; }
        else
        { return "OK"; }
      }
      catch (Exception ex)
      {
        log.Fatal(ex);
        return "Error: " + ex.Message.ToString();
      }
    }

    public string TestSaveManagementData()
    {
      //test values
      string sGUID = "aaaaabbbbbcccccc";
      string sCmzId = "1";
      string sCmz = "CMZ 01";
      string sBOrA = "B";
      string sManDuration = "2";
      string sManName = "Test Man Name";
      string sManId = "3";
      string sManPathName = "Test Path Name";
      string sManPathId = "4";
      string sManYears = "2";
      string sManCropsNbr = "2";
      string sManCropsNames = "Test Crop 1, Test Crop 2";
      string sManCropsDesc = "";
      string sCreateDate = DateTime.Now.ToShortDateString();

      string sDBOrA = "B";
      string sDDId = "1";
      string sDDCrop = "Test Crop 1";
      int? nDDCropId = null;
      int nDDOpId = 1;
      int nDDManId = 2;
      string sDDOper = "Test Operation";
      int nDDOperId = 3;
      string sDDOperCode = "Test Op Code";
      string sDDOperCodeDesc = "Test Op Code Desc";
      string sDDDate = DateTime.Now.ToString("yyyy-MM-dd");
      string sDDAmt = "5";
      string sDDDepth = "7";

      string sFile = "";

      List<MgmtFileInfo> lstMFInfo = new List<MgmtFileInfo>();
      List<MgmtDetailsData> lstMDData = new List<MgmtDetailsData>();

      try
      {
        getAppSettings();
        log.Info(sMeName + "<<Starting - TestSaveManagementData>>");

        //check for valid
        if (sGUID.Length < 1) return "Error: Missing GUID value.";

        // create internal file info
        while (sBOrA != "")
        {
          MgmtFileInfo mfInfo = new MgmtFileInfo();
          mfInfo.mfiGUID = sGUID;
          mfInfo.mfiCmzId = sCmzId;
          mfInfo.mfiCmz = sCmz;
          mfInfo.mfiBOrA = sBOrA;
          mfInfo.mfiManDuration = sManDuration;
          mfInfo.mfiManName = sManName;
          mfInfo.mfiManId = sManId;
          mfInfo.mfiManPathName = sManPathName;
          mfInfo.mfiManPathId = sManPathId;
          mfInfo.mfiManYears = sManYears;
          mfInfo.mfiManCropsNbr = sManCropsNbr;
          mfInfo.mfiManCropsNames = sManCropsNames;
          mfInfo.mfiManCropsDesc = sManCropsDesc;
          mfInfo.mfiCreateDate = sCreateDate;
          lstMFInfo.Add(mfInfo);
          if (sBOrA == "A") sBOrA = "";
          if (sBOrA == "B") sBOrA = "A";
        }

        // create detail data
        while (sDBOrA != "")
        {
          MgmtDetailsData mdData = new MgmtDetailsData();
          mdData.mddBOrA = sDBOrA;
          mdData.mddDId = sDDId;
          mdData.mddDCrop = sDDCrop;
          // mdData.mddDCropId = 		nDDCropIdl;
          mdData.mddDOpId = nDDOpId;
          mdData.mddDManId = nDDManId;
          mdData.mddDOper = sDDOper;
          mdData.mddDOperId = nDDOperId;
          mdData.mddDOperCode = sDDOperCode;
          mdData.mddDOperCodeDesc = sDDOperCodeDesc;
          mdData.mddDDate = sDDDate;
          mdData.mddDAmt = sDDAmt;
          mdData.mddDDepth = sDDDepth;
          lstMDData.Add(mdData);
          if (sDBOrA == "A") sDBOrA = "";
          if (sDBOrA == "B") sDBOrA = "A";
        }

        MgmtFileData mfData = new MgmtFileData();
        mfData.mfdInfoBAndA = lstMFInfo;
        mfData.mfdDDataBAndA = lstMDData;

        sFile = ProcessCommon.SafeBSlashPathEndString(ProcessCommon.sNTTManagementFileLocation) + sGUID.ToString() + ".dat";

        if (!Directory.Exists(ProcessCommon.sNTTManagementFileLocation)) { Directory.CreateDirectory(ProcessCommon.sNTTManagementFileLocation); }

        JavaScriptSerializer jssDataout = new JavaScriptSerializer();

        StreamWriter writeFileStream = new StreamWriter(sFile);
        writeFileStream.Write(jssDataout.Serialize(mfData).ToString());

        writeFileStream.Close();

        log.Info(sMeName + "<<Ending - TestSaveManagementData>>");
        return "OK";
      }
      catch (Exception ex)
      {
        StackTrace sTrace = new StackTrace();
        log.Fatal(ex);
        return "Error: " + ex.Message.ToString();
      }
    }

    public string TestGetManagementData()
    {
      //test values
      string sGUID = "aaaaabbbbbcccccc";
      string sCmzId = "1";
      string sCmz = "CMZ 01";
      string sBOrA = "B";
      string sManDuration = "2";
      string sManName = "Test Man Name";
      string sManId = "3";
      string sManPathName = "Test Path Name";
      string sManPathId = "4";
      string sManYears = "2";
      string sManCropsNbr = "2";
      string sManCropsNames = "Test Crop 1, Test Crop 2";
      string sManCropsDesc = "";
      string sCreateDate = DateTime.Now.ToShortDateString();

      string sDBOrA = "B";
      string sDDId = "1";
      string sDDCrop = "Test Crop 1";
      int? nDDCropId = null;
      int nDDOpId = 1;
      int nDDManId = 2;
      string sDDOper = "Test Operation";
      int nDDOperId = 3;
      string sDDOperCode = "Test Op Code";
      string sDDOperCodeDesc = "Test Op Code Desc";
      string sDDDate = DateTime.Now.ToString("yyyy-MM-dd");
      string sDDAmt = "5";
      string sDDDepth = "7";

      // sGUID file name to be saved
      string sTmp = "";
      string sFile = "";
      bool bValidContents = true;
      try
      {
        getAppSettings();
        log.Info(sMeName + "<<Starting - TestGetManagementData>>");

        //just check parsing contents of saved test file
        sFile = ProcessCommon.SafeBSlashPathEndString(ProcessCommon.sNTTManagementFileLocation) + sGUID.ToString() + ".dat";
        if (!File.Exists(sFile)) return "Error: File not found: " + sFile;

        StreamReader readFileStream = new StreamReader(sFile);
        readFileStream.BaseStream.Seek(0, SeekOrigin.Begin);
        sTmp = readFileStream.ReadToEnd();
        readFileStream.Close();

        MgmtFileData mfData = new MgmtFileData();
        try
        {
          JavaScriptSerializer jssData = new JavaScriptSerializer();
          mfData = jssData.Deserialize<MgmtFileData>(sTmp);
        }
        catch
        {
          throw new Exception("Error: Invalid management data file format.");
        }

        //validate file contents
        // check internal file info
        while (sBOrA != "")
        {
          var mMInfo = (from MgmtFileInfo in mfData.mfdInfoBAndA where (MgmtFileInfo.mfiBOrA == sBOrA) select MgmtFileInfo).Take(1).SingleOrDefault();
          if (mMInfo.mfiGUID != sGUID) bValidContents = false;
          if (mMInfo.mfiCmzId != sCmzId) bValidContents = false;
          if (mMInfo.mfiCmz != sCmz) bValidContents = false;
          if (mMInfo.mfiBOrA != sBOrA) bValidContents = false;
          if (mMInfo.mfiManDuration != sManDuration) bValidContents = false;
          if (mMInfo.mfiManName != sManName) bValidContents = false;
          if (mMInfo.mfiManId != sManId) bValidContents = false;
          if (mMInfo.mfiManPathName != sManPathName) bValidContents = false;
          if (mMInfo.mfiManPathId != sManPathId) bValidContents = false;
          if (mMInfo.mfiManYears != sManYears) bValidContents = false;
          if (mMInfo.mfiManCropsNbr != sManCropsNbr) bValidContents = false;
          if (mMInfo.mfiManCropsNames != sManCropsNames) bValidContents = false;
          if (mMInfo.mfiManCropsDesc != sManCropsDesc) bValidContents = false;
          if (sBOrA == "A") sBOrA = "";
          if (sBOrA == "B") sBOrA = "A";
        }

        // check detail data
        while (sDBOrA != "")
        {
          var mDData = (from MgmtDetailsData in mfData.mfdDDataBAndA where (MgmtDetailsData.mddBOrA == sDBOrA) select MgmtDetailsData).Take(1).SingleOrDefault();
          if (mDData.mddDId != sDDId) bValidContents = false;
          if (mDData.mddDCrop != sDDCrop) bValidContents = false;
          // if (mDData.mddDCropId != 		nDDCropIdl) bValidContents = false;
          if (mDData.mddDOpId != nDDOpId) bValidContents = false;
          if (mDData.mddDManId != nDDManId) bValidContents = false;
          if (mDData.mddDOper != sDDOper) bValidContents = false;
          if (mDData.mddDOperId != nDDOperId) bValidContents = false;
          if (mDData.mddDOperCode != sDDOperCode) bValidContents = false;
          if (mDData.mddDOperCodeDesc != sDDOperCodeDesc) bValidContents = false;
          //if (mDData.mddDDate != sDDDate) bValidContents = false;
          if (mDData.mddDAmt != sDDAmt) bValidContents = false;
          if (mDData.mddDDepth != sDDDepth) bValidContents = false;
          if (sDBOrA == "A") sDBOrA = "";
          if (sDBOrA == "B") sDBOrA = "A";
        }

        log.Info(sMeName + "<<Ending - TestGetManagementData>>");
        if (bValidContents == false)
        { return "Error: File contents not valid."; }
        else
        { return "OK"; }
      }
      catch (Exception ex)
      {
        log.Fatal(ex);
        return "Error: " + ex.Message.ToString();
      }
    }

    public string TestGetSubAReady()
    {
      string sResult = "";
      string sRtn = "OK";
      string sReturnedHsg = "B"; //default hsg
      try
      {
        getAppSettings();
        log.Info(sMeName + "<<Starting - TestGetSubAReady>>");

        //test values
        ProcessCommon.sChkGUID = "aaaaabbbbbcccccc";
        ProcessCommon.sChkXMax = "-84.314106356257639";
        ProcessCommon.sChkYMin = "41.2680696763643";
        ProcessCommon.sChkXMin = "-84.326141756042361";
        ProcessCommon.sChkYMax = "41.275392371506406";
        sResult = getFileValidExists(ProcessCommon.sChkGUID, "soil");
        if (sResult != sRtn) throw new Exception(sResult);

        //subarea processing
        GetSubAreaReady getSubAReady = new GetSubAreaReady();
        sReturnedHsg = getSubAReady.DoSoilFiles(ProcessCommon.sAPEXRunLocation, ProcessCommon.sAPEXSubAreaSubFile, ProcessCommon.sAPEXSoil2110File, ProcessCommon.sAPEXSoilFieldFile);
        if (sReturnedHsg.StartsWith("Error")) throw new Exception(sReturnedHsg);

        log.Info(sMeName + "<<Ending - TestGetSubAReady>>");
        return "OK";
      }
      catch (Exception ex)
      {
          log.Fatal(ex);
        return "Error: " + ex.Message.ToString();
      }
    }

    public string TestGetManagementReady()
    {
      string sResult = "";
      string sRtn = "OK";
      string sReturnedHsg = "B"; //default hsg
      try
      {
        getAppSettings();
        log.Info(sMeName + "<<Starting - TestGetManagementReady>>");

        //these could be local files - maybe it would be quicker
        ManagementsClient mapManClient = new ManagementsClient(ProcessCommon.sAppEndPointServicesManagements);
        ProcessCommon.LstMPCrops = mapManClient.GetMappedCropData();
        ProcessCommon.LstMPOperations = mapManClient.GetMappedOperationData();

        //test values
        string sGUID = "aaaaabbbbbcccccc";
        string sCmzId = "1";
        string sCmz = "";
        string sBOrA = "B";
        string sBManDuration = "1";
        string sBManName = "CMZ 01\\a.Single Year/Single Crop Templates\\Winter Wheat\\winter wheat; FC, st pt, fcult, z1";
        string sBManId = "980";
        string sBManPathName = "";
        string sBManPathId = "59";
        string sBManYears = "1";
        string sBManCropsNbr = "1";
        string sBManCropsNames = "Wheat, winter 7in rows";
        string sBManCropsDesc = "Start: xxx End: xxx";
        string sBCreateDate = "10/7/2013";

        string sAManDuration = "1";
        string sAManName = "CMZ 01\\a.Single Year/Single Crop Templates\\Corn silage\\corn silage;Ffcult,  z1";
        string sAManId = "229";
        string sAManPathName = "";
        string sAManPathId = "13";
        string sAManYears = "1";
        string sAManCropsNbr = "1";
        string sAManCropsNames = "Corn, silage ";
        string sAManCropsDesc = "Start: xxx End: xxx";
        string sACreateDate = "10/7/2013";

        ProcessCommon.sChkGUID = sGUID;
        ProcessCommon.LstChkMFInfoBAndA = new List<MgmtFileInfo>();
        MgmtFileInfo mfBInfo = new MgmtFileInfo()
        {
          mfiGUID = sGUID,
          mfiCmzId = sCmzId,
          mfiCmz = sCmz,
          mfiBOrA = sBOrA,
          mfiManDuration = sBManDuration,
          mfiManName = sBManName,
          mfiManId = sBManId,
          mfiManPathName = sBManPathName,
          mfiManPathId = sBManPathId,
          mfiManYears = sBManYears,
          mfiManCropsNbr = sBManCropsNbr,
          mfiManCropsNames = sBManCropsNames,
          mfiManCropsDesc = sBManCropsDesc,
          mfiCreateDate = sBCreateDate
        };
        ProcessCommon.LstChkMFInfoBAndA.Add(mfBInfo);

        MgmtFileInfo mfAInfo = new MgmtFileInfo()
        {
          mfiGUID = sGUID,
          mfiCmzId = sCmzId,
          mfiCmz = sCmz,
          mfiBOrA = "A",
          mfiManDuration = sAManDuration,
          mfiManName = sAManName,
          mfiManId = sAManId,
          mfiManPathName = sAManPathName,
          mfiManPathId = sAManPathId,
          mfiManYears = sAManYears,
          mfiManCropsNbr = sAManCropsNbr,
          mfiManCropsNames = sAManCropsNames,
          mfiManCropsDesc = sAManCropsDesc,
          mfiCreateDate = sACreateDate
        };
        ProcessCommon.LstChkMFInfoBAndA.Add(mfAInfo);

        sResult = getFileValidExists(ProcessCommon.sChkGUID, "management");
        if (sResult != sRtn) throw new Exception(sResult);

        sResult = getFileValidExists(ProcessCommon.sChkGUID, "lookupcrop");
        if (sResult != sRtn) throw new Exception(sResult);

        //management processing
        GetManagementReady getMgmtReady = new GetManagementReady();
        sResult = getMgmtReady.DoManagementFiles(ProcessCommon.sAPEXRunLocation, ProcessCommon.sAPEXManagementOpcFile,  sReturnedHsg);
        if (sResult.StartsWith("Error")) throw new Exception(sResult);

        log.Info(sMeName + "<<Ending - TestGetManagementReady>>");
        return "OK";
      }
      catch (Exception ex)
      {
          log.Fatal(ex);
        return "Error: " + ex.Message.ToString();
      }
    }

    //this is for local testing
    //public string TestGetOutputNTT()

    public RunNttFileData TestGetOutputNTT()
    {
      string sResult = "";
      string sRtn = "OK";
      try
      {
        getAppSettings();
        log.Info(sMeName + "<<Starting - TestGetOutputNTT>>");

        //get ntt files
        GetOutputNTTFile getOutputNtt = new GetOutputNTTFile();
        sResult = getOutputNtt.GetNTTFile(ProcessCommon.sAPEXRunLocation, ProcessCommon.sAPEXOutBaseNttFile, ProcessCommon.sAPEXOutAltNttFile);

        if (sResult != sRtn) throw new Exception(sResult);

        ProcessCommon.RnfData.RnfDataBAndA = ProcessCommon.LstNttData;

        //this is for local testing
        //return "OK";

        //this is for UI testing
        //no json for now
        //JavaScriptSerializer jssData = new JavaScriptSerializer();
        //return jssData.Serialize(ProcessCommon.RnfData.RnfDataBAndA).ToString();

        log.Info(sMeName + "<<Ending - TestGetOutputNTT>>");
        return ProcessCommon.RnfData;
      }
      catch (Exception ex)
      {
        //this is for local testing
        //StackTrace sTrace = new StackTrace();
        //LogHandler.WriteToErrorFile(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", ex);
        //return "Error: " + ex.Message.ToString();

        log.Fatal(ex);
        // create error info
        ProcessCommon.RnfData = new RunNttFileData();
        ProcessCommon.LstNttData = new List<APEXNttData>();
        APEXNttData anData = new APEXNttData();
        anData.AndBOrA = "Error";
        anData.AndSUB = "Error: " + ex.Message.ToString();
        ProcessCommon.LstNttData.Add(anData);

        ProcessCommon.RnfData.RnfDataBAndA = ProcessCommon.LstNttData;
        return ProcessCommon.RnfData;
      }
    }

    public string TestRunAPEXBat()
    {
      string sResult = "";
      string sRtn = "OK";
      string sRunFile = "";
      try
      {
        getAppSettings();
        log.Info(sMeName + "<<Starting - TestRunAPEXBat>>");

        //APEX processing
        //Create a new process info structure.
        sRunFile = ProcessCommon.SafeBSlashPathEndString(ProcessCommon.sAPEXRunLocation) + ProcessCommon.sAPEXRunFile.ToString();
        System.Diagnostics.ProcessStartInfo psi = new System.Diagnostics.ProcessStartInfo(sRunFile);
        Process p = System.Diagnostics.Process.Start(psi);
        //Wait for the process to end.
        p.WaitForExit();

        //sResult = chk4FilePresent(ProcessCommon.sAPEXRunLocation, ProcessCommon.sAPEXOutBaseNttFile);
        //if (sResult != "OK") { return sResult.ToString(); }

        //sResult = chk4FilePresent(ProcessCommon.sAPEXRunLocation, ProcessCommon.sAPEXOutAltNttFile);
        //if (sResult != "OK") { return sResult.ToString(); }

        ////parse out ntt files into xml for return
        //GetOutputNTTFile getOutputNtt = new GetOutputNTTFile();
        //sReturn = getOutputNtt.GetNTTFile(ProcessCommon.sAPEXRunLocation, ProcessCommon.sAPEXOutBaseNttFile, ProcessCommon.sAPEXOutAltNttFile);

        log.Info(sMeName + "<<Ending - TestRunAPEXBat>>");
        return "OK";
      }
      catch (Exception ex)
      {
        log.Fatal(ex);
        return "Error: " + ex.Message.ToString();
      }
    }

    #endregion

    public void ClientDebug(ClientLogData debugData)
    {
      try
      {
        getAppSettings();

        LogHandler.WriteToClientDebugFile(debugData);

      }
      catch (Exception ex)
      {

        log.Fatal(ex);
        //do nothing
        //return null;
      }
    }

    public void ClientError(ClientLogData errorData)
    {
      try
      {
        getAppSettings();
        LogHandler.WriteToClientErrorFile(errorData);

      }
      catch (Exception ex)
      {
          log.Fatal(ex);
        //do nothing
        //return null;
      }
    }

    private void getAppSettings()
    {
      string sTmp = "";
      int nInteger;
      bool isInteger;
      double nDouble;
      bool isDouble;
      try
      {
        log.Info(sMeName + "<<Starting - getAppSettings>>");

        //set default values
        ProcessCommon.sNTTClimateFileLocation = ProcessCommon.sDefaultNTTClimateFileLocation;
        ProcessCommon.sNTTSoilFileLocation = ProcessCommon.sDefaultNTTSoilFileLocation;
        ProcessCommon.sNTTManagementFileLocation = ProcessCommon.sDefaultNTTManagementFileLocation;
        ProcessCommon.sNTTMapFileLocation = ProcessCommon.sDefaultNTTMapFileLocation;

        ProcessCommon.sAppEndPointServicesHCE = ProcessCommon.sDefaultAppEndPointServicesHCE;
        ProcessCommon.sAppEndPointServicesManagements = ProcessCommon.sDefaultAppEndPointServicesManagements;
        ProcessCommon.sAppEndPointServicesSoils = ProcessCommon.sDefaultAppEndPointServicesSoils;

        ProcessCommon.nWestBC = ProcessCommon.nDefaultWestBC;
        ProcessCommon.nEastBC = ProcessCommon.nDefaultEastBC;
        ProcessCommon.nNorthBC = ProcessCommon.nDefaultNorthBC;
        ProcessCommon.nSouthBC = ProcessCommon.nDefaultSouthBC;
        ProcessCommon.nCellSize = ProcessCommon.nDefaultCellSize;
        ProcessCommon.nNbrRows = ProcessCommon.nDefaultNbrRows;
        ProcessCommon.nNbrColumns = ProcessCommon.nDefaultNbrColumns;
        ProcessCommon.nYearStart = ProcessCommon.nDefaultYearStart;
        ProcessCommon.nYearEnd = ProcessCommon.nDefaultYearEnd;

        ProcessCommon.sAPEXLookupDataFile = ProcessCommon.sDefaultAPEXLookupDataFile;
        ProcessCommon.sAPEXRunLocation = ProcessCommon.sDefaultAPEXRunLocation;
        ProcessCommon.sAPEXRunFile = ProcessCommon.sDefaultAPEXRunFile;
        ProcessCommon.sAPEXSiteSitFile = ProcessCommon.sDefaultAPEXSiteSitFile;
        ProcessCommon.sAPEXWeatherDlyFile = ProcessCommon.sDefaultAPEXWeatherDlyFile;
        ProcessCommon.sAPEXWeatherWthFile = ProcessCommon.sDefaultAPEXWeatherWthFile;
        ProcessCommon.sAPEXSubAreaSubFile = ProcessCommon.sDefaultAPEXSubAreaSubFile;
        ProcessCommon.sAPEXSoil2110File = ProcessCommon.sDefaultAPEXSoil2110File;
        ProcessCommon.sAPEXSoilFieldFile = ProcessCommon.sDefaultAPEXSoilFieldFile;
        ProcessCommon.sAPEXManagementOpcFile = ProcessCommon.sDefaultAPEXManagementOpcFile;
        ProcessCommon.sAPEXOutBaseNttFile = ProcessCommon.sDefaultAPEXOutBaseNttFile;
        ProcessCommon.sAPEXOutAltNttFile = ProcessCommon.sDefaultAPEXOutAltNttFile;

        ProcessCommon.sAppDebug = ProcessCommon.sDefaultAppDebug;
        ProcessCommon.sAppDebugFile = ProcessCommon.sDefaultAppDebugFile;
        ProcessCommon.sAppDebugLocation = ProcessCommon.sDefaultAppDebugLocation;
        ProcessCommon.sAppLogErrors = ProcessCommon.sDefaultAppLogErrors;
        ProcessCommon.sAppLogErrorFile = ProcessCommon.sDefaultAppLogErrorFile;
        ProcessCommon.sAppLogErrorLocation = ProcessCommon.sDefaultAppLogErrorLocation;
        ProcessCommon.sDeleteDebugFiles = ProcessCommon.sDefaultDeleteDebugFiles;
        ProcessCommon.sDeleteDebugAfterDays = ProcessCommon.sDefaultDeleteDebugAfterDays;
        ProcessCommon.sDeleteLOGFiles = ProcessCommon.sDefaultDeleteLOGFiles;
        ProcessCommon.sDeleteLOGAfterDays = ProcessCommon.sDefaultDeleteLOGAfterDays;

        ProcessCommon.sAppClientDebug = ProcessCommon.sDefaultAppDebug;
        ProcessCommon.sAppClientDebugFile = ProcessCommon.sDefaultAppDebugFile;
        ProcessCommon.sAppClientDebugLocation = ProcessCommon.sDefaultAppDebugLocation;
        ProcessCommon.sAppClientLogErrors = ProcessCommon.sDefaultAppLogErrors;
        ProcessCommon.sAppClientLogErrorFile = ProcessCommon.sDefaultAppLogErrorFile;
        ProcessCommon.sAppClientLogErrorLocation = ProcessCommon.sDefaultAppLogErrorLocation;
        ProcessCommon.sDeleteClientDebugFiles = ProcessCommon.sDefaultDeleteDebugFiles;
        ProcessCommon.sDeleteClientDebugAfterDays = ProcessCommon.sDefaultDeleteDebugAfterDays;
        ProcessCommon.sDeleteClientLOGFiles = ProcessCommon.sDefaultDeleteLOGFiles;
        ProcessCommon.sDeleteClientLOGAfterDays = ProcessCommon.sDefaultDeleteLOGAfterDays;

        sTmp = configurationAppSettings.Get("NTTClimateFileLocation");
        if (sTmp.Length > 0) { ProcessCommon.sNTTClimateFileLocation = sTmp; }
        sTmp = configurationAppSettings.Get("NTTSoilFileLocation");
        if (sTmp.Length > 0) { ProcessCommon.sNTTSoilFileLocation = sTmp; }
        sTmp = configurationAppSettings.Get("NTTManagementFileLocation");
        if (sTmp.Length > 0) { ProcessCommon.sNTTManagementFileLocation = sTmp; }
        sTmp = configurationAppSettings.Get("NTTMapFileLocation");
        if (sTmp.Length > 0) { ProcessCommon.sNTTMapFileLocation = sTmp; }

        sTmp = configurationAppSettings.Get("AppEndPointServicesHCE");
        if (sTmp.Length > 0) { ProcessCommon.sAppEndPointServicesHCE = sTmp; }
        sTmp = configurationAppSettings.Get("AppEndPointServicesManagements");
        if (sTmp.Length > 0) { ProcessCommon.sAppEndPointServicesManagements = sTmp; }
        sTmp = configurationAppSettings.Get("AppEndPointServicesSoils");
        if (sTmp.Length > 0) { ProcessCommon.sAppEndPointServicesSoils = sTmp; }

        sTmp = ""; sTmp = configurationAppSettings.Get("WestBC");
        ProcessCommon.TestDouble(sTmp, out isDouble, out nDouble);
        if (isDouble) ProcessCommon.nWestBC = nDouble;
        sTmp = ""; sTmp = configurationAppSettings.Get("EastBC");
        ProcessCommon.TestDouble(sTmp, out isDouble, out nDouble);
        if (isDouble) ProcessCommon.nEastBC = nDouble;
        sTmp = ""; sTmp = configurationAppSettings.Get("NorthBC");
        ProcessCommon.TestDouble(sTmp, out isDouble, out nDouble);
        if (isDouble) ProcessCommon.nNorthBC = nDouble;
        sTmp = ""; sTmp = configurationAppSettings.Get("SouthBC");
        ProcessCommon.TestDouble(sTmp, out isDouble, out nDouble);
        if (isDouble) ProcessCommon.nSouthBC = nDouble;
        sTmp = ""; sTmp = configurationAppSettings.Get("YearStart");
        ProcessCommon.TestInteger(sTmp, out isInteger, out nInteger);
        if (isInteger) ProcessCommon.nYearStart = nInteger;
        sTmp = ""; sTmp = configurationAppSettings.Get("YearEnd");
        ProcessCommon.TestInteger(sTmp, out isInteger, out nInteger);
        if (isInteger) ProcessCommon.nYearEnd = nInteger;
        sTmp = ""; sTmp = configurationAppSettings.Get("NbrRows");
        ProcessCommon.TestInteger(sTmp, out isInteger, out nInteger);
        if (isInteger) ProcessCommon.nNbrRows = nInteger;
        sTmp = ""; sTmp = configurationAppSettings.Get("NbrColumns");
        ProcessCommon.TestInteger(sTmp, out isInteger, out nInteger);
        if (isInteger) ProcessCommon.nNbrColumns = nInteger;
        sTmp = ""; sTmp = configurationAppSettings.Get("CellSize");
        ProcessCommon.TestDouble(sTmp, out isDouble, out nDouble);
        if (isDouble) ProcessCommon.nCellSize = nDouble;

        sTmp = configurationAppSettings.Get("AppDebug");
        if (sTmp.Length > 0) { ProcessCommon.sAppDebug = sTmp; }
        ProcessCommon.TestInteger(ProcessCommon.sAppDebug, out isInteger, out nInteger);
        if (isInteger) { ProcessCommon.nAppDebug = nInteger; } else { ProcessCommon.nAppDebug = 0; }

        sTmp = configurationAppSettings.Get("AppDebugFile");
        if (sTmp.Length > 0) { ProcessCommon.sAppDebugFile = sTmp; }
        sTmp = configurationAppSettings.Get("AppDebugLocation");
        if (sTmp.Length > 0) { ProcessCommon.sAppDebugLocation = sTmp; }
        sTmp = configurationAppSettings.Get("AppLogErrors");
        if (sTmp.Length > 0) { ProcessCommon.sAppLogErrors = sTmp; }
        sTmp = configurationAppSettings.Get("AppLogErrorFile");
        if (sTmp.Length > 0) { ProcessCommon.sAppLogErrorFile = sTmp; }
        sTmp = configurationAppSettings.Get("AppLogErrorLocation");
        if (sTmp.Length > 0) { ProcessCommon.sAppLogErrorLocation = sTmp; }
        sTmp = configurationAppSettings.Get("DeleteDebugFiles");
        if (sTmp.Length > 0) { ProcessCommon.sDeleteDebugFiles = sTmp; }
        sTmp = configurationAppSettings.Get("DeleteDebugAfterDays");
        if (sTmp.Length > 0) { ProcessCommon.sDeleteDebugAfterDays = sTmp; }
        sTmp = configurationAppSettings.Get("DeleteLOGFiles");
        if (sTmp.Length > 0) { ProcessCommon.sDeleteLOGFiles = sTmp; }
        sTmp = configurationAppSettings.Get("DeleteLOGAfterDays");
        if (sTmp.Length > 0) { ProcessCommon.sDeleteLOGAfterDays = sTmp; }

        sTmp = configurationAppSettings.Get("AppClientDebug");
        if (sTmp.Length > 0) { ProcessCommon.sAppClientDebug = sTmp; }
        sTmp = configurationAppSettings.Get("AppClientDebugFile");
        if (sTmp.Length > 0) { ProcessCommon.sAppClientDebugFile = sTmp; }
        sTmp = configurationAppSettings.Get("AppClientDebugLocation");
        if (sTmp.Length > 0) { ProcessCommon.sAppClientDebugLocation = sTmp; }
        sTmp = configurationAppSettings.Get("AppClientLogErrors");
        if (sTmp.Length > 0) { ProcessCommon.sAppClientLogErrors = sTmp; }
        sTmp = configurationAppSettings.Get("AppClientLogErrorFile");
        if (sTmp.Length > 0) { ProcessCommon.sAppClientLogErrorFile = sTmp; }
        sTmp = configurationAppSettings.Get("AppClientLogErrorLocation");
        if (sTmp.Length > 0) { ProcessCommon.sAppClientLogErrorLocation = sTmp; }
        sTmp = configurationAppSettings.Get("DeleteClientDebugFiles");
        if (sTmp.Length > 0) { ProcessCommon.sDeleteClientDebugFiles = sTmp; }
        sTmp = configurationAppSettings.Get("DeleteClientDebugAfterDays");
        if (sTmp.Length > 0) { ProcessCommon.sDeleteClientDebugAfterDays = sTmp; }
        sTmp = configurationAppSettings.Get("DeleteClientLOGFiles");
        if (sTmp.Length > 0) { ProcessCommon.sDeleteClientLOGFiles = sTmp; }
        sTmp = configurationAppSettings.Get("DeleteClientLOGAfterDays");
        if (sTmp.Length > 0) { ProcessCommon.sDeleteClientLOGAfterDays = sTmp; }

        log.Info(sMeName + "<<Ending - getAppSettings>>");
      }
      catch (Exception ex)
      {
          log.Fatal(ex);
        //do nothing
      }
    }

    private string getTestFileNxtSequential()
    {
      bool bFound = true;
      int nFileCount = 1;
      string sTestName = "";
      string sTestFile = "";
      try
      {
        log.Info(sMeName + "<<Starting - getTestFileNxtSequential>>");
        //find next available sequential test file name
        do
        {
          sTestName = string.Format("{0}{1, 3:000}", "test", nFileCount);
          sTestFile = ProcessCommon.SafeBSlashPathEndString(ProcessCommon.sNTTClimateFileLocation) + sTestName.ToString() + ".dat";
          if (!File.Exists(sTestFile)) bFound = false;
          nFileCount += 1;
        } while (bFound == true);

        log.Info(sMeName + "<<Ending - getTestFileNxtSequential>>");
        return sTestName;
      }
      catch (Exception ex)
      {
          log.Fatal(ex);
        //return "Error: " + ex.Message.ToString();
        return "test000.dat";
      }
    }

    private string getFileValidExists(string sGUID, string sType)
    {
      string sRtn = "OK";
      string sTmp = "";
      string sTmp1 = "";
      string sFile = "";
      string sFilename = "";
      string sFileextension = ".dat";
      string sBOrA = "B";
      bool bValidContents = true;
      try
      {
        log.Info(sMeName + "<<Starting - getFileValidExists>>");

        sTmp1 = String.Format("GUID: {0}, Type: {1}", sGUID, sType);
        log.Debug("Params: " + sTmp1);

        switch (sType)
        {
          case "climate": { sFilename = ProcessCommon.sNTTClimateFileLocation; break; }
          case "soil": { sFilename = ProcessCommon.sNTTSoilFileLocation; break; }
          case "management": { sFilename = ProcessCommon.sNTTManagementFileLocation; break; }
          case "lookupcrop": 
            {
              sFilename = ProcessCommon.SafeBSlashPathEndString(ProcessCommon.sNTTMapFileLocation) + ProcessCommon.sAPEXLookupDataFile.ToString();
              sFile = sFilename;
            break;
          }
        }

        log.Debug("sFilename: " + sFilename);

        if (!sFilename.EndsWith("xml")) sFile = ProcessCommon.SafeBSlashPathEndString(sFilename) + sGUID.ToString() + sFileextension;
        if (!File.Exists(sFile))
        {
          log.Debug("sFile: " + sFile + " - not found.");
          return "File not found: " + sFile;
        }

        StreamReader readFileStream = new StreamReader(sFile);
        readFileStream.BaseStream.Seek(0, SeekOrigin.Begin);
        sTmp = readFileStream.ReadToEnd();
        readFileStream.Close();

        switch (sType)
        {
          case "climate": 
            {
              ClimateFileData cfData = new ClimateFileData();
              try
              {
                JavaScriptSerializer jssData = new JavaScriptSerializer();
                cfData = jssData.Deserialize<ClimateFileData>(sTmp);
              }
              catch
              { throw new Exception("Invalid climate data file format."); }

              //validate file contents
              if (cfData.cfdInfo.cfiGUID != ProcessCommon.sChkGUID) bValidContents = false;
              if (cfData.cfdInfo.cfiLat != ProcessCommon.sChkLat) bValidContents = false;
              if (cfData.cfdInfo.cfiLong != ProcessCommon.sChkLong) bValidContents = false;
              if (cfData.cfdInfo.cfiDateFrom != ProcessCommon.sChkDateFrom) bValidContents = false;
              if (cfData.cfdInfo.cfiDateTo != ProcessCommon.sChkDateTo) bValidContents = false;
              if (cfData.cfdInfo.cfiRecCount != cfData.cfdScData.Count().ToString()) bValidContents = false;

              if (bValidContents == false) throw new Exception("Invalid climate data in file.");
              //keep climate
              ProcessCommon.LstSData = cfData.cfdScData;
              break;
            }
          case "soil":
            {
              SoilFileData sfData = new SoilFileData();
              try
              {
                JavaScriptSerializer jssData = new JavaScriptSerializer();
                sfData = jssData.Deserialize<SoilFileData>(sTmp);
              }
              catch
              { throw new Exception("Invalid soil data file format."); }

              //validate file contents
              if (sfData.sfdInfo.sfiGUID != ProcessCommon.sChkGUID) bValidContents = false;
              if (sfData.sfdInfo.sfiXMax != ProcessCommon.sChkXMax) bValidContents = false;
              if (sfData.sfdInfo.sfiYMin != ProcessCommon.sChkYMin) bValidContents = false;
              if (sfData.sfdInfo.sfiXMin != ProcessCommon.sChkXMin) bValidContents = false;
              if (sfData.sfdInfo.sfiYMax != ProcessCommon.sChkYMax) bValidContents = false;
              if (sfData.sfdInfo.sfiRecCount != sfData.sfdDData.Count().ToString()) bValidContents = false;

              if (bValidContents == false) throw new Exception("Invalid soil data in file.");
              //keep soils
              ProcessCommon.LstSCData = new List<SoilComponentsData>();
              ProcessCommon.LstSlayDData = new List<AOISoilLayers>();

              ProcessCommon.LstSCData = sfData.sfdCData;
              ProcessCommon.LstSlayDData = sfData.sfdDData;
              break;
            }          
        case "management": 
            {
              MgmtFileData mfData = new MgmtFileData();
              try
              {
                JavaScriptSerializer jssData = new JavaScriptSerializer();
                mfData = jssData.Deserialize<MgmtFileData>(sTmp);
              }
              catch
              { throw new Exception("Invalid management data file format."); }

              //validate file contents
              List<MgmtFileInfo> lstmfInfo = mfData.mfdInfoBAndA;

              // check internal file info
              while (sBOrA != "")
              {
                var mMInfo = (from MgmtFileInfo in mfData.mfdInfoBAndA where (MgmtFileInfo.mfiBOrA == sBOrA) select MgmtFileInfo).Take(1).SingleOrDefault();
                var mChkMInfo = (from MgmtFileInfo in ProcessCommon.LstChkMFInfoBAndA where (MgmtFileInfo.mfiBOrA == sBOrA) select MgmtFileInfo).Take(1).SingleOrDefault();
                if (mMInfo == null || mChkMInfo == null)
                { throw new Exception("Invalid management data file or validation info format."); }
                
                if (mChkMInfo.mfiGUID != mMInfo.mfiGUID) bValidContents = false;
                if (mChkMInfo.mfiCmz != mMInfo.mfiCmz) bValidContents = false;
                if (mChkMInfo.mfiCmzId != mMInfo.mfiCmzId) bValidContents = false;
                if (mChkMInfo.mfiManDuration != mMInfo.mfiManDuration) bValidContents = false;
                if (mChkMInfo.mfiManName != mMInfo.mfiManName) bValidContents = false;
                if (mChkMInfo.mfiManId != mMInfo.mfiManId) bValidContents = false;
                if (mChkMInfo.mfiManPathName != mMInfo.mfiManPathName) bValidContents = false;
                if (mChkMInfo.mfiManPathId != mMInfo.mfiManPathId) bValidContents = false;
                if (mChkMInfo.mfiManYears != mMInfo.mfiManYears) bValidContents = false;
                if (mChkMInfo.mfiManCropsNbr != mMInfo.mfiManCropsNbr) bValidContents = false;
                if (mChkMInfo.mfiManCropsNames != mMInfo.mfiManCropsNames) bValidContents = false;
                if (mChkMInfo.mfiManCropsDesc != mMInfo.mfiManCropsDesc) bValidContents = false;
                if (mChkMInfo.mfiCreateDate != mMInfo.mfiCreateDate) bValidContents = false;
                if (sBOrA == "A") sBOrA = "";
                if (sBOrA == "B") sBOrA = "A";
              }
              if (bValidContents == false) return "Invalid management file info values.";

              //keep managements
              ProcessCommon.LstMFInfoBAndA = new List<MgmtFileInfo>();
              ProcessCommon.LstMDDataBAndA = new List<MgmtDetailsData>();
              ProcessCommon.LstMFInfoBAndA = mfData.mfdInfoBAndA;
              ProcessCommon.LstMDDataBAndA = mfData.mfdDDataBAndA;
              break; 
            }          
          case "lookupcrop":
            {
              try
              {
                XDocument docLookup = new XDocument();
                docLookup = XDocument.Parse(sTmp.ToString());

                ProcessCommon.LstRlcData = (from c in docLookup.Descendants("RLCropDta")
                                            select new RunLookupCropData(c.Element("rlcdcId").Value, c.Element("rlcdcNbr").Value, c.Element("rlcdcCode").Value, c.Element("rlcdcName").Value, c.Element("rlcdcPlantPop").Value, c.Element("rlcdcHeatUnits").Value, c.Element("rlcdcLUN").Value, c.Element("rlcdcHsgA").Value, c.Element("rlcdcHsgB").Value, c.Element("rlcdcHsgC").Value, c.Element("rlcdcHsgD").Value)).ToList<RunLookupCropData>();
              }
              catch 
              { 
                return "Invalid lookup crop data file format."; 
              }

              if (ProcessCommon.LstRlcData == null)  return "Invalid lookup crop data file values.";

              break;
            }
        }

        log.Info(sMeName + "<<Ending - getFileValidExists>>");
        return sRtn;
      }
      catch (Exception ex)
      {
        log.Debug(ex);
        //return "Error: " + ex.Message.ToString();
        File.Delete(sFile);
        return ex.Message.ToString();
      }
    }

    private string getThisSoilDetail(SoilComponentsData scData)
    {
      string sReturn = "OK";
      int nLoop = 0;
      bool bError = true;
      bool isDouble;
      double nDouble;

      string sTmpMusym = "";
      double sTmpComppct = 0;
      string sTmpCompname = "";
      double sTmpTDEP = -1;
      double sTmpLDEP = 0;
      double sTmpSAND = 0;
      double sTmpSILT = 0;
      double sTmpBD = 0;
      double sTmpOM = 0;
      double sTmpCEC = 0;
      double sTmpPH = 0;
      string sTmpHORIZDESC2 = "";
      double sTmpSLOPEL = 0;
      string sTmpKSAT = "";
      string sTmpALBEDO = "";
      string sTmpCOARSE = "";

      bool bFoundNList = false;
      List<AOISoilCompNames> SoilComps = new List<AOISoilCompNames>();
      double nDepthT = 0;
      double nDepthL = 0;

      double nHighestComppct = 0;
      string sHighestCompname = "";

      List<AOISoilLayers> localSoillayrs = new List<AOISoilLayers>();
      try
      {
        log.Info(sMeName + "<<Starting - getThisSoilDetail>>");

        /*
         * some of the validation should be moved to the get/save SDA query area
         * at this point we should have valid soil detail data and sufficient layers
         * in layer depth sequence
         * from NTTAPEX.vb
         * If layerNumber = 1 Then
         * 'validate if this layer is going to be used for Agriculture Lands
         * If dr1("LDEP") <= 5 And dr1("Sand") = 0 And dr1("Silt") = 0 And dr1("OM") > 25 And dr1("BD") < 0.8 Then
         *   Continue Do
         */

        lstSoilComponents.Clear();
        lstSoillayrs.Clear();
        /*
         * soil layers are added to Soillayrs as found from top to bottom (Hzdept_r and Hzdepb_r)
         * within matching Musym, numerous Compname entries can exist
         * each Compname can have numerous layer entries
         * 2-step Logic (for now):
         * store each different Compname with it's layer entries
         * select one of the Compname entries that starts with depth 0 and ends with depth => 50
         */

        //locate all matching soil symbol in list with valid data
        foreach (SoilDetailsData sDetail in ProcessCommon.LstSDData)
        {
          if (sDetail.sddMusym == scData.scdSymbol && sDetail.sddRvindicator.ToLower() == "yes")
          {
            sTmpMusym = sDetail.sddMusym;
            sTmpComppct = 0;
            sTmpCompname = sDetail.sddCompname;
            sTmpTDEP = -1;
            sTmpLDEP = 0;
            sTmpSAND = 0;
            sTmpSILT = 0;
            sTmpBD = 0;
            sTmpOM = 0;
            sTmpCEC = 0;
            sTmpPH = 0;
            sTmpHORIZDESC2 = "";
            sTmpSLOPEL = 0;
            sTmpKSAT = "";
            sTmpALBEDO = "";
            sTmpCOARSE = "";
            bError = false;
            nLoop = 0;
            do
            {
              ProcessCommon.TestDouble(sDetail.sddComppct_r, out isDouble, out nDouble);
              if (isDouble) { sTmpComppct = nDouble; } else { bError = true; break; }

              ProcessCommon.TestDouble(sDetail.sddHzdept_r, out isDouble, out nDouble);
              if (isDouble) { sTmpTDEP = nDouble; } else { bError = true; break; }

              ProcessCommon.TestDouble(sDetail.sddHzdepb_r, out isDouble, out nDouble);
              if (isDouble) { sTmpLDEP = nDouble; } else { bError = true; break; }

              ProcessCommon.TestDouble(sDetail.sddSandtotal_r, out isDouble, out nDouble);
              if (isDouble) { sTmpSAND = nDouble; } else { bError = true; break; }

              ProcessCommon.TestDouble(sDetail.sddSilttotal_r, out isDouble, out nDouble);
              if (isDouble) { sTmpSILT = nDouble; } else { bError = true; break; }

              sTmpBD = 0;

              ProcessCommon.TestDouble(sDetail.sddOm_r, out isDouble, out nDouble);
              if (isDouble) { sTmpOM = nDouble; } else { bError = true; break; }

              ProcessCommon.TestDouble(sDetail.sddEcec_r, out isDouble, out nDouble);
              if (isDouble) { sTmpCEC = nDouble; } else { sTmpCEC = 0; }

              sTmpPH = 7;
              sTmpHORIZDESC2 = sDetail.sddHydgrp;

              ProcessCommon.TestDouble(sDetail.sddSlope_r, out isDouble, out nDouble);
              if (isDouble) { sTmpSLOPEL = nDouble; } else { bError = true; break; }

              sTmpKSAT = "0";
              sTmpALBEDO = "";
              sTmpCOARSE = "";
              nLoop = 1;
            } while (nLoop == 0);

            //save locally if valid since they may be out of sTmpLDEP sequence
            if (bError != true)
            {
              //AOISoilLayers layr = new AOISoilLayers(sTmpMusym, sTmpComppct, sTmpCompname, 0, sTmpTDEP, sTmpLDEP, sTmpSAND, sTmpSILT, sTmpBD, sTmpOM, sTmpCEC, sTmpPH, sTmpHORIZDESC2, sTmpSLOPEL, sTmpKSAT, sTmpALBEDO, sTmpCOARSE);
              AOISoilLayers layr = new AOISoilLayers()
              {
                SlayMusym = sTmpMusym,
                SlayComppct = sTmpComppct,
                SlayCompname = sTmpCompname,
                SlayLayerNbr = 0,
                SlayTDEP = sTmpTDEP,
                SlayLDEP = sTmpLDEP,
                SlaySAND = sTmpSAND,
                SlaySILT = sTmpSILT,
                SlayBD = sTmpBD,
                SlayOM = sTmpOM,
                SlayCEC = sTmpCEC,
                SlayPH = sTmpPH,
                SlayHORIZDESC2 = sTmpHORIZDESC2,
                SlaySLOPEL = sTmpSLOPEL,
                SlayKSAT = sTmpKSAT,
                SlayALBEDO = sTmpALBEDO,
                SlayCOARSE = sTmpCOARSE
              };
              localSoillayrs.Add(layr);
            }
          }
        }

        //create an entry for each component layer - same Compname and pct
        bool bFound = false;
        foreach (AOISoilLayers aLayr in localSoillayrs)
        {
          bFound = false;
          foreach (AOISoilCompNames aCompName in lstSoilComponents)
          { if (aLayr.SlayCompname == aCompName.SCName) { bFound = true; break; } }
          if (bFound != true)
          {
            AOISoilCompNames sASCN = new AOISoilCompNames(aLayr.SlayCompname, aLayr.SlayComppct, lstSoillayrs);
            lstSoilComponents.Add(sASCN);
            if (sHighestCompname == "")
            {
              sHighestCompname = aLayr.SlayCompname;
              nHighestComppct = aLayr.SlayComppct;
            }
            if (nHighestComppct < aLayr.SlayComppct)
            {
              sHighestCompname = aLayr.SlayCompname;
              nHighestComppct = aLayr.SlayComppct;
            }
          }
        }

        //assign layer# to local entries in low-high sTmpLDEP sequence (what about duplicates???)
        //all layer numbers start as 0 and are assigned a number if they are valid and unique
        double nLowestLayerVal = 9999;
        int nLayerCnt = 0;
        int nLayerNbr = 0;
        int nLayerNbrs = localSoillayrs.Count();
        //do this for each component layer
        foreach (AOISoilCompNames aCompName in lstSoilComponents)
        {
          nLayerCnt = 0;
          if (nLayerNbrs > 0)
          {
            do
            {
              nLayerCnt += 1;
              nLowestLayerVal = 9999;
              //find next low to high using lower depth
              foreach (AOISoilLayers aLayr in localSoillayrs)
              {
                if (aLayr.SlayCompname == aCompName.SCName && aLayr.SlayComppct == aCompName.SCPct && aLayr.SlayLayerNbr == 0)
                {
                  if (nLowestLayerVal == 9999) nLowestLayerVal = aLayr.SlayLDEP;
                  if (nLowestLayerVal > aLayr.SlayLDEP) nLowestLayerVal = aLayr.SlayLDEP; //lowest
                }
              }
              foreach (AOISoilLayers aLayr in localSoillayrs)
              {
                if (aLayr.SlayCompname == aCompName.SCName && aLayr.SlayComppct == aCompName.SCPct && aLayr.SlayLayerNbr == 0 && aLayr.SlayLDEP == nLowestLayerVal)
                {
                  nLayerNbr += 1;
                  aLayr.SlayLayerNbr = nLayerNbr; break;
                }
              }
            } while (nLayerCnt < nLayerNbrs);
          }
        }

        //look through what was found to get a valid component layer
        //start with the already found highest percent
        //return OK if a valid component layer 0 => 50 was found and added to the PF.details
        string sPrevHighCompname = "";
        double nPrevHighPct = 9999;
        foreach (AOISoilCompNames aCompName in lstSoilComponents)
        {
          nDepthT = 9999;
          nDepthL = -1;
          bFoundNList = false;
          foreach (AOISoilLayers aLayr in localSoillayrs)
          {
            if (aLayr.SlayCompname == sHighestCompname) 
            {
              if (aLayr.SlayTDEP < nDepthT) nDepthT = aLayr.SlayTDEP;
              if (aLayr.SlayLDEP > nDepthL) nDepthL = aLayr.SlayLDEP;
            } 
          }
          if (nDepthT == 0 && nDepthL >= 50) //must start with zero and be more than 50
          {
            bFoundNList = true; break;
          }
          if (bFoundNList == true) break;

          //find next highest available component layer
          sPrevHighCompname = sHighestCompname;
          nPrevHighPct = nHighestComppct;
          nHighestComppct = 0;
          sHighestCompname = "";
          foreach (AOISoilLayers aLayr in localSoillayrs)
          {
            if (aLayr.SlayCompname != sPrevHighCompname && aLayr.SlayComppct <= nPrevHighPct)
            {
              if (sHighestCompname == "")
              {
                sHighestCompname = aLayr.SlayCompname;
                nHighestComppct = aLayr.SlayComppct;
              }
              if (nHighestComppct < aLayr.SlayComppct)
              {
                sHighestCompname = aLayr.SlayCompname;
                nHighestComppct = aLayr.SlayComppct;
              }
            }
          }
        }

        if (bFoundNList == true)
        {
          foreach (AOISoilLayers aLayr in localSoillayrs)
          {
            if (aLayr.SlayCompname == sHighestCompname)
            {
              ProcessCommon.LstSlayDData.Add(aLayr);
            }
          }
          log.Info(sMeName + "<<Ending - getThisSoilDetail>>");
          return sReturn;
        }

        log.Info(sMeName + "<<Ending - getThisSoilDetail>>");
        return "Not found";
      }
      catch (Exception ex)
      {
        log.Fatal(ex);
        sReturn = "Error: " + ex.ToString();
      }
      return sReturn;
    }

    private string chk4FilePresent(string sPathName, string sFileName)
    {
      string sReturn = "OK";
      string sFile = "";
      try
      {
        sFile = ProcessCommon.SafeBSlashPathEndString(sPathName) + sFileName.ToString();
        if (!File.Exists(sFile))
        {
          sReturn = "Error: Not found: " + sFile.ToString();
        }

      }
      catch (Exception ex)
      {
        StackTrace sTrace = new StackTrace();
        log.Fatal(ex);
        sReturn = "Error: " + ex.ToString();
      }
      return sReturn;
    }
  }
}
