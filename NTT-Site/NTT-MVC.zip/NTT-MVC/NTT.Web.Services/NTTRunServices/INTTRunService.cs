﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace NTTRunServices
{
  // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IRunService" in both code and config file together.
  [ServiceContract]
  public interface INTTRunService
  {
    [OperationContract]
    string SaveClimateData(string sGUID, string sLat, string sLong, string sDateFrom, string sDateTo);

    [OperationContract]
    List<SoilComponentsData> SaveSoilsData(string sGUID, string sXMax, string sYMin, string sXMin, string sYMax);

    [OperationContract]
    string SaveManagementData(MgmtFileData MFData);

    [OperationContract]
    RunNttFileData RunApexBaseAndAlt(RunParamsData rpData);

    #region Test Methods
    [OperationContract]
    string GetHello();

    [OperationContract]
    string GetHelloSettings();

    [OperationContract]
    string TestSaveClimateData();

    [OperationContract]
    string TestGetClimateData();

    [OperationContract]
    string TestSaveSoilsData();

    [OperationContract]
    string TestGetSoilsData();

    [OperationContract]
    string TestSaveManagementData();

    [OperationContract]
    string TestGetManagementData();

    [OperationContract]
    string TestGetSubAReady();

    [OperationContract]
    string TestGetManagementReady();

    [OperationContract]
    //this is for local testing
    //string TestGetOutputNTT();
    RunNttFileData TestGetOutputNTT();

    [OperationContract]
    string TestRunAPEXBat();
    #endregion

    [OperationContract]
    void ClientDebug(ClientLogData debugData);

    [OperationContract]
    void ClientError(ClientLogData errorData);
  }

  [DataContract]
  public class ClientLogData
  {
    [DataMember]
    public string CLDId { get; set; }
    [DataMember]
    public string CLDModule { get; set; }
    [DataMember]
    public string CLDFunction { get; set; }
    [DataMember]
    public string CLDException { get; set; }
    [DataMember]
    public string CLDMsg { get; set; }
    [DataMember]
    public string CLDLevel { get; set; }
    [DataMember]
    public string CLDIndent { get; set; }
  }


  // Use a data contract as illustrated in the sample below to add composite types to service operations.
  //[DataContract]
  //public class CompositeType
  //{
  //  bool boolValue = true;
  //  string stringValue = "Hello ";

  //  [DataMember]
  //  public bool BoolValue
  //  {
  //    get { return boolValue; }
  //    set { boolValue = value; }
  //  }

  //  [DataMember]
  //  public string StringValue
  //  {
  //    get { return stringValue; }
  //    set { stringValue = value; }
  //  }
  //}
}
