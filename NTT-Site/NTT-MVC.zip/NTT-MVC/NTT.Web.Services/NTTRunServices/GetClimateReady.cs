//---------------------------------------------------
//Summary
//GetClimateReady - Get Climate Files Ready for APEX processing runs.
//---------------------------------------------------
//Revision History
//Rev#  Date     Who   Change history
// 001  10/23/13 HAC   Use already verified/loaded climate data;
//                      From 2011 NTT WNTSCRunServicesCS project source.
//---------------------------------------------------

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Xml;
using System.Xml.Linq;

using NTTRunServices.LogHandlr;
using NTTRunServices.ProcessComn;

namespace NTTRunServices
{
  public class GetClimateReady
  {
    private static string sMeName = "GetClimateReady";
    private static log4net.ILog _log;
    public static log4net.ILog log
    {
        get
        {
            if (_log == null)
            {
                _log = log4net.LogManager.GetLogger("ApplicationLogDBAppender");
            }

            return _log;
        }
    }


    public string DoClimateFiles(string sPathNameOut, string sFileNameSit, string sFileNameDly, string sFileNameDaily)
    {
      string sReturn = "OK";
      string sFileOutSit = "";
      string sFileOutDly = "";
      string sFileOutDaily = "";
      string sTmp = "";
      StringBuilder sbSitInfo = new StringBuilder();
      StringBuilder sbTmp = new StringBuilder();
      StreamReader strmClimateDetail = null;
      StreamWriter swSit = null;
      StreamWriter swDly = null;
      StreamWriter swDaily = null;

      double nOrigLat = 40.12;
      double nOrigLong = 103.17;
      double nOrigElev = 500;
      double nLat = 0;
      double nLong = 0;

      double nDouble;
      bool isDouble;

      try
      {
        ProcessCommon.TestDouble(ProcessCommon.sChkLat, out isDouble, out nDouble);
        if (isDouble) { nLat = nDouble; } else { nLat = nOrigLat; }
        sTmp = ProcessCommon.sChkLong.StartsWith("-") ? ProcessCommon.sChkLong.Substring(1) : ProcessCommon.sChkLong;
        ProcessCommon.TestDouble(sTmp, out isDouble, out nDouble);
        if (isDouble) { nLong = nDouble; } else { nLong = nOrigLong; }

        //format the .sit file
        sFileOutSit = ProcessCommon.SafeBSlashPathEndString(sPathNameOut) + sFileNameSit.ToString();
        if (File.Exists(sFileOutSit)) { File.Delete(sFileOutSit); }

        swSit = new StreamWriter(File.OpenWrite(sFileOutSit));
        //line 1
        sbSitInfo.AppendFormat("{0}{1}{2}", " .sit file Subbasin:1  Date: ", DateTime.Now.ToString(), Environment.NewLine);
        //line 2
        sbSitInfo.Append(Environment.NewLine);
        //line 3
        sbSitInfo.Append(Environment.NewLine);
        //line 4
        //e.g.   40.12  103.17 1395.98     1.0    0.00    0.00    0.00    0.00    0.00
        sbSitInfo.AppendFormat("{0, 8:0.00}{1, 8:0.00}{2, 8:0.00}{3, 8:0.0}{4, 8:0.00}{5, 8:0.00}{6, 8:0.00}{7, 8:0.00}{8, 8:0.00}{9}", nLat, nLong, nOrigElev, 1, 0, 0, 0, 0, 0, Environment.NewLine);
        //lines 5-19
        for (int nCnt = 1; nCnt < 14; nCnt++)
        {  sbSitInfo.Append(Environment.NewLine);  }

        swSit.WriteLine(sbSitInfo.ToString());

        swSit.Close();
        swSit.Dispose();

        //format the entities into .dly and .wth files
        sFileOutDly = ProcessCommon.SafeBSlashPathEndString(sPathNameOut) + sFileNameDly.ToString();
        if (File.Exists(sFileOutDly)) { File.Delete(sFileOutDly); }

        sFileOutDaily = ProcessCommon.SafeBSlashPathEndString(sPathNameOut) + sFileNameDaily.ToString();
        if (File.Exists(sFileOutDaily)) { File.Delete(sFileOutDly); }

        swDly = new StreamWriter(File.OpenWrite(sFileOutDly));
        swDaily = new StreamWriter(File.OpenWrite(sFileOutDaily));

        swDly.WriteLine("GUID .dly file");
        swDly.WriteLine("  241974"); //years and start year

        foreach (ScData scData in ProcessCommon.LstSData)
        {
          //no way to check for upperbound
          //date sequence is year, month day
          //convert raw climate values to celsius
          try
          {
            sbTmp.Remove(0, sbTmp.Length);
            string[] sTemp = scData.Date.Split('/');
            sbTmp.Append(sTemp[2].Substring(0, 4).PadLeft(6));
            sbTmp.Append(string.Format("{0, 2:00}", Convert.ToInt32(sTemp[0])).PadLeft(4));
            sbTmp.Append(string.Format("{0, 2:00}", Convert.ToInt32(sTemp[1])).PadLeft(4));
            sbTmp.Append("".PadLeft(6));
            sbTmp.Append(scData.Max.PadLeft(6));
            sbTmp.Append(scData.Min.PadLeft(6));
            sbTmp.Append(scData.Precip.PadLeft(6));
          }
          catch { throw new ArgumentException("Invalid climate data format in file."); }

          swDly.WriteLine(sbTmp.ToString());
          swDaily.WriteLine(sbTmp.ToString());
        }

        swDly.Close();
        swDly.Dispose();
        swDaily.Close();
        swDaily.Dispose();

      }
      catch (Exception ex)
      {
        log.Fatal(ex);
        sReturn = "Error: " + ex.ToString();
      }
      finally
      {
        if (swSit != null)
        {
          swSit.Close();
          swSit.Dispose();
        }
        if (strmClimateDetail != null)
        {
          strmClimateDetail.Close();
          strmClimateDetail.Dispose();
        }
        if (swDly != null)
        {
          swDly.Close();
          swDly.Dispose();
        }
        if (swDaily != null)
        {
          swDaily.Close();
          swDaily.Dispose();
        }
      }
      return sReturn;
    }
  }
}