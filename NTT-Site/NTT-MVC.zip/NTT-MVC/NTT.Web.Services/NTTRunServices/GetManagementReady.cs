//---------------------------------------------------
//Summary
//GetManagementReady - Get Management Files Ready for APEX processing runs.
//---------------------------------------------------
//Revision History
//Rev#  Date     Who   Change history
// 001  10/30/13 HAC   Use already verified/loaded management data;
//                      From 2011 NTT WNTSCRunServicesCS project source.
//---------------------------------------------------

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Xml;
using System.Xml.Linq;

using NTTRunServices.LogHandlr;
using NTTRunServices.NTTManagementsServiceReference;
using NTTRunServices.ProcessComn;

namespace NTTRunServices
{
  public class GetManagementReady
  {
    private static string sMeName = "GetManagementReady";

    private List<MgmtDetailsData> lstMDCCycle = new List<MgmtDetailsData>();
    private List<MgmtDetailsData> lstMDCCycleMore = new List<MgmtDetailsData>();
    private List<MgmtFileCropCycles> lstMDCCycles = new List<MgmtFileCropCycles>();
    private static log4net.ILog _log;
    public static log4net.ILog log
    {
        get
        {
            if (_log == null)
            {
                _log = log4net.LogManager.GetLogger("ApplicationLogDBAppender");
            }

            return _log;
        }
    }

    //private List<ManagementDetail> ManagementdetalsAlt = null;
    //private List<LookupDataCrop> LookupDataCrps = null;

    public string DoManagementFiles(string sPathNameOut, string sFileNameOpc, string sHsg)
    {
      string sReturn = "OK";
      string sTmp = "";
      string sFile = "";
      string sFileLookup = "";
      string sFileOutManagement = "";
      string sTractorIDNotUsed = "     ";
      string sRtn = "";
      //string sYr = "";
      //string sMo = "";
      //string sDa = "";
      int nYr = 0;
      double nAmtD = 0;
      double nAmtOpv1 = 0;
      double nAmtOpv2 = 0;
      double nAmtOpv3 = 0;
      double nAmtOpv4 = 0;
      double nAmtOpv5 = 0;
      double nAmtOpv6 = 0;
      double nDouble;
      bool isDouble;
      bool bCropFound = false;
      string sHsgValue = "";
      string sManagementNbr = "";
      StringBuilder sbManLines = new StringBuilder();
      StringBuilder sbManLine1 = new StringBuilder();
      StreamWriter swMan = null;

      //List<ManagementDetail> ManagementDet = null;

      try
      {
        log.Info(sMeName + "<<Starting - DoManagementFiles>>");

        /* create new .opc files containing baseline and alternative managements (e.g. A1.opc and A2.opc)
         */
        if (sPathNameOut.Length == 0 ||
            sFileNameOpc.Length == 0)
        { sReturn = "Error: One or more managements parameters missing."; }
        if (sHsg.ToUpper() == "A" ||
            sHsg.ToUpper() == "B" ||
            sHsg.ToUpper() == "C" ||
            sHsg.ToUpper() == "D") { }
        else
        { sReturn = "Error: One or more managements parameters missing."; }

        if (ProcessCommon.nAppDebug > 3)
        {
          log.Debug(sMeName + " MDetails Rows: " + ProcessCommon.LstMDDataBAndA.Count.ToString());
        }

        //take LMOD detail and turn it into APEX detail
        //select by B/A and order by date
        lstMDCCycles = new List<MgmtFileCropCycles>(); //one or more crop years

        for (int nCnt = 1; nCnt < 3; nCnt++)
        {
          var mDData = nCnt == 1 ? (from MgmtDetailsData in ProcessCommon.LstMDDataBAndA orderby MgmtDetailsData.mddDDate where (MgmtDetailsData.mddBOrA == "B") select MgmtDetailsData) : (from MgmtDetailsData in ProcessCommon.LstMDDataBAndA orderby MgmtDetailsData.mddDDate where (MgmtDetailsData.mddBOrA == "A") select MgmtDetailsData);

          //breakout each crop year plant/harvest cycle
          //find planted crop
          lstMDCCycle = new List<MgmtDetailsData>(); //single crop year
          lstMDCCycleMore = new List<MgmtDetailsData>(); //single crop year, after harvest in same crop year

          string sFoundCrop = "";
          string sFoundCropId = "";
          string sFoundCropNa = "";
          bool bFoundHarvest = false;
          string sDateHarvest = ""; ;
          bool bFoundKill = false;
          bool bFoundMore = false;

          sTmp = nCnt == 1 ? "B" : "A";
          log.Debug(sMeName +  "MDetails " + sTmp + " Rows: " + mDData.Count().ToString());


          sFoundCrop = "";
          sFoundCropId = "";
          sFoundCropNa = "";
          bFoundHarvest = false;
          sDateHarvest = ""; ;
          bFoundKill = false;
          bFoundMore = false;

          foreach (MgmtDetailsData mdData in mDData)
          {
            //where to stop for a crop year
            //harvest found - try one more to see if it is a kill
            //does LMOD have a 'kill' entry
            //if harvest found,
            //  lookup found Crop to get the apex id
            //  assign id to all entries in lstMDCCycle
            //  add lstMDCCycle to lstMDCCycles to save this crop year
            //  start a new lstMDCCycle and clear, found crop, harvest and kill

            //just for now - make things work with limited UI and mapping
            //bypass all 'fert' types
            //bypass all 'sprayer' types
            //starts with 'harvest', change to a havest type
            //starts with 'plant' or 'drill', change to plant type

            if (mdData.mddDOper == null || mdData.mddDOperCodeDesc == null) //bypass unmapped operations
            {
                log.Debug(sMeName + " Bypassed null: " + mdData.mddDOperCodeDesc + " DOp: " + mdData.mddDOper);

            }
            else
            {
              //need to do multi-year and more mapping
              if (mdData.mddDOper.ToLower().StartsWith("fert")) { mdData.mddDOperCodeDesc = "fertilize"; }
              else if (mdData.mddDOper.ToLower().StartsWith("harvest")) { mdData.mddDOperCodeDesc = "harvest"; }
              else if (mdData.mddDOper.ToLower().StartsWith("sprayer")) { mdData.mddDOperCodeDesc = "pesticide"; }
              else if (mdData.mddDOper.ToLower().StartsWith("plant")) { mdData.mddDOperCodeDesc = "plant"; }
              else if (mdData.mddDOper.ToLower().StartsWith("drill")) { mdData.mddDOperCodeDesc = "plant"; }
            
              switch (mdData.mddDOperCodeDesc.ToLower())
              {
                case "fertilize":
                  break;
                case "harvest":
                  bFoundHarvest = true; 
                  sDateHarvest = mdData.mddDDate;
                  break;
                //case "harvest once without kill":
                //  //does APEX handle this?
                //  break;
                case "irrigate":
                  break;
                case "kill":
                  bFoundKill = true;
                  break;
                case "pesticide":
                  break;
                //case "plant-drill":
                case "plant":
                  //could be for next year crop
                  if (bFoundHarvest == true)
                  {
                    //previous year already found
                    if (sFoundCrop == "") throw new ArgumentException("Invalid management data - No plant before harvest");
                  }
                  sFoundCrop = mdData.mddDCrop;
                  break;
                case "till":
                  break;
                case "tractor":
                  break;
                default:
                  throw new ArgumentException("Invalid management data - Crop type not mapped: " + mdData.mddDOperCodeDesc);
              }

              if (bFoundMore == true)
              {
                if (bFoundKill == true)
                {
                  //must be last kill opereration for the crop year
                  lstMDCCycle.Add(mdData);
                }
                else
                { lstMDCCycleMore.Add(mdData); }
              }
              else { lstMDCCycle.Add(mdData); }

              if (bFoundHarvest == true) bFoundMore = true;
            }
          }

          //single year
          if (bFoundHarvest == true && sFoundCropId == "")
          {
            var mCrop = (from MappedCrop in ProcessCommon.LstMPCrops where (sFoundCrop == MappedCrop.LCrName) select MappedCrop).Take(1).SingleOrDefault();
            if (mCrop == null) throw new ArgumentException("Invalid management data - Crop not mapped: " + sFoundCrop);
            sFoundCropId = mCrop.ACrId;
            sFoundCropNa = mCrop.ACrName; //4 char apex crop name
          }

          if (bFoundKill != true)
          {
            MgmtDetailsData mdDtaKill = new MgmtDetailsData
            {
              mddBOrA =  nCnt == 1 ? "B" : "A",
              mddDOperCodeDesc = "Kill",
              mddDDate = sDateHarvest
            };
          lstMDCCycle.Add(mdDtaKill);
          }

          MgmtFileCropCycles mCYr = new MgmtFileCropCycles();
          mCYr.mfdDDataCCycle =lstMDCCycle;
          mCYr.mfdDDataBOrA = nCnt == 1 ? "B" : "A";
          mCYr.mfdDDataCropId = sFoundCropId;
          mCYr.mfdDDataCropNa = sFoundCropNa;
          lstMDCCycles.Add(mCYr);

          #region testcode01
          //debug code: next - show contents in log
          if (log.IsDebugEnabled)
          {

            log.DebugFormat("CropYr for CropID: {0} CropNa: {1}", sFoundCropId, sFoundCropNa);
            foreach (MgmtDetailsData mdDta in lstMDCCycle)
            {
              log.DebugFormat("DDate: {0} DOpCDesc: {1} DOp: {2}", mdDta.mddDDate, mdDta.mddDOperCodeDesc, mdDta.mddDOper);
            }
          }
          #endregion

          //get ready for apex
          foreach (MgmtFileCropCycles mCCycles in lstMDCCycles)
          {
            mCCycles.mfDDataCDetail = new List<ManagementDetail>();
            foreach (MgmtDetailsData mdData in mCCycles.mfdDDataCCycle)
            {
              ManagementDetail maDetail = new ManagementDetail();
              int nmaCntNbr = 1;
              int nmaCntYr = 1;

              //possibly different date formats out of LMOD
              //yyyy-mm-dd at this time
              try
              {
                DateTime dtDate = Convert.ToDateTime(mdData.mddDDate);
                maDetail.MAyy = nmaCntYr.ToString();
                maDetail.MAmm = dtDate.Month.ToString();
                maDetail.MAdd = dtDate.Day.ToString();
              }
              catch { throw new ArgumentException("Invalid management data date."); }

              maDetail.MAId = nmaCntNbr.ToString();
              maDetail.MAType = mdData.mddDOperCodeDesc;
              maDetail.MAName = mdData.mddDOper;

              //get IDs based on type
              bool bBypassOp = false;
              switch (mdData.mddDOperCodeDesc.ToLower())
              {
                case "fertilize":
                  //test code here - remove later
                  maDetail.MATillID = "580";
                  maDetail.MAFertID = "1";
                  maDetail.MADepth = "5";
                  maDetail.MAAmt = "50";
                  break;
                case "harvest":
                  var mOperH = (from MappedOperation in ProcessCommon.LstMPOperations where (mdData.mddDOper == MappedOperation.LOpName) select MappedOperation).Take(1).SingleOrDefault();
                  if (mOperH == null) throw new ArgumentException("Invalid management data - Harvest operation not mapped: " + mdData.mddDOper);
                  maDetail.MATillID = mOperH.AOpId;
                  break;
                case "irrigate":
                  bBypassOp = true;
                  break;
                case "kill":
                  maDetail.MATillID = "451";
                  break;
                case "pesticide":
                  bBypassOp = true;
                  break;
                case "plant":
                  var mOperP = (from MappedOperation in ProcessCommon.LstMPOperations where (mdData.mddDOper == MappedOperation.LOpName) select MappedOperation).Take(1).SingleOrDefault();
                  if (mOperP == null) throw new ArgumentException("Invalid management data - Plant operation not mapped: " + mdData.mddDOper);
                  maDetail.MATillID = mOperP.AOpId;

                  var mOperLup = (from RunLookupCropData in ProcessCommon.LstRlcData where (sFoundCropNa == RunLookupCropData.rlcdcCode) select RunLookupCropData).Take(1).SingleOrDefault();
                  if (mOperLup == null) throw new ArgumentException("Invalid management data - Plant lookup not mapped: " + sFoundCropNa);
                  maDetail.MAPlantPop = mOperLup.rlcdcPlantPop;
                  maDetail.MAHeatUnits = mOperLup.rlcdcHeatUnits;
                  maDetail.MALun = mOperLup.rlcdcLUN;
                  //select A,B,C,D needed here...
                  maDetail.MAHsg = mOperLup.rlcdcHsgA;
                  break;
                case "till":
                  var mOperT = (from MappedOperation in ProcessCommon.LstMPOperations where (mdData.mddDOper == MappedOperation.LOpName) select MappedOperation).Take(1).SingleOrDefault();
                  if (mOperT == null) throw new ArgumentException("Invalid management data - Till operation not mapped: " + mdData.mddDOper);
                  maDetail.MATillID = mOperT.AOpId;
                  break;
                case "tractor":
                  bBypassOp = true;
                  break;
                default:
                  throw new ArgumentException("Invalid management data - Crop type not mapped: " + mdData.mddDOperCodeDesc);
              }
              mCCycles.mfDDataCDetail.Add(maDetail);
            }
          }

          //get the cropid for each plant/harvest cycle (crop year)
          //if missing, add a 'kill' entry to the end of the crop year
          //later, apply the cropid to all entries in the crop year
        }

        #region testcode02
        //debug code: next - show contents in log
        //if (ProcessCommon.nAppDebug > 3)
        if(log.IsDebugEnabled)
        {
          foreach (MgmtFileCropCycles mCCycles in lstMDCCycles)
          {
            log.DebugFormat("BorA: {0} Id-Na: {1}-{2}\n", mCCycles.mfdDDataBOrA, mCCycles.mfdDDataCropId, mCCycles.mfdDDataCropNa);
            foreach (ManagementDetail mdDetail in mCCycles.mfDDataCDetail)
            {
              log.DebugFormat("ymd: {0}{1}{2} Ty: {3}\n", mdDetail.MAyy, mdDetail.MAmm, mdDetail.MAdd, mdDetail.MAType);
            }
          }
        }
        #endregion

        // base into A1.opc and alt into A2.opc
        for (int nCnt = 1; nCnt < 3; nCnt++)
        {
          var mCropCycle = nCnt == 1 ? (from MgmtFileCropCycles in lstMDCCycles where (MgmtFileCropCycles.mfdDDataBOrA == "B") select MgmtFileCropCycles).Take(1).SingleOrDefault() : (from MgmtFileCropCycles in lstMDCCycles where (MgmtFileCropCycles.mfdDDataBOrA == "A") select MgmtFileCropCycles).Take(1).SingleOrDefault();

          sbManLines.Remove(0, sbManLines.Length);
          sManagementNbr = sFileNameOpc.Replace("#", nCnt.ToString());

          // into new .opc file
          sFileOutManagement = ProcessCommon.SafeBSlashPathEndString(sPathNameOut) + sManagementNbr.ToString();
          if (File.Exists(sFileOutManagement)) { File.Delete(sFileOutManagement); }

          swMan = new StreamWriter(File.OpenWrite(sFileOutManagement));

          //Note: input data s/b valid at this point
          //line 1
          sbManLines.AppendFormat(" .Opc file created directly by the user. Date: {0} {1}", DateTime.Now.ToString(), Environment.NewLine);
          //line 2
          sbManLines.AppendFormat("{0, 4:0}{1}", "33", Environment.NewLine);

          //line 3 +
          foreach (ManagementDetail mDet in mCropCycle.mfDDataCDetail)
          {
            nAmtOpv1 = 0; nAmtOpv2 = 0; nAmtOpv3 = 0; nAmtOpv4 = 0; nAmtOpv5 = 0; nAmtOpv6 = 0;

            sbManLine1.Remove(0, sbManLine1.Length);
            switch (mDet.MAType.ToLower())
            {
              case "fertilize":
                //Amt to kg
                ProcessCommon.TestDouble(mDet.MAAmt, out isDouble, out nDouble);
                nAmtD = isDouble == true ? nDouble : 0;
                if (nAmtD > 0)
                  nAmtOpv1 = ((nAmtD * ProcessCommon.nLbs2Kg) / ProcessCommon.nAc2Ha);
                //Depth to mm
                ProcessCommon.TestDouble(mDet.MADepth, out isDouble, out nDouble);
                nAmtD = (isDouble == true) ? nDouble : 0;
                nAmtOpv2 = nAmtD > 0 ? nAmtD * ProcessCommon.nIn2Mm : 0;

                sbManLine1.AppendFormat("{0, 5}{1, 8:0.00}{2, 8:0.00}{3, 8:0.00}{4, 8:0.00}{5, 8:0.00}{6, 8:0.00}", mDet.MAFertID, nAmtOpv1, nAmtOpv2, nAmtOpv3, nAmtOpv4, nAmtOpv5, nAmtOpv6);
                break;
              case "harvest":
                sbManLine1.AppendFormat("{0, 5}{1, 8:0.00}{2, 8:0.00}{3, 8:0.00}{4, 8:0.00}{5, 8:0.00}{6, 8:0.00}", mDet.MAFertID, nAmtOpv1, nAmtOpv2, nAmtOpv3, nAmtOpv4, nAmtOpv5, nAmtOpv6);
                break;
              case "irrigate":
                break;
              case "kill":
                sbManLine1.AppendFormat("{0, 5}{1, 8:0.00}{2, 8:0.00}{3, 8:0.00}{4, 8:0.00}{5, 8:0.00}{6, 8:0.00}", mDet.MAFertID, nAmtOpv1, nAmtOpv2, nAmtOpv3, nAmtOpv4, nAmtOpv5, nAmtOpv6);
                break;
              case "pesticide":
                break;
              case "plant":
                //heat units
                ProcessCommon.TestDouble(mDet.MAHeatUnits, out isDouble, out nDouble);
                nAmtOpv1 = (isDouble == true) ? nDouble : 1500;
                //hsg
                ProcessCommon.TestDouble(mDet.MAHsg, out isDouble, out nDouble);
                nAmtOpv2 = (isDouble == true) ? nDouble : 0;
                //plant population
                ProcessCommon.TestDouble(mDet.MAPlantPop, out isDouble, out nDouble);
                nAmtOpv5 = (isDouble == true) ? nDouble : 0;
                sbManLine1.AppendFormat("{0, 5}{1, 8:0.00}{2, 8:-0.0}{3, 8:0.00}{4, 8}{5, 8:0.00}{6, 8:0.00}", mDet.MAFertID, nAmtOpv1, nAmtOpv2, nAmtOpv3, "        ", nAmtOpv5, nAmtOpv6);
                break;
              case "till":
                sbManLine1.AppendFormat("{0, 5}{1, 8:0.00}{2, 8:0.00}{3, 8:0.00}{4, 8:0.00}{5, 8:0.00}{6, 8:0.00}", mDet.MAFertID, nAmtOpv1, nAmtOpv2, nAmtOpv3, nAmtOpv4, nAmtOpv5, nAmtOpv6);
                break;
              case "tractor":
                break;
              default:
                throw new ArgumentException("Invalid management detail - Crop type not mapped: " + mDet.MAType);
            }

            //create only valid entries
            if (sbManLine1.Length > 0)
            {
              sbManLines.AppendFormat("{0, 2}{1, 2}{2, 2}{3, 5}{4, 5}{5, 5}", mDet.MAyy, mDet.MAmm, mDet.MAdd, mDet.MATillID, sTractorIDNotUsed, mCropCycle.mfdDDataCropId);
              sbManLines.Append(sbManLine1.ToString());
              sbManLines.AppendFormat("{0}", Environment.NewLine);
            }
          }

          //output .opc file contents
          swMan.WriteLine(sbManLines.ToString());

          swMan.Close();
          swMan.Dispose();
        }
      }
      catch (Exception ex)
      {
        log.Fatal(ex);
        sReturn = "Error: " + ex.ToString();
      }
      finally
      {
        if (swMan != null)
        {
          swMan.Close();
          swMan.Dispose();
        }
      }
      log.Info(sMeName + "<<Ending - DoManagementFiles>>");

      return sReturn;
    }

  }

  #region Unused
  ////management data source file
  //sFile = ProcessCommon.SafeBSlashPathEndString(sPathName) + sFileName.ToString();
  //if (!File.Exists(sFile))
  //{ sReturn = "Error: Not found: " + sFile.ToString(); }

  ////lookup data source file
  //sFileLookup = ProcessCommon.SafeBSlashPathEndString(sPathNameLookup) + sFileNameLookup.ToString();
  //if (!File.Exists(sFileLookup))
  //{ sReturn = "Error: Not found: " + sFileLookup.ToString(); }

  ////get file contents and convert to xml document
  //strmLookupData = new StreamReader(sFileLookup, false);
  //strmLookupData.BaseStream.Seek(0, SeekOrigin.Begin);
  //sRtn = strmLookupData.ReadToEnd();
  //strmLookupData.Close();

  //XDocument docLookup = new XDocument();
  //docLookup = XDocument.Parse(sRtn.ToString());

  //try
  //{
  //  LookupDataCrps = (from c in docLookup.Descendants("LDCropNfo")
  //                 select new LookupDataCrop(c.Element("LDCropID").Value, c.Element("LDCropNbr").Value, c.Element("LDCropCode").Value, c.Element("LDCropName").Value, c.Element("LDCropPlantPop").Value, c.Element("LDCropHeatUnits").Value, c.Element("LDCropLUN").Value, c.Element("LDCropHsgA").Value, c.Element("LDCropHsgB").Value, c.Element("LDCropHsgC").Value, c.Element("LDCropHsgD").Value)).ToList<LookupDataCrop>();
  //}
  //catch { throw new ArgumentException("Empty lookup crop data file " + sFileLookup.ToString()); }

  //if (LookupDataCrps == null) { throw new ArgumentException(" Error: Empty lookup crop data file " + sFileLookup.ToString()); }

  ////get file contents and convert to xml document
  //strmManagementDetail = new StreamReader(sFile, false);
  //strmManagementDetail.BaseStream.Seek(0, SeekOrigin.Begin);
  //sRtn = strmManagementDetail.ReadToEnd();
  //strmManagementDetail.Close();

  //XDocument doc = new XDocument();
  //doc = XDocument.Parse(sRtn.ToString());

  //try
  //{
  //ManagementdetalsBase = (from c in doc.Descendants("MDBaseNfo")
  //    select new ManagementDetail(c.Element("evtId").Value, c.Element("evtYYMMDD").Value, c.Element("evtType").Value, c.Element("evtName").Value, c.Element("evtAmt").Value, c.Element("evtTillID").Value, c.Element("evtCropID").Value, c.Element("evtFertID").Value, c.Element("evtDepth").Value)).ToList<ManagementDetail>();
  //}
  //catch { throw new ArgumentException("Empty management baseline data file " + sFile.ToString()); }

  //if (ManagementdetalsBase == null) { throw new ArgumentException(" Error: Empty management baseline data file " + sFile.ToString()); }

  //try
  //{
  //  ManagementdetalsAlt = (from c in doc.Descendants("MDAltNfo")
  //    select new ManagementDetail(c.Element("evtId").Value, c.Element("evtYYMMDD").Value, c.Element("evtType").Value, c.Element("evtName").Value, c.Element("evtAmt").Value, c.Element("evtTillID").Value, c.Element("evtCropID").Value, c.Element("evtFertID").Value, c.Element("evtDepth").Value)).ToList<ManagementDetail>();
  //}
  //catch { throw new ArgumentException("Empty management alternate data file " + sFile.ToString()); }

  //if (ManagementdetalsAlt == null) { throw new ArgumentException(" Error: Empty management alternate data file " + sFile.ToString()); }

  //// base into A1.opc and alt into A2.opc
  //for (int nCnt = 1; nCnt < 3; nCnt++)
  //{
  //  ManagementDet = nCnt == 1 ? ManagementdetalsBase : ManagementdetalsAlt;

  //  sbManLines.Remove(0, sbManLines.Length);
  //  sManagementNbr = sFileNameOpc.Replace("#", nCnt.ToString());

  //  // into new .opc file
  //  sFileOutManagement = ProcessCommon.SafeBSlashPathEndString(sPathNameOut) + sManagementNbr.ToString();
  //  if (File.Exists(sFileOutManagement)) { File.Delete(sFileOutManagement); }

  //  swMan = new StreamWriter(File.OpenWrite(sFileOutManagement));

  //  //Note: input data s/b valid at this point

  //  //line 1
  //  sbManLines.AppendFormat(" .Opc file created directly by the user. Date: {0} {1}", DateTime.Now.ToString(), Environment.NewLine);
  //  //line 2
  //  sbManLines.AppendFormat("{0, 4:0}{1}", "33", Environment.NewLine);

  //  //line 3 +
  //  foreach (ManagementDetail mDet in ManagementDet)
  //  {
  //    nAmtOpv1 = 0; nAmtOpv2 = 0; nAmtOpv3 = 0; nAmtOpv4 = 0; nAmtOpv5 = 0; nAmtOpv6 = 0;
  //    sYr = ""; sMo = ""; sDa = ""; nYr = 0;
  //    if (mDet.MAyymmdd.Length == 6)
  //    {
  //      sYr = mDet.MAyymmdd.Substring(0, 2);
  //      sMo = mDet.MAyymmdd.Substring(2, 2);
  //      sDa = mDet.MAyymmdd.Substring(4, 2);
  //      if (int.TryParse(sYr, out nYr))
  //      {
  //        if (nYr > 10) nYr = nYr - 73;
  //      }
  //    }
  //    if (nYr == 0) throw new ArgumentException("Invalid management data date in file " + sFile.ToString());

  //    sbManLines.AppendFormat("{0, 2}{1, 2}{2, 2}{3, 5}{4, 5}{5, 5}", nYr.ToString(), sMo, sDa, mDet.MATillID, sTractorIDNotUsed, mDet.MACropID);

  //    switch (mDet.MAType.ToUpper())
  //    {
  //      case "HARV":
  //        sbManLines.AppendFormat("{0, 5}{1, 8:0.00}{2, 8:0.00}{3, 8:0.00}{4, 8:0.00}{5, 8:0.00}{6, 8:0.00}", mDet.MAFertID, nAmtOpv1, nAmtOpv2, nAmtOpv3, nAmtOpv4, nAmtOpv5, nAmtOpv6);
  //        break;

  //      case "KILL":
  //        sbManLines.AppendFormat("{0, 5}{1, 8:0.00}{2, 8:0.00}{3, 8:0.00}{4, 8:0.00}{5, 8:0.00}{6, 8:0.00}", mDet.MAFertID, nAmtOpv1, nAmtOpv2, nAmtOpv3, nAmtOpv4, nAmtOpv5, nAmtOpv6);
  //        break;

  //      case "NUTC": // kg/ha of fertilizer and Depth of fertilizer applied
  //        ProcessCommon.TestDouble(mDet.MAAmt, out isDouble, out nDouble);
  //        if (isDouble) { nAmtD = nDouble; } else { nAmtD = 0; }
  //        if (nAmtD > 0)
  //          nAmtOpv1 = ((nAmtD * ProcessCommon.nLbs2Kg) / ProcessCommon.nAc2Ha);

  //        // Note: mDet.MADepth is already in mm
  //        ProcessCommon.TestDouble(mDet.MADepth, out isDouble, out nDouble);
  //        if (isDouble) { nAmtD = nDouble; } else { nAmtD = 0; }
  //        //nAmtOpv2 = nAmtD > 0 ? nAmtD * ProcessCommon.nIn2Mm : ProcessCommon.nIn2Mm;
  //        nAmtOpv2 = nAmtD > 0 ? nAmtD : ProcessCommon.nIn2Mm;

  //        sbManLines.AppendFormat("{0, 5}{1, 8:0.00}{2, 8:0.00}{3, 8:0.00}{4, 8:0.00}{5, 8:0.00}{6, 8:0.00}", mDet.MAFertID, nAmtOpv1, nAmtOpv2, nAmtOpv3, nAmtOpv4, nAmtOpv5, nAmtOpv6);
  //        break;

  //      case "PLNT":
  //        bCropFound = false;
  //        foreach (LookupDataCrop LUCrop in LookupDataCrps)
  //        {
  //          // can't use the name here
  //          // if (mDet.MAName.ToUpper() == LUCrop.LDcCode.ToUpper() && mDet.MACropID == LUCrop.LDcNbr)

  //          if (mDet.MACropID == LUCrop.LDcNbr)
  //          {
  //            ProcessCommon.TestDouble(LUCrop.LDcHeatUnits, out isDouble, out nDouble);
  //            if (isDouble) { nAmtOpv1 = nDouble; } else { nAmtOpv1 = 1500; }

  //            //use soil hsg value to match lookup - how to check for valid value?
  //            switch (sHsg.ToUpper())
  //            {
  //              case "A":
  //                sHsgValue = LUCrop.LDcHsgA; break;
  //              case "B":
  //                sHsgValue = LUCrop.LDcHsgB; break;
  //              case "C":
  //                sHsgValue = LUCrop.LDcHsgC; break;
  //              case "D":
  //                sHsgValue = LUCrop.LDcHsgD; break;
  //            }
  //            ProcessCommon.TestDouble(sHsgValue, out isDouble, out nDouble);
  //            if (isDouble) { nAmtOpv2 = nDouble; } else { nAmtOpv2 = 0; }
  //            ProcessCommon.TestDouble(LUCrop.LDcPlantPop, out isDouble, out nDouble);
  //            if (isDouble) { nAmtOpv5 = nDouble; } else { nAmtOpv5 = 0; }

  //            sbManLines.AppendFormat("{0, 5}{1, 8:0.00}{2, 8:-0.0}{3, 8:0.00}{4, 8}{5, 8:0.00}{6, 8:0.00}", mDet.MAFertID, nAmtOpv1, nAmtOpv2, nAmtOpv3, "        ", nAmtOpv5, nAmtOpv6);
  //            bCropFound = true; break;
  //          }
  //        }
  //        if (bCropFound == false) throw new ArgumentException("Invalid management data crop in file " + sFile.ToString());
  //        break;

  //      case "TILL":
  //        sbManLines.AppendFormat("{0, 5}{1, 8:0.00}{2, 8:0.00}{3, 8:0.00}{4, 8:0.00}{5, 8:0.00}{6, 8:0.00}", mDet.MAFertID, nAmtOpv1, nAmtOpv2, nAmtOpv3, nAmtOpv4, nAmtOpv5, nAmtOpv6);
  //        break;

  //      default:
  //        throw new ArgumentException("Invalid management data type in file " + sFile.ToString());
  //    }
  //    sbManLines.AppendFormat("{0}", Environment.NewLine);

  //} //end for


  //  //output .opc file contents
  //  swMan.WriteLine(sbManLines.ToString());

  //  swMan.Close();
  //  swMan.Dispose();
  //}

  #endregion

}