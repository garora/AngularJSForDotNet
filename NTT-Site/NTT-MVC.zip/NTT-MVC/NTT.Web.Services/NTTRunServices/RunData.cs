using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NTTRunServices
{
  public class RunData
  {
  }

#region Climate processing
  public class ClimateFileData
  {
    public ClimateFileInfo cfdInfo { get; set; }
    public List<ScData> cfdScData { get; set; }
  }

  public class ClimateFileInfo
  {
    public string cfiGUID { get; set; }
    public string cfiLat { get; set; }
    public string cfiLong { get; set; }
    public string cfiDateFrom { get; set; }
    public string cfiDateTo { get; set; }
    public string cfiValidDays { get; set; }
    public string cfiRecCount { get; set; }
    public string cfiCreateDate { get; set; }
  }

  public class ScData
  {
    public string Date { get; set; }
    public string Min { get; set; }
    public string Max { get; set; }
    public string Precip { get; set; }
  }
  #endregion

#region Soil processing
  public class SoilFileData
  {
    public SoilFileInfo sfdInfo { get; set; }
    public List<SoilComponentsData> sfdCData { get; set; }
    public List<AOISoilLayers> sfdDData { get; set; }
  }

  public class SoilFileInfo
  {
    public string sfiGUID { get; set; }
    public string sfiXMax { get; set; }
    public string sfiYMin { get; set; }
    public string sfiXMin { get; set; }
    public string sfiYMax { get; set; }
    public string sfiSoilType { get; set; }
    public string sfiRecCount { get; set; }
    public string sfiCreateDate { get; set; }
  }

  public class SoilComponentsData
  {
    public string scdSSA { get; set; }
    public string scdSymbol { get; set; }
    public string scdName { get; set; }
    public string scdAcres { get; set; }
    public string scdPercent { get; set; }
    public string scdSlope { get; set; }
    public string scdPH { get; set; }
    public string scdStatus { get; set; }
  }

  public class SoilDetailsData
  {
    public string sddSaversion { get; set; }
    public string sddSaverest { get; set; }
    public string sddAreasymbol { get; set; }
    public string sddAreaname { get; set; }
    public string sddMusym { get; set; }
    public string sddMuname { get; set; }
    public string sddMuseq { get; set; }
    public string sddMukey { get; set; }
    public string sddComppct_r { get; set; }
    public string sddCompname { get; set; }
    public string sddSlope_r { get; set; }
    public string sddCokey { get; set; }
    public string sddHydricrating { get; set; }
    public string sddHydgrp { get; set; }
    public string sddHzdept_r { get; set; }
    public string sddHzdepb_r { get; set; }
    public string sddChkey { get; set; }
    public string sddSandtotal_r { get; set; }
    public string sddSilttotal_r { get; set; }
    public string sddClaytotal_r { get; set; }
    public string sddOm_r { get; set; }
    public string sddEcec_r { get; set; }
    public string sddAwc_r { get; set; }
    public string sddKffact { get; set; }
    public string sddKwfact { get; set; }
    public string sddTexdesc { get; set; }
    public string sddTexture { get; set; }
    public string sddStratextsflag { get; set; }
    public string sddRvindicator { get; set; }
    public string sddTexcl { get; set; }
  }

  public class AOISoilLayers
  {
    public string SlayMusym { get; set; }
    public double SlayComppct { get; set; }
    public string SlayCompname { get; set; }
    public int SlayLayerNbr { get; set; }
    public double SlayTDEP { get; set; }
    public double SlayLDEP { get; set; }
    public double SlaySAND { get; set; }
    public double SlaySILT { get; set; }
    public double SlayBD { get; set; }
    public double SlayOM { get; set; }
    public double SlayCEC { get; set; }
    public double SlayPH { get; set; }
    public string SlayHORIZDESC2 { get; set; }
    public double SlaySLOPEL { get; set; }
    public string SlayKSAT { get; set; }
    public string SlayALBEDO { get; set; }
    public string SlayCOARSE { get; set; }
  }

  public class AOISoilCompNames
  {
    public string SCName;
    public double SCPct;
    public List<AOISoilLayers> SoilComplayrs;

    public AOISoilCompNames(string sSCName, double sSCPct, List<AOISoilLayers> sSoilComplayrs)
    {
      SCName = sSCName;
      SCPct = sSCPct;
      SoilComplayrs = sSoilComplayrs;
    }
  }

#endregion

#region Managements processing
  public class MgmtFileCropCycles
  {
    public List<MgmtDetailsData> mfdDDataCCycle { get; set; }
    public List<ManagementDetail> mfDDataCDetail { get; set; }
    public string mfdDDataBOrA { get; set; }
    public string mfdDDataCropId { get; set; }
    public string mfdDDataCropNa { get; set; }
  }

  public class MgmtFileData
  {
    public List<MgmtFileInfo> mfdInfoBAndA { get; set; }
    public List<MgmtDetailsData> mfdDDataBAndA { get; set; }
  }

  public class MgmtFileInfo
  {
    public string mfiGUID { get; set; }
    public string mfiCmzId { get; set; }
    public string mfiCmz { get; set; }
    public string mfiBOrA { get; set; }
    public string mfiManDuration { get; set; }
    public string mfiManName { get; set; }
    public string mfiManId { get; set; }
    public string mfiManPathName { get; set; }
    public string mfiManPathId { get; set; }
    public string mfiManYears { get; set; }
    public string mfiManCropsNbr { get; set; }
    public string mfiManCropsNames { get; set; }
    public string mfiManCropsDesc { get; set; }
    public string mfiCreateDate { get; set; }
  }

  public class MgmtDetailsData
  {
    public string mddBOrA { get; set; }
    public string mddDId { get; set; }
    public string mddDCrop { get; set; }
    public int? mddDCropId { get; set; }
    public int mddDOpId { get; set; }
    public int mddDManId { get; set; }
    public string mddDOper { get; set; }
    public int mddDOperId { get; set; }
    public string mddDOperCode { get; set; }
    public string mddDOperCodeDesc { get; set; }
    public string mddDDate { get; set; }
    public string mddDAmt { get; set; }
    public string mddDDepth { get; set; }
  }

  //from prior crop matrix 
  public class ManagementDetail
  {
    public string MAId { get; set; }
    public string MAyy { get; set; }
    public string MAmm { get; set; }
    public string MAdd { get; set; }
    public string MAType { get; set; }
    public string MAName { get; set; }
    public string MAAmt { get; set; }
    public string MATillID { get; set; }
    public string MACropID { get; set; }
    public string MAFertID { get; set; }
    public string MATracID { get; set; }
    public string MAPestID { get; set; }
    public string MADepth { get; set; }
    public string MAPlantPop { get; set; }
    public string MAHeatUnits { get; set; }
    public string MAHsg { get; set; }
    public string MALun { get; set; }
  }

#endregion

#region APEXRun processing
  public class RunParamsData
  {
    public string rpdGUID { get; set; }
    public string rpdAction { get; set; }
    public string rpdClimateLat { get; set; }
    public string rpdClimateLong { get; set; }
    public string rpdClimateDateFrom { get; set; }
    public string rpdClimateDateTo { get; set; }
    public string rpdSoilsXMax { get; set; }
    public string rpdSoilsYMin { get; set; }
    public string rpdSoilsXMin { get; set; }
    public string rpdSoilsYMax { get; set; }
    public string rpdMgmtCmz { get; set; }
    public List<MgmtFileInfo> rpdMgmtInfoBAndA { get; set; }
  }

  public class RunLookupCropData
  {
    public string rlcdcId;
    public string rlcdcNbr;
    public string rlcdcCode;
    public string rlcdcName;
    public string rlcdcPlantPop;
    public string rlcdcHeatUnits;
    public string rlcdcLUN;
    public string rlcdcHsgA;
    public string rlcdcHsgB;
    public string rlcdcHsgC;
    public string rlcdcHsgD;

    public RunLookupCropData()
    { }

    public RunLookupCropData(string srlcdcId, string srlcdcNbr, string srlcdcCode, string srlcdcName, string srlcdcPlantPop, string srlcdcHeatUnits, string srlcdcLUN, string srlcdcHsgA, string srlcdcHsgB, string srlcdcHsgC, string srlcdcHsgD)
    {
      rlcdcId = srlcdcId;
      rlcdcNbr = srlcdcNbr;
      rlcdcCode = srlcdcCode;
      rlcdcName = srlcdcName;
      rlcdcPlantPop = srlcdcPlantPop;
      rlcdcHeatUnits = srlcdcHeatUnits;
      rlcdcLUN = srlcdcLUN;
      rlcdcHsgA = srlcdcHsgA;
      rlcdcHsgB = srlcdcHsgB;
      rlcdcHsgC = srlcdcHsgC;
      rlcdcHsgD = srlcdcHsgD;
    }
  }

  //anticipating additional elements being added
  public class RunNttFileData
  {
    public List<APEXNttData> RnfDataBAndA { get; set; }
  }

  public class APEXNttData
  {
    public string AndBOrA { get; set; }
    public string AndSUB { get; set; }
    public string AndYEAR { get; set; }
    public string AndPRKN { get; set; }
    public string AndAVOL { get; set; }
    public string AndFLOW { get; set; }
    public string AndSED { get; set; }
    public string AndORGN { get; set; }
    public string AndORGP { get; set; }
    public string AndNO3 { get; set; }
    public string AndPO4 { get; set; }
    public string AndCROP { get; set; }
    public string AndYLD1 { get; set; }
    public string AndYLD2 { get; set; }
    public string AndPRKP { get; set; }
    public string AndField { get; set; }
    public string AndQDR { get; set; }
    public string AndDPRK { get; set; }
    public string AndQDRN { get; set; }
    public string AndN20 { get; set; }
    public string AndCO2 { get; set; }
    public string AndDN { get; set; }
  }

#endregion

}
