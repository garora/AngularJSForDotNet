//---------------------------------------------------
//Summary
//NTTRunServices - Web service for Run data.
//---------------------------------------------------
//Revision History
//Rev#  Date     Who   Change history
// 002  01/28/14 HAC   Add dynamic end point addresses for soils and managements.
// 001  07/22/13 HAC   Initial version;
//---------------------------------------------------

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text; //for StringBuilder
using System.Web;

using NTTRunServices.NTTManagementsServiceReference;
using NTTRunServices.LogHandlr;

namespace NTTRunServices.ProcessComn
{
  public static class ProcessCommon
  {
    private static string sMeName = "ProcessCommon";

    public const double nDefaultWestBC = -125.02083333;
    public const double nDefaultEastBC = -66.47916757;
    public const double nDefaultNorthBC = 49.9375;
    public const double nDefaultSouthBC = 24.0625;
    public const double nDefaultCellSize = 0.04166667;
    public const int nDefaultNbrRows = 621;
    public const int nDefaultNbrColumns = 1405;
    public const int nDefaultYearStart = 1960;
    public const int nDefaultYearEnd = 2001;

    public const double nLbs2Kg = 0.453592;
    public const double nAc2Ha = 0.404686;
    public const double nIn2Mm = 25.4;

    public static string sDefaultNTTClimateFileLocation = @"C:\A-NTTRunLocation\ClimateFiles";
    public static string sDefaultNTTSoilFileLocation = @"C:\A-NTTRunLocation\SoilFiles";
    public static string sDefaultNTTManagementFileLocation = @"C:\A-NTTRunLocation\ManagementFiles";
    public static string sDefaultNTTMapFileLocation = @"C:\A-NTTRunLocation\MapFiles";

    public static string sDefaultAppEndPointServicesHCE = "Service1Soap_Dev";
    public static string sDefaultAppEndPointServicesManagements = "BasicHttpBinding_IManagements_Dev";
    public static string sDefaultAppEndPointServicesSoils = "BasicHttpBinding_ISoilComponentService_Dev";

    public static string sDefaultAPEXLookupDataFile = "APEXLookupData.xml";
    public static string sDefaultAPEXRunLocation = @"C:\A-APEX4NTT\RunAPEXModel";
    public static string sDefaultAPEXRunFile = "RunAPEX.bat";
    public static string sDefaultAPEXSiteSitFile = "ZN-Field.sit";
    public static string sDefaultAPEXWeatherDlyFile = "ZN-Field.dly";
    public static string sDefaultAPEXWeatherWthFile = "ZN-Field.wth";
    public static string sDefaultAPEXSubAreaSubFile = "ZN-FIELD.sub";
    public static string sDefaultAPEXSoil2110File = "SOIL2110.dat";
    public static string sDefaultAPEXSoilFieldFile = "ZN-FIELD###.sol";
    public static string sDefaultAPEXManagementOpcFile = "A#.opc";
    public static string sDefaultAPEXOutBaseNttFile = "ZO1FIELD.ntt";
    public static string sDefaultAPEXOutAltNttFile = "ZO2FIELD.ntt";

    //soils
    public static List<SoilComponentsData> LstSCData = new List<SoilComponentsData>(); //returned to UI
    public static List<SoilDetailsData> LstSDData = new List<SoilDetailsData>();
    public static List<AOISoilLayers> LstSlayDData = new List<AOISoilLayers>();
    //climate
    public static List<ScData> LstSData = new List<ScData>();
    //managements
    public static List<MgmtFileInfo> LstMFInfoBAndA = new List<MgmtFileInfo>();
    public static List<MgmtDetailsData> LstMDDataBAndA = new List<MgmtDetailsData>();
    //mapped
    public static List<MappedCrop> LstMPCrops = new List<MappedCrop>();
    public static List<MappedOperation> LstMPOperations = new List<MappedOperation>();

    //run params and data
    public static RunNttFileData RnfData = new RunNttFileData();
    public static List<RunLookupCropData> LstRlcData = new List<RunLookupCropData>();
    public static List<APEXNttData> LstNttData = new List<APEXNttData>();

    public static string sDefaultAppDebug = "0";
    public static string sDefaultAppDebugFile = "NTTRunDebugLog";
    public static string sDefaultAppDebugLocation = @"C:\A-NTTRunLocation\DebugLogs";
    public static string sDefaultAppLogErrors = "Y";
    public static string sDefaultAppLogErrorFile = "NTTRunErrorLog";
    public static string sDefaultAppLogErrorLocation = @"C:\A-NTTRunLocation\ErrorLogs";
    public static string sDefaultDeleteDebugFiles = "N";
    public static string sDefaultDeleteDebugAfterDays = "2";
    public static string sDefaultDeleteLOGFiles = "N";
    public static string sDefaultDeleteLOGAfterDays = "2";

    public static string sDefaultAppClientDebug = "0";
    public static string sDefaultAppClientDebugFile = "NTTClientDebugLog";
    public static string sDefaultAppClientDebugLocation = @"C:\A-NTTRunLocation\ClientDebugLogs";
    public static string sDefaultAppClientLogErrors = "Y";
    public static string sDefaultAppClientLogErrorFile = "NTTClientErrorLog";
    public static string sDefaultAppClientLogErrorLocation = @"C:\A-NTTRunLocation\ClientErrorLogs";
    public static string sDefaultDeleteClientDebugFiles = "N";
    public static string sDefaultDeleteClientDebugAfterDays = "2";
    public static string sDefaultDeleteClientLOGFiles = "N";
    public static string sDefaultDeleteClientLOGAfterDays = "2";

    public static double nWestBC = -125.02083333;
    public static double nEastBC = -66.47916757;
    public static double nNorthBC = 49.9375;
    public static double nSouthBC = 24.0625;
    public static double nCellSize = 0.04166667;
    public static int nNbrRows = 621;
    public static int nNbrColumns = 1405;
    public static int nYearStart = 1960;
    public static int nYearEnd = 2001;

    public static string sNTTClimateFileLocation = "";
    public static string sNTTSoilFileLocation = "";
    public static string sNTTManagementFileLocation = "";
    public static string sNTTMapFileLocation = "";

    public static string sAppEndPointServicesHCE = "";
    public static string sAppEndPointServicesManagements = "";
    public static string sAppEndPointServicesSoils = "";

    public static string sAPEXLookupDataFile = "";
    public static string sAPEXRunLocation = "";
    public static string sAPEXRunFile = "";
    public static string sAPEXSiteSitFile = "";
    public static string sAPEXWeatherDlyFile = "";
    public static string sAPEXWeatherWthFile = "";
    public static string sAPEXSubAreaSubFile = "";
    public static string sAPEXSoil2110File = "";
    public static string sAPEXSoilFieldFile = "";
    public static string sAPEXManagementOpcFile = "";
    public static string sAPEXOutBaseNttFile = "";
    public static string sAPEXOutAltNttFile = "";

    public static string sAppDebug = "";
    public static int nAppDebug = 0;
    public static string sAppDebugFile = "";
    public static string sAppDebugLocation = "";
    public static string sAppLogErrors = "";
    public static string sAppLogErrorFile = "";
    public static string sAppLogErrorLocation = "";
    public static string sDeleteDebugFiles = "";
    public static string sDeleteDebugAfterDays = "";
    public static string sDeleteLOGFiles = "";
    public static string sDeleteLOGAfterDays = "";

    public static string sAppClientDebug = "";
    public static string sAppClientDebugFile = "";
    public static string sAppClientDebugLocation = "";
    public static string sAppClientLogErrors = "";
    public static string sAppClientLogErrorFile = "";
    public static string sAppClientLogErrorLocation = "";
    public static string sDeleteClientDebugFiles = "";
    public static string sDeleteClientDebugAfterDays = "";
    public static string sDeleteClientLOGFiles = "";
    public static string sDeleteClientLOGAfterDays = "";

    //validate files before run process
    public static string sChkGUID = "";
    public static string sChkLat = "";
    public static string sChkLong = "";
    public static string sChkDateFrom = "";
    public static string sChkDateTo = "";
    public static string sChkXMax = "";
    public static string sChkYMin = "";
    public static string sChkXMin = "";
    public static string sChkYMax = "";

    public static string sChkCmz = "";
    public static List<MgmtFileInfo> LstChkMFInfoBAndA = new List<MgmtFileInfo>();

    private static string sValue;

    public static StringBuilder sbLogMessage = new StringBuilder();

    public static string SafeBSlashPathEndString(string strValue)
    {
      try
      {
        sValue = strValue;

        if (!strValue.EndsWith("\\"))
        {
          sValue = strValue.ToString() + "\\";
          return sValue;
        }
        else { return sValue; }
      }
      catch (Exception ex)
      {
        StackTrace sTrace = new StackTrace();
        LogHandler.WriteToErrorFile(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", ex);
        throw ex;
      }
    }

    public static void TestDouble(string sValue, out bool isDouble, out double nDouble)
    {
      try
      {
        isDouble = false; nDouble = 0;
        isDouble = double.TryParse(sValue, out nDouble);
      }
      catch (Exception ex)
      {
        StackTrace sTrace = new StackTrace();
        LogHandler.WriteToErrorFile(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", ex);
        throw ex;
      }
    }

    public static void TestInteger(string sValue, out bool isInteger, out int nInt)
    {
      try
      {
        isInteger = false; nInt = 0;
        isInteger = int.TryParse(sValue, out nInt);
      }
      catch (Exception ex)
      {
        StackTrace sTrace = new StackTrace();
        LogHandler.WriteToErrorFile(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", ex);
        throw ex;
      }
    }

    public static void TestDate(string sValue, out bool isDate, out DateTime dtDate)
    {
      try
      {
        isDate = false; dtDate = new DateTime(1900, 1, 1);
        isDate = DateTime.TryParse(sValue, out dtDate);
      }
      catch (Exception ex)
      {
        StackTrace sTrace = new StackTrace();
        LogHandler.WriteToErrorFile(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", ex);
        throw ex;
      }
    }

  }
}