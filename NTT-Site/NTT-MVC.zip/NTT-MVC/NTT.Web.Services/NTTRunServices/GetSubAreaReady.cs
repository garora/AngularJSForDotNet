//---------------------------------------------------
//Summary
//GetSubAreaReady - Get Soils Files Ready for APEX processing runs.
//---------------------------------------------------
//Revision History
//Rev#  Date     Who   Change history
// 001  10/23/13 HAC   Use already verified/loaded soils data;
//                      From 2011 NTT WNTSCRunServicesCS project source.
//---------------------------------------------------

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Xml;
using System.Xml.Linq;

using NTTRunServices.LogHandlr;
using NTTRunServices.ProcessComn;

namespace NTTRunServices
{
  public class GetSubAreaReady
    {
    private static string sMeName = "GetSubAreaReady";
        private static log4net.ILog _log;
        public static log4net.ILog log
        {
            get
            {
                if (_log == null)
                {
                    _log = log4net.LogManager.GetLogger("ApplicationLogDBAppender");
                }

                return _log;
            }
        }

    //private List<AOISoilLayers> Soillayrs = new List<AOISoilLayers>();

    public string DoSoilFiles(string sPathNameOut, string sFileNameSub, string sFileNameSoil2110, string sFileNameSoilField)
    {
      string sReturnHsg = "B"; //default hsg
      string sResult = "";
      string sFile = "";
      string sFileOutSub = "";
      string sFileOutDat = "";
      string sFileOutSol = "";
      string sRtn = "";
      int nSolLineStart = 4;
      int nSolLineNbr = 0;
      int nSolLineMax = 0;
      int nSoilNbr = 0;
      double nTmpAmt = 0;
      string sSoilNbr = "";

      double nHighestComppct = 9999;
      string sHighestCompname = "";

      //double nAcres = 0;
      //double nAcresHa = 0;
      //double nCHL = 0;

      StreamWriter swSub = null;
      StreamWriter swDat = null;
      StreamWriter swSol = null;
      StringBuilder sbSubArea12Lines = new StringBuilder();
      StringBuilder sbDatLines = new StringBuilder();
      StringBuilder sbSolLines = new StringBuilder();
      StringBuilder[] sb30SolLines = new StringBuilder[46]; //1s based

      //for testing w/o calcs
      double nTestAcre = 1.17;
      double nTestCHL = .22;
      double nTestSoilSlope = .13;
      double nTestSlopeLength = 27.43;
      double nTestrCHL = .22;
      double nDrainDepthmm = 0;

      try
      {
        /* create a new .sub file containing each valid soil (e.g. ZN-FIELD.sub)
         * create a new soil .dat file containing each valid soil (e.g. SOIL2110.dat)
         * create a separate soil .sol for each valid soil (ZN-FIELD001.sol)
         */
        if (sPathNameOut.Length == 0 ||
            sFileNameSub.Length == 0 ||
            sFileNameSoil2110.Length == 0 ||
            sFileNameSoilField.Length == 0)
        { throw new ArgumentException("One or more soil parameters missing."); }

          for (int nCnt = 1; nCnt <= sb30SolLines.GetUpperBound(0); nCnt++)
          { sb30SolLines[nCnt] = new StringBuilder(); }

          //format the entities into .sub and .sol files
          sFileOutSub = ProcessCommon.SafeBSlashPathEndString(sPathNameOut) + sFileNameSub.ToString();
          if (File.Exists(sFileOutSub)) { File.Delete(sFileOutSub); }
          sFileOutDat = ProcessCommon.SafeBSlashPathEndString(sPathNameOut) + sFileNameSoil2110.ToString();
          if (File.Exists(sFileOutDat)) { File.Delete(sFileOutDat); }

          swSub = new StreamWriter(File.OpenWrite(sFileOutSub));
          swDat = new StreamWriter(File.OpenWrite(sFileOutDat));

          sbDatLines.Remove(0, sbDatLines.Length);

          //foreach (AOISoils aois in Soildets)
          foreach (SoilComponentsData scData in ProcessCommon.LstSCData)
          {
            //if (scData.scdSymbol.ToLower() == "totals") { continue; }; //not used in this later version
            //if (scData.scdStatus.ToLower() != "ok") { continue; }; //not used in this later version

            //find highest percentage details for each soil component layer
            //this.Soillayrs.Clear();

            //just do it here
            var sLayrs = from aLayr in ProcessCommon.LstSlayDData
                         orderby aLayr.SlayComppct descending, aLayr.SlayLayerNbr
                         where aLayr.SlayMusym == scData.scdSymbol
                         select aLayr;

            if (sLayrs.Count() == 0) { return "Error: Empty or invalid soil details data file " + sFile.ToString(); }
            nHighestComppct = 9999;
            sHighestCompname = "";

            sbSubArea12Lines.Remove(0, sbSubArea12Lines.Length);
            sbSolLines.Remove(0, sbSolLines.Length);

            nSoilNbr++;
            //line 1
            sbSubArea12Lines.AppendFormat("{0, 8}{1}{2}{3}", "1", "0000000000000000  .sub file Subbasin:1  Date: ", DateTime.Now.ToString(), Environment.NewLine);
            //line 2
            sbSubArea12Lines.AppendFormat("{0, 4:0}{1}{2}", nSoilNbr, "   1   1   0   0   0   0   0   0   0   0   0", Environment.NewLine);
            //line 3
            sbSubArea12Lines.AppendFormat("{0}{1}", "     .00     .00     0.0     0.0", Environment.NewLine);
            //line 4
            sbSubArea12Lines.AppendFormat("{0, 8:0.00}{1, 8:0.00}{2}{3, 8:0.00}{4, 8:0.00}{5}{6}", nTestAcre, nTestCHL, "     .00   .0258   .0000", nTestSoilSlope, nTestSlopeLength, "   .0000", Environment.NewLine);
            //line 5
            sbSubArea12Lines.AppendFormat("{0, 8:0.00}{1}{2}", nTestrCHL, "                                             .00    .000", Environment.NewLine);
            //line 6
            sbSubArea12Lines.Append(Environment.NewLine);
            //line 7
            sbSubArea12Lines.Append(Environment.NewLine);
            //line 8
            sbSubArea12Lines.AppendFormat("{0}{1, 4}{2}{3}", "   0   0   0   0   0", nDrainDepthmm, "   0   0   0   0   0   0", Environment.NewLine);
            //line 9
            sbSubArea12Lines.AppendFormat("{0}{1}", "     .00     .00     .00                    0.0      .00     0.0", Environment.NewLine);
            //line 10
            sbSubArea12Lines.AppendFormat("{0}{1}", "     1.0     .00                                    000.", Environment.NewLine);
            //line 11
            sbSubArea12Lines.AppendFormat("{0}{1}", "   0", Environment.NewLine);
            //line 12
            //sbSubArea12Lines.AppendFormat("{0}{1}", "    0.00", Environment.NewLine);
            sbSubArea12Lines.AppendFormat("{0}", "    0.00");
            //output .sub file contents
            swSub.WriteLine(sbSubArea12Lines.ToString());

            // into .dat file
            sSoilNbr = string.Format("{0, 3:000}", nSoilNbr);
            sSoilNbr = sFileNameSoilField.Replace("###", sSoilNbr);
            sbDatLines.AppendFormat("{0, 3:000}{1}{2}{3}", nSoilNbr, " ", sSoilNbr, Environment.NewLine);

            // into new .sol file
            sFileOutSol = ProcessCommon.SafeBSlashPathEndString(sPathNameOut) + sSoilNbr.ToString();
            if (File.Exists(sFileOutSol)) { File.Delete(sFileOutSol); }

            swSol = new StreamWriter(File.OpenWrite(sFileOutSol));

            //line 1
            sbSolLines.AppendFormat(" .sol file Soil:{0}  Date: {1} {2}{3}", nSoilNbr.ToString(), DateTime.Now.ToString(), scData.scdName, Environment.NewLine);
            //line 2 some test code for now - need to use actual hsg value within each layer below
            double nAlb = .23;
            int nHsg = 2;
            sbSolLines.AppendFormat("{0, 8:0.00}{1, 7:0}{2}{3}", nAlb, nHsg, ".", Environment.NewLine);
            //line 3 why 10; ask!
            double nMaxLayers = 10;
            sbSolLines.AppendFormat("{0, 8:0.0}{1}", nMaxLayers, Environment.NewLine);

            // .sol line 4 through 30
            nSolLineMax = sb30SolLines.GetUpperBound(0);

            for (nSolLineNbr = nSolLineStart; nSolLineNbr <= nSolLineMax; nSolLineNbr++)
            { sb30SolLines[nSolLineNbr].Remove(0, sb30SolLines[nSolLineNbr].Length); }

            //need to retrieve sequenced low to high layers
            foreach (AOISoilLayers slyr in sLayrs)
            {
              if (nHighestComppct == 9999)
              {
                nHighestComppct = slyr.SlayComppct;
                sHighestCompname = slyr.SlayCompname;
              }
              if (nHighestComppct != slyr.SlayComppct || sHighestCompname != slyr.SlayCompname) break;

              for (nSolLineNbr = nSolLineStart; nSolLineNbr <= nSolLineMax; nSolLineNbr++)
              {
                //save the hsg value for return
                sReturnHsg = sReturnHsg != slyr.SlayHORIZDESC2 ? slyr.SlayHORIZDESC2 : sReturnHsg;

                switch (nSolLineNbr)
                {
                  case 4:
                    nTmpAmt = slyr.SlayLDEP > 0 ? slyr.SlayLDEP / 100 : slyr.SlayLDEP;
                    sb30SolLines[nSolLineNbr].AppendFormat("{0, 8:0.000}", nTmpAmt); break;
                  case 5:
                    nTmpAmt = slyr.SlayBD < 0.7 ? 0.7 : slyr.SlayBD;
                    nTmpAmt = nTmpAmt > 1.9 ? 1.9 : nTmpAmt;
                    sb30SolLines[nSolLineNbr].AppendFormat("{0, 8:0.000}", nTmpAmt); break;
                  case 6:
                    sb30SolLines[nSolLineNbr].AppendFormat("{0, 8:0.000}", 0); break;
                  case 7:
                    sb30SolLines[nSolLineNbr].AppendFormat("{0, 8:0.000}", 0); break;
                  case 8:
                    sb30SolLines[nSolLineNbr].AppendFormat("{0, 8:0.00}", slyr.SlaySAND); break;
                  case 9:
                    sb30SolLines[nSolLineNbr].AppendFormat("{0, 8:0.00}", slyr.SlaySILT); break;
                  case 10:
                    sb30SolLines[nSolLineNbr].AppendFormat("{0, 8:0.00}", 0); break;
                  case 11:
                    nTmpAmt = slyr.SlayPH < 4.5 ? 4.5 : slyr.SlayPH;
                    nTmpAmt = nTmpAmt > 8.5 ? 8.5 : nTmpAmt;
                    sb30SolLines[nSolLineNbr].AppendFormat("{0, 8:0.00}", nTmpAmt); break;
                  case 12:
                    sb30SolLines[nSolLineNbr].AppendFormat("{0, 8:0.00}", 0); break;
                  case 13:
                    nTmpAmt = slyr.SlayOM > 0 ? slyr.SlayOM / 1.72 : 0.1;
                    nTmpAmt = nTmpAmt > 10 ? 10 : nTmpAmt;
                    sb30SolLines[nSolLineNbr].AppendFormat("{0, 8:0.00}", nTmpAmt); break;
                  case 14:
                    sb30SolLines[nSolLineNbr].AppendFormat("{0, 8:0.00}", 0); break;
                  case 15:
                    sb30SolLines[nSolLineNbr].AppendFormat("{0, 8:0.00}", slyr.SlayCEC); break;
                  case 16:
                    sb30SolLines[nSolLineNbr].AppendFormat("{0, 8:0.00}", 0); break;
                  case 17:
                    sb30SolLines[nSolLineNbr].AppendFormat("{0, 8:0.00}", 0); break;
                  case 18:
                    sb30SolLines[nSolLineNbr].AppendFormat("{0, 8:0.00}", 0); break;
                  case 19:
                    sb30SolLines[nSolLineNbr].AppendFormat("{0, 8:0.00}", 0); break;
                  case 20:
                    nTmpAmt = slyr.SlayBD < 0.7 ? 0.7 : slyr.SlayBD;
                    nTmpAmt = nTmpAmt > 1.9 ? 1.9 : nTmpAmt;
                    sb30SolLines[nSolLineNbr].AppendFormat("{0, 8:0.00}", nTmpAmt); break;
                  case 21:
                    sb30SolLines[nSolLineNbr].AppendFormat("{0, 8:0.00}", 0); break;
                  case 22:
                    sb30SolLines[nSolLineNbr].AppendFormat("{0, 8:0.00}", 0); break;
                  case 23:
                    sb30SolLines[nSolLineNbr].AppendFormat("{0, 8:0.00}", 0); break;
                  case 24:
                    sb30SolLines[nSolLineNbr].AppendFormat("{0, 8:0.00}", 0); break;
                  case 25:
                    sb30SolLines[nSolLineNbr].AppendFormat("{0}", ""); break;
                  case 26:
                    sb30SolLines[nSolLineNbr].AppendFormat("{0}", "", 0); break;
                  case 27:
                    sb30SolLines[nSolLineNbr].AppendFormat("{0}", "", 0); break;
                  case 28:
                    sb30SolLines[nSolLineNbr].AppendFormat("{0}", "", 0); break;
                  case 29:
                    sb30SolLines[nSolLineNbr].AppendFormat("{0, 8:0.00}", 0); break;
                  case 30:
                    sb30SolLines[nSolLineNbr].AppendFormat("{0, 8:0.00}", 0); break;
                }
              }
            }

            //newlines
            for (nSolLineNbr = nSolLineStart; nSolLineNbr <= nSolLineMax; nSolLineNbr++)
            {
              sb30SolLines[nSolLineNbr].AppendFormat("{0}", Environment.NewLine);
              sbSolLines.Append(sb30SolLines[nSolLineNbr]);
            }

            //output .sol file contents
            swSol.WriteLine(sbSolLines.ToString());

            swSol.Close();
            swSol.Dispose();
          }

          //output .dat file contents
          swDat.WriteLine(sbDatLines.ToString());

          swSub.Close();
          swSub.Dispose();
          swDat.Close();
          swDat.Dispose();
      }
      catch (Exception ex)
      {
        log.Fatal(ex);
        return "Error: " + ex.ToString();
      }
      finally
      {
        if (swSub != null)
        {
          swSub.Close();
          swSub.Dispose();
        }
        if (swDat != null)
        {
          swDat.Close();
          swDat.Dispose();
        }
        if (swSol != null)
        {
          swSol.Close();
          swSol.Dispose();
        }
      }
      return sReturnHsg;
    }

    //private string getSoilDetail(XDocument xDoc)
    //{
    //  string sReturn = "OK";
    //  try
    //  {

    //    try {
    //    Soildetals = (from d in xDoc.Descendants("Table")
    //                  orderby d.Element("areasymbol").Value, d.Element("lkey").Value
    //                  select new SoilDetail(d.Element("saversion").Value, d.Element("saverest").Value, d.Element("areasymbol").Value, d.Element("areaname").Value, d.Element("lkey").Value, d.Element("musym").Value, d.Element("muname").Value, d.Element("museq").Value, d.Element("mukey").Value, d.Element("comppct_r").Value, d.Element("compname").Value, d.Element("localphase").Value, d.Element("slope_r").Value, d.Element("cokey").Value, d.Element("majcompflag").Value, d.Element("hydricrating").Value, d.Element("hydgrp").Value, d.Element("hzdept_r").Value, d.Element("hzdepb_r").Value, d.Element("chkey").Value, d.Element("sandtotal_r").Value, d.Element("silttotal_r").Value, d.Element("claytotal_r").Value, d.Element("om_r").Value, d.Element("ecec_r").Value, d.Element("awc_r").Value, d.Element("kffact").Value, d.Element("kwfact").Value, d.Element("texdesc").Value, d.Element("texture").Value, d.Element("stratextsflag").Value, d.Element("rvindicator").Value, d.Element("texcl").Value)).ToList<SoilDetail>();
    //    }
    //    catch { throw new ArgumentException("Empty soil data details file "); }

    //    if (Soildetals == null) { throw new ArgumentException("Empty soil data details file "); }

    //  }
    //  catch (Exception ex)
    //  {
    //    StackTrace sTrace = new StackTrace();
    //    LogHandler.WriteToErrorFile(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", ex);
    //    sReturn = "Error: " + ex.ToString();
    //  }
    //  return sReturn;
    //}

    private string getBestSoilDetail(SoilComponentsData scData)
    {
      string sReturn = "OK";
      string sTmp = "";
      double nPrevHighPct = 9999;
      try
      {
        var sLayrs = from aLayr in ProcessCommon.LstSlayDData orderby aLayr.SlayComppct descending, aLayr.SlayLayerNbr
                     where aLayr.SlayMusym == scData.scdSymbol
                     select aLayr;

        
        
        //find next highest available component layer
        //sPrevHighCompname = sHighestCompname;
        //nPrevHighPct = nHighestComppct;
        //nHighestComppct = 0;
        //sHighestCompname = "";
        //foreach (AOISoilLayers aLayr in ProcessCommon.LstSlayDData)
        //{
        //  if (aLayr.SlayCompname == scData.scdSymbol && aLayr.SlayComppct <= nPrevHighPct)
        //  {
        //    if (sHighestCompname == "")
        //    {
        //      sHighestCompname = aLayr.SlayCompname;
        //      nHighestComppct = aLayr.SlayComppct;
        //    }
        //    if (nHighestComppct < aLayr.SlayComppct)
        //    {
        //      sHighestCompname = aLayr.SlayCompname;
        //      nHighestComppct = aLayr.SlayComppct;
        //    }
        //  }
        //}


        return sReturn;

      }
      catch (Exception ex)
      {
        StackTrace sTrace = new StackTrace();
        log.Fatal(ex);
        sReturn = "Error: " + ex.ToString();
      }
      return sReturn;
    }
  }
}