//---------------------------------------------------
//Summary
//GetOutputNTTFile - Get ouput NTT data from APEX processing runs.
//---------------------------------------------------
//Revision History
//Rev#  Date     Who   Change history
// 001  12/14/10 HAC   Initial version.
//---------------------------------------------------

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Xml;
using System.Xml.Linq;

using NTTRunServices.LogHandlr;
using NTTRunServices.ProcessComn;

namespace NTTRunServices
{
  public class GetOutputNTTFile
  {
    private static string sMeName = "GetOutputNTTFile";
    private static log4net.ILog _log;
    public static log4net.ILog log
    {
        get
        {
            if (_log == null)
            {
                _log = log4net.LogManager.GetLogger("ApplicationLogDBAppender");
            }

            return _log;
        }
    }


    public string GetNTTFile(string sPathName, string sFileBaseName, string sFileAltName)
    {
      string sReturn = "OK";
      string sLine = "";
      string sFile = "";
      string sFileBase = "";
      string sFileAlt = "";
      string sTmp = "";
      int nCnt = 0;
      int nCntData = 0;
      string[] sColumns = null;
      string[] sData = null;
      StreamReader strmNttDetail = null;
      //StreamReader strmNttAltDetail = null;
      //StringBuilder sbTmp = new StringBuilder();

      try
      {
        //get ntt files contents and convert to a single xml document
        sFileBase = ProcessCommon.SafeBSlashPathEndString(sPathName) + sFileBaseName.ToString();
        if (!File.Exists(sFileBase)) { return "Error: Not found: " + sFileBase.ToString(); }
        sFileAlt = ProcessCommon.SafeBSlashPathEndString(sPathName) + sFileAltName.ToString();
        if (!File.Exists(sFileAlt)) { return "Error: Not found: " + sFileAlt.ToString(); }

        ProcessCommon.LstNttData = new List<APEXNttData>();
        for (int nCntAB = 1; nCntAB < 3; nCntAB++)
        {
          sFile = nCntAB == 1 ? sFileBase : sFileAlt;
          strmNttDetail = new StreamReader(sFile, false);
          while ((sLine = strmNttDetail.ReadLine()) != null)
          {
            nCnt += 1;
            if (nCnt == 3)
            {
              sColumns = sLine.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries);
              //fix invalid xml characters in column headings
              nCntData = 0;
              foreach (string cData in sColumns)
              {
                sColumns[nCntData] = cData.Replace("#", "");
                nCntData += 1;
              }
            }
            else if (nCnt > 3)
            {
              //fix Total line to be the same number of columns
              if (sLine.ToLower().Trim().StartsWith("total"))
              {
                sLine = "0 " + sLine + " 0 0 0 0 0 0 0 0 0 0 0";
              }
              sData = sLine.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries);
              //store values found
              sTmp = "";
              if (sColumns.Count() != sData.Count())
              { throw new ArgumentException("Invalid data format in file: " + sFile); }

              APEXNttData anData = new APEXNttData();
              anData.AndBOrA = nCntAB == 1 ? "B" : "A";

              for (nCntData = 0; nCntData < sData.Count(); nCntData++)
              {
                switch (nCntData)
                {
                  case 0: anData.AndSUB = sData[nCntData].ToString(); break;
                  case 1: anData.AndYEAR = sData[nCntData].ToString(); break;
                  case 2: anData.AndPRKN = sData[nCntData].ToString(); break;
                  case 3: anData.AndAVOL = sData[nCntData].ToString(); break;
                  case 4: anData.AndFLOW = sData[nCntData].ToString(); break;
                  case 5: anData.AndSED = sData[nCntData].ToString(); break;
                  case 6: anData.AndORGN = sData[nCntData].ToString(); break;
                  case 7: anData.AndORGP = sData[nCntData].ToString(); break;
                  case 8: anData.AndNO3 = sData[nCntData].ToString(); break;
                  case 9: anData.AndPO4 = sData[nCntData].ToString(); break;
                  case 10: anData.AndCROP = sData[nCntData].ToString(); break;
                  case 11: anData.AndYLD1 = sData[nCntData].ToString(); break;
                  case 12: anData.AndYLD2 = sData[nCntData].ToString(); break;
                  case 13: anData.AndPRKP = sData[nCntData].ToString(); break;
                  case 14: anData.AndField = sData[nCntData].ToString(); break;
                  case 15: anData.AndQDR = sData[nCntData].ToString(); break;
                  case 16: anData.AndDPRK = sData[nCntData].ToString(); break;
                  case 17: anData.AndQDRN = sData[nCntData].ToString(); break;
                  case 18: anData.AndN20 = sData[nCntData].ToString(); break;
                  case 19: anData.AndCO2 = sData[nCntData].ToString(); break;
                  case 20: anData.AndDN = sData[nCntData].ToString(); break;
                }
              }
              ProcessCommon.LstNttData.Add(anData);

              //nCntData = 0;
              //oFIDetail = new XElement("NttBaseNfo");
              //foreach (string oColData in sColumns)
              //{
              //  oFIDetail.Add(new XElement(oColData, sData[nCntData].ToString()));
              //  nCntData += 1;
              //}
              //xFIDetail.Add(oFIDetail);
            }
          }
          strmNttDetail.Close();
          strmNttDetail.Dispose();
          sColumns = null;
          sData = null;
          nCnt = 0;
        }

        strmNttDetail.Close();
        strmNttDetail.Dispose();
      }
      catch (Exception ex)
      {
        log.Fatal(ex);
        sReturn = "Error: " + ex.ToString();
      }
      finally
      {
        if (strmNttDetail != null)
        {
          strmNttDetail.Close();
          strmNttDetail.Dispose();
        }
      }
      return sReturn;
    }
  }
}
