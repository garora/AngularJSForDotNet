﻿//---------------------------------------------------
//Summary
//High Resolution Climate Extractor (HCE) - HCEClimateService.
// JSON format
//---------------------------------------------------
//Revision History
//Rev#  Date     Who   Change history
// 003  02/18/14 HAC   Add debug and error logging.
// 002  10/23/13 HAC   Convert raw values to celsius.
// 001  10/15/11 HAC   Initial C# version.
//---------------------------------------------------

using System;
using System.Collections.Generic;
using System.Diagnostics; //for StackTrace
using System.Linq;
using System.Text; //for StringBuilder
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Xml.Linq;

using NTT.Web.Services.Component;

namespace HCEClimateService
{
  /// <summary>
  /// Summary description for Service1
  /// </summary>
  [WebService(Namespace = "http://tempuri.org/")]
  [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
  [System.ComponentModel.ToolboxItem(false)]
  // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
  // [System.Web.Script.Services.ScriptService]
  public class Service1 : System.Web.Services.WebService
  {
      private static log4net.ILog _log;
      public static log4net.ILog log
      {
          get
          {
              if (_log == null)
              {
                  _log = log4net.LogManager.GetLogger("Error");
              }

              return _log;
          }
      }

    private static string sMeName = "Service1";
    private System.Collections.Specialized.NameValueCollection configurationAppSettings = System.Configuration.ConfigurationManager.AppSettings;

    List<ScData> lstSData = new List<ScData>();

    [WebMethod]
    public string HelloWorld()
    {
      try
      {
          log.Debug("<<Starting - Hello World >>");
          log.Debug("<<Ending Hello World >>");
    
        return "Hello World";
      }
      catch (Exception ex)
      {
        log.Fatal(ex);
        return "Error: " + ex.Message.ToString();
      }
    }

    [WebMethod]
    public string GetClimateHCE(int nRow, int nCol, DateTime sDateFrom, DateTime sDateTo)
    {
      NTTSCDDBDataClassesDataContext db = new NTTSCDDBDataClassesDataContext();

      int nNbrColumns = 1406;
      string[] arrMin = null; string[] arrMax = null; string[] arrPrecip = null;

      try
      {
          string name = this.GetType().Name + "." + System.Reflection.MethodBase.GetCurrentMethod().Name;
        log.Info("<<Starting " + name + " >>" );

        var mSCData = from scdata in db.scdatas where (scdata.scdrow == nRow && scdata.scdtype < 3 && scdata.scddate >= sDateFrom && scdata.scddate <= sDateTo) orderby scdata.scddate, scdata.scdtype select scdata;

        foreach (scdata sData in mSCData)
        {
          switch (sData.scdtype)
          {
            case 0:
              { arrMin = sData.scddata.ToString().Split(' '); break; }
            case 1:
              { arrMax = sData.scddata.ToString().Split(' '); break; }
            case 2:
              {
                arrPrecip = sData.scddata.ToString().Split(' ');
                if (arrMin.Length == nNbrColumns &&
                    arrMax.Length == nNbrColumns &&
                    arrPrecip.Length == nNbrColumns)
                {
                  ScData sDta = new ScData();
                  sDta.Date = String.Format("{0:MM\\/dd\\/yyyy}", sData.scddate.ToString());
                  sDta.Min = Math.Round(Convert.ToDecimal(arrMin[nCol]) / 100, 1).ToString();
                  sDta.Max = Math.Round(Convert.ToDecimal(arrMax[nCol]) / 100, 1).ToString();
                  sDta.Precip = Math.Round(Convert.ToDecimal(arrPrecip[nCol]) / 100, 2).ToString();
                  //sDta.Min = arrMin[nCol];
                  //sDta.Max = arrMax[nCol];
                  //sDta.Precip = arrPrecip[nCol];
                  lstSData.Add(sDta);
                  break;
                }
                else
                {
                    log.Error(name + ": Error: Invalid database data.");
                    return "Error: Invalid database data."; 
                }
              }
          }
        }
        JavaScriptSerializer jssData = new JavaScriptSerializer();
        StringBuilder sbLogMessage = new StringBuilder();
          sbLogMessage.Remove(0, sbLogMessage.Length);
          sbLogMessage.AppendFormat("<<113>> Row:{0} Column:{1}", nRow.ToString(), nCol.ToString());
          sbLogMessage.Append(Environment.NewLine);
          sbLogMessage.AppendFormat("<<113>> From:{0} To:{1}", sDateFrom.ToString(), sDateTo.ToString());
          sbLogMessage.Append(Environment.NewLine);
          sbLogMessage.AppendFormat("<<113>>Count:{0}", lstSData.Count().ToString());
          log.Debug(this.GetType().ToString() + sbLogMessage.ToString());
    
          log.Info(sMeName + "<<Ending - GetClimateHCE>>");
        
        return jssData.Serialize(lstSData).ToString();

      }
      catch (Exception ex)
      {
        log.Fatal(ex);
        return "Error: " + ex.Message.ToString();
      }
    }

    [WebMethod]
    public string TestClimateHCEXml()
    {
      NTTSCDDBDataClassesDataContext db = new NTTSCDDBDataClassesDataContext();

      int nNbrColumns = 1406;
      string[] arrMin = null; string[] arrMax = null; string[] arrPrecip = null;

      //test data location
      int nRow = 100;
      int nCol = 100;
      DateTime sDateFrom = new DateTime(2001, 1, 1);
      DateTime sDateTo = new DateTime(2001, 1, 31);

      try
      {
        string name = this.GetType().Name + "." + System.Reflection.MethodBase.GetCurrentMethod().Name;
        log.Info("<<Starting - " + name + " >>");

        XDocument doc = new XDocument();
        XDeclaration xd = new XDeclaration("1.0", "utf-8", "yes");
        doc.Declaration = xd;

        XElement xSCData = new XElement("SerialCompleteData");
        var mSCData = from scdata in db.scdatas where (scdata.scdrow == nRow && scdata.scdtype < 3 && scdata.scddate >= sDateFrom && scdata.scddate <= sDateTo) orderby scdata.scddate, scdata.scdtype select scdata;

        foreach (scdata sData in mSCData)
        {
          switch (sData.scdtype)
          {
            case 0:
              { arrMin = sData.scddata.ToString().Split(' '); break; }
            case 1:
              { arrMax = sData.scddata.ToString().Split(' '); break; }
            case 2:
              {
                arrPrecip = sData.scddata.ToString().Split(' ');
                if (arrMin.Length == nNbrColumns &&
                    arrMax.Length == nNbrColumns &&
                    arrPrecip.Length == nNbrColumns)
                {
                  XElement oSCData = new XElement("SCData");
                  oSCData.Add(new XElement("Date", String.Format("{0:MM\\/dd\\/yyyy}", sData.scddate.ToString())));
                  oSCData.Add(new XElement("Min", Math.Round(Convert.ToDecimal(arrMin[nCol]) / 100, 1).ToString()));
                  oSCData.Add(new XElement("Max", Math.Round(Convert.ToDecimal(arrMax[nCol]) / 100, 1).ToString()));
                  oSCData.Add(new XElement("Precip", Math.Round(Convert.ToDecimal(arrPrecip[nCol]) / 100, 2).ToString()));
                  //oSCData.Add(new XElement("Min", arrMin[nCol]));
                  //oSCData.Add(new XElement("Max", arrMax[nCol]));
                  //oSCData.Add(new XElement("Precip", arrPrecip[nCol]));
                  xSCData.Add(oSCData);
                  break;
                }
                else
                { return "Error: Invalid database data."; }
              }
          }
        }
        doc.Add(xSCData);

        StringBuilder sbLogMessage = new StringBuilder();
        sbLogMessage.AppendFormat("<<185>> Row:{0} Column:{1}", nRow.ToString(), nCol.ToString());
        sbLogMessage.Append(Environment.NewLine);
        sbLogMessage.AppendFormat("<<185>> From:{0} To:{1}", sDateFrom.ToString(), sDateTo.ToString());
        sbLogMessage.Append(Environment.NewLine);
        sbLogMessage.AppendFormat("<<185>>Count:{0}", lstSData.Count().ToString());
        log.Debug(sMeName + sbLogMessage.ToString());

        log.Info("<<Ending - " + name + " >>");
        
        return doc.ToString();
      }
      catch (Exception ex)
      {
           log.Fatal(ex);
           return "Error: " + ex.Message.ToString();
      }
    }

    [WebMethod]
    public string TestClimateHCEJson()
    {
      NTTSCDDBDataClassesDataContext db = new NTTSCDDBDataClassesDataContext();

      int nNbrColumns = 1406;
      string[] arrMin = null; string[] arrMax = null; string[] arrPrecip = null;

      //test data location
      int nRow = 100;
      int nCol = 100;
      DateTime sDateFrom = new DateTime(2001, 1, 1);
      DateTime sDateTo = new DateTime(2001, 1, 31);

      try
      {
        string name = this.GetType().Name + "." + System.Reflection.MethodBase.GetCurrentMethod().Name;
        log.Info("<<Starting - " + name + ">>");  
        
        var mSCData = from scdata in db.scdatas where (scdata.scdrow == nRow && scdata.scdtype < 3 && scdata.scddate >= sDateFrom && scdata.scddate <= sDateTo) orderby scdata.scddate, scdata.scdtype select scdata;

        foreach (scdata sData in mSCData)
        {
          switch (sData.scdtype)
          {
            case 0:
              { arrMin = sData.scddata.ToString().Split(' '); break; }
            case 1:
              { arrMax = sData.scddata.ToString().Split(' '); break; }
            case 2:
              {
                try
                {
                arrPrecip = sData.scddata.ToString().Split(' ');
                if (arrMin.Length == nNbrColumns &&
                    arrMax.Length == nNbrColumns &&
                    arrPrecip.Length == nNbrColumns)
                {
                  ScData sDta = new ScData();
                  sDta.Date = String.Format("{0:MM\\/dd\\/yyyy}", sData.scddate.ToString());
                  sDta.Min = Math.Round(Convert.ToDecimal(arrMin[nCol]) / 100, 1).ToString();
                  sDta.Max = Math.Round(Convert.ToDecimal(arrMax[nCol]) / 100, 1).ToString();
                  sDta.Precip = Math.Round(Convert.ToDecimal(arrPrecip[nCol]) / 100, 2).ToString();
                  //sDta.Min = arrMin[nCol];
                  //sDta.Max = arrMax[nCol];
                  //sDta.Precip = arrPrecip[nCol];
                  lstSData.Add(sDta);
                  break;
                }
                else
                { return "Error: Invalid climate database data."; }
                }
                catch
                { throw new Exception("Invalid climate data values."); }
            }
          }
        }

        //test error condition
        //return "Error: Test code - Invalid database data.";
        StringBuilder sbLogMessage = new StringBuilder();
          sbLogMessage.AppendFormat("<<258>> Row:{0} Column:{1}", nRow.ToString(), nCol.ToString());
          sbLogMessage.Append(Environment.NewLine);
          sbLogMessage.AppendFormat("<<258>> From:{0} To:{1}", sDateFrom.ToString(), sDateTo.ToString());
          sbLogMessage.Append(Environment.NewLine);
          sbLogMessage.AppendFormat("<<258>>Count:{0}", lstSData.Count().ToString());
          log.Debug(sMeName + sbLogMessage.ToString());


        JavaScriptSerializer jssData = new JavaScriptSerializer();

        log.Info("<<Ending - " + name + " >>");

        return jssData.Serialize(lstSData).ToString();
      }
      catch (Exception ex)
      {
        log.Fatal(ex);
        return "Error: " + ex.Message.ToString();
      }
    }
  }
}

