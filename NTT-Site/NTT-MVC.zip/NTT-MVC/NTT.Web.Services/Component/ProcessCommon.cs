﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using NTTManagementsService;
using NTTRunServices;

namespace NTT.Web.Services.Component
{
    public class ProcessCommon
    {
        public static string NTTMapFileLocation = "";
        public static string NTTMapCropFile = "";
        public static string NTTMapTillageFile = "";
        public static string NTTMapFertilizerFile = "";
        public static string NTTMapPathFile = "";
        public static string NTTMapManagementFile = "";
        public static string ApexOpCodesFile = "";

        public static string APEXCropFile = "";
        public static string APEXTillageFile = "";
        public static string APEXFertilizerFile = "";

        public static string NTTClimateFileLocation = "";
        public static string NTTSoilFileLocation = "";
        public static string NTTManagementFileLocation = "";

        public static string AppEndPointServicesHCE = "";
        public static string AppEndPointServicesManagements = "";
        public static string AppEndPointServicesSoils = "";
        public static string AppEndPointServicesSDM = "";

        public static double WestBC = 0;
        public static double EastBC = 0;
        public static double NorthBC = 0;
        public static double SouthBC = 0;
        public static double CellSize = 0;
        public static int NbrRows = 0;
        public static int NbrColumns = 0;
        public static int YearStart = 0;
        public static int YearEnd = 0;

        public static string APEXLookupDataFile = "";
        public static string APEXRunLocation = "";
        public static string APEXRunFile = "";
        public static string APEXSiteSitFile = "";
        public static string APEXWeatherDlyFile = "";
        public static string APEXWeatherWthFile = "";
        public static string APEXSubAreaSubFile = "";
        public static string APEXSoil2110File = "";
        public static string APEXSoilFieldFile = "";
        public static string APEXManagementOpcFile = "";
        public static string APEXOutBaseNttFile = "";
        public static string APEXOutAltNttFile = "";

        // should these be in here, or in the Managements service?
        public const double Lbs2Kg = 0.453592;
        public const double Ac2Ha = 0.404686;
        public const double In2Mm = 25.4;

        public static string ChkGUID = "";
        public static string ChkLat = "";
        public static string ChkLong = "";
        public static string ChkDateFrom = "";
        public static string ChkDateTo = "";
        public static string ChkXMax = "";
        public static string ChkYMin = "";
        public static string ChkXMin = "";
        public static string ChkYMax = "";

        public static string ChkCmz = "";
        public static List<MgmtFileInfo> LstChkMFInfoBAndA = new List<MgmtFileInfo>();


        //soils
        public static List<SoilComponentsData> LstSCData = new List<SoilComponentsData>(); //returned to UI
        public static List<SoilDetailsData> LstSDData = new List<SoilDetailsData>();
        public static List<AOISoilLayers> LstSlayDData = new List<AOISoilLayers>();

        //climate
        public static List<ScData> LstSData = new List<ScData>();

        //managements
        public static List<MgmtFileInfo> LstMFInfoBAndA = new List<MgmtFileInfo>();
        public static List<MgmtDetailsData> LstMDDataBAndA = new List<MgmtDetailsData>();

        //mapped
        public static List<MappedCrop> LstMPCrops = new List<MappedCrop>();
        public static List<MappedOperation> LstMPOperations = new List<MappedOperation>();

        //run params and data
        public static RunNttFileData RnfData = new RunNttFileData();
        public static List<RunLookupCropData> LstRlcData = new List<RunLookupCropData>();
        public static List<APEXNttData> LstNttData = new List<APEXNttData>();

        public static void GetAppSettings()
        {
            try
            {
                //MGT
                NTTMapFileLocation = ConfigurationManager.AppSettings["NTTMapFileLocation"];
                NTTMapCropFile = ConfigurationManager.AppSettings["NTTMapCropFile"];
                NTTMapTillageFile = ConfigurationManager.AppSettings["NTTMapTillageFile"];
                NTTMapFertilizerFile = ConfigurationManager.AppSettings["NTTMapFertilizerFile"];
                NTTMapPathFile = ConfigurationManager.AppSettings["NTTMapPathFile"];
                NTTMapManagementFile = ConfigurationManager.AppSettings["NTTMapManagementFile"];
                ApexOpCodesFile = ConfigurationManager.AppSettings["ApexOpCodes"];

                //MappingAPEX
                APEXCropFile = ConfigurationManager.AppSettings["Crop2110.dat"];
                APEXTillageFile = ConfigurationManager.AppSettings["Till2110.dat"];
                APEXFertilizerFile = ConfigurationManager.AppSettings["Fert2110.dat"];
                
                //Run
                AppEndPointServicesHCE = ConfigurationManager.AppSettings["Service1Soap_Dev"];
                AppEndPointServicesManagements = ConfigurationManager.AppSettings["BasicHttpBinding_IManagements_Dev"];
                AppEndPointServicesSoils = ConfigurationManager.AppSettings["BasicHttpBinding_ISoilComponentService_Dev"];

                Double.TryParse(ConfigurationManager.AppSettings["WestBC"], out WestBC);
                Double.TryParse(ConfigurationManager.AppSettings["EastBC"], out EastBC);
                Double.TryParse(ConfigurationManager.AppSettings["NorthBC"], out NorthBC);
                Double.TryParse(ConfigurationManager.AppSettings["SouthBC"], out SouthBC);
                Double.TryParse(ConfigurationManager.AppSettings["CellSize"], out CellSize);
                int.TryParse(ConfigurationManager.AppSettings["NbrRows"], out NbrRows);
                int.TryParse(ConfigurationManager.AppSettings["NbrColumns"], out NbrColumns);
                int.TryParse(ConfigurationManager.AppSettings["YearStart"], out YearStart);
                int.TryParse(ConfigurationManager.AppSettings["YearEnd"], out YearEnd);
                
                APEXLookupDataFile = ConfigurationManager.AppSettings["APEXLookupDataFile"];
                APEXRunLocation = ConfigurationManager.AppSettings["APEXRunLocation"];
                APEXRunFile = ConfigurationManager.AppSettings["APEXRunFile"];
                APEXSiteSitFile = ConfigurationManager.AppSettings["APEXSiteSitFile"];
                APEXWeatherDlyFile = ConfigurationManager.AppSettings["APEXWeatherDlyFile"];
                APEXWeatherWthFile = ConfigurationManager.AppSettings["APEXWeatherWthFile"];
                APEXSubAreaSubFile = ConfigurationManager.AppSettings["APEXSubAreaSubFile"];
                APEXSoil2110File = ConfigurationManager.AppSettings["APEXSoil2110File"];
                APEXSoilFieldFile = ConfigurationManager.AppSettings["APEXSoilFieldFile"];
                APEXManagementOpcFile = ConfigurationManager.AppSettings["APEXManagementOpcFile"];
                APEXOutBaseNttFile = ConfigurationManager.AppSettings["APEXOutBaseNttFile"];
                APEXOutAltNttFile = ConfigurationManager.AppSettings["APEXOutAltNttFile"];

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static string SafeBSlashPathEndString(string path)
        {
            string result = String.Empty;

            try
            {
               result = path;

                if (!path.EndsWith("\\"))
                {
                    result = path + "\\";
                }

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static void TestDouble(string sValue, out bool isDouble, out double nDouble)
        {
            isDouble = false; nDouble = 0;
            isDouble = double.TryParse(sValue, out nDouble);
        }

        public static void TestInteger(string sValue, out bool isInteger, out int nInt)
        {
            isInteger = false; nInt = 0;
            isInteger = int.TryParse(sValue, out nInt);
        }

        public static void TestDate(string sValue, out bool isDate, out DateTime dtDate)
        {
            isDate = false; dtDate = new DateTime(1900, 1, 1);
            isDate = DateTime.TryParse(sValue, out dtDate);
        }
    }
}