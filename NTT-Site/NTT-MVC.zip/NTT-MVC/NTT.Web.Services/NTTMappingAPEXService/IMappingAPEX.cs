using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;

namespace NTTMappingAPEXService
{  
  [ServiceContract]
  public interface IMappingAPEX
  {
    //Get all CMZs
    [OperationContract]
    List<LMODCmz> GetCmzData();

    //Get all managements in mapped path
    [OperationContract]
    List<LMODManagement> GetManagementsInPath(int nPathId);

    //Get operation details in management
    [OperationContract]
    List<LMODManagementOperationDetail> GetOperationsDetailsInManagement(int nManId);

    //Get all APEX operations from tillage file
    [OperationContract]
    List<APEXOperation> GetTillageData();

    //Get all APEX operation codes from xml file
    [OperationContract]
    List<APEXOperationCode> GetTillageCodesData();

    //Get all LMOD operations from RusleSkelDB
    [OperationContract]
    List<LMODOperation> GetLMODOperationData();

    //Get all mapped operations from mapped file
    [OperationContract]
    List<MappedOperation> GetMappedOperationData();

    //Save mapped operations to mapped file
    [OperationContract]
    void SaveMappedOperationData(List<MappedOperation> mappedData);

    //Get all APEX crops from crop file
    [OperationContract]
    List<APEXCrop> GetCropData();

    //Get all LMOD Crops from RusleSkelDB
    [OperationContract]
    List<LMODCrop> GetLMODCropData();

    //Get all mapped Crops from mapped file
    [OperationContract]
    List<MappedCrop> GetMappedCropData();

    //Save mapped Crops to mapped file
    [OperationContract]
    void SaveMappedCropData(List<MappedCrop> mappedData);

    //Get all LMOD Paths from RusleSkelDB
    [OperationContract]
    List<LMODPath> GetLMODPathData(int nCmzId);

    //Get all mapped Paths from mapped file
    [OperationContract]
    List<MappedPath> GetMappedPathData(int nCmzId);

    //Save mapped Paths to mapped file
    [OperationContract]
    void SaveMappedPathData(int nCmzId, List<MappedPath> mappedData);

    //Get all mapped Managements from mapped file
    [OperationContract]
    List<MappedManagement> GetMappedManagementData(int nCmzId);

    //Save mapped Managements to mapped file
    [OperationContract]
    void SaveMappedManagementData(int nCmzId, List<MappedManagement> mappedData);

  }

  #region CMZ Data
  [DataContract]
  public class LMODCmz
  {
    [DataMember]
    public string LCmzId { get; set; }
    [DataMember]
    public string LCmzZone { get; set; }
    [DataMember]
    public string LCmzEnabled { get; set; }
  }
  #endregion

  #region Operation Data
  [DataContract]
  public class APEXOperation
  {
    [DataMember]
    public string AOpId { get; set; }
    [DataMember]
    public string AOpName { get; set; }
    [DataMember]
    public string AOpCode { get; set; }
    [DataMember]
    public string AOpEqp { get; set; }
  }

  [DataContract]
  public class APEXOperationCode
  {
    [DataMember]
    public string AOCId { get; set; }
    [DataMember]
    public string AOCCode { get; set; }
    [DataMember]
    public string AOCName { get; set; }
    [DataMember]
    public string AOCNameAbbrev { get; set; }
    [DataMember]
    public string AOCActive { get; set; }
  }

  [DataContract]
  public class LMODOperation
  {
    [DataMember]
    public string LOpId { get; set; }
    [DataMember]
    public string LOpName { get; set; }
  }

  [DataContract]
  public class MappedOperation
  {
    [DataMember]
    public string LOpId { get; set; }
    [DataMember]
    public string LOpName { get; set; }
    [DataMember]
    public string AOpId { get; set; }
    [DataMember]
    public string AOpName { get; set; }
    [DataMember]
    public string AOpEqp { get; set; }
    [DataMember]
    public string AOpCode { get; set; }
    [DataMember]
    public string AOpCodeDesc { get; set; }
  }
  #endregion

  #region Crop Data
  [DataContract]
  public class APEXCrop
  {
    [DataMember]
    public string ACrId { get; set; }
    [DataMember]
    public string ACrName { get; set; }
    [DataMember]
    public string ACrDesc { get; set; }
  }

  [DataContract]
  public class LMODCrop
  {
    [DataMember]
    public string LCrId { get; set; }
    [DataMember]
    public string LCrName { get; set; }
  }

  [DataContract]
  public class MappedCrop
  {
    [DataMember]
    public string LCrId { get; set; }
    [DataMember]
    public string LCrName { get; set; }
    [DataMember]
    public string ACrId { get; set; }
    [DataMember]
    public string ACrName { get; set; }
    [DataMember]
    public string ACrDesc { get; set; }
  }
  #endregion

  #region Path Data
  [DataContract]
  public class LMODPath
  {
    [DataMember]
    public string LPaId { get; set; }
    [DataMember]
    public string LPaFilecount { get; set; }
    [DataMember]
    public string LPaName { get; set; }
    [DataMember]
    public string LPaCmzId { get; set; }
  }

  [DataContract]
  public class MappedPath
  {
    [DataMember]
    public string LPaId { get; set; }
    [DataMember]
    public string LPaCmzId { get; set; }
    [DataMember]
    public string LPaName { get; set; }
    [DataMember]
    public string LPaShowcount { get; set; }
  }
  #endregion

  #region Management Data
  [DataContract]
  public class LMODManagement
  {
    [DataMember]
    public string LManId { get; set; }
    [DataMember]
    public string LManName { get; set; }
    [DataMember]
    public string LManDuration { get; set; }
    [DataMember]
    public string LManPathId { get; set; }
    [DataMember]
    public string LManCmzId { get; set; }
  }

  [DataContract]
  public class MappedManagement
  {
    [DataMember]
    public string LManId { get; set; }
    [DataMember]
    public string LManName { get; set; }
    [DataMember]
    public string LManDuration { get; set; }
    [DataMember]
    public string LManPathId { get; set; }
    [DataMember]
    public string LManCmzId { get; set; }
  }
  #endregion

  #region ManagementOperation Data
  [DataContract]
  public class LMODManagementOperation
  {
    [DataMember]
    public int LManOpId { get; set; }
    [DataMember]
    public DateTime LManOpDate { get; set; }
    [DataMember]
    public int LManOpManId { get; set; }
    [DataMember]
    public int LManOpOperId { get; set; }
    [DataMember]
    public int? LManOpCropId { get; set; }
  }

  [DataContract]
  public class LMODManagementOperationDetail
  {
    [DataMember]
    public int LManOpId { get; set; }
    [DataMember]
    public DateTime LManOpDate { get; set; }
    [DataMember]
    public int LManOpManId { get; set; }
    [DataMember]
    public int LManOpOperId { get; set; }
    [DataMember]
    public int? LManOpCropId { get; set; }
    [DataMember]
    public string LManOpOper { get; set; }
    [DataMember]
    public string LManOpCrop { get; set; }
  }
  #endregion

}
