﻿//---------------------------------------------------
//Summary
//NTTMappingAPEXService - Web service for APEX mapping.
//---------------------------------------------------
//Revision History
//Rev#  Date     Who   Change history
// 001  02/03/12 HAC   Get parameters from web.config.
//---------------------------------------------------

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;

using NTTMappingAPEXService.ProcessComn;

namespace NTTMappingAPEXService.LogHandlr
{
  public static class LogHandler
  {

    private static string sMeName = "LogHandler";

    public static void WriteToDebugFile(string sMessage, int nLevel = 1, int nCharIndent = 0)
    {
      //  Config file entries
      //  <!--   Writing to a debug log file  -->
      //  0 - no debug logging; 1 - navigation; 2 - more detail; 3 - verbose detail; 4 - everything
      //  <add key="AppDebug" value="0"/>
      //  N - nutrient; C - carbon; B - both
      //  <add key="AppDebugType" value="N"/>
      //  <add key="AppDebugFile" value="NTTDebugLog"/>
      //  <add key="AppDebugLocation" value="E:\NTTTestLocation\DebugLogs"/>

      bool bAppend = false;
      string sDebugPath = "";
      string sDebugFile = "";
      string sTemp = "";
      int nAppDebuglevel = 0;
      DateTime dtNow = DateTime.Now;
      StreamWriter swLog = null;

      int nInteger;
      bool isInteger;

      try
      {
        ProcessCommon.TestInteger(ProcessCommon.sAppDebug, out isInteger, out nInteger);
        if (isInteger) { nAppDebuglevel = nInteger; } else { nAppDebuglevel = 0; }

        if (nAppDebuglevel == 0) return;
        if (nLevel > nAppDebuglevel) return;

        sDebugPath = ProcessCommon.sAppDebugLocation;
        if (!Directory.Exists(sDebugPath)) { Directory.CreateDirectory(sDebugPath); }

        sDebugFile = ProcessCommon.sAppDebugFile;
        if (!sDebugFile.EndsWith(".log")) { sDebugFile += ".log"; }
        sDebugFile = ProcessCommon.SafeBSlashPathEndString(sDebugPath) + String.Format("{0:yyMMdd}", dtNow) + sDebugFile.ToString();

        sTemp = new String('-', nCharIndent) + sMessage.ToString();
        sTemp = dtNow.ToShortDateString() + " " + dtNow.ToLongTimeString() + " " + sTemp.ToString();

        //had to use this to create a new file otherwise
        //error file is being used by another process
        if (!File.Exists(sDebugFile))
        {
          sTemp += Environment.NewLine;
          File.WriteAllText(sDebugFile, sTemp.ToString());
        }
        else
        {
          bAppend = true;
          swLog = new StreamWriter(sDebugFile, bAppend);
          swLog.WriteLine(sTemp);
          swLog.Flush(); swLog.Close(); swLog.Dispose();
        }

      }
      catch (Exception ex)
      {
        StackTrace sTrace = new StackTrace();
        LogHandler.WriteToErrorFile(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", ex);
      }
      finally
      {
        if (swLog != null)
        { swLog.Close(); swLog.Dispose(); }
      }
    }

    public static void WriteToErrorFile(string sModule, string sFunction, string sMessage, System.Exception exInner)
    {
      //  Config file entries
      //  <add key="AppLogErrors" value="Y"/>
      //  <add key="AppLogErrorFile" value="NTTErrorLog"/>
      //  <add key="AppLogErrorLocation" value="E:\NTTTestLocation\ErrorLogs"/>

      bool bAppend = false;
      string sErrorPath = "";
      string sErrorFile = "";
      string sTemp = "";
      StringBuilder sbDetails = new StringBuilder();
      DateTime dtNow = DateTime.Now;
      StreamWriter swLog = null;

      try
      {
        if (ProcessCommon.sAppLogErrors.ToLower() != "y") return;

        sErrorPath = ProcessCommon.sAppLogErrorLocation;
        if (!Directory.Exists(sErrorPath)) { Directory.CreateDirectory(sErrorPath); }

        sErrorFile = ProcessCommon.sAppLogErrorFile;
        if (!sErrorFile.EndsWith(".log")) { sErrorFile += ".log"; }
        sErrorFile = ProcessCommon.SafeBSlashPathEndString(sErrorPath) + String.Format("{0:yyMMdd}", dtNow) + sErrorFile.ToString();

        sbDetails.Remove(0, sbDetails.Length);
        sbDetails.AppendFormat("**ERROR** Reported by: {0} + {1}{2}", sModule.ToString(), sFunction.ToString(), Environment.NewLine);
        sbDetails.AppendFormat("{0}{1}", sMessage.ToString(), Environment.NewLine);
        if (exInner != null)
        {
          sbDetails.AppendFormat(" Error Details:{0}", Environment.NewLine);
          sbDetails.AppendFormat("{0}{1}", exInner.Message, Environment.NewLine);

          if (exInner.InnerException != null)
          {
            sbDetails.AppendFormat(" InnerException Details:{0}", Environment.NewLine);
            sbDetails.AppendFormat("{0}{1}", exInner.InnerException.Message, Environment.NewLine);

            sbDetails.AppendFormat(" InnerException Source:{0}", Environment.NewLine);
            sbDetails.AppendFormat("{0}{1}", exInner.InnerException.Source, Environment.NewLine);
          }
          else
          {
            sbDetails.Append(">>> Error Detail not available <<<" + Environment.NewLine);
          }

        }
        sbDetails.Append(Environment.NewLine);

        //had to use this to create a new file otherwise
        //error file is being used by another process
        if (!File.Exists(sErrorFile))
        {
          sTemp += Environment.NewLine;
          File.WriteAllText(sErrorFile, sbDetails.ToString());
        }
        else
        { bAppend = true; }

        swLog = new StreamWriter(sErrorFile, bAppend);
        swLog.WriteLine(sbDetails.ToString());
        swLog.Flush(); swLog.Close(); swLog.Dispose();

      }
      catch (Exception ex)
      {
      }
      finally
      {
        if (swLog != null)
        { swLog.Close(); swLog.Dispose(); }
      }
    }

    private static string getStack(Exception ex)
    {
      string sTemp = "";
      int nLineNbr = 0;
      int nLineNbrEnd = 0;
      int nFileName = 0;
      int nMethod = 0;
      int nMethodEnd = 0;
      StringBuilder sbStack = new StringBuilder();

      try
      {
        if (ex != null)
        {

        }
      }
      catch (Exception ex1)
      {
        StackTrace sTrace = new StackTrace();
        LogHandler.WriteToErrorFile(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", ex1);
      }
      return sTemp;
    }

  }
}


//Public Sub WriteToErrorFile(ByVal sModule As String, ByVal sFunction As String, ByVal sMessage As String, ByVal exInner As System.Exception)
//  Dim sErrorPath As String = ""
//  Dim sErrorFile As String = ""
//  Dim objText As System.IO.StreamWriter
//  Dim dtNow As DateTime = Now()
//  Dim booAppend As Boolean = False
//  Dim sDetail As New StringBuilder
//  Dim sMsgtolog As String = String.Empty

//  Try
//    If Not configurationAppSettings.Get("AppLogErrors").ToString.ToLower = "y" Then
//      Exit Sub
//    End If



//    sDetail.Append("**ERROR** Reported by: " + sModule.ToString + "+" + sFunction.ToString)
//    sDetail.Append(ControlChars.CrLf)
//    sDetail.Append(sMessage)
//    sDetail.Append(ControlChars.CrLf)
//    If Not exInner Is Nothing Then
//      sDetail.Append(" Error Details:")
//      sDetail.Append(ControlChars.CrLf)
//      sDetail.Append(exInner.Message)
//      sDetail.Append(ControlChars.CrLf)
//      If Not exInner.InnerException Is Nothing Then
//        sDetail.Append(" InnerException Details:")
//        sDetail.Append(ControlChars.CrLf)
//        sDetail.Append(exInner.InnerException.Message)
//        sDetail.Append(ControlChars.CrLf)
//        sDetail.Append(" InnerException Source:")
//        sDetail.Append(ControlChars.CrLf)
//        sDetail.Append(exInner.InnerException.Source)
//        sDetail.Append(ControlChars.CrLf)
//        sDetail.Append(getStack(exInner.InnerException))
//        sDetail.Append(ControlChars.CrLf)
//      End If
//      sDetail.Append(ControlChars.CrLf)
//      sDetail.Append(" Source:")
//      sDetail.Append(ControlChars.CrLf)
//      sDetail.Append(exInner.Source)
//      sDetail.Append(ControlChars.CrLf)
//      sDetail.Append(getStack(exInner))
//      sDetail.Append(ControlChars.CrLf)
//    Else
//      sDetail.Append(">>> Error Detail not available <<<")
//    End If
//    sDetail.Append(ControlChars.CrLf)
//    sDetail.Append(ControlChars.CrLf)

//    sMsgtolog = dtNow.ToShortDateString.ToString + " " + dtNow.ToLongTimeString.ToString + " " + sDetail.ToString
//    objText = New StreamWriter(sErrorFile, booAppend)
//    objText.WriteLine(sMsgtolog.ToString)
//    objText.Flush()
//    objText.Close()

//  Catch ex As Exception
//    '// do nothing
//  Finally
//    If Not objText Is Nothing Then
//      objText.Close()
//    End If
//  End Try
//End Sub

//Private Function getStack(ByVal ex As Exception) As String
//  Dim sTemp As String = ""
//  Dim nLineNbr As Integer
//  Dim nLineNbrEnd As Integer
//  Dim nFileName As Integer
//  Dim nMethod As Integer
//  Dim nMethodEnd As Integer
//  Dim sbStack As New StringBuilder(512)

//  If Not ex Is Nothing Then
//    Try
//      sTemp = ex.StackTrace
//      nLineNbrEnd = 0
//      nLineNbr = InStr(sTemp, ":line")

//      Do While nLineNbr > 0
//        '// found Line Number, get end of line Nbr
//        nLineNbrEnd = InStr(nLineNbr, sTemp, " ")   '// space before line nbr
//        nLineNbrEnd = InStr(nLineNbrEnd + 1, sTemp, " ") '// space After line nbr
//        If nLineNbrEnd = 0 Then '// end of line
//          nLineNbrEnd = sTemp.Length
//        End If
//        nFileName = InStrRev(sTemp, "\", nLineNbr) '// Backslash before file name + 1
//        nMethodEnd = InStrRev(sTemp, " in ", nFileName) - 1 '// end of routine name
//        nMethod = InStrRev(sTemp, ".", nMethodEnd)    '// start of Routine NAme
//        sbStack.Append(" At ")
//        sbStack.Append(sTemp.Substring(nMethod, (nMethodEnd - nMethod)))
//        sbStack.Append(" in ")
//        sbStack.Append(sTemp.Substring(nFileName, (nLineNbrEnd - nFileName)))
//        ' sbStack.Append(vbLf)
//        nLineNbr = InStr(nLineNbrEnd, sTemp, ":line")
//      Loop

//      getStack = sbStack.ToString

//    Catch ex1 As Exception
//      Try
//        sTemp = ex.ToString
//      Catch
//        sTemp = "Unable to get stack trace"
//      End Try
//      getStack = sTemp
//    End Try
//  Else
//    getStack = String.Empty
//  End If
//End Function
