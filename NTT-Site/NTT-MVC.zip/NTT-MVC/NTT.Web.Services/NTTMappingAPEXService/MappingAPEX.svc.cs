//---------------------------------------------------
//Summary
//NTTMappingAPEXService - Web service for APEX mapping.
//---------------------------------------------------
//Revision History
//Rev#  Date     Who   Change history
//
// 010  03/01/13 HAC   Add AOpCode and AOpCodeDesc to MappedOperation.
// 009  02/14/13 HAC   Begin working with LMOD data.
// 008  01/29/13 HAC   Add AOpCode to APEXOperation; new apexOpCodes.xml file;
//                      new GetTillageCodesData DataContract for list of APEXOperationCode.
// 007  04/03/12 HAC   Add processing for GetMappedManagementData and SaveMappedManagementData;
//                      new MappedManagement DataContract;
//                      new GetManagementsInPath and GetOperationsDetailsInManagement;
//                      add LPaShowcount to mapped paths.
// 006  02/28/12 HAC   Comment out unused GetMappedPathFiles and MappedPathFiles;
//                      Comment out original code for 'Note' examples.
// 005  02/17/12 HAC   Change Path processing, add cmz_id;
//                      change GetLMODPathData(int nCmzId) to select by CMZ.
// 004  02/15/12 HAC   Add Path processing; use params file names.
// 003  02/03/12 HAC   Get parameters from web.config;
//                      add ProcessCommon, LogHandler, error and debugg logging.
// 002  02/02/12 HAC   Add Crop processing;
//                      additional validation of data.
// 001  01/27/12 HAC   Initial version;
//---------------------------------------------------

//ToDo: Needs to serialize output from GetTillageData
//ToDo: Needs to check for duplicate till and crop id in .dat files

using System;
using System.Collections.Generic;
using System.Diagnostics; //for StackTrace
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.ServiceModel;
using System.Text;
using System.ServiceModel.Activation;
using System.ServiceModel.Web; //added
using System.Web;
using System.Web.Configuration;
using System.Xml;
using System.Xml.Linq;

using NTTMappingAPEXService.ProcessComn;
using NTTMappingAPEXService.LogHandlr;

namespace NTTMappingAPEXService
{
    [AspNetCompatibilityRequirements
    (RequirementsMode = AspNetCompatibilityRequirementsMode.Required)]
    public class MappingAPEX : IMappingAPEX
    {
        private static string sMeName = "IMappingAPEX";
        private System.Collections.Specialized.NameValueCollection configurationAppSettings = System.Configuration.ConfigurationManager.AppSettings;
        private static log4net.ILog _log;
        public static log4net.ILog log
        {
            get
            {
                if (_log == null)
                {
                    _log = log4net.LogManager.GetLogger("ApplicationLogDBAppender");
                }

                return _log;
            }
        }


        public List<LMODCmz> GetCmzData()
        {
            StackTrace sTrace = new StackTrace();
            try
            {
                getAppSettings(sTrace.GetFrame(0).GetMethod().Name);
                log.Info(sMeName + "<<Starting - " + sTrace.GetFrame(0).GetMethod().Name + ">>");

                RusleSkelDBDataContext RSDBcontext = new RusleSkelDBDataContext();

                List<LMODCmz> lmCMZs = new List<LMODCmz>();

                var lmCmzs = (from lm in RSDBcontext.lookup_cmzs orderby lm.cmz_zone select lm);
                if (lmCmzs != null)
                {
                    foreach (var sCms in lmCmzs)
                    {
                        LMODCmz lCm = new LMODCmz();
                        lCm.LCmzId = sCms.cmz_id.ToString();
                        lCm.LCmzZone = sCms.cmz_zone;
                        lCm.LCmzEnabled = sCms.cmz_enabled.ToString();
                        lmCMZs.Add(lCm);
                    }
                }   

                log.Info(sMeName + "<<Ending - " + sTrace.GetFrame(0).GetMethod().Name + ">>");

                return lmCMZs;
            }
            catch (Exception ex)
            {
                log.Fatal(ex);
                //do nothing
                return null;
            }
        }

        public List<LMODManagement> GetManagementsInPath(int nPathId)
        {
            StackTrace sTrace = new StackTrace();
            try
            {
                getAppSettings(sTrace.GetFrame(0).GetMethod().Name);
                log.Info(sMeName + "<<Starting - " + sTrace.GetFrame(0).GetMethod().Name + ">>");

                RusleSkelDBDataContext RSDBcontext = new RusleSkelDBDataContext();

                List<LMODManagement> lmManagements = new List<LMODManagement>();

                var lmMans = (from lm in RSDBcontext.lookup_managements
                                orderby lm.man_name
                                where lm.path_id == nPathId
                                select lm);
                if (lmMans != null)
                {
                    foreach (var sMas in lmMans)
                    {
                        LMODManagement lMa = new LMODManagement();
                        lMa.LManId = sMas.man_id.ToString();
                        lMa.LManName = sMas.man_name;
                        lMa.LManDuration = sMas.man_duration.ToString();
                        lMa.LManCmzId = sMas.cmz_id.ToString();
                        lMa.LManPathId = sMas.path_id.ToString();
                        lmManagements.Add(lMa);
                    }
                }

                log.Info(sMeName + "<<Ending - " + sTrace.GetFrame(0).GetMethod().Name + ">>");

                return lmManagements;
            }
            catch (Exception ex)
            {
                LogHandler.WriteToErrorFile(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", ex);
                //do nothing
                return null;
            }
        }

        public List<LMODManagementOperationDetail> GetOperationsDetailsInManagement(int nManId)
        {
          StackTrace sTrace = new StackTrace();
          try
          {
            getAppSettings(sTrace.GetFrame(0).GetMethod().Name);
            log.Info(sMeName + "<<Starting - " + sTrace.GetFrame(0).GetMethod().Name + ">>");

            RusleSkelDBDataContext RSDBcontext = new RusleSkelDBDataContext();

            List<LMODManagementOperationDetail> lmOperationDetails = new List<LMODManagementOperationDetail>();

            var lmOps = (from mOp in RSDBcontext.lookup_managementoperations
                         orderby mOp.manop_date
                         where mOp.man_id == nManId
                         select mOp).ToList();

            if (lmOps != null)
            {
              foreach (var lmO in lmOps)
              {
                LMODManagementOperationDetail lMaOp = new LMODManagementOperationDetail();
                lMaOp.LManOpId = lmO.manop_id;
                lMaOp.LManOpManId = lmO.man_id;
                lMaOp.LManOpOperId = lmO.oper_id;
                lMaOp.LManOpCropId = lmO.crop_id;
                lMaOp.LManOpDate = lmO.manop_date;
                //get operation name
                var oOp = (from oP in RSDBcontext.lookup_operations
                           where lMaOp.LManOpOperId == oP.oper_id
                           select oP).Take(1).SingleOrDefault();
                lMaOp.LManOpOper = oOp.oper_name;
                //get crop name
                if (lMaOp.LManOpCropId != null)
                {
                  if (lMaOp.LManOpCropId > 0)
                  {
                    var cCr = (from cR in RSDBcontext.lookup_crops
                               where lMaOp.LManOpCropId == cR.crop_id
                               select cR).Take(1).SingleOrDefault();
                    lMaOp.LManOpCrop = cCr.crop_name;
                  }
                }
                lmOperationDetails.Add(lMaOp);
              }
            }

            log.Info(sMeName + "<<Ending - " + sTrace.GetFrame(0).GetMethod().Name + ">>");

            return lmOperationDetails;
          }
          catch (Exception ex)
          {
            LogHandler.WriteToErrorFile(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", ex);
            //do nothing
            return null;
          }
        }

        public List<APEXOperation> GetTillageData()
        {
          StackTrace sTrace = new StackTrace();
          string sTmp = "";
          int nInteger;
          bool isInteger;
          double nDouble;
          bool isDouble;
          bool bAllOk = true;
          try
          {
            getAppSettings(sTrace.GetFrame(0).GetMethod().Name);
            log.Info(sMeName + "<<Starting - " + sTrace.GetFrame(0).GetMethod().Name + ">>");
        
            //string dataPath = HttpContext.Current.Server.MapPath("APEXData");
            string dataPath = ProcessCommon.sNTTMapFileLocation;
            if (Directory.Exists(dataPath) == false)
              throw new ArgumentException("Missing dataPath location: " + dataPath.ToString());
            else
            {
              List<APEXOperation> returnVals = new List<APEXOperation>();
              string sFile = string.Format("{0}\\{1}", dataPath, ProcessCommon.sAPEXTillageFile);

              if (File.Exists(sFile))
              {
                using (StreamReader sr = new StreamReader(
                    File.Open(sFile, FileMode.Open, FileAccess.Read)))
                {
                  string tillData = "";
                  while ((tillData = sr.ReadLine()) != null)
                  {
                    if (tillData.Length > 245)
                    {
                      APEXOperation aOp = new APEXOperation();
                      aOp.AOpId = tillData.Substring(0, 5).Trim();
                      aOp.AOpName = tillData.Substring(6, 8).Trim();
                      aOp.AOpCode = tillData.Substring(195, 8).Trim();
                      aOp.AOpEqp = tillData.Substring(243).Trim();

                      //valid data only
                      bAllOk = true;
                      sTmp = ""; sTmp = aOp.AOpId;
                      ProcessCommon.TestInteger(sTmp, out isInteger, out nInteger);
                      if (!isInteger) bAllOk = false;
                      if (aOp.AOpName.Length < 1) bAllOk = false;
                      sTmp = ""; sTmp = aOp.AOpCode.Trim();
                      ProcessCommon.TestDouble(sTmp, out isDouble, out nDouble);
                      if (!isDouble)
                      { bAllOk = false; }
                      else
                      {
                        aOp.AOpCode = Convert.ToString(Convert.ToInt32(Convert.ToDouble(aOp.AOpCode)));
                      }
                      if (aOp.AOpEqp.Length < 1) bAllOk = false;
                      if (bAllOk == true) returnVals.Add(aOp);

                      //won't serialize??
                      //using (MemoryStream opStrm = new MemoryStream())
                      //{
                      //  DataContractJsonSerializer opSer = new DataContractJsonSerializer(typeof(APEXOperation));
                      //  opSer.WriteObject(opStrm, aOp);
                      //  returnVals.Add((opSer.ReadObject(opStrm)) as APEXOperation);
                      //}
                    }
                  }
                  sr.Close();
                }
              }

              log.Debug(sTrace.GetFrame(0).GetMethod().Name + " returnVals: " + returnVals.Count.ToString());

              var SortedList = returnVals.OrderBy(r => r.AOpEqp).ToList();

              log.Info(sMeName + "<<Ending - " + sTrace.GetFrame(0).GetMethod().Name + ">>");

              return SortedList;

              //won't serialize??
              //using (FileStream fs = new FileStream(sFile, FileMode.Open, FileAccess.Read))
              //{
              //  DataContractJsonSerializer noteSer =
              //    new DataContractJsonSerializer(typeof(Note));
              //  RetVal.Add(noteSer.ReadObject(fs) as Note);
              //  fs.Close();
              //}

              //List<object> objTill = new List<object>();
              //objTill.Add(returnVals.ToString());
              //return SerializeToJsonString(objTill).ToString();


              //return SerializeToJsonString(object oBject = returnVals);
            }
          }
          catch (Exception ex)
          {
            LogHandler.WriteToErrorFile(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", ex);
            //do nothing
            return null;
          }
        }

        public List<APEXOperationCode> GetTillageCodesData()
        {
          StackTrace sTrace = new StackTrace();
          string sRtn = "";
          try
          {
            getAppSettings(sTrace.GetFrame(0).GetMethod().Name);
            log.Info(sMeName + "<<Starting - " + sTrace.GetFrame(0).GetMethod().Name + ">>");

              List<APEXCodesInfo> lstCodes = getTillCodes();
        
            List<APEXOperationCode> returnVals = new List<APEXOperationCode>();
            foreach (APEXCodesInfo lC in lstCodes)
            {
              APEXOperationCode aC = new APEXOperationCode();
              aC.AOCId = lC.acoId;
              aC.AOCCode = lC.acoCode;
              aC.AOCName = lC.acoNameAbbrev;
              aC.AOCNameAbbrev = lC.acoNameAbbrev;
              aC.AOCActive = lC.acoActive;
              returnVals.Add(aC);
            }
            log.Info(sMeName + "<<Ending - " + sTrace.GetFrame(0).GetMethod().Name + ">>");
            return returnVals;

          }
          catch (Exception ex)
          {
            log.Fatal(ex);
            return null;
          }
        }

        public List<LMODOperation> GetLMODOperationData()
        {
            StackTrace sTrace = new StackTrace();
            try
            {
                getAppSettings(sTrace.GetFrame(0).GetMethod().Name);
                log.Info(sMeName + "<<Starting - " + sTrace.GetFrame(0).GetMethod().Name + ">>");

                RusleSkelDBDataContext RSDBcontext = new RusleSkelDBDataContext();

                List<LMODOperation> lmOperations = new List<LMODOperation>();

                var lmOps = (from lm in RSDBcontext.lookup_operations orderby lm.oper_name select lm);
                if (lmOps != null)
                {
                    foreach (var sOps in lmOps)
                    {
                        LMODOperation lOp = new LMODOperation();
                        lOp.LOpId = sOps.oper_id.ToString();
                        lOp.LOpName = sOps.oper_name;
                        lmOperations.Add(lOp);
                    }
                }

                log.Debug(sTrace.GetFrame(0).GetMethod().Name + " lmOperations: " + lmOperations.Count.ToString());
                log.Info(sMeName + "<<Ending - " + sTrace.GetFrame(0).GetMethod().Name + ">>");

                return lmOperations;
            }
            catch (Exception ex)
            {
                log.Fatal(ex);
                return null;
            }
        }

        public List<MappedOperation> GetMappedOperationData()
        {
            StackTrace sTrace = new StackTrace();
            try
            {
                getAppSettings(sTrace.GetFrame(0).GetMethod().Name);
                log.Info(sMeName + "<<Starting - " + sTrace.GetFrame(0).GetMethod().Name + ">>");
                List<APEXCodesInfo> lstCodes = getTillCodes();

                string dataPath = ProcessCommon.sNTTMapFileLocation;
                if (Directory.Exists(dataPath) == false)
                    throw new ArgumentException("Missing dataPath location: " + dataPath.ToString());
                else
                {
                    List<MappedOperation> returnVals = new List<MappedOperation>();
                    string sFile = string.Format("{0}\\{1}", dataPath, ProcessCommon.sNTTMapTillageFile);

                    if (File.Exists(sFile))
                    {
                        using (FileStream fs = new FileStream(sFile, FileMode.Open, FileAccess.Read))
                        {
                            DataContractJsonSerializer noteSer = new DataContractJsonSerializer(typeof(List<MappedOperation>));
                            returnVals = noteSer.ReadObject(fs) as List<MappedOperation>;
                            fs.Close();
                        }

                        //get operation code description if missing
                        foreach (MappedOperation mOper in returnVals)
                        {
                            if (mOper.AOpCodeDesc == null || mOper.AOpCodeDesc.Length == 0)
                            {
                                var aoCode = (from ac in lstCodes where ac.acoCode == mOper.AOpCode select ac).Take(1).SingleOrDefault();;
                                if (aoCode != null) mOper.AOpCodeDesc = aoCode.acoNameAbbrev;
                            }
                        }

                        log.Debug(sTrace.GetFrame(0).GetMethod().Name + " returnVals: " + returnVals.Count.ToString());
                        log.Info(sMeName + "<<Ending - " + sTrace.GetFrame(0).GetMethod().Name + ">>");

                        return returnVals;
                    }
                    else
                    {
                        throw new ArgumentException("Missing mapped.operations file " + sFile.ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                log.Info(ex);
                return null;
            }
        }

        public void SaveMappedOperationData(List<MappedOperation> mapppedData)
        {
            StackTrace sTrace = new StackTrace();
            try
            {
                getAppSettings(sTrace.GetFrame(0).GetMethod().Name);
                log.Info(sMeName + "<<Starting - " + sTrace.GetFrame(0).GetMethod().Name + ">>");

                //include 
                string dataPath = ProcessCommon.sNTTMapFileLocation;
                if (Directory.Exists(dataPath))
                {
                    string sFile = string.Format("{0}\\{1}", dataPath, ProcessCommon.sNTTMapTillageFile);
                    using (FileStream fs = new FileStream
                    (
                    sFile,
                    FileMode.Create,
                    FileAccess.ReadWrite)
                    )
                    {
                        DataContractJsonSerializer noteSer = new DataContractJsonSerializer(typeof(List<MappedOperation>));
                        noteSer.WriteObject(fs, mapppedData);
                        fs.Close();

                        log.Info(sMeName + "<<Ending - " + sTrace.GetFrame(0).GetMethod().Name + ">>");
                    }
                }
                else
                { throw new ArgumentException("Missing dataPath location: " + dataPath.ToString()); }

            }
            catch (Exception ex)
            {
                log.Fatal(ex);
                //return null;
            }
        }

        public List<APEXCrop> GetCropData()
        {
            StackTrace sTrace = new StackTrace();
            string sTmp = "";
            int nInteger;
            bool isInteger;
            bool bAllOk = true;
            try
            {
                getAppSettings(sTrace.GetFrame(0).GetMethod().Name);
                log.Info(sMeName + "<<Starting - " + sTrace.GetFrame(0).GetMethod().Name + ">>");

                //string dataPath = HttpContext.Current.Server.MapPath("APEXData");
                string dataPath = ProcessCommon.sNTTMapFileLocation;
                if (Directory.Exists(dataPath) == false)
                    throw new ArgumentException("Missing dataPath location: " + dataPath.ToString());
                else
                {
                    List<APEXCrop> returnVals = new List<APEXCrop>();
                    string sFile = string.Format("{0}\\{1}", dataPath, ProcessCommon.sAPEXCropFile);

                    if (File.Exists(sFile))
                    {
                        using (StreamReader sr = new StreamReader(
                            File.Open(sFile, FileMode.Open, FileAccess.Read)))
                        {
                            string cropData = "";
                            while ((cropData = sr.ReadLine()) != null)
                            {
                                if (cropData.Length > 467)
                                {
                                    APEXCrop aCr = new APEXCrop();
                                    aCr.ACrId = cropData.Substring(0, 5).Trim();
                                    aCr.ACrName = cropData.Substring(6, 4).Trim();
                                    aCr.ACrDesc = cropData.Substring(466).Trim();

                                    //valid data only
                                    bAllOk = true;
                                    sTmp = ""; sTmp = aCr.ACrId;
                                    ProcessCommon.TestInteger(sTmp, out isInteger, out nInteger);
                                    if (!isInteger) bAllOk = false;
                                    if (aCr.ACrName.Length < 1) bAllOk = false;
                                    if (aCr.ACrDesc.Length < 1) bAllOk = false;
                                    if (bAllOk == true) returnVals.Add(aCr);
                                }
                            }
                            sr.Close();
                        }   
                    }      

                    log.Debug(sTrace.GetFrame(0).GetMethod().Name + " returnVals: " + returnVals.Count.ToString());
                    var SortedList = returnVals.OrderBy(r => r.ACrDesc).ToList();
                    log.Info(sMeName + "<<Ending - " + sTrace.GetFrame(0).GetMethod().Name + ">>");

                    return SortedList;
                }
            }
            catch (Exception ex)
            {
                log.Fatal(ex);
                return null;
            }
        }

        public List<LMODCrop> GetLMODCropData()
        {
            StackTrace sTrace = new StackTrace();
            try
            {
                getAppSettings(sTrace.GetFrame(0).GetMethod().Name);
                log.Info(sMeName + "<<Starting - " + sTrace.GetFrame(0).GetMethod().Name + ">>");

                RusleSkelDBDataContext RSDBcontext = new RusleSkelDBDataContext();

                List<LMODCrop> lmCrops = new List<LMODCrop>();

                var lmCrs = (from lm in RSDBcontext.lookup_crops orderby lm.crop_name select lm);
                if (lmCrs != null)
                {
                    foreach (var sCrs in lmCrs)
                    {
                        LMODCrop lCr = new LMODCrop();
                        lCr.LCrId = sCrs.crop_id.ToString();
                        lCr.LCrName = sCrs.crop_name;
                        lmCrops.Add(lCr);
                    }
                }

                log.Debug(sTrace.GetFrame(0).GetMethod().Name + " lmCrops: " + lmCrops.Count.ToString());

                log.Info(sMeName + "<<Ending - " + sTrace.GetFrame(0).GetMethod().Name + ">>");

                return lmCrops;
            }
            catch (Exception ex)
            {
                log.Fatal(ex);
                return null;
            }
        }

        public List<MappedCrop> GetMappedCropData()
        {
            StackTrace sTrace = new StackTrace();
            try
            {
                getAppSettings(sTrace.GetFrame(0).GetMethod().Name);
                log.Info(sMeName + "<<Starting - " + sTrace.GetFrame(0).GetMethod().Name + ">>");

                //string dataPath = HttpContext.Current.Server.MapPath("APEXData");
                string dataPath = ProcessCommon.sNTTMapFileLocation;
                if (Directory.Exists(dataPath) == false)
                throw new ArgumentException("Missing dataPath location: " + dataPath.ToString());
                else
                {
                    List<MappedCrop> returnVals = new List<MappedCrop>();
                    string sFile = string.Format("{0}\\{1}", dataPath, ProcessCommon.sNTTMapCropFile);

                    if (File.Exists(sFile))
                    {
                        using (FileStream fs = new FileStream(sFile, FileMode.Open, FileAccess.Read))
                        {
                            DataContractJsonSerializer noteSer = new DataContractJsonSerializer(typeof(List<MappedCrop>));
                            returnVals = noteSer.ReadObject(fs) as List<MappedCrop>;
                            fs.Close();
                        }

                        log.Debug(sTrace.GetFrame(0).GetMethod().Name + " returnVals: " + returnVals.Count.ToString());
                        log.Info(sMeName + "<<Ending - " + sTrace.GetFrame(0).GetMethod().Name + ">>");

                        return returnVals;
                    }
                    else
                    {
                        throw new ArgumentException("Missing mapped.crops file " + sFile.ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                log.Fatal(ex);
                return null;
            }
        }

        public void SaveMappedCropData(List<MappedCrop> mapppedData)
        {
            StackTrace sTrace = new StackTrace();
            try
            {
                getAppSettings(sTrace.GetFrame(0).GetMethod().Name);
                log.Info(sMeName + "<<Starting - " + sTrace.GetFrame(0).GetMethod().Name + ">>");

                //string dataPath = HttpContext.Current.Server.MapPath("APEXData");
                string dataPath = ProcessCommon.sNTTMapFileLocation;
                if (Directory.Exists(dataPath))
                {
                    string sFile = string.Format("{0}\\{1}", dataPath, ProcessCommon.sNTTMapCropFile);
                    using (FileStream fs = new FileStream
                        (
                        sFile,
                        FileMode.Create,
                        FileAccess.ReadWrite)
                        )
                    {
                        DataContractJsonSerializer noteSer = new DataContractJsonSerializer(typeof(List<MappedCrop>));
                        noteSer.WriteObject(fs, mapppedData);
                        fs.Close();

                        log.Info(sMeName + "<<Ending - " + sTrace.GetFrame(0).GetMethod().Name + ">>");
                    }
                }
                else
                { throw new ArgumentException("Missing dataPath location: " + dataPath.ToString()); }
            }
            catch (Exception ex)
            {
                log.Fatal(ex);

                //return null;
            }
        }

        public List<LMODPath> GetLMODPathData(int nCmzId)
        {
            StackTrace sTrace = new StackTrace();
            try
            {
                getAppSettings(sTrace.GetFrame(0).GetMethod().Name);
                log.Info(sMeName + "<<Starting - " + sTrace.GetFrame(0).GetMethod().Name + ">>");

                RusleSkelDBDataContext RSDBcontext = new RusleSkelDBDataContext();

                List<LMODPath> lmPaths = new List<LMODPath>();

                var lmPas = (from lp in RSDBcontext.lookup_paths where lp.cmz_id == nCmzId orderby lp.path_name select lp);
                if (lmPas != null)
                {
                    foreach (var sPas in lmPas)
                    {
                    LMODPath lPa = new LMODPath();
                    lPa.LPaId = sPas.path_id.ToString();
                    lPa.LPaFilecount = sPas.path_filecount.ToString();
                    lPa.LPaName = sPas.path_name;
                    lPa.LPaCmzId = sPas.cmz_id.ToString();
                    lmPaths.Add(lPa);
                    }
                }

                log.Debug("GetLMODPathData lmPaths: " + lmPaths.Count.ToString());
                log.Info(sMeName + "<<Ending - " + sTrace.GetFrame(0).GetMethod().Name + ">>");

                return lmPaths;
            }
            catch (Exception ex)
            {
                log.Fatal(ex);
                return null;
            }
        }

        public List<MappedPath> GetMappedPathData(int nCmzId)
        {
            StackTrace sTrace = new StackTrace();
            try
            {
                getAppSettings(sTrace.GetFrame(0).GetMethod().Name);
                log.Info(sMeName + "<<Starting - " + sTrace.GetFrame(0).GetMethod().Name + ">>");

                //string dataPath = HttpContext.Current.Server.MapPath("APEXData");
                string dataPath = ProcessCommon.sNTTMapFileLocation;
                if (Directory.Exists(dataPath) == false)
                    throw new ArgumentException("Missing dataPath location: " + dataPath.ToString());
                else
                {
                    List<MappedPath> returnVals = new List<MappedPath>();
                    string sFile = string.Format("{0}\\{1}{2}", dataPath, nCmzId.ToString(), ProcessCommon.sNTTMapPathFile);

                    if (File.Exists(sFile))
                    {
                        using (FileStream fs = new FileStream(sFile, FileMode.Open, FileAccess.Read))
                        {
                            DataContractJsonSerializer noteSer = new DataContractJsonSerializer(typeof(List<MappedPath>));
                            returnVals = noteSer.ReadObject(fs) as List<MappedPath>;
                            fs.Close();
                        }

                        log.Debug(sTrace.GetFrame(0).GetMethod().Name + " returnVals: " + returnVals.Count.ToString());
                        log.Info(sMeName + "<<Ending - " + sTrace.GetFrame(0).GetMethod().Name + ">>");

                        return returnVals;
                    }
                    else
                    {
                        throw new ArgumentException("Missing mapped.paths file " + sFile.ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                log.Fatal(ex);
                return null;
            }
        }

        public void SaveMappedPathData(int nCmzId, List<MappedPath> mapppedData)
        {
          StackTrace sTrace = new StackTrace();
          try
          {
            getAppSettings(sTrace.GetFrame(0).GetMethod().Name);
            log.Info(sMeName + "<<Starting - " + sTrace.GetFrame(0).GetMethod().Name + ">>");

            //string dataPath = HttpContext.Current.Server.MapPath("APEXData");
            string dataPath = ProcessCommon.sNTTMapFileLocation;
            if (Directory.Exists(dataPath))
            {
              string sFile = string.Format("{0}\\{1}{2}", dataPath, nCmzId.ToString(), ProcessCommon.sNTTMapPathFile);
              using (FileStream fs = new FileStream
                (
                  sFile,
                  FileMode.Create,
                  FileAccess.ReadWrite)
                )
              {
                DataContractJsonSerializer noteSer = new DataContractJsonSerializer(typeof(List<MappedPath>));
                noteSer.WriteObject(fs, mapppedData);
                fs.Close();

                log.Info(sMeName + "<<Ending - " + sTrace.GetFrame(0).GetMethod().Name + ">>");
              }
            }
            else
            { throw new ArgumentException("Missing dataPath location: " + dataPath.ToString()); }

          }
          catch (Exception ex)
          {
            log.Fatal(ex);
            //return null;
          }
        }

        public List<MappedManagement> GetMappedManagementData(int nCmzId)
        {
            StackTrace sTrace = new StackTrace();
            try
            {
                getAppSettings(sTrace.GetFrame(0).GetMethod().Name);
                log.Info(sMeName + "<<Starting - " + sTrace.GetFrame(0).GetMethod().Name + ">>");

                //string dataPath = HttpContext.Current.Server.MapPath("APEXData");
                string dataPath = ProcessCommon.sNTTMapFileLocation;
                if (Directory.Exists(dataPath) == false)
                    throw new ArgumentException("Missing dataPath location: " + dataPath.ToString());
                else
                {
                    List<MappedManagement> returnVals = new List<MappedManagement>();
                    string sFile = string.Format("{0}\\{1}{2}", dataPath, nCmzId.ToString(), ProcessCommon.sNTTMapManagementFile);

                    if (File.Exists(sFile))
                    {
                        using (FileStream fs = new FileStream(sFile, FileMode.Open, FileAccess.Read))
                        {
                            DataContractJsonSerializer noteSer = new DataContractJsonSerializer(typeof(List<MappedManagement>));
                            returnVals = noteSer.ReadObject(fs) as List<MappedManagement>;
                            fs.Close();
                        }

                        log.Debug(sTrace.GetFrame(0).GetMethod().Name + " returnVals: " + returnVals.Count.ToString());

                        log.Info(sMeName + "<<Ending - " + sTrace.GetFrame(0).GetMethod().Name + ">>");

                        return returnVals;
                    }
                    else
                    {
                        throw new ArgumentException("Missing mapped.managements file " + sFile.ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                log.Fatal(ex);
                return null;
            }
        }

        public void SaveMappedManagementData(int nCmzId, List<MappedManagement> mapppedData)
        {
            StackTrace sTrace = new StackTrace();
            try
            {
                getAppSettings(sTrace.GetFrame(0).GetMethod().Name);
                log.Info(sMeName + "<<Starting - " + sTrace.GetFrame(0).GetMethod().Name + ">>");

                //string dataPath = HttpContext.Current.Server.MapPath("APEXData");
                string dataPath = ProcessCommon.sNTTMapFileLocation;
                if (Directory.Exists(dataPath))
                {
                    string sFile = string.Format("{0}\\{1}{2}", dataPath, nCmzId.ToString(), ProcessCommon.sNTTMapManagementFile);
                    using (FileStream fs = new FileStream
                    (
                        sFile,
                        FileMode.Create,
                        FileAccess.ReadWrite)
                    )
                    {
                    DataContractJsonSerializer noteSer = new DataContractJsonSerializer(typeof(List<MappedManagement>));
                    noteSer.WriteObject(fs, mapppedData);
                    fs.Close();

                    log.Info(sMeName + "<<Ending - " + sTrace.GetFrame(0).GetMethod().Name + ">>");
                    }
                }
                else
                { throw new ArgumentException("Missing dataPath location: " + dataPath.ToString()); }

            }
            catch (Exception ex)
            {
                log.Fatal(ex);
               //return null;
            }
        }

        //did not work
        //public static string SerializeToJsonString(object objectToSerialize) 
        //{ 
        //  using (MemoryStream ms = new MemoryStream()) 
        //  { 
        //    DataContractJsonSerializer serializer = new DataContractJsonSerializer(objectToSerialize.GetType()); 
        //    serializer.WriteObject(ms, objectToSerialize); 
        //    ms.Position = 0; 
        //    using (StreamReader reader = new StreamReader(ms)) 
        //    { 
        //      return reader.ReadToEnd(); 
        //    } 
        //  } 
        //}

        #region LMOD Methods

        public string TestGetLMODOperations()
        {
          StackTrace sTrace = new StackTrace();
          try
          {
            getAppSettings(sTrace.GetFrame(0).GetMethod().Name);
            log.Info(sMeName + "<<Starting - " + sTrace.GetFrame(0).GetMethod().Name + ">>");

            //string sQuery = sQueryTestLMODOps;
            //string sQuery = sQueryTestLMODMgmts;

            //start here
            //string sQuery = sQueryTestLMODOpsXML;
            //HttpWebRequest request = WebRequest.Create(sQuery) as HttpWebRequest;

            //using (WebResponse response = request.GetResponse())
            //{
            //  StreamReader stmReader = new StreamReader(response.GetResponseStream());
            //  string sTmp = stmReader.ReadToEnd();
            //  stmReader.Close();

            //  //format content to work with xml parse
            //  //remove dtd
            //  //remove <metadata ...>
            //  //remove <files ...>
            //  //remove all '\' characters
            //  //keep <lmod_file ...>
            //  StringBuilder sbTmp = new StringBuilder();
            //  sbTmp.Append("<?xml version=\"1.0\" standalone=\"yes\"?><lmod_set>");
            //  int nLocStart = sTmp.IndexOf("<lmod_file");
            //  int nLocEnd = sTmp.IndexOf("</files>");
            //  int nLocLength = 0;
            //  if (nLocStart > 0 && nLocEnd > 0 && nLocStart < nLocEnd)
            //  {
            //    nLocLength = (sTmp.Length - nLocStart) - (sTmp.Length - nLocEnd);
            //    sbTmp.Append(sTmp.Substring(nLocStart, nLocLength));
            //    sbTmp.Append("</lmod_set>");
            //    XDocument doc = new XDocument();
            //    //doc = XDocument.Parse(sTmp.ToString());
            //    sbTmp.Replace(@"\", "");
            //    doc = XDocument.Parse(sbTmp.ToString());
            //    sTmp = "";
            //  }
            //  else
            //  { throw new ArgumentException("Invalid XML format: " + sQuery.ToString()); }

            //  return sTmp;
            //}
            log.Info(sMeName + "<<Ending - " + sTrace.GetFrame(0).GetMethod().Name + ">>");
            return "";
          }
          catch (Exception ex)
          {
            log.Fatal(ex);
            return null;
          }
        }

        #endregion

        private List<APEXCodesInfo> getTillCodes()
        {
          StackTrace sTrace = new StackTrace();
          string sRtn = "";
          XDocument doc = null;
          try
          {
            log.Info(sMeName + "<<Starting - " + sTrace.GetFrame(0).GetMethod().Name + ">>");

            string dataPath = ProcessCommon.sNTTMapFileLocation;
            if (Directory.Exists(dataPath) == false)
              throw new ArgumentException("Missing dataPath location: " + dataPath.ToString());
            else
            {
              List<APEXOperationCode> returnVals = new List<APEXOperationCode>();
              string sFile = string.Format("{0}\\{1}", dataPath, ProcessCommon.sApexOpCodesFile);

              if (File.Exists(sFile))
              {
                StreamReader sr = new StreamReader(sFile, false);
                sr.BaseStream.Seek(0, SeekOrigin.Begin);
                sRtn = sr.ReadToEnd();
                sr.Close();

                doc = new XDocument();
                doc = XDocument.Parse(sRtn.ToString());
              }

              var CodeInfos = (from c in doc.Descendants("AOCData")
                               select new APEXCodesInfo(c.Element("AOCId").Value, c.Element("AOCCode").Value, c.Element("AOCName").Value, c.Element("AOCNameAbbrev").Value, c.Element("AOCActive").Value));

              if (CodeInfos == null) { return null; }

              var SortedList = CodeInfos.OrderBy(r => r.acoNameAbbrev).ToList();

              log.Info(sMeName + "<<Ending - " + sTrace.GetFrame(0).GetMethod().Name + ">>");
              return SortedList;
            }
          }
          catch (Exception ex)
          {
            log.Fatal(ex);
            //do nothing
            return null;
          }
        }


        private void getAppSettings(string sName)
        {
          StackTrace sTrace = new StackTrace();
          string sTmp = "";
          try
          {
              log.Info(sMeName + "<<Starting - " + sTrace.GetFrame(0).GetMethod().Name + sName + ">>");

            //set default values
            ProcessCommon.sNTTMapFileLocation = ProcessCommon.sDefaultNTTMapFileLocation;
            ProcessCommon.sAPEXCropFile =       ProcessCommon.sDefaultAPEXCropFile;
            ProcessCommon.sAPEXTillageFile =    ProcessCommon.sDefaultAPEXTillageFile;
            ProcessCommon.sAPEXFertilizerFile = ProcessCommon.sDefaultAPEXFertilizerFile;
            ProcessCommon.sNTTMapCropFile =     ProcessCommon.sDefaultNTTMapCropFile;
            ProcessCommon.sNTTMapTillageFile =  ProcessCommon.sDefaultNTTMapTillageFile;
            ProcessCommon.sNTTMapFertilizerFile = ProcessCommon.sDefaultNTTMapFertilizerFile;
            ProcessCommon.sNTTMapPathFile = ProcessCommon.sDefaultNTTMapPathFile;
            ProcessCommon.sNTTMapManagementFile = ProcessCommon.sDefaultNTTMapManagementFile;
            ProcessCommon.sApexOpCodesFile = ProcessCommon.sDefaultApexOpCodesFile;
            ProcessCommon.sAppDebug = ProcessCommon.sDefaultAppDebug;
            ProcessCommon.sAppDebugFile =        ProcessCommon.sDefaultAppDebugFile;
            ProcessCommon.sAppDebugLocation =    ProcessCommon.sDefaultAppDebugLocation;
            ProcessCommon.sAppLogErrors =        ProcessCommon.sDefaultAppLogErrors;
            ProcessCommon.sAppLogErrorFile =     ProcessCommon.sDefaultAppLogErrorFile;
            ProcessCommon.sAppLogErrorLocation = ProcessCommon.sDefaultAppLogErrorLocation;
            ProcessCommon.sDeleteDebugFiles =    ProcessCommon.sDefaultDeleteDebugFiles;
            ProcessCommon.sDeleteDebugAfterDays = ProcessCommon.sDefaultDeleteDebugAfterDays;
            ProcessCommon.sDeleteLOGFiles =      ProcessCommon.sDefaultDeleteLOGFiles;
            ProcessCommon.sDeleteLOGAfterDays =  ProcessCommon.sDefaultDeleteLOGAfterDays;

            sTmp = configurationAppSettings.Get("NTTMapFileLocation");
            if (sTmp.Length > 0) { ProcessCommon.sNTTMapFileLocation = sTmp; }
            sTmp = configurationAppSettings.Get("APEXCropFile");
            if (sTmp.Length > 0) { ProcessCommon.sAPEXCropFile = sTmp; }
            sTmp = configurationAppSettings.Get("APEXTillageFile");
            if (sTmp.Length > 0) { ProcessCommon.sAPEXTillageFile = sTmp; }
            sTmp = configurationAppSettings.Get("APEXFertilizerFile");
            if (sTmp.Length > 0) { ProcessCommon.sAPEXFertilizerFile = sTmp; }
            sTmp = configurationAppSettings.Get("NTTMapCropFile");
            if (sTmp.Length > 0) { ProcessCommon.sNTTMapCropFile = sTmp; }
            sTmp = configurationAppSettings.Get("NTTMapTillageFile");
            if (sTmp.Length > 0) { ProcessCommon.sNTTMapTillageFile = sTmp; }
            sTmp = configurationAppSettings.Get("NTTMapFertilizerFile");
            if (sTmp.Length > 0) { ProcessCommon.sNTTMapFertilizerFile = sTmp; }
            sTmp = configurationAppSettings.Get("NTTMapPathFile");
            if (sTmp.Length > 0) { ProcessCommon.sNTTMapPathFile = sTmp; }
            sTmp = configurationAppSettings.Get("NTTMapManagementFile");
            if (sTmp.Length > 0) { ProcessCommon.sNTTMapManagementFile = sTmp; }
            sTmp = configurationAppSettings.Get("ApexOpCodes");
            if (sTmp.Length > 0) { ProcessCommon.sApexOpCodesFile = sTmp; }
            sTmp = configurationAppSettings.Get("AppDebug");
            if (sTmp.Length > 0) { ProcessCommon.sAppDebug = sTmp; }
            sTmp = configurationAppSettings.Get("AppDebugFile");
            if (sTmp.Length > 0) { ProcessCommon.sAppDebugFile = sTmp; }
            sTmp = configurationAppSettings.Get("AppDebugLocation");
            if (sTmp.Length > 0) { ProcessCommon.sAppDebugLocation = sTmp; }
            sTmp = configurationAppSettings.Get("AppLogErrors");
            if (sTmp.Length > 0) { ProcessCommon.sAppLogErrors = sTmp; }
            sTmp = configurationAppSettings.Get("AppLogErrorFile");
            if (sTmp.Length > 0) { ProcessCommon.sAppLogErrorFile = sTmp; }
            sTmp = configurationAppSettings.Get("AppLogErrorLocation");
            if (sTmp.Length > 0) { ProcessCommon.sAppLogErrorLocation = sTmp; }
            sTmp = configurationAppSettings.Get("DeleteDebugFiles");
            if (sTmp.Length > 0) { ProcessCommon.sDeleteDebugFiles = sTmp; }
            sTmp = configurationAppSettings.Get("DeleteDebugAfterDays");
            if (sTmp.Length > 0) { ProcessCommon.sDeleteDebugAfterDays = sTmp; }
            sTmp = configurationAppSettings.Get("DeleteLOGFiles");
            if (sTmp.Length > 0) { ProcessCommon.sDeleteLOGFiles = sTmp; }
            sTmp = configurationAppSettings.Get("DeleteLOGAfterDays");
            if (sTmp.Length > 0) { ProcessCommon.sDeleteLOGAfterDays = sTmp; }

            log.Info(sMeName + "<<Ending - getAppSettings>>");
          }
          catch (Exception ex)
          {
            log.Fatal(ex);
            //do nothing
          }
        }

        private string chk4FilePresent(string sPathName, string sFileName)
        {
          StackTrace sTrace = new StackTrace();
          string sReturn = "OK";
          string sFile = "";
          try
          {
            log.Info(sMeName + "<<Starting - " + sTrace.GetFrame(0).GetMethod().Name + ">>");

            sFile = ProcessCommon.SafeBSlashPathEndString(sPathName) + sFileName.ToString();
            if (!File.Exists(sFile))
            {
              log.Info(sMeName + "Error: Not found: " + sFile.ToString());

              sReturn = "Error: Not found: " + sFile.ToString();
            }

            log.Info(sMeName + "<<Ending - " + sTrace.GetFrame(0).GetMethod().Name + ">>");

          }
          catch (Exception ex)
          {
            LogHandler.WriteToErrorFile(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", ex);
            sReturn = "Error: " + ex.ToString();
          }
          return sReturn;
        }
    }

    public class APEXCodesInfo
    {
        public string acoId;
        public string acoCode;
        public string acoName;
        public string acoNameAbbrev;
        public string acoActive;

        public APEXCodesInfo(string sacoId, string sacoCode, string sacoName, string sacoNameAbbrev, string sacoActive)
        {
            acoId = sacoId;
            acoCode = sacoCode;
            acoName = sacoName;
            acoNameAbbrev = sacoNameAbbrev;
            acoActive = sacoActive;
        }

    }
}
