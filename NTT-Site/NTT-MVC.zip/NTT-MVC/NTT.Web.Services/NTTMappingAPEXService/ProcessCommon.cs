﻿//---------------------------------------------------
//Summary
//NTTMappingAPEXService - Web service for APEX mapping.
//---------------------------------------------------
//Revision History
//Rev#  Date     Who   Change history
// 003  01/30/13 HAC   Add ApexOpCodes XML file static file containing operation types.
// 002  04/03/12 HAC   Add mapped.managements file.
// 001  02/03/12 HAC   Get parameters from web.config.
//---------------------------------------------------

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Web;

using NTTMappingAPEXService.LogHandlr;

namespace NTTMappingAPEXService.ProcessComn
{
  public static class ProcessCommon
  {
    private static string sMeName = "ProcessCommon";

    public static string sDefaultNTTMapFileLocation = @"C:\NTTServices\NTTMappingAPEXService\NTTMappingAPEXService\APEXData";
    public static string sDefaultAPEXCropFile = "crop2110.dat";
    public static string sDefaultAPEXTillageFile = "till2110.dat";
    public static string sDefaultAPEXFertilizerFile = "fert2110.dat";
    public static string sDefaultNTTMapCropFile = "mapped.crops";
    public static string sDefaultNTTMapTillageFile = "mapped.operations";
    public static string sDefaultNTTMapFertilizerFile = "mapped.fertilizers";
    public static string sDefaultNTTMapPathFile = "mapped.paths";
    public static string sDefaultNTTMapManagementFile = "mapped.managements";
    public static string sDefaultApexOpCodesFile = "ApexOpCodes.xml";

    public static string sDefaultAppDebug = "0";
    public static string sDefaultAppDebugFile = "NTTMappingDebugLog";
    public static string sDefaultAppDebugLocation = @"C:\A-NTTRunLocation\DebugLogs";
    public static string sDefaultAppLogErrors = "Y";
    public static string sDefaultAppLogErrorFile = "NTTMappingErrorLog";
    public static string sDefaultAppLogErrorLocation = @"C:\A-NTTRunLocation\ErrorLogs";
    public static string sDefaultDeleteDebugFiles = "N";
    public static string sDefaultDeleteDebugAfterDays = "2";
    public static string sDefaultDeleteLOGFiles = "N";
    public static string sDefaultDeleteLOGAfterDays = "2";

    //public static string sTmp = "";
    public static string sNTTMapFileLocation = "";
    public static string sAPEXCropFile = "";
    public static string sAPEXTillageFile = "";
    public static string sAPEXFertilizerFile = "";
    public static string sNTTMapCropFile = "";
    public static string sNTTMapTillageFile = "";
    public static string sNTTMapFertilizerFile = "";
    public static string sNTTMapPathFile = "";
    public static string sNTTMapManagementFile = "";
    public static string sApexOpCodesFile = "";

    public static string sAppDebug = "";
    public static string sAppDebugFile = "";
    public static string sAppDebugLocation = "";
    public static string sAppLogErrors = "";
    public static string sAppLogErrorFile = "";
    public static string sAppLogErrorLocation = "";
    public static string sDeleteDebugFiles = "";
    public static string sDeleteDebugAfterDays = "";
    public static string sDeleteLOGFiles = "";
    public static string sDeleteLOGAfterDays = "";

    private static string sValue;

    public static string SafeBSlashPathEndString(string strValue)
    {
      try
      {
        sValue = strValue;

        if (!strValue.EndsWith("\\"))
        {
          sValue = strValue.ToString() + "\\";
          return sValue;
        }
        else { return sValue; }
      }
      catch (Exception ex)
      {
        StackTrace sTrace = new StackTrace();
        LogHandler.WriteToErrorFile(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", ex);
        throw ex;
      }
    }

    public static void TestDouble(string sValue, out bool isDouble, out double nDouble)
    {
      try
      {
        isDouble = false; nDouble = 0;
        isDouble = double.TryParse(sValue, out nDouble);
      }
      catch (Exception ex)
      {
        StackTrace sTrace = new StackTrace();
        LogHandler.WriteToErrorFile(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", ex);
        throw ex;
      }
    }

    public static void TestInteger(string sValue, out bool isInteger, out int nInt)
    {
      try
      {
        isInteger = false; nInt = 0;
        isInteger = int.TryParse(sValue, out nInt);
      }
      catch (Exception ex)
      {
        StackTrace sTrace = new StackTrace();
        LogHandler.WriteToErrorFile(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", ex);
        throw ex;
      }
    }

  }
}