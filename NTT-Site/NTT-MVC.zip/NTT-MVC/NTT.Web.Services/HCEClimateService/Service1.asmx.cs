﻿//---------------------------------------------------
//Summary
//High Resolution Climate Extractor (HCE) - HCEClimateService.
// JSON format
//---------------------------------------------------
//Revision History
//Rev#  Date     Who   Change history
// 003  02/18/14 HAC   Add debug and error logging.
// 002  10/23/13 HAC   Convert raw values to celsius.
// 001  10/15/11 HAC   Initial C# version.
//---------------------------------------------------

using System;
using System.Collections.Generic;
using System.Diagnostics; //for StackTrace
using System.Linq;
using System.Text; //for StringBuilder
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Xml.Linq;

using HCEClimateService.LogHandlr;
using HCEClimateService.ProcessComn;

namespace HCEClimateService
{
  /// <summary>
  /// Summary description for Service1
  /// </summary>
  [WebService(Namespace = "http://tempuri.org/")]
  [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
  [System.ComponentModel.ToolboxItem(false)]
  // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
  // [System.Web.Script.Services.ScriptService]
  public class Service1 : System.Web.Services.WebService
  {
      private static log4net.ILog _log;
      public static log4net.ILog log
      {
          get
          {
              if (_log == null)
              {
                  _log = log4net.LogManager.GetLogger("ApplicationLogDBAppender");
              }

              return _log;
          }
      }

    private static string sMeName = "Service1";
    private System.Collections.Specialized.NameValueCollection configurationAppSettings = System.Configuration.ConfigurationManager.AppSettings;

    List<ScData> lstSData = new List<ScData>();

    [WebMethod]
    public string HelloWorld()
    {
      StackTrace sTrace = new StackTrace();
      try
      {
        getAppSettings(sTrace.GetFrame(0).GetMethod().Name);
        log.Debug("<<Starting - Hello World >>");
        log.Debug("<<Ending Hello World >>");
    
        return "Hello World";
      }
      catch (Exception ex)
      {
        log.Fatal(ex);
        return "Error: " + ex.Message.ToString();
      }
    }

    [WebMethod]
    public string GetClimateHCE(int nRow, int nCol, DateTime sDateFrom, DateTime sDateTo)
    {
      StackTrace sTrace = new StackTrace();
      NTTSCDDBDataClassesDataContext db = new NTTSCDDBDataClassesDataContext();

      int nNbrColumns = 1406;
      string[] arrMin = null; string[] arrMax = null; string[] arrPrecip = null;

      try
      {
        getAppSettings(sTrace.GetFrame(0).GetMethod().Name);
        //LogHandler.WriteToDebugFile(sMeName + "<<Starting - " + sTrace.GetFrame(0).GetMethod().Name + ">>", 2, 0);
        log.Info("GetClimateHCE <<Starting" + this.GetType().ToString() + ">>" );

        var mSCData = from scdata in db.scdatas where (scdata.scdrow == nRow && scdata.scdtype < 3 && scdata.scddate >= sDateFrom && scdata.scddate <= sDateTo) orderby scdata.scddate, scdata.scdtype select scdata;

        foreach (scdata sData in mSCData)
        {
          switch (sData.scdtype)
          {
            case 0:
              { arrMin = sData.scddata.ToString().Split(' '); break; }
            case 1:
              { arrMax = sData.scddata.ToString().Split(' '); break; }
            case 2:
              {
                arrPrecip = sData.scddata.ToString().Split(' ');
                if (arrMin.Length == nNbrColumns &&
                    arrMax.Length == nNbrColumns &&
                    arrPrecip.Length == nNbrColumns)
                {
                  ScData sDta = new ScData();
                  sDta.Date = String.Format("{0:MM\\/dd\\/yyyy}", sData.scddate.ToString());
                  sDta.Min = Math.Round(Convert.ToDecimal(arrMin[nCol]) / 100, 1).ToString();
                  sDta.Max = Math.Round(Convert.ToDecimal(arrMax[nCol]) / 100, 1).ToString();
                  sDta.Precip = Math.Round(Convert.ToDecimal(arrPrecip[nCol]) / 100, 2).ToString();
                  //sDta.Min = arrMin[nCol];
                  //sDta.Max = arrMax[nCol];
                  //sDta.Precip = arrPrecip[nCol];
                  lstSData.Add(sDta);
                  break;
                }
                else
                {
                    log.Error(this.GetType().ToString() + ".GetClimateHCE: Error: Invalid database data.");
                    return "Error: Invalid database data."; 
                }
              }
          }
        }
        JavaScriptSerializer jssData = new JavaScriptSerializer();

          ProcessCommon.sbLogMessage.Remove(0, ProcessCommon.sbLogMessage.Length);
          ProcessCommon.sbLogMessage.AppendFormat("<<113>> Row:{0} Column:{1}", nRow.ToString(), nCol.ToString());
          ProcessCommon.sbLogMessage.Append(Environment.NewLine);
          ProcessCommon.sbLogMessage.AppendFormat("<<113>> From:{0} To:{1}", sDateFrom.ToString(), sDateTo.ToString());
          ProcessCommon.sbLogMessage.Append(Environment.NewLine);
          ProcessCommon.sbLogMessage.AppendFormat("<<113>>Count:{0}", lstSData.Count().ToString());
          log.Debug(this.GetType().ToString() + ProcessCommon.sbLogMessage.ToString());
    
          log.Info(sMeName + "<<Ending - GetClimateHCE>>");
        
        return jssData.Serialize(lstSData).ToString();

      }
      catch (Exception ex)
      {
        log.Fatal(ex);
        return "Error: " + ex.Message.ToString();
      }
    }

    [WebMethod]
    public string TestClimateHCEXml()
    {
      StackTrace sTrace = new StackTrace();
      NTTSCDDBDataClassesDataContext db = new NTTSCDDBDataClassesDataContext();

      int nNbrColumns = 1406;
      string[] arrMin = null; string[] arrMax = null; string[] arrPrecip = null;

      //test data location
      int nRow = 100;
      int nCol = 100;
      DateTime sDateFrom = new DateTime(2001, 1, 1);
      DateTime sDateTo = new DateTime(2001, 1, 31);

      try
      {
        getAppSettings(sTrace.GetFrame(0).GetMethod().Name);
        log.Info(sMeName + "<<Starting - " + sTrace.GetFrame(0).GetMethod().Name + ">>");

        XDocument doc = new XDocument();
        XDeclaration xd = new XDeclaration("1.0", "utf-8", "yes");
        doc.Declaration = xd;

        XElement xSCData = new XElement("SerialCompleteData");
        var mSCData = from scdata in db.scdatas where (scdata.scdrow == nRow && scdata.scdtype < 3 && scdata.scddate >= sDateFrom && scdata.scddate <= sDateTo) orderby scdata.scddate, scdata.scdtype select scdata;

        foreach (scdata sData in mSCData)
        {
          switch (sData.scdtype)
          {
            case 0:
              { arrMin = sData.scddata.ToString().Split(' '); break; }
            case 1:
              { arrMax = sData.scddata.ToString().Split(' '); break; }
            case 2:
              {
                arrPrecip = sData.scddata.ToString().Split(' ');
                if (arrMin.Length == nNbrColumns &&
                    arrMax.Length == nNbrColumns &&
                    arrPrecip.Length == nNbrColumns)
                {
                  XElement oSCData = new XElement("SCData");
                  oSCData.Add(new XElement("Date", String.Format("{0:MM\\/dd\\/yyyy}", sData.scddate.ToString())));
                  oSCData.Add(new XElement("Min", Math.Round(Convert.ToDecimal(arrMin[nCol]) / 100, 1).ToString()));
                  oSCData.Add(new XElement("Max", Math.Round(Convert.ToDecimal(arrMax[nCol]) / 100, 1).ToString()));
                  oSCData.Add(new XElement("Precip", Math.Round(Convert.ToDecimal(arrPrecip[nCol]) / 100, 2).ToString()));
                  //oSCData.Add(new XElement("Min", arrMin[nCol]));
                  //oSCData.Add(new XElement("Max", arrMax[nCol]));
                  //oSCData.Add(new XElement("Precip", arrPrecip[nCol]));
                  xSCData.Add(oSCData);
                  break;
                }
                else
                { return "Error: Invalid database data."; }
              }
          }
        }
        doc.Add(xSCData);

        ProcessCommon.sbLogMessage.Remove(0, ProcessCommon.sbLogMessage.Length);
        ProcessCommon.sbLogMessage.AppendFormat("<<185>> Row:{0} Column:{1}", nRow.ToString(), nCol.ToString());
        ProcessCommon.sbLogMessage.Append(Environment.NewLine);
        ProcessCommon.sbLogMessage.AppendFormat("<<185>> From:{0} To:{1}", sDateFrom.ToString(), sDateTo.ToString());
        ProcessCommon.sbLogMessage.Append(Environment.NewLine);
        ProcessCommon.sbLogMessage.AppendFormat("<<185>>Count:{0}", lstSData.Count().ToString());
        log.Debug(sMeName + ProcessCommon.sbLogMessage.ToString());

        LogHandler.WriteToDebugFile(sMeName + "<<Ending - TestClimateHCEXml>>", 2, 0);
        log.Info(sMeName + "<<Ending - TestClimateHCEXml>>");
        
        return doc.ToString();
      }
      catch (Exception ex)
      {
           log.Fatal(ex);
           return "Error: " + ex.Message.ToString();
      }
    }

    [WebMethod]
    public string TestClimateHCEJson()
    {
      StackTrace sTrace = new StackTrace();
      NTTSCDDBDataClassesDataContext db = new NTTSCDDBDataClassesDataContext();

      int nNbrColumns = 1406;
      string[] arrMin = null; string[] arrMax = null; string[] arrPrecip = null;

      //test data location
      int nRow = 100;
      int nCol = 100;
      DateTime sDateFrom = new DateTime(2001, 1, 1);
      DateTime sDateTo = new DateTime(2001, 1, 31);

      try
      {
 
        getAppSettings(sTrace.GetFrame(0).GetMethod().Name);
        log.Info(sMeName + "<<Starting - " + sTrace.GetFrame(0).GetMethod().Name + ">>");  
        
        var mSCData = from scdata in db.scdatas where (scdata.scdrow == nRow && scdata.scdtype < 3 && scdata.scddate >= sDateFrom && scdata.scddate <= sDateTo) orderby scdata.scddate, scdata.scdtype select scdata;

        foreach (scdata sData in mSCData)
        {
          switch (sData.scdtype)
          {
            case 0:
              { arrMin = sData.scddata.ToString().Split(' '); break; }
            case 1:
              { arrMax = sData.scddata.ToString().Split(' '); break; }
            case 2:
              {
                try
                {
                arrPrecip = sData.scddata.ToString().Split(' ');
                if (arrMin.Length == nNbrColumns &&
                    arrMax.Length == nNbrColumns &&
                    arrPrecip.Length == nNbrColumns)
                {
                  ScData sDta = new ScData();
                  sDta.Date = String.Format("{0:MM\\/dd\\/yyyy}", sData.scddate.ToString());
                  sDta.Min = Math.Round(Convert.ToDecimal(arrMin[nCol]) / 100, 1).ToString();
                  sDta.Max = Math.Round(Convert.ToDecimal(arrMax[nCol]) / 100, 1).ToString();
                  sDta.Precip = Math.Round(Convert.ToDecimal(arrPrecip[nCol]) / 100, 2).ToString();
                  //sDta.Min = arrMin[nCol];
                  //sDta.Max = arrMax[nCol];
                  //sDta.Precip = arrPrecip[nCol];
                  lstSData.Add(sDta);
                  break;
                }
                else
                { return "Error: Invalid climate database data."; }
                }
                catch
                { throw new Exception("Invalid climate data values."); }
            }
          }
        }

        //test error condition
        //return "Error: Test code - Invalid database data.";

          ProcessCommon.sbLogMessage.Remove(0, ProcessCommon.sbLogMessage.Length);
          ProcessCommon.sbLogMessage.AppendFormat("<<258>> Row:{0} Column:{1}", nRow.ToString(), nCol.ToString());
          ProcessCommon.sbLogMessage.Append(Environment.NewLine);
          ProcessCommon.sbLogMessage.AppendFormat("<<258>> From:{0} To:{1}", sDateFrom.ToString(), sDateTo.ToString());
          ProcessCommon.sbLogMessage.Append(Environment.NewLine);
          ProcessCommon.sbLogMessage.AppendFormat("<<258>>Count:{0}", lstSData.Count().ToString());
          LogHandler.WriteToDebugFile(sMeName + ProcessCommon.sbLogMessage.ToString(), 4, 4);
          log.Debug(sMeName + ProcessCommon.sbLogMessage.ToString());


        JavaScriptSerializer jssData = new JavaScriptSerializer();

        log.Info(sMeName + "<<Ending - TestClimateHCEJson>>");

        return jssData.Serialize(lstSData).ToString();
      }
      catch (Exception ex)
      {
        log.Fatal(ex);
        return "Error: " + ex.Message.ToString();
      }
    }

    private void getAppSettings(string sName)
    {
      StackTrace sTrace = new StackTrace();
      string sTmp = "";
      int nInteger;
      bool isInteger;
      try
      {
        log.Info(sMeName + "<<Starting - " + sTrace.GetFrame(0).GetMethod().Name + sName + ">>");

        //set default values
        ProcessCommon.sAppDebug = ProcessCommon.sDefaultAppDebug;
        ProcessCommon.sAppDebugFile = ProcessCommon.sDefaultAppDebugFile;
        ProcessCommon.sAppDebugLocation = ProcessCommon.sDefaultAppDebugLocation;
        ProcessCommon.sAppLogErrors = ProcessCommon.sDefaultAppLogErrors;
        ProcessCommon.sAppLogErrorFile = ProcessCommon.sDefaultAppLogErrorFile;
        ProcessCommon.sAppLogErrorLocation = ProcessCommon.sDefaultAppLogErrorLocation;
        ProcessCommon.sDeleteDebugFiles = ProcessCommon.sDefaultDeleteDebugFiles;
        ProcessCommon.sDeleteDebugAfterDays = ProcessCommon.sDefaultDeleteDebugAfterDays;
        ProcessCommon.sDeleteLOGFiles = ProcessCommon.sDefaultDeleteLOGFiles;
        ProcessCommon.sDeleteLOGAfterDays = ProcessCommon.sDefaultDeleteLOGAfterDays;

        sTmp = configurationAppSettings.Get("AppDebug");
        if (sTmp.Length > 0) { ProcessCommon.sAppDebug = sTmp; }
        ProcessCommon.TestInteger(ProcessCommon.sAppDebug, out isInteger, out nInteger);
        if (isInteger) { ProcessCommon.nAppDebug = nInteger; } else { ProcessCommon.nAppDebug = 0; }

        sTmp = configurationAppSettings.Get("AppDebugFile");
        if (sTmp.Length > 0) { ProcessCommon.sAppDebugFile = sTmp; }
        sTmp = configurationAppSettings.Get("AppDebugLocation");
        if (sTmp.Length > 0) { ProcessCommon.sAppDebugLocation = sTmp; }
        sTmp = configurationAppSettings.Get("AppLogErrors");
        if (sTmp.Length > 0) { ProcessCommon.sAppLogErrors = sTmp; }
        sTmp = configurationAppSettings.Get("AppLogErrorFile");
        if (sTmp.Length > 0) { ProcessCommon.sAppLogErrorFile = sTmp; }
        sTmp = configurationAppSettings.Get("AppLogErrorLocation");
        if (sTmp.Length > 0) { ProcessCommon.sAppLogErrorLocation = sTmp; }
        sTmp = configurationAppSettings.Get("DeleteDebugFiles");
        if (sTmp.Length > 0) { ProcessCommon.sDeleteDebugFiles = sTmp; }
        sTmp = configurationAppSettings.Get("DeleteDebugAfterDays");
        if (sTmp.Length > 0) { ProcessCommon.sDeleteDebugAfterDays = sTmp; }
        sTmp = configurationAppSettings.Get("DeleteLOGFiles");
        if (sTmp.Length > 0) { ProcessCommon.sDeleteLOGFiles = sTmp; }
        sTmp = configurationAppSettings.Get("DeleteLOGAfterDays");
        if (sTmp.Length > 0) { ProcessCommon.sDeleteLOGAfterDays = sTmp; }

        log.Info(sMeName + "<<Ending - getAppSettings>>");
      }
      catch (Exception ex)
      {
        log.Fatal(ex);
        //do nothing
      }
    }
  }
}

