//---------------------------------------------------
//Summary
//NTTManagementsService - Web service for APEX mapping.
//---------------------------------------------------
//Revision History
//Rev#  Date     Who   Change history
// 001  02/18/14 HAC   Get parameters from web.config.
//---------------------------------------------------

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text; //for StringBuilder
using System.Web;

using HCEClimateService.LogHandlr;

namespace HCEClimateService.ProcessComn
{
  public static class ProcessCommon
  {
    private static string sMeName = "ProcessCommon";

    public static string sDefaultAppDebug = "0";
    public static string sDefaultAppDebugFile = "HCEClimateDebugLog";
    public static string sDefaultAppDebugLocation = @"C:\A-HCEClimateLocation\DebugLogs";
    public static string sDefaultAppLogErrors = "Y";
    public static string sDefaultAppLogErrorFile = "HCEClimateErrorLog";
    public static string sDefaultAppLogErrorLocation = @"C:\A-HCEClimateLocation\ErrorLogs";
    public static string sDefaultDeleteDebugFiles = "N";
    public static string sDefaultDeleteDebugAfterDays = "2";
    public static string sDefaultDeleteLOGFiles = "N";
    public static string sDefaultDeleteLOGAfterDays = "2";

    //public static string sTmp = "";
    public static string sNTTMapFileLocation = "";
    public static string sNTTMapCropFile = "";
    public static string sNTTMapTillageFile = "";
    public static string sNTTMapFertilizerFile = "";
    public static string sNTTMapPathFile = "";
    public static string sNTTMapManagementFile = "";
    public static string sApexOpCodesFile = "";

    public static string sAppDebug = "";
    public static int nAppDebug = 0;
    public static string sAppDebugFile = "";
    public static string sAppDebugLocation = "";
    public static string sAppLogErrors = "";
    public static string sAppLogErrorFile = "";
    public static string sAppLogErrorLocation = "";
    public static string sDeleteDebugFiles = "";
    public static string sDeleteDebugAfterDays = "";
    public static string sDeleteLOGFiles = "";
    public static string sDeleteLOGAfterDays = "";

    private static string sValue;

    public static StringBuilder sbLogMessage = new StringBuilder();

    public static string SafeBSlashPathEndString(string strValue)
    {
      try
      {
        sValue = strValue;

        if (!strValue.EndsWith("\\"))
        {
          sValue = strValue.ToString() + "\\";
          return sValue;
        }
        else { return sValue; }
      }
      catch (Exception ex)
      {
        StackTrace sTrace = new StackTrace();
        LogHandler.WriteToErrorFile(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", ex);
        throw ex;
      }
    }

    public static void TestDouble(string sValue, out bool isDouble, out double nDouble)
    {
      try
      {
        isDouble = false; nDouble = 0;
        isDouble = double.TryParse(sValue, out nDouble);
      }
      catch (Exception ex)
      {
        StackTrace sTrace = new StackTrace();
        LogHandler.WriteToErrorFile(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", ex);
        throw ex;
      }
    }

    public static void TestInteger(string sValue, out bool isInteger, out int nInt)
    {
      try
      {
        isInteger = false; nInt = 0;
        isInteger = int.TryParse(sValue, out nInt);
      }
      catch (Exception ex)
      {
        StackTrace sTrace = new StackTrace();
        LogHandler.WriteToErrorFile(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", ex);
        throw ex;
      }
    }

  }
}