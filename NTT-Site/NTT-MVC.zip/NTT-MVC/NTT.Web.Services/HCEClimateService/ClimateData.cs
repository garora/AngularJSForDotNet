﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HCEClimateService
{
  public class ClimateData
  {
  }

  public class ScData
  {
    public string Date { get; set; }
    public string Min { get; set; }
    public string Max { get; set; }
    public string Precip { get; set; }
  }
}