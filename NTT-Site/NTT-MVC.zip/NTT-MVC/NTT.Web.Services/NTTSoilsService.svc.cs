﻿//---------------------------------------------------
//Summary
//NTTSoilsService - Web service for APEX Run data and processing.
//---------------------------------------------------
//Revision History
//Rev#  Date     Who   Change history
// 003  03/13/14 HAC  Add new GetSDMSoilsAllCompPct and GetSDMTestSoilsAllCompPct.
// 003  02/05/14 HAC  More debugging and error logging.
// 002  09/09/13 HAC  Add additional functionality to get soil details;
//                     include test functionality;
//                     BB query hosting is not always working so use details query
//                      only in GetSDMTestSoilsAll.
// 001  01/09/13 HAC  Initial version.
//---------------------------------------------------
//
//Test Methods
//  GetSDMTestSoilComponents
//    Static bounding box coordinates
//    Returns a list of soil components layers
//  GetSDMTestSoilDetails
//    Static bounding box coordinates
//    Returns a list of the 1st 50 soil details rows
//

using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics; //for StackTrace
using System.IO;
using System.Linq;
using System.Net; //WebClient
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Activation; //AspNetCompatibility
using System.ServiceModel.Web;
using System.Text;
using System.Web;
using System.Xml;
using System.Xml.Linq;

using SDMTabularServiceSoap = NTT.Web.Services.SDMTabularServiceSoap;
using NTT.Web.Services.Component;

namespace NTTSoilsService
{
  // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
  //[AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Required)]
  public class SoilComponentService : ISoilComponentService
  {
    private static string sMeName = "ISoilComponentService";
    private System.Collections.Specialized.NameValueCollection configurationAppSettings = System.Configuration.ConfigurationManager.AppSettings;
    private static log4net.ILog _log;
    public static log4net.ILog log
    {
        get
        {
            if (_log == null)
            {
                _log = log4net.LogManager.GetLogger("ApplicationLogDBAppender");
            }

            return _log;
        }
    }

    private const string sMajCompPct = @" and majcompflag = 'Yes' and comppct_r >= ";
    private const string sOrderBy = " ORDER BY museq, comppct_r DESC, compname";
    private const string sSingleKey = " = '791732'";
    private const string sMultiKey = " in ";
    private const string sBBoxCoordinates = "-123.504,45.38,-123.46,45.41";
    private const string sBBoxQuery = @"http://sdmdataaccess.nrcs.usda.gov/Spatial/SDMNAD83Geographic.wfs?Service=WFS&Version=1.0.0&Request=GetFeature&OutputFormat=XmlMukeyList&Typename=MapunitPolyNoGeometry&BBOX=";
    private const string sBBoxFTCDevQuery = @"http://sdmdataaccess.dev.sc.egov.usda.gov/Spatial/SDMNAD83Geographic.wfs?Service=WFS&Version=1.0.0&Request=GetFeature&OutputFormat=XmlMukeyList&Typename=MapunitPolyNoGeometry&BBOX=";

    private const string sQuerySDMSoils = @"
           SELECT saversion, 
                  saverest,
                  l.areasymbol,
                  l.areaname,
                  l.lkey,
                  musym, 
                  muname, 
                  museq, 
                  mu.mukey,
                  comppct_r, 
                  compname, 
                  localphase, 
                  slope_r, 
                  c.cokey,
                  hydricrating, 
                  hydgrp, 
                  hzdept_r, 
                  hzdepb_r, 
                  ch.chkey, 
                  sandtotal_r, 
                  silttotal_r, 
                  claytotal_r, 
                  om_r, 
                  ecec_r, 
                  awc_r, 
                  kffact, 
                  kwfact,
                  texdesc, 
                  texture, 
                  stratextsflag, 
                  chtgrp.rvindicator,
                  texcl
                  FROM sacatalog sac 
                  INNER JOIN legend l ON l.areasymbol = sac.areasymbol AND l.areatypename = 'Non-MLRA Soil Survey Area'
                  INNER JOIN mapunit mu ON mu.lkey = l.lkey 
                  LEFT OUTER JOIN component c ON c.mukey = mu.mukey 
                  LEFT OUTER JOIN chorizon ch ON ch.cokey = c.cokey 
                  LEFT OUTER JOIN chtexturegrp chtgrp ON chtgrp.chkey = ch.chkey 
                  LEFT OUTER JOIN chtexture cht ON cht.chtgkey = chtgrp.chtgkey
                  LEFT OUTER JOIN chtexturemod chtmod ON chtmod.chtkey = cht.chtkey 
                  WHERE  mu.mukey ";

    //Oregon
    //private const string sQuerySDMSoilsBBox = @"http://sdmdataaccess.nrcs.usda.gov/Spatial/SDMNAD83Geographic.wfs?Service=WFS&Version=1.0.0&Request=GetFeature&OutputFormat=XmlMukeyList&Typename=MapunitPolyNoGeometry&BBOX=-123.504,45.38,-123.46,45.41";
    /*Ohio - Defiance
     * XMin = -84.326141756042361
     * XMax = -84.314106356257639
     * YMin = 41.2680696763643
     * YMax = 41.275392371506406
     * Ordinate order must be 'minx, miny, maxx, maxy
     */
    private const string sQuerySDMSoilsBBox = @"http://sdmdataaccess.nrcs.usda.gov/Spatial/SDMNAD83Geographic.wfs?Service=WFS&Version=1.0.0&Request=GetFeature&OutputFormat=XmlMukeyList&Typename=MapunitPolyNoGeometry&BBOX=-84.326141756042361,41.2680696763643,-84.314106356257639,41.275392371506406";
    private const string sQueryFTCDevSoilsBBox = @"http://sdmdataaccess.dev.sc.egov.usda.gov/Spatial/SDMNAD83Geographic.wfs?Service=WFS&Version=1.0.0&Request=GetFeature&OutputFormat=XmlMukeyList&Typename=MapunitPolyNoGeometry&BBOX=-84.326141756042361,41.2680696763643,-84.314106356257639,41.275392371506406";

    //Oregon
    //private const string sQuerySDMSoilsBBMUKeys = "'67221','67225','67141','67234','67235','67165','67229','67218','67187','67205','67201','62508','62494','62509','62469','62496'";
    //Ohio - Defiance
    private const string sQuerySDMSoilsBBMUKeys = "'168477','168450','168458','168459','168449','168465','168474','168466','168471'";

    //FTCDev test
    //http://sdmdataaccess.dev.sc.egov.usda.gov:2345/Spatial/SDMNAD83Geographic.wfs?Service=WFS&Version=1.0.0&Request=GetFeature&OutputFormat=XmlMukeyList&Typename=MapunitPolyNoGeometry&BBOX=-123.504,45.38,-123.46,45.41
    //http://sdmdataaccess.dev.sc.egov.usda.gov:2345/Query.aspx

    //private const string sQuerySDMSoilsLMODOps = @"http://oms-db2.engr.colostate.edu/rest_files/byroot/operations?format=json";  //return operations in json format

    //private const string sQuerySDMSoilsLMODOpsXML = @"http://oms-db2.engr.colostate.edu/rest_files/byroot/operations?format=xml";  //return operations in json format

    //private const string sQuerySDMSoilsLMODMgmts = @"http://oms-db2.engr.colostate.edu/rest_files/byroot/managements?offset=100&limit=100";  //return operations in json format

    public List<SoilComponentsData> GetSDMSoilComponents(string sXMax, string sYMin, string sXMin, string sYMax)
    {
      StackTrace sTrace = new StackTrace();
      string sMUKLStart = "<MapUnitKeyList>";
      string sMUKLEnd = "</MapUnitKeyList>";
      int nMUKLStartLocation = 0;
      int nMUKLEndLocation = 0;
      HttpWebRequest request = null;
      try
      {
        getAppSettings(sTrace.GetFrame(0).GetMethod().Name);
        log.Info(sMeName + "<<Starting - " + sTrace.GetFrame(0).GetMethod().Name + ">>");

        //HttpWebRequest request = WebRequest.Create(sQuery) as HttpWebRequest;
        if (ProcessCommon.AppEndPointServicesSDM.EndsWith("SDM"))
        {
          string sQuery = String.Format("{0}{1},{2},{3},{4}", sBBoxQuery, sXMax, sYMin, sXMin, sYMax);
          log.Debug("sQuery: " + sQuery.ToString());
          request = WebRequest.Create(sQuery) as HttpWebRequest;
        }
        else
        {
          string sQuery = String.Format("{0}{1},{2},{3},{4}", sBBoxFTCDevQuery, sXMax, sYMin, sXMin, sYMax);
          log.Debug("sQuery: " + sQuery.ToString());
          request = WebRequest.Create(sQuery) as HttpWebRequest;
        }

        using (WebResponse response = request.GetResponse())
        {
          StreamReader stmReader = new StreamReader(response.GetResponseStream());
          string sTmp = stmReader.ReadToEnd();
          stmReader.Close();

          //if in error
          //"<?xml version='1.0' encoding=\"UTF-8\" standalone=\"no\" ?>\r\n<ServiceExceptionReport xmlns=\"http://www.opengis.net/ogc\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://www.opengis.net/ogc http://schemas.opengis.net/wms/1.1.1/OGC-exception.xsd\">\n<ServiceException>\r\nError getting BBOX and extent area from WFS request string (shorthand BBOX filter). Unable to create Rectangle from supplied corner coordinates. Ordinate order must be 'minx, miny, maxx, maxy'</ServiceException>\r\n</ServiceExceptionReport>\r\n"

          //extract values in MapUnitKeyList
          //<?xml version="1.0" encoding="ISO-8859-1" standalone="yes" ?> 
          //<MapUnitKeyList>'64070','64071','64174','64175','64081','64166','64079','64154'</MapUnitKeyList> 

          if (sTmp.Length == 0)
          { return null; } //return null for now

          nMUKLStartLocation = sTmp.IndexOf(sMUKLStart);
          nMUKLEndLocation = sTmp.IndexOf(sMUKLEnd);

          if (nMUKLStartLocation == 0 || nMUKLEndLocation == 0 || nMUKLEndLocation < nMUKLStartLocation)
          { return null; } //return null for now

          string sKeys = sTmp.Substring(nMUKLStartLocation + sMUKLStart.Length, nMUKLEndLocation - (sMUKLStart.Length + nMUKLStartLocation));

          log.Debug("sKeys: " + sKeys.ToString());

        //get details based on returned keys
          SDMTabularServiceSoap.SDMTabularServiceSoapClient soilDataMart = new SDMTabularServiceSoap.SDMTabularServiceSoapClient(ProcessCommon.AppEndPointServicesSDM);

        string sQString = String.Format("{0} {1} ({2}) {3}", sQuerySDMSoils.ToString(), sMultiKey.ToString(), sKeys.ToString(), sOrderBy.ToString());

        DataSet dsSDMTest = soilDataMart.RunQuery(sQString.ToString());

        if ( dsSDMTest == null )
        {
          return null; //return null for now
        }
        if (dsSDMTest.Tables[0].Rows.Count < 1) return null; //return null for now

        log.Debug("Rows: " + dsSDMTest.Tables[0].Rows.Count.ToString());

        List<SoilComponentsData> soilData = new List<SoilComponentsData>();

        String previousMuseq = "";
        String previousMusym = "";

        for (int i = 0; i < dsSDMTest.Tables[0].Rows.Count; i++)
        {
          if (!String.IsNullOrEmpty(dsSDMTest.Tables[0].Rows[i]["museq"].ToString()))
          {
            String mapUnitSeq = dsSDMTest.Tables[0].Rows[i]["museq"].ToString();
            String mapUnitSym = dsSDMTest.Tables[0].Rows[i]["musym"].ToString();
            if (mapUnitSeq != previousMuseq || mapUnitSym != previousMusym)
            {
              SoilComponentsData sSoil = new SoilComponentsData
                {
                  scdSSA = dsSDMTest.Tables[0].Rows[i]["areasymbol"].ToString(),
                  scdSymbol = mapUnitSym,
                  scdName = dsSDMTest.Tables[0].Rows[i]["muname"].ToString(),
                  scdAcres = "0",
                  scdPercent = "0",
                  scdSlope = "0",
                  scdPH = "0",
                  scdStatus = ""
                };
              soilData.Add(sSoil);
            }

            previousMuseq = mapUnitSeq;
            previousMusym = mapUnitSym;
          }
        }

        log.Debug("Components: " + soilData.Count.ToString());
        log.Info(sMeName + "<<Ending - " + sTrace.GetFrame(0).GetMethod().Name + ">>");

        return soilData;
        }
      }
      catch (Exception ex)
      {
        log.Fatal(ex);
        return null;
      }
    }

    public List<SoilDetailsData> GetSDMSoilDetails(string sXMax, string sYMin, string sXMin, string sYMax)
    {
      StackTrace sTrace = new StackTrace();
      string sMUKLStart = "<MapUnitKeyList>";
      string sMUKLEnd = "</MapUnitKeyList>";
      int nMUKLStartLocation = 0;
      int nMUKLEndLocation = 0;
      HttpWebRequest request = null;

      try
      {
        getAppSettings(sTrace.GetFrame(0).GetMethod().Name);
        log.Info(sMeName + "<<Starting - " + sTrace.GetFrame(0).GetMethod().Name + ">>");

        //HttpWebRequest request = WebRequest.Create(sQuery) as HttpWebRequest;
        if (ProcessCommon.AppEndPointServicesSDM.EndsWith("SDM"))
        {
          string sQuery = String.Format("{0}{1},{2},{3},{4}", sBBoxQuery, sXMax, sYMin, sXMin, sYMax);
          log.Debug("sQuery: " + sQuery.ToString());
          request = WebRequest.Create(sQuery) as HttpWebRequest;
        }
        else
        {
          string sQuery = String.Format("{0}{1},{2},{3},{4}", sBBoxFTCDevQuery, sXMax, sYMin, sXMin, sYMax);
          log.Debug("sQuery: " + sQuery.ToString());
          request = WebRequest.Create(sQuery) as HttpWebRequest;
        }

        using (WebResponse response = request.GetResponse())
        {
          StreamReader stmReader = new StreamReader(response.GetResponseStream());
          string sTmp = stmReader.ReadToEnd();
          stmReader.Close();

          //if in error
          //"<?xml version='1.0' encoding=\"UTF-8\" standalone=\"no\" ?>\r\n<ServiceExceptionReport xmlns=\"http://www.opengis.net/ogc\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://www.opengis.net/ogc http://schemas.opengis.net/wms/1.1.1/OGC-exception.xsd\">\n<ServiceException>\r\nError getting BBOX and extent area from WFS request string (shorthand BBOX filter). Unable to create Rectangle from supplied corner coordinates. Ordinate order must be 'minx, miny, maxx, maxy'</ServiceException>\r\n</ServiceExceptionReport>\r\n"

          //extract values in MapUnitKeyList
          //<?xml version="1.0" encoding="ISO-8859-1" standalone="yes" ?> 
          //<MapUnitKeyList>'64070','64071','64174','64175','64081','64166','64079','64154'</MapUnitKeyList> 

          if (sTmp.Length == 0)
          { return null; } //return null for now

          nMUKLStartLocation = sTmp.IndexOf(sMUKLStart);
          nMUKLEndLocation = sTmp.IndexOf(sMUKLEnd);

          if (nMUKLStartLocation == 0 || nMUKLEndLocation == 0 || nMUKLEndLocation < nMUKLStartLocation)
          { return null; } //return null for now

          string sKeys = sTmp.Substring(nMUKLStartLocation + sMUKLStart.Length, nMUKLEndLocation - (sMUKLStart.Length + nMUKLStartLocation));

          log.Debug("sKeys: " + sKeys.ToString());

          //get details based on returned keys
          SDMTabularServiceSoap.SDMTabularServiceSoapClient soilDataMart = new SDMTabularServiceSoap.SDMTabularServiceSoapClient();

          string sQString = String.Format("{0} {1} ({2}) {3}", sQuerySDMSoils.ToString(), sMultiKey.ToString(), sKeys.ToString(), sOrderBy.ToString());

          log.Debug("sQString: " + sQString.ToString());

          DataSet dsSDMTest = soilDataMart.RunQuery(sQString.ToString());

          if (dsSDMTest == null)
          {
            return null; //return null for now
          }
          if (dsSDMTest.Tables[0].Rows.Count < 1) return null; //return null for now

          log.Debug("Rows: " + dsSDMTest.Tables[0].Rows.Count.ToString());

          List<SoilDetailsData> soilDetails = new List<SoilDetailsData>();

          for (int i = 0; i < dsSDMTest.Tables[0].Rows.Count; i++)
          {
            if (!String.IsNullOrEmpty(dsSDMTest.Tables[0].Rows[i]["museq"].ToString()))
            {
              SoilDetailsData sSoil = new SoilDetailsData
              {
                sddSaversion = dsSDMTest.Tables[0].Rows[i]["saversion"].ToString(),
                sddSaverest = dsSDMTest.Tables[0].Rows[i]["saverest"].ToString(),
                sddAreasymbol = dsSDMTest.Tables[0].Rows[i]["areasymbol"].ToString(),
                sddAreaname = dsSDMTest.Tables[0].Rows[i]["areaname"].ToString(),
                sddMusym = dsSDMTest.Tables[0].Rows[i]["musym"].ToString(),
                sddMuname = dsSDMTest.Tables[0].Rows[i]["muname"].ToString(),
                sddMuseq = dsSDMTest.Tables[0].Rows[i]["museq"].ToString(),
                sddMukey = dsSDMTest.Tables[0].Rows[i]["mukey"].ToString(),
                sddComppct_r = dsSDMTest.Tables[0].Rows[i]["comppct_r"].ToString(),
                sddCompname = dsSDMTest.Tables[0].Rows[i]["compname"].ToString(),
                sddSlope_r = dsSDMTest.Tables[0].Rows[i]["slope_r"].ToString(),
                sddCokey = dsSDMTest.Tables[0].Rows[i]["cokey"].ToString(),
                sddHydricrating = dsSDMTest.Tables[0].Rows[i]["hydricrating"].ToString(),
                sddHydgrp = dsSDMTest.Tables[0].Rows[i]["hydgrp"].ToString(),
                sddHzdept_r = dsSDMTest.Tables[0].Rows[i]["hzdept_r"].ToString(),
                sddHzdepb_r = dsSDMTest.Tables[0].Rows[i]["hzdepb_r"].ToString(),
                sddChkey = dsSDMTest.Tables[0].Rows[i]["chkey"].ToString(),
                sddSandtotal_r = dsSDMTest.Tables[0].Rows[i]["sandtotal_r"].ToString(),
                sddSilttotal_r = dsSDMTest.Tables[0].Rows[i]["silttotal_r"].ToString(),
                sddClaytotal_r = dsSDMTest.Tables[0].Rows[i]["claytotal_r"].ToString(),
                sddOm_r = dsSDMTest.Tables[0].Rows[i]["om_r"].ToString(),
                sddEcec_r = dsSDMTest.Tables[0].Rows[i]["ecec_r"].ToString(),
                sddAwc_r = dsSDMTest.Tables[0].Rows[i]["awc_r"].ToString(),
                sddKffact = dsSDMTest.Tables[0].Rows[i]["kffact"].ToString(),
                sddKwfact = dsSDMTest.Tables[0].Rows[i]["kwfact"].ToString(),
                sddTexdesc = dsSDMTest.Tables[0].Rows[i]["texdesc"].ToString(),
                sddTexture = dsSDMTest.Tables[0].Rows[i]["texture"].ToString(),
                sddStratextsflag = dsSDMTest.Tables[0].Rows[i]["stratextsflag"].ToString(),
                sddRvindicator = dsSDMTest.Tables[0].Rows[i]["rvindicator"].ToString(),
                sddTexcl = dsSDMTest.Tables[0].Rows[i]["texcl"].ToString()
              };
              soilDetails.Add(sSoil);
            }
          }

          log.Debug("Details: " + soilDetails.Count.ToString());
          log.Info(sMeName + "<<Ending - " + sTrace.GetFrame(0).GetMethod().Name + ">>");

          return soilDetails;
        }
      }
      catch (Exception ex)
      {
        log.Fatal(ex);
        return null;
      }
    }

    public SoilAllData GetSDMSoilsAll(string sXMax, string sYMin, string sXMin, string sYMax)
    {
      StackTrace sTrace = new StackTrace();
      string sMUKLStart = "<MapUnitKeyList>";
      string sMUKLEnd = "</MapUnitKeyList>";
      int nMUKLStartLocation = 0;
      int nMUKLEndLocation = 0;
      //int nFirst50 = 0;

      List<SoilComponentsData> soilData = new List<SoilComponentsData>();
      List<SoilDetailsData> soilDetails = new List<SoilDetailsData>();
      HttpWebRequest request = null;
      try
      {
        getAppSettings(sTrace.GetFrame(0).GetMethod().Name);
        log.Info(sMeName + "<<Starting - " + sTrace.GetFrame(0).GetMethod().Name + ">>");

        //test code
        //string sQuery = sQuerySDMSoilsBBox;

        //string sQuery = String.Format("{0}{1},{2},{3},{4}", sBBoxQuery, sXMax, sYMin, sXMin, sYMax);

        //HttpWebRequest request = WebRequest.Create(sQuery) as HttpWebRequest;
        if (ProcessCommon.AppEndPointServicesSDM.EndsWith("SDM"))
        {
          string sQuery = String.Format("{0}{1},{2},{3},{4}", sBBoxQuery, sXMin, sYMin, sXMax, sYMax);
          log.Debug("sQuery: " + sQuery.ToString());
          request = WebRequest.Create(sQuery) as HttpWebRequest;
        }
        else
        {
          string sQuery = String.Format("{0}{1},{2},{3},{4}", sBBoxFTCDevQuery, sXMin, sYMin, sXMax, sYMax);
          log.Debug("sQuery: " + sQuery.ToString());
          request = WebRequest.Create(sQuery) as HttpWebRequest;
        }

        if (request == null) throw new Exception("SDM Soils BBQuery failed.");

        using (WebResponse response = request.GetResponse())
        {
          StreamReader stmReader = new StreamReader(response.GetResponseStream());
          string sTmp = stmReader.ReadToEnd();
          stmReader.Close();

          log.Debug("Response: " + sTmp);

          //if in error
          //"<?xml version='1.0' encoding=\"UTF-8\" standalone=\"no\" ?>\r\n<ServiceExceptionReport xmlns=\"http://www.opengis.net/ogc\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://www.opengis.net/ogc http://schemas.opengis.net/wms/1.1.1/OGC-exception.xsd\">\n<ServiceException>\r\nError getting BBOX and extent area from WFS request string (shorthand BBOX filter). Unable to create Rectangle from supplied corner coordinates. Ordinate order must be 'minx, miny, maxx, maxy'</ServiceException>\r\n</ServiceExceptionReport>\r\n"

          //extract values in MapUnitKeyList
          //<?xml version="1.0" encoding="ISO-8859-1" standalone="yes" ?> 
          //<MapUnitKeyList>'64070','64071','64174','64175','64081','64166','64079','64154'</MapUnitKeyList> 

          if (sTmp.Length == 0)
          {
            log.Error("Response: Returning null - nothing returned from BB query.");
            throw new Exception("SDM Soils BBQuery failed.");
          }

          nMUKLStartLocation = sTmp.IndexOf(sMUKLStart);
          nMUKLEndLocation = sTmp.IndexOf(sMUKLEnd);

          if (nMUKLStartLocation == 0 || nMUKLEndLocation == 0 || nMUKLEndLocation < nMUKLStartLocation)
          {
            log.Error("Response: Returning null - invalid data format from query.");
            throw new Exception("SDM Soils BBQuery parse location failed.");
          }

          string sKeys = sTmp.Substring(nMUKLStartLocation + sMUKLStart.Length, nMUKLEndLocation - (sMUKLStart.Length + nMUKLStartLocation));

          log.Debug("sKeys: " + sKeys.ToString());

          //get details based on returned keys
          SDMTabularServiceSoap.SDMTabularServiceSoapClient soilDataMart = new SDMTabularServiceSoap.SDMTabularServiceSoapClient(ProcessCommon.AppEndPointServicesSDM);

          //orig test
          //string sQString = String.Format("{0} {1} ({2}) {3}", sQuerySDMSoils.ToString(), sMultiKey.ToString(), "'64070','64071','64174','64175','64081','64166','64079','64154'", sOrderBy.ToString());

          //more test code when spatial query is not working
          //string sQString = String.Format("{0} {1} ({2}) {3}", sQuerySDMSoils.ToString(), sMultiKey.ToString(), sQuerySDMSoilsBBMUKeys.ToString(), sOrderBy.ToString());

          string sQString = String.Format("{0} {1} ({2}) {3}", sQuerySDMSoils.ToString(), sMultiKey.ToString(), sKeys.ToString(), sOrderBy.ToString());

          log.Debug("sQString: " + sQString.ToString());

          DataSet dsSDMTest = soilDataMart.RunQuery(sQString.ToString());

          if (dsSDMTest == null)
          {
            log.Error("SDM Soils Query failed.  RunQuery: Returning null - nothing returned from RunQuery.");
            throw new Exception("SDM Soils Query failed.");
          }
          if (dsSDMTest.Tables[0].Rows.Count < 1)
          {
              log.Error("SDM Soils Query returned nothing. RunQuery: Returning null - No rows returned from RunQuery.");
            throw new Exception("SDM Soils Query returned nothing.");
          }

          log.Debug("Rows: " + dsSDMTest.Tables[0].Rows.Count.ToString());

          String previousMuseq = "";
          String previousMusym = "";

          for (int i = 0; i < dsSDMTest.Tables[0].Rows.Count; i++)
          {
            if (!String.IsNullOrEmpty(dsSDMTest.Tables[0].Rows[i]["museq"].ToString()))
            {
              String mapUnitSeq = dsSDMTest.Tables[0].Rows[i]["museq"].ToString();
              String mapUnitSym = dsSDMTest.Tables[0].Rows[i]["musym"].ToString();
              if (mapUnitSeq != previousMuseq || mapUnitSym != previousMusym)
              {
                SoilComponentsData sSoil = new SoilComponentsData
                {
                  scdSSA = dsSDMTest.Tables[0].Rows[i]["areasymbol"].ToString(),
                  scdSymbol = mapUnitSym,
                  scdName = dsSDMTest.Tables[0].Rows[i]["muname"].ToString(),
                  scdAcres = "0",
                  scdPercent = "0",
                  scdSlope = "0",
                  scdPH = "0",
                  scdStatus = ""
                };
                soilData.Add(sSoil);
              }

              previousMuseq = mapUnitSeq;
              previousMusym = mapUnitSym;
            }
          }

          log.Debug("Components: " + soilData.Count.ToString());

          for (int i = 0; i < dsSDMTest.Tables[0].Rows.Count; i++)
          {
            //if (nFirst50 < 50) // test code
            //{
              if (!String.IsNullOrEmpty(dsSDMTest.Tables[0].Rows[i]["museq"].ToString()))
              {
                try
                {
                  SoilDetailsData sSoil = new SoilDetailsData
                  {
                    sddSaversion = dsSDMTest.Tables[0].Rows[i]["saversion"].ToString(),
                    sddSaverest = dsSDMTest.Tables[0].Rows[i]["saverest"].ToString(),
                    sddAreasymbol = dsSDMTest.Tables[0].Rows[i]["areasymbol"].ToString(),
                    sddAreaname = dsSDMTest.Tables[0].Rows[i]["areaname"].ToString(),
                    sddMusym = dsSDMTest.Tables[0].Rows[i]["musym"].ToString(),
                    sddMuname = dsSDMTest.Tables[0].Rows[i]["muname"].ToString(),
                    sddMuseq = dsSDMTest.Tables[0].Rows[i]["museq"].ToString(),
                    sddMukey = dsSDMTest.Tables[0].Rows[i]["mukey"].ToString(),
                    sddComppct_r = dsSDMTest.Tables[0].Rows[i]["comppct_r"].ToString(),
                    sddCompname = dsSDMTest.Tables[0].Rows[i]["compname"].ToString(),
                    sddSlope_r = dsSDMTest.Tables[0].Rows[i]["slope_r"].ToString(),
                    sddCokey = dsSDMTest.Tables[0].Rows[i]["cokey"].ToString(),
                    sddHydricrating = dsSDMTest.Tables[0].Rows[i]["hydricrating"].ToString(),
                    sddHydgrp = dsSDMTest.Tables[0].Rows[i]["hydgrp"].ToString(),
                    sddHzdept_r = dsSDMTest.Tables[0].Rows[i]["hzdept_r"].ToString(),
                    sddHzdepb_r = dsSDMTest.Tables[0].Rows[i]["hzdepb_r"].ToString(),
                    sddChkey = dsSDMTest.Tables[0].Rows[i]["chkey"].ToString(),
                    sddSandtotal_r = dsSDMTest.Tables[0].Rows[i]["sandtotal_r"].ToString(),
                    sddSilttotal_r = dsSDMTest.Tables[0].Rows[i]["silttotal_r"].ToString(),
                    sddClaytotal_r = dsSDMTest.Tables[0].Rows[i]["claytotal_r"].ToString(),
                    sddOm_r = dsSDMTest.Tables[0].Rows[i]["om_r"].ToString(),
                    sddEcec_r = dsSDMTest.Tables[0].Rows[i]["ecec_r"].ToString(),
                    sddAwc_r = dsSDMTest.Tables[0].Rows[i]["awc_r"].ToString(),
                    sddKffact = dsSDMTest.Tables[0].Rows[i]["kffact"].ToString(),
                    sddKwfact = dsSDMTest.Tables[0].Rows[i]["kwfact"].ToString(),
                    sddTexdesc = dsSDMTest.Tables[0].Rows[i]["texdesc"].ToString(),
                    sddTexture = dsSDMTest.Tables[0].Rows[i]["texture"].ToString(),
                    sddStratextsflag = dsSDMTest.Tables[0].Rows[i]["stratextsflag"].ToString(),
                    sddRvindicator = dsSDMTest.Tables[0].Rows[i]["rvindicator"].ToString(),
                    sddTexcl = dsSDMTest.Tables[0].Rows[i]["texcl"].ToString()
                  };
                  soilDetails.Add(sSoil);
                  //nFirst50 += 1;
                }
                catch(Exception ex)
                {
                  log.Fatal("SDM Soils parse details failed. Cannot format detail data row #: " + i.ToString(), ex);
                  throw new ApplicationException("SDM Soils parse details failed.");
                }
              }
          }
          log.Debug("Details: " + soilDetails.Count.ToString());
        }

        SoilAllData sAllData = new SoilAllData();
        sAllData.saComponents = soilData;
        sAllData.saDetails = soilDetails;

        log.Info(sMeName + "<<Ending - " + sTrace.GetFrame(0).GetMethod().Name + ">>");

        return sAllData;
      }
      catch (Exception ex)
      {
        log.Fatal(ex);
        // create error info
        SoilAllData sAllData = new SoilAllData();
        soilData = new List<SoilComponentsData>();

        SoilComponentsData scInfo = new SoilComponentsData();
        scInfo.scdSSA = "Error";
        scInfo.scdName = "Error: " + ex.Message.ToString();
        soilData.Add(scInfo);
        sAllData.saComponents = soilData;
        sAllData.saDetails = null;
        return sAllData;
      }
    }

    public SoilAllData GetSDMSoilsAllCompPct(string sXMax, string sYMin, string sXMin, string sYMax, int nCompPct)
    {
      StackTrace sTrace = new StackTrace();
      string sMUKLStart = "<MapUnitKeyList>";
      string sMUKLEnd = "</MapUnitKeyList>";
      int nMUKLStartLocation = 0;
      int nMUKLEndLocation = 0;
      //int nFirst50 = 0;

      List<SoilComponentsData> soilData = new List<SoilComponentsData>();
      List<SoilDetailsData> soilDetails = new List<SoilDetailsData>();
      HttpWebRequest request = null;
      try
      {
        getAppSettings(sTrace.GetFrame(0).GetMethod().Name);
        log.Info(sMeName + "<<Starting - " + sTrace.GetFrame(0).GetMethod().Name + ">>");

        //test code
        //string sQuery = sQuerySDMSoilsBBox;

        //string sQuery = String.Format("{0}{1},{2},{3},{4}", sBBoxQuery, sXMax, sYMin, sXMin, sYMax);

        //HttpWebRequest request = WebRequest.Create(sQuery) as HttpWebRequest;
        if (ProcessCommon.AppEndPointServicesSDM.EndsWith("SDM"))
        {
          string sQuery = String.Format("{0}{1},{2},{3},{4}", sBBoxQuery, sXMin, sYMin, sXMax, sYMax);
          log.Debug("sQuery: " + sQuery.ToString());
          request = WebRequest.Create(sQuery) as HttpWebRequest;
        }
        else
        {
          string sQuery = String.Format("{0}{1},{2},{3},{4}", sBBoxFTCDevQuery, sXMin, sYMin, sXMax, sYMax);
          log.Debug("sQuery: " + sQuery.ToString());
          request = WebRequest.Create(sQuery) as HttpWebRequest;
        }

        if (request == null) throw new Exception("SDM Soils BBQuery failed - empty.");

        using (WebResponse response = request.GetResponse())
        {
          StreamReader stmReader = new StreamReader(response.GetResponseStream());
          string sTmp = stmReader.ReadToEnd();
          stmReader.Close();

          log.Debug("Response: " + sTmp);

          //if in error
          //"<?xml version='1.0' encoding=\"UTF-8\" standalone=\"no\" ?>\r\n<ServiceExceptionReport xmlns=\"http://www.opengis.net/ogc\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://www.opengis.net/ogc http://schemas.opengis.net/wms/1.1.1/OGC-exception.xsd\">\n<ServiceException>\r\nError getting BBOX and extent area from WFS request string (shorthand BBOX filter). Unable to create Rectangle from supplied corner coordinates. Ordinate order must be 'minx, miny, maxx, maxy'</ServiceException>\r\n</ServiceExceptionReport>\r\n"

          //extract values in MapUnitKeyList
          //<?xml version="1.0" encoding="ISO-8859-1" standalone="yes" ?> 
          //<MapUnitKeyList>'64070','64071','64174','64175','64081','64166','64079','64154'</MapUnitKeyList> 

          if (sTmp.Length == 0)
          {
            log.Debug("Response: Returning null - nothing returned from BB query.");
            throw new Exception("SDM Soils BBQuery failed - nothing returned.");
          }

          nMUKLStartLocation = sTmp.IndexOf(sMUKLStart);
          nMUKLEndLocation = sTmp.IndexOf(sMUKLEnd);

          if (nMUKLStartLocation == 0 || nMUKLEndLocation == 0 || nMUKLEndLocation < nMUKLStartLocation)
          {
            log.Debug("Response: Returning null - invalid data format from query.");
            throw new Exception("SDM Soils BBQuery parse location failed.");
          }

          string sKeys = sTmp.Substring(nMUKLStartLocation + sMUKLStart.Length, nMUKLEndLocation - (sMUKLStart.Length + nMUKLStartLocation));

          log.Debug("sKeys: " + sKeys.ToString());

          //get details based on returned keys
          SDMTabularServiceSoap.SDMTabularServiceSoapClient soilDataMart = new SDMTabularServiceSoap.SDMTabularServiceSoapClient(ProcessCommon.AppEndPointServicesSDM);

          //orig test
          //string sQString = String.Format("{0} {1} ({2}) {3}", sQuerySDMSoils.ToString(), sMultiKey.ToString(), "'64070','64071','64174','64175','64081','64166','64079','64154'", sOrderBy.ToString());

          //more test code when spatial query is not working
          //string sQString = String.Format("{0} {1} ({2}) {3}", sQuerySDMSoils.ToString(), sMultiKey.ToString(), sQuerySDMSoilsBBMUKeys.ToString(), sOrderBy.ToString());

          if (nCompPct < 1 || nCompPct > 100) nCompPct = 10; //set to 10 if invalid

          string sQString = String.Format("{0} {1} ({2}) {3}{4}{5}", sQuerySDMSoils.ToString(), sMultiKey.ToString(), sKeys.ToString(), sMajCompPct, nCompPct.ToString(), sOrderBy.ToString());

          log.Debug("sQString: " + sQString.ToString());

          DataSet dsSDMTest = soilDataMart.RunQuery(sQString.ToString());

          if (dsSDMTest == null)
          {
            log.Debug("RunQuery: Returning null - nothing returned from RunQuery.");
            throw new Exception("SDM Soils Query failed.");
          }
          if (dsSDMTest.Tables[0].Rows.Count < 1)
          {
            log.Debug("RunQuery: Returning null - No rows returned from RunQuery.");
            throw new Exception("SDM Soils Query returned nothing.");
          }

          log.Debug("Rows: " + dsSDMTest.Tables[0].Rows.Count.ToString());

          String previousMuseq = "";
          String previousMusym = "";

          for (int i = 0; i < dsSDMTest.Tables[0].Rows.Count; i++)
          {
            if (!String.IsNullOrEmpty(dsSDMTest.Tables[0].Rows[i]["museq"].ToString()))
            {
              String mapUnitSeq = dsSDMTest.Tables[0].Rows[i]["museq"].ToString();
              String mapUnitSym = dsSDMTest.Tables[0].Rows[i]["musym"].ToString();
              if (mapUnitSeq != previousMuseq || mapUnitSym != previousMusym)
              {
                SoilComponentsData sSoil = new SoilComponentsData
                {
                  scdSSA = dsSDMTest.Tables[0].Rows[i]["areasymbol"].ToString(),
                  scdSymbol = mapUnitSym,
                  scdName = dsSDMTest.Tables[0].Rows[i]["muname"].ToString(),
                  scdAcres = "0",
                  scdPercent = "0",
                  scdSlope = "0",
                  scdPH = "0",
                  scdStatus = ""
                };
                soilData.Add(sSoil);
              }

              previousMuseq = mapUnitSeq;
              previousMusym = mapUnitSym;
            }
          }

          log.Debug("Components: " + soilData.Count.ToString());

          for (int i = 0; i < dsSDMTest.Tables[0].Rows.Count; i++)
          {
            //if (nFirst50 < 50) // test code
            //{
            if (!String.IsNullOrEmpty(dsSDMTest.Tables[0].Rows[i]["museq"].ToString()))
            {
              try
              {
                SoilDetailsData sSoil = new SoilDetailsData
                {
                  sddSaversion = dsSDMTest.Tables[0].Rows[i]["saversion"].ToString(),
                  sddSaverest = dsSDMTest.Tables[0].Rows[i]["saverest"].ToString(),
                  sddAreasymbol = dsSDMTest.Tables[0].Rows[i]["areasymbol"].ToString(),
                  sddAreaname = dsSDMTest.Tables[0].Rows[i]["areaname"].ToString(),
                  sddMusym = dsSDMTest.Tables[0].Rows[i]["musym"].ToString(),
                  sddMuname = dsSDMTest.Tables[0].Rows[i]["muname"].ToString(),
                  sddMuseq = dsSDMTest.Tables[0].Rows[i]["museq"].ToString(),
                  sddMukey = dsSDMTest.Tables[0].Rows[i]["mukey"].ToString(),
                  sddComppct_r = dsSDMTest.Tables[0].Rows[i]["comppct_r"].ToString(),
                  sddCompname = dsSDMTest.Tables[0].Rows[i]["compname"].ToString(),
                  sddSlope_r = dsSDMTest.Tables[0].Rows[i]["slope_r"].ToString(),
                  sddCokey = dsSDMTest.Tables[0].Rows[i]["cokey"].ToString(),
                  sddHydricrating = dsSDMTest.Tables[0].Rows[i]["hydricrating"].ToString(),
                  sddHydgrp = dsSDMTest.Tables[0].Rows[i]["hydgrp"].ToString(),
                  sddHzdept_r = dsSDMTest.Tables[0].Rows[i]["hzdept_r"].ToString(),
                  sddHzdepb_r = dsSDMTest.Tables[0].Rows[i]["hzdepb_r"].ToString(),
                  sddChkey = dsSDMTest.Tables[0].Rows[i]["chkey"].ToString(),
                  sddSandtotal_r = dsSDMTest.Tables[0].Rows[i]["sandtotal_r"].ToString(),
                  sddSilttotal_r = dsSDMTest.Tables[0].Rows[i]["silttotal_r"].ToString(),
                  sddClaytotal_r = dsSDMTest.Tables[0].Rows[i]["claytotal_r"].ToString(),
                  sddOm_r = dsSDMTest.Tables[0].Rows[i]["om_r"].ToString(),
                  sddEcec_r = dsSDMTest.Tables[0].Rows[i]["ecec_r"].ToString(),
                  sddAwc_r = dsSDMTest.Tables[0].Rows[i]["awc_r"].ToString(),
                  sddKffact = dsSDMTest.Tables[0].Rows[i]["kffact"].ToString(),
                  sddKwfact = dsSDMTest.Tables[0].Rows[i]["kwfact"].ToString(),
                  sddTexdesc = dsSDMTest.Tables[0].Rows[i]["texdesc"].ToString(),
                  sddTexture = dsSDMTest.Tables[0].Rows[i]["texture"].ToString(),
                  sddStratextsflag = dsSDMTest.Tables[0].Rows[i]["stratextsflag"].ToString(),
                  sddRvindicator = dsSDMTest.Tables[0].Rows[i]["rvindicator"].ToString(),
                  sddTexcl = dsSDMTest.Tables[0].Rows[i]["texcl"].ToString()
                };
                soilDetails.Add(sSoil);
                //nFirst50 += 1;
              }
              catch(Exception ex)
              {
                  log.Fatal("SDM Soils parse details failed.  Cannot format detail data row #: " + i.ToString(), ex);
                  throw new ApplicationException("SDM Soils parse details failed.");
              }
            }
            //}
          }
          log.Debug("Details: " + soilDetails.Count.ToString());
        }

        SoilAllData sAllData = new SoilAllData();
        sAllData.saComponents = soilData;
        sAllData.saDetails = soilDetails;

        log.Debug(sMeName + "<<Ending - " + sTrace.GetFrame(0).GetMethod().Name + ">>");

        return sAllData;
      }
      catch (Exception ex)
      {
        log.Fatal(ex);
        // create error info
        SoilAllData sAllData = new SoilAllData();
        soilData = new List<SoilComponentsData>();
        soilDetails = new List<SoilDetailsData>();

        SoilComponentsData scInfo = new SoilComponentsData();
        scInfo.scdSSA = "Error";
        scInfo.scdName = "Error: " + ex.Message.ToString();
        soilData.Add(scInfo);
        sAllData.saComponents = soilData;
        sAllData.saDetails = soilDetails;
        return sAllData;
      }
    }

    #region Test Methods

    public string GetHello(string value)
    {
      StackTrace sTrace = new StackTrace();
      try
      {
        getAppSettings(sTrace.GetFrame(0).GetMethod().Name);
        log.Info(sMeName + "<<Starting - " + sTrace.GetFrame(0).GetMethod().Name + ">>");

        log.Debug(sMeName + "<<Ending - " + sTrace.GetFrame(0).GetMethod().Name + ">>");
      return string.Format("You asked for: Hello: ", value);
      }
      catch (Exception ex)
      {
        log.Fatal(ex);
        return "Error: " + ex.Message.ToString();
      }
    }
    public string GetSDMTestRows()
    {
      StackTrace sTrace = new StackTrace();
      try
      {
        getAppSettings(sTrace.GetFrame(0).GetMethod().Name);
        log.Info(sMeName + "<<Starting - " + sTrace.GetFrame(0).GetMethod().Name + ">>");

        SDMTabularServiceSoap.SDMTabularServiceSoapClient soilDataMart = new SDMTabularServiceSoap.SDMTabularServiceSoapClient(ProcessCommon.AppEndPointServicesSDM);

        DataSet dsSDMTest = soilDataMart.RunQuery(sQuerySDMSoils.ToString() + sSingleKey.ToString());

        log.Info(sMeName + "<<Ending - " + sTrace.GetFrame(0).GetMethod().Name + ">>");

        if (dsSDMTest == null)
        {
          return "Rows found: 0";
        }
        else
        {
          return "Rows found: " + dsSDMTest.Tables[0].Rows.Count.ToString();

            //DataTable table = dataSet.Tables[0];
            //return (Single)table.Rows[0][0];
        }
      }
      catch (Exception ex)
      {
        log.Fatal(ex);
        return "Error: " + ex.Message.ToString();
      }
    }
    public string GetSDMTestDSetXML()
    {
      StackTrace sTrace = new StackTrace();
      try
      {
        getAppSettings(sTrace.GetFrame(0).GetMethod().Name);
        log.Info(sMeName + "<<Starting - " + sTrace.GetFrame(0).GetMethod().Name + ">>");

        SDMTabularServiceSoap.SDMTabularServiceSoapClient soilDataMart = new SDMTabularServiceSoap.SDMTabularServiceSoapClient(ProcessCommon.AppEndPointServicesSDM);

        DataSet dsSDMTest = soilDataMart.RunQuery(sQuerySDMSoils.ToString() + sSingleKey.ToString());

        log.Debug(sMeName + "<<Ending - " + sTrace.GetFrame(0).GetMethod().Name + ">>");

        if (dsSDMTest == null)
        {
          return "Error: Returned null.";
        }
        else
        {
          return dsSDMTest.GetXml();
        }
      }
      catch (Exception ex)
      {
        log.Fatal(ex);
        return "Error: " + ex.Message.ToString();
      }
    }
    public string GetSDMTestBBoxHttpResponse()
    {
      StackTrace sTrace = new StackTrace();
      string sTmp = "";
      HttpWebRequest request = null;

      try
      {
        getAppSettings(sTrace.GetFrame(0).GetMethod().Name);
        log.Info(sMeName + "<<Starting - " + sTrace.GetFrame(0).GetMethod().Name + ">>");

        //HttpWebRequest request = WebRequest.Create(sQuerySDMSoilsBBox) as HttpWebRequest;
        if (ProcessCommon.AppEndPointServicesSDM.EndsWith("SDM"))
        {
          request = WebRequest.Create(sQuerySDMSoilsBBox) as HttpWebRequest;
        }
        else
        {
          request = WebRequest.Create(sQueryFTCDevSoilsBBox) as HttpWebRequest;
        }

        using (WebResponse response = request.GetResponse())
        {
          using (XmlReader reader = new XmlTextReader(response.GetResponseStream()))
          {
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.Load(reader);
            //return readResponse(xmlDoc, geometry);
            //just a test
            sTmp = xmlDoc.InnerXml.ToString();
          }
        }

        log.Info(sMeName + "<<Ending - " + sTrace.GetFrame(0).GetMethod().Name + ">>");

        return sTmp;
      }
      catch (Exception ex)
      {
        log.Fatal(ex);
        return "Error: " + ex.Message.ToString();
      }
    }
    public string GetSDMTestBBoxCoordinates(string sXMax, string sYMin, string sXMin, string sYMax)
    {
      StackTrace sTrace = new StackTrace();
      string sReturn = "";
      string sMUKLStart = "<MapUnitKeyList>";
      string sMUKLEnd = "</MapUnitKeyList>";
      int nMUKLStartLocation = 0;
      int nMUKLEndLocation = 0;
      HttpWebRequest request = null;
      try
      {
        getAppSettings(sTrace.GetFrame(0).GetMethod().Name);
        log.Info(sMeName + "<<Starting - " + sTrace.GetFrame(0).GetMethod().Name + ">>");

        //string sQuery = sBBoxQuery + sBBoxCoordinates; //static BB values for test

        //HttpWebRequest request = WebRequest.Create(sQuery) as HttpWebRequest;
        if (ProcessCommon.AppEndPointServicesSDM.EndsWith("SDM"))
        {
          string sQuery = String.Format("{0}{1},{2},{3},{4}", sBBoxQuery, sXMax, sYMin, sXMin, sYMax);
          request = WebRequest.Create(sQuery) as HttpWebRequest;
        }
        else
        {
          string sQuery = String.Format("{0}{1},{2},{3},{4}", sBBoxFTCDevQuery, sXMax, sYMin, sXMin, sYMax);
          request = WebRequest.Create(sQuery) as HttpWebRequest;
        }

        using (WebResponse response = request.GetResponse())
        {
          StreamReader stmReader = new StreamReader(response.GetResponseStream());
          string sTmp = stmReader.ReadToEnd();
          stmReader.Close();

          //extract values in MapUnitKeyList
          //<?xml version="1.0" encoding="ISO-8859-1" standalone="yes" ?> 
          //<MapUnitKeyList>'64070','64071','64174','64175','64081','64166','64079','64154'</MapUnitKeyList> 

          if (sTmp.Length == 0)
          {
            return sReturn;
          }

          nMUKLStartLocation = sTmp.IndexOf(sMUKLStart);
          nMUKLEndLocation = sTmp.IndexOf(sMUKLEnd);

          if (nMUKLStartLocation == 0 || nMUKLEndLocation == 0 || nMUKLEndLocation < nMUKLStartLocation)
          {
            return sReturn;
          }

          sReturn = sTmp.Substring(nMUKLStartLocation + sMUKLStart.Length, nMUKLEndLocation - (sMUKLStart.Length + nMUKLStartLocation));
        }
      }
      catch (Exception ex)
      {
          log.Fatal(ex);
          throw ex;
      }
      log.Info(sMeName + "<<Ending - " + sTrace.GetFrame(0).GetMethod().Name + ">>");
      return sReturn;
    }
    public string GetSDMTestBBoxRows()
    {
      StackTrace sTrace = new StackTrace();
      string sQuery = "";
      try
      {
        getAppSettings(sTrace.GetFrame(0).GetMethod().Name);
        log.Info(sMeName + "<<Starting - " + sTrace.GetFrame(0).GetMethod().Name + ">>");

        string sMUKeys = getMUKeys(sBBoxCoordinates);

        SDMTabularServiceSoap.SDMTabularServiceSoapClient soilDataMart = new SDMTabularServiceSoap.SDMTabularServiceSoapClient(ProcessCommon.AppEndPointServicesSDM);

        sQuery = string.Format("{0} in ( {1} )", sQuerySDMSoils.ToString(), sMUKeys.ToString());
        DataSet dsSDMTest = soilDataMart.RunQuery(sQuery);

        if (dsSDMTest == null)
        {
          return "Rows found: 0";
        }
        else
        {
          log.Info(sMeName + "<<Ending - " + sTrace.GetFrame(0).GetMethod().Name + ">>");
          return "Rows found: " + dsSDMTest.Tables[0].Rows.Count.ToString();
        }
      }
      catch (Exception ex)
      {
        //StackTrace sTrace = new StackTrace();
        //WriteToErrorFile(sMeName, sPathName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", ex);
        //throw ex;
          log.Error(ex);
        return "Rows found: 0";
      }
    }
    public List<SoilComponentsData> GetSDMTestSoilComponents()
    {
      StackTrace sTrace = new StackTrace();
      string sMUKLStart = "<MapUnitKeyList>";
      string sMUKLEnd = "</MapUnitKeyList>";
      int nMUKLStartLocation = 0;
      int nMUKLEndLocation = 0;
      HttpWebRequest request = null;

      try
      {
        getAppSettings(sTrace.GetFrame(0).GetMethod().Name);
        log.Info(sMeName + "<<Starting - " + sTrace.GetFrame(0).GetMethod().Name + ">>");

        //HttpWebRequest request = WebRequest.Create(sQuery) as HttpWebRequest;
        if (ProcessCommon.AppEndPointServicesSDM.EndsWith("SDM"))
        {
          string sQuery = sQuerySDMSoilsBBox;
          log.Debug("sQuery: " + sQuery.ToString());
          request = WebRequest.Create(sQuery) as HttpWebRequest;
        }
        else
        {
          string sQuery = sQueryFTCDevSoilsBBox;
          log.Debug("sQuery: " + sQuery.ToString());
          request = WebRequest.Create(sQuery) as HttpWebRequest;
        }

        using (WebResponse response = request.GetResponse())
        {
          StreamReader stmReader = new StreamReader(response.GetResponseStream());
          string sTmp = stmReader.ReadToEnd();
          stmReader.Close();

          //if in error
          //"<?xml version='1.0' encoding=\"UTF-8\" standalone=\"no\" ?>\r\n<ServiceExceptionReport xmlns=\"http://www.opengis.net/ogc\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://www.opengis.net/ogc http://schemas.opengis.net/wms/1.1.1/OGC-exception.xsd\">\n<ServiceException>\r\nError getting BBOX and extent area from WFS request string (shorthand BBOX filter). Unable to create Rectangle from supplied corner coordinates. Ordinate order must be 'minx, miny, maxx, maxy'</ServiceException>\r\n</ServiceExceptionReport>\r\n"

          //extract values in MapUnitKeyList
          //<?xml version="1.0" encoding="ISO-8859-1" standalone="yes" ?> 
          //<MapUnitKeyList>'64070','64071','64174','64175','64081','64166','64079','64154'</MapUnitKeyList> 

          if (sTmp.Length == 0)
          { return null; } //return null for now

          nMUKLStartLocation = sTmp.IndexOf(sMUKLStart);
          nMUKLEndLocation = sTmp.IndexOf(sMUKLEnd);

          if (nMUKLStartLocation == 0 || nMUKLEndLocation == 0 || nMUKLEndLocation < nMUKLStartLocation)
          { return null; } //return null for now

          string sKeys = sTmp.Substring(nMUKLStartLocation + sMUKLStart.Length, nMUKLEndLocation - (sMUKLStart.Length + nMUKLStartLocation));

          log.Debug("sKeys: " + sKeys.ToString());

          //get details based on returned keys
          SDMTabularServiceSoap.SDMTabularServiceSoapClient soilDataMart = new SDMTabularServiceSoap.SDMTabularServiceSoapClient(ProcessCommon.AppEndPointServicesSDM);

          string sQString = String.Format("{0} {1} ({2}) {3}", sQuerySDMSoils.ToString(), sMultiKey.ToString(), sKeys.ToString(), sOrderBy.ToString());

          DataSet dsSDMTest = soilDataMart.RunQuery(sQString.ToString());

          if (dsSDMTest == null)
          {
            return null; //return null for now
          }
          if (dsSDMTest.Tables[0].Rows.Count < 1) return null; //return null for now

          log.Debug("Rows: " + dsSDMTest.Tables[0].Rows.Count.ToString());

          List<SoilComponentsData> soilData = new List<SoilComponentsData>();

          String previousMuseq = "";
          String previousMusym = "";

          for (int i = 0; i < dsSDMTest.Tables[0].Rows.Count; i++)
          {
            if (!String.IsNullOrEmpty(dsSDMTest.Tables[0].Rows[i]["museq"].ToString()))
            {
              String mapUnitSeq = dsSDMTest.Tables[0].Rows[i]["museq"].ToString();
              String mapUnitSym = dsSDMTest.Tables[0].Rows[i]["musym"].ToString();
              if (mapUnitSeq != previousMuseq || mapUnitSym != previousMusym)
              {
                SoilComponentsData sSoil = new SoilComponentsData
                {
                  scdSSA = dsSDMTest.Tables[0].Rows[i]["areasymbol"].ToString(),
                  scdSymbol = mapUnitSym,
                  scdName = dsSDMTest.Tables[0].Rows[i]["muname"].ToString(),
                  scdAcres = "0",
                  scdPercent = "0",
                  scdSlope = "0",
                  scdPH = "0",
                  scdStatus = ""
                };
                soilData.Add(sSoil);
              }

              previousMuseq = mapUnitSeq;
              previousMusym = mapUnitSym;
            }
          }

          log.Debug("Components: " + soilData.Count.ToString());

        log.Info(sMeName + "<<Ending - " + sTrace.GetFrame(0).GetMethod().Name + ">>");

          return soilData;
        }
      }
      catch (Exception ex)
      {
        log.Fatal(ex);
        return null;
      }
    }
    public List<SoilDetailsData> GetSDMTestSoilDetails()
    {
      StackTrace sTrace = new StackTrace();
      string sMUKLStart = "<MapUnitKeyList>";
      string sMUKLEnd = "</MapUnitKeyList>";
      int nMUKLStartLocation = 0;
      int nMUKLEndLocation = 0;
      int nFirst50 = 0;
      HttpWebRequest request = null;
      try
      {
        getAppSettings(sTrace.GetFrame(0).GetMethod().Name);
        log.Info(sMeName + "<<Starting - " + sTrace.GetFrame(0).GetMethod().Name + ">>");

        //HttpWebRequest request = WebRequest.Create(sQuery) as HttpWebRequest;
        if (ProcessCommon.AppEndPointServicesSDM.EndsWith("SDM"))
        {
          string sQuery = sQuerySDMSoilsBBox;
          log.Debug("sQuery: " + sQuery.ToString());
          request = WebRequest.Create(sQuery) as HttpWebRequest;
        }
        else
        {
          string sQuery = sQueryFTCDevSoilsBBox;
          log.Debug("sQuery: " + sQuery.ToString());
          request = WebRequest.Create(sQuery) as HttpWebRequest;
        }

        using (WebResponse response = request.GetResponse())
        {
          StreamReader stmReader = new StreamReader(response.GetResponseStream());
          string sTmp = stmReader.ReadToEnd();
          stmReader.Close();

          //if in error
          //"<?xml version='1.0' encoding=\"UTF-8\" standalone=\"no\" ?>\r\n<ServiceExceptionReport xmlns=\"http://www.opengis.net/ogc\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://www.opengis.net/ogc http://schemas.opengis.net/wms/1.1.1/OGC-exception.xsd\">\n<ServiceException>\r\nError getting BBOX and extent area from WFS request string (shorthand BBOX filter). Unable to create Rectangle from supplied corner coordinates. Ordinate order must be 'minx, miny, maxx, maxy'</ServiceException>\r\n</ServiceExceptionReport>\r\n"

          //extract values in MapUnitKeyList
          //<?xml version="1.0" encoding="ISO-8859-1" standalone="yes" ?> 
          //<MapUnitKeyList>'64070','64071','64174','64175','64081','64166','64079','64154'</MapUnitKeyList> 

          if (sTmp.Length == 0)
          { return null; } //return null for now

          nMUKLStartLocation = sTmp.IndexOf(sMUKLStart);
          nMUKLEndLocation = sTmp.IndexOf(sMUKLEnd);

          if (nMUKLStartLocation == 0 || nMUKLEndLocation == 0 || nMUKLEndLocation < nMUKLStartLocation)
          { return null; } //return null for now

          string sKeys = sTmp.Substring(nMUKLStartLocation + sMUKLStart.Length, nMUKLEndLocation - (sMUKLStart.Length + nMUKLStartLocation));

          log.Debug("sKeys: " + sKeys.ToString());

          //get details based on returned keys
          SDMTabularServiceSoap.SDMTabularServiceSoapClient soilDataMart = new SDMTabularServiceSoap.SDMTabularServiceSoapClient(ProcessCommon.AppEndPointServicesSDM);

          string sQString = String.Format("{0} {1} ({2}) {3}", sQuerySDMSoils.ToString(), sMultiKey.ToString(), sKeys.ToString(), sOrderBy.ToString());

          DataSet dsSDMTest = soilDataMart.RunQuery(sQString.ToString());

          if (dsSDMTest == null)
          {
            return null; //return null for now
          }
          if (dsSDMTest.Tables[0].Rows.Count < 1) return null; //return null for now

          log.Debug("Rows: " + dsSDMTest.Tables[0].Rows.Count.ToString());

          List<SoilDetailsData> soilDetails = new List<SoilDetailsData>();

          for (int i = 0; i < dsSDMTest.Tables[0].Rows.Count; i++)
          {
            if (nFirst50 < 50)
            {
              if (!String.IsNullOrEmpty(dsSDMTest.Tables[0].Rows[i]["museq"].ToString()))
              {
                try
                {
                  SoilDetailsData sSoil = new SoilDetailsData
                  {
                    sddSaversion = dsSDMTest.Tables[0].Rows[i]["saversion"].ToString(),
                    sddSaverest = dsSDMTest.Tables[0].Rows[i]["saverest"].ToString(),
                    sddAreasymbol = dsSDMTest.Tables[0].Rows[i]["areasymbol"].ToString(),
                    sddAreaname = dsSDMTest.Tables[0].Rows[i]["areaname"].ToString(),
                    sddMusym = dsSDMTest.Tables[0].Rows[i]["musym"].ToString(),
                    sddMuname = dsSDMTest.Tables[0].Rows[i]["muname"].ToString(),
                    sddMuseq = dsSDMTest.Tables[0].Rows[i]["museq"].ToString(),
                    sddMukey = dsSDMTest.Tables[0].Rows[i]["mukey"].ToString(),
                    sddComppct_r = dsSDMTest.Tables[0].Rows[i]["comppct_r"].ToString(),
                    sddCompname = dsSDMTest.Tables[0].Rows[i]["compname"].ToString(),
                    sddSlope_r = dsSDMTest.Tables[0].Rows[i]["slope_r"].ToString(),
                    sddCokey = dsSDMTest.Tables[0].Rows[i]["cokey"].ToString(),
                    sddHydricrating = dsSDMTest.Tables[0].Rows[i]["hydricrating"].ToString(),
                    sddHydgrp = dsSDMTest.Tables[0].Rows[i]["hydgrp"].ToString(),
                    sddHzdept_r = dsSDMTest.Tables[0].Rows[i]["hzdept_r"].ToString(),
                    sddHzdepb_r = dsSDMTest.Tables[0].Rows[i]["hzdepb_r"].ToString(),
                    sddChkey = dsSDMTest.Tables[0].Rows[i]["chkey"].ToString(),
                    sddSandtotal_r = dsSDMTest.Tables[0].Rows[i]["sandtotal_r"].ToString(),
                    sddSilttotal_r = dsSDMTest.Tables[0].Rows[i]["silttotal_r"].ToString(),
                    sddClaytotal_r = dsSDMTest.Tables[0].Rows[i]["claytotal_r"].ToString(),
                    sddOm_r = dsSDMTest.Tables[0].Rows[i]["om_r"].ToString(),
                    sddEcec_r = dsSDMTest.Tables[0].Rows[i]["ecec_r"].ToString(),
                    sddAwc_r = dsSDMTest.Tables[0].Rows[i]["awc_r"].ToString(),
                    sddKffact = dsSDMTest.Tables[0].Rows[i]["kffact"].ToString(),
                    sddKwfact = dsSDMTest.Tables[0].Rows[i]["kwfact"].ToString(),
                    sddTexdesc = dsSDMTest.Tables[0].Rows[i]["texdesc"].ToString(),
                    sddTexture = dsSDMTest.Tables[0].Rows[i]["texture"].ToString(),
                    sddStratextsflag = dsSDMTest.Tables[0].Rows[i]["stratextsflag"].ToString(),
                    sddRvindicator = dsSDMTest.Tables[0].Rows[i]["rvindicator"].ToString(),
                    sddTexcl = dsSDMTest.Tables[0].Rows[i]["texcl"].ToString()
                  };
                  soilDetails.Add(sSoil);
                  nFirst50 += 1;
                }
                catch
                { //do nothing for now
                }
              }
            }
          }

          log.Debug("Details: " + soilDetails.Count.ToString());

          log.Info(sMeName + "<<Ending - " + sTrace.GetFrame(0).GetMethod().Name + ">>");

          return soilDetails;
        }
      }
      catch (Exception ex)
      {
        log.Fatal(ex);
        return null;
      }
    }
    public SoilAllData GetSDMTestSoilsAll()
    {
      StackTrace sTrace = new StackTrace();
      string sMUKLStart = "<MapUnitKeyList>";
      string sMUKLEnd = "</MapUnitKeyList>";
      int nMUKLStartLocation = 0;
      int nMUKLEndLocation = 0;
      //int nFirst50 = 0;
      try
      {
        getAppSettings(sTrace.GetFrame(0).GetMethod().Name);
        log.Info(sMeName + "<<Starting - " + sTrace.GetFrame(0).GetMethod().Name + ">>");

        //string sQuery = sQuerySDMSoilsBBox;

        //LogHandler.WriteToDebugFile("sQuery: " + sQuery.ToString(), 4, 4);

        //HttpWebRequest request = WebRequest.Create(sQuery) as HttpWebRequest;

        //using (WebResponse response = request.GetResponse())
        //{
        //  StreamReader stmReader = new StreamReader(response.GetResponseStream());
        //  string sTmp = stmReader.ReadToEnd();
        //  stmReader.Close();

        //  //if in error
        //  //"<?xml version='1.0' encoding=\"UTF-8\" standalone=\"no\" ?>\r\n<ServiceExceptionReport xmlns=\"http://www.opengis.net/ogc\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://www.opengis.net/ogc http://schemas.opengis.net/wms/1.1.1/OGC-exception.xsd\">\n<ServiceException>\r\nError getting BBOX and extent area from WFS request string (shorthand BBOX filter). Unable to create Rectangle from supplied corner coordinates. Ordinate order must be 'minx, miny, maxx, maxy'</ServiceException>\r\n</ServiceExceptionReport>\r\n"

        //  //extract values in MapUnitKeyList
        //  //<?xml version="1.0" encoding="ISO-8859-1" standalone="yes" ?> 
        //  //<MapUnitKeyList>'64070','64071','64174','64175','64081','64166','64079','64154'</MapUnitKeyList> 

        //  if (sTmp.Length == 0)
        //  { return null; } //return null for now

        //  nMUKLStartLocation = sTmp.IndexOf(sMUKLStart);
        //  nMUKLEndLocation = sTmp.IndexOf(sMUKLEnd);

        //  if (nMUKLStartLocation == 0 || nMUKLEndLocation == 0 || nMUKLEndLocation < nMUKLStartLocation)
        //  { return null; } //return null for now

        //  string sKeys = sTmp.Substring(nMUKLStartLocation + sMUKLStart.Length, nMUKLEndLocation - (sMUKLStart.Length + nMUKLStartLocation));

        //  LogHandler.WriteToDebugFile("sKeys: " + sKeys.ToString(), 4, 4);

          //get details based on returned keys
        SDMTabularServiceSoap.SDMTabularServiceSoapClient soilDataMart = new SDMTabularServiceSoap.SDMTabularServiceSoapClient(ProcessCommon.AppEndPointServicesSDM);

        //orig test
          //string sQString = String.Format("{0} {1} ({2}) {3}", sQuerySDMSoils.ToString(), sMultiKey.ToString(), "'64070','64071','64174','64175','64081','64166','64079','64154'", sOrderBy.ToString());

          string sQString = String.Format("{0} {1} ({2}) {3}", sQuerySDMSoils.ToString(), sMultiKey.ToString(), sQuerySDMSoilsBBMUKeys.ToString(), sOrderBy.ToString());

        DataSet dsSDMTest = soilDataMart.RunQuery(sQString.ToString());

        if (dsSDMTest == null) throw new Exception("SDM Soils Query failed.");
        if (dsSDMTest.Tables[0].Rows.Count < 1) throw new Exception("SDM Soils Query returned nothing.");

        log.Debug("Rows: " + dsSDMTest.Tables[0].Rows.Count.ToString());

        List<SoilComponentsData> soilData = new List<SoilComponentsData>();

        String previousMuseq = "";
        String previousMusym = "";

        for (int i = 0; i < dsSDMTest.Tables[0].Rows.Count; i++)
        {
          if (!String.IsNullOrEmpty(dsSDMTest.Tables[0].Rows[i]["museq"].ToString()))
          {
            String mapUnitSeq = dsSDMTest.Tables[0].Rows[i]["museq"].ToString();
            String mapUnitSym = dsSDMTest.Tables[0].Rows[i]["musym"].ToString();
            if (mapUnitSeq != previousMuseq || mapUnitSym != previousMusym)
            {
              SoilComponentsData sSoil = new SoilComponentsData
              {
                scdSSA = dsSDMTest.Tables[0].Rows[i]["areasymbol"].ToString(),
                scdSymbol = mapUnitSym,
                scdName = dsSDMTest.Tables[0].Rows[i]["muname"].ToString(),
                scdAcres = "0",
                scdPercent = "0",
                scdSlope = "0",
                scdPH = "0",
                scdStatus = ""
              };
              soilData.Add(sSoil);
            }

            previousMuseq = mapUnitSeq;
            previousMusym = mapUnitSym;
          }
        }

        List<SoilDetailsData> soilDetails = new List<SoilDetailsData>();

        for (int i = 0; i < dsSDMTest.Tables[0].Rows.Count; i++)
        {
          //if (nFirst50 < 50)
          //{
            if (!String.IsNullOrEmpty(dsSDMTest.Tables[0].Rows[i]["museq"].ToString()))
            {
              try
              {
                SoilDetailsData sSoil = new SoilDetailsData
                {
                  sddSaversion = dsSDMTest.Tables[0].Rows[i]["saversion"].ToString(),
                  sddSaverest = dsSDMTest.Tables[0].Rows[i]["saverest"].ToString(),
                  sddAreasymbol = dsSDMTest.Tables[0].Rows[i]["areasymbol"].ToString(),
                  sddAreaname = dsSDMTest.Tables[0].Rows[i]["areaname"].ToString(),
                  sddMusym = dsSDMTest.Tables[0].Rows[i]["musym"].ToString(),
                  sddMuname = dsSDMTest.Tables[0].Rows[i]["muname"].ToString(),
                  sddMuseq = dsSDMTest.Tables[0].Rows[i]["museq"].ToString(),
                  sddMukey = dsSDMTest.Tables[0].Rows[i]["mukey"].ToString(),
                  sddComppct_r = dsSDMTest.Tables[0].Rows[i]["comppct_r"].ToString(),
                  sddCompname = dsSDMTest.Tables[0].Rows[i]["compname"].ToString(),
                  sddSlope_r = dsSDMTest.Tables[0].Rows[i]["slope_r"].ToString(),
                  sddCokey = dsSDMTest.Tables[0].Rows[i]["cokey"].ToString(),
                  sddHydricrating = dsSDMTest.Tables[0].Rows[i]["hydricrating"].ToString(),
                  sddHydgrp = dsSDMTest.Tables[0].Rows[i]["hydgrp"].ToString(),
                  sddHzdept_r = dsSDMTest.Tables[0].Rows[i]["hzdept_r"].ToString(),
                  sddHzdepb_r = dsSDMTest.Tables[0].Rows[i]["hzdepb_r"].ToString(),
                  sddChkey = dsSDMTest.Tables[0].Rows[i]["chkey"].ToString(),
                  sddSandtotal_r = dsSDMTest.Tables[0].Rows[i]["sandtotal_r"].ToString(),
                  sddSilttotal_r = dsSDMTest.Tables[0].Rows[i]["silttotal_r"].ToString(),
                  sddClaytotal_r = dsSDMTest.Tables[0].Rows[i]["claytotal_r"].ToString(),
                  sddOm_r = dsSDMTest.Tables[0].Rows[i]["om_r"].ToString(),
                  sddEcec_r = dsSDMTest.Tables[0].Rows[i]["ecec_r"].ToString(),
                  sddAwc_r = dsSDMTest.Tables[0].Rows[i]["awc_r"].ToString(),
                  sddKffact = dsSDMTest.Tables[0].Rows[i]["kffact"].ToString(),
                  sddKwfact = dsSDMTest.Tables[0].Rows[i]["kwfact"].ToString(),
                  sddTexdesc = dsSDMTest.Tables[0].Rows[i]["texdesc"].ToString(),
                  sddTexture = dsSDMTest.Tables[0].Rows[i]["texture"].ToString(),
                  sddStratextsflag = dsSDMTest.Tables[0].Rows[i]["stratextsflag"].ToString(),
                  sddRvindicator = dsSDMTest.Tables[0].Rows[i]["rvindicator"].ToString(),
                  sddTexcl = dsSDMTest.Tables[0].Rows[i]["texcl"].ToString()
                };
                soilDetails.Add(sSoil);
                //nFirst50 += 1;
              }
              catch
              { throw new Exception("SDM Soils parse details failed."); }
            }
          //}
        }

        SoilAllData sAllData = new SoilAllData();
        sAllData.saComponents = soilData;
        sAllData.saDetails = soilDetails;

        log.Debug("Components: " + soilData.Count.ToString());
        log.Debug("Details: " + soilDetails.Count.ToString());

        log.Info(sMeName + "<<Ending - " + sTrace.GetFrame(0).GetMethod().Name + ">>");

        return sAllData;
      }
      catch (Exception ex)
      {
        log.Fatal(ex);
        // create error info
        SoilAllData sAllData = new SoilAllData();
        List<SoilComponentsData> soilData = new List<SoilComponentsData>();
        
        SoilComponentsData scInfo = new SoilComponentsData();
        scInfo.scdSSA = "Error";
        scInfo.scdName = "Error: " + ex.Message.ToString();
        soilData.Add(scInfo);
        sAllData.saComponents = soilData;
        sAllData.saDetails = null;
        return sAllData;
      }
    }
    public SoilAllData GetSDMTestSoilsAllCompPct()
    {
      StackTrace sTrace = new StackTrace();
      string sMUKLStart = "<MapUnitKeyList>";
      string sMUKLEnd = "</MapUnitKeyList>";
      int nMUKLStartLocation = 0;
      int nMUKLEndLocation = 0;
      //int nFirst50 = 0;
      try
      {
        getAppSettings(sTrace.GetFrame(0).GetMethod().Name);
        log.Info(sMeName + "<<Starting - " + sTrace.GetFrame(0).GetMethod().Name + ">>");

        //string sQuery = sQuerySDMSoilsBBox;

        //LogHandler.WriteToDebugFile("sQuery: " + sQuery.ToString(), 4, 4);

        //HttpWebRequest request = WebRequest.Create(sQuery) as HttpWebRequest;

        //using (WebResponse response = request.GetResponse())
        //{
        //  StreamReader stmReader = new StreamReader(response.GetResponseStream());
        //  string sTmp = stmReader.ReadToEnd();
        //  stmReader.Close();

        //  //if in error
        //  //"<?xml version='1.0' encoding=\"UTF-8\" standalone=\"no\" ?>\r\n<ServiceExceptionReport xmlns=\"http://www.opengis.net/ogc\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://www.opengis.net/ogc http://schemas.opengis.net/wms/1.1.1/OGC-exception.xsd\">\n<ServiceException>\r\nError getting BBOX and extent area from WFS request string (shorthand BBOX filter). Unable to create Rectangle from supplied corner coordinates. Ordinate order must be 'minx, miny, maxx, maxy'</ServiceException>\r\n</ServiceExceptionReport>\r\n"

        //  //extract values in MapUnitKeyList
        //  //<?xml version="1.0" encoding="ISO-8859-1" standalone="yes" ?> 
        //  //<MapUnitKeyList>'64070','64071','64174','64175','64081','64166','64079','64154'</MapUnitKeyList> 

        //  if (sTmp.Length == 0)
        //  { return null; } //return null for now

        //  nMUKLStartLocation = sTmp.IndexOf(sMUKLStart);
        //  nMUKLEndLocation = sTmp.IndexOf(sMUKLEnd);

        //  if (nMUKLStartLocation == 0 || nMUKLEndLocation == 0 || nMUKLEndLocation < nMUKLStartLocation)
        //  { return null; } //return null for now

        //  string sKeys = sTmp.Substring(nMUKLStartLocation + sMUKLStart.Length, nMUKLEndLocation - (sMUKLStart.Length + nMUKLStartLocation));

        //  LogHandler.WriteToDebugFile("sKeys: " + sKeys.ToString(), 4, 4);

        //get details based on returned keys
        SDMTabularServiceSoap.SDMTabularServiceSoapClient soilDataMart = new SDMTabularServiceSoap.SDMTabularServiceSoapClient(ProcessCommon.AppEndPointServicesSDM);
        

        //orig test
        //string sQString = String.Format("{0} {1} ({2}) {3}", sQuerySDMSoils.ToString(), sMultiKey.ToString(), "'64070','64071','64174','64175','64081','64166','64079','64154'", sOrderBy.ToString());

        string sQString = String.Format("{0} {1} ({2}) {3}{4}{5}", sQuerySDMSoils.ToString(), sMultiKey.ToString(), sQuerySDMSoilsBBMUKeys.ToString(), sMajCompPct, "10", sOrderBy.ToString());

        DataSet dsSDMTest = soilDataMart.RunQuery(sQString.ToString());

        if (dsSDMTest == null) throw new Exception("SDM Soils Query failed.");
        if (dsSDMTest.Tables[0].Rows.Count < 1) throw new Exception("SDM Soils Query returned nothing.");

        log.Debug("Rows: " + dsSDMTest.Tables[0].Rows.Count.ToString());

        List<SoilComponentsData> soilData = new List<SoilComponentsData>();

        String previousMuseq = "";
        String previousMusym = "";

        for (int i = 0; i < dsSDMTest.Tables[0].Rows.Count; i++)
        {
          if (!String.IsNullOrEmpty(dsSDMTest.Tables[0].Rows[i]["museq"].ToString()))
          {
            String mapUnitSeq = dsSDMTest.Tables[0].Rows[i]["museq"].ToString();
            String mapUnitSym = dsSDMTest.Tables[0].Rows[i]["musym"].ToString();
            if (mapUnitSeq != previousMuseq || mapUnitSym != previousMusym)
            {
              SoilComponentsData sSoil = new SoilComponentsData
              {
                scdSSA = dsSDMTest.Tables[0].Rows[i]["areasymbol"].ToString(),
                scdSymbol = mapUnitSym,
                scdName = dsSDMTest.Tables[0].Rows[i]["muname"].ToString(),
                scdAcres = "0",
                scdPercent = "0",
                scdSlope = "0",
                scdPH = "0",
                scdStatus = ""
              };
              soilData.Add(sSoil);
            }

            previousMuseq = mapUnitSeq;
            previousMusym = mapUnitSym;
          }
        }

        List<SoilDetailsData> soilDetails = new List<SoilDetailsData>();

        for (int i = 0; i < dsSDMTest.Tables[0].Rows.Count; i++)
        {
          //if (nFirst50 < 50)
          //{
          if (!String.IsNullOrEmpty(dsSDMTest.Tables[0].Rows[i]["museq"].ToString()))
          {
            try
            {
              SoilDetailsData sSoil = new SoilDetailsData
              {
                sddSaversion = dsSDMTest.Tables[0].Rows[i]["saversion"].ToString(),
                sddSaverest = dsSDMTest.Tables[0].Rows[i]["saverest"].ToString(),
                sddAreasymbol = dsSDMTest.Tables[0].Rows[i]["areasymbol"].ToString(),
                sddAreaname = dsSDMTest.Tables[0].Rows[i]["areaname"].ToString(),
                sddMusym = dsSDMTest.Tables[0].Rows[i]["musym"].ToString(),
                sddMuname = dsSDMTest.Tables[0].Rows[i]["muname"].ToString(),
                sddMuseq = dsSDMTest.Tables[0].Rows[i]["museq"].ToString(),
                sddMukey = dsSDMTest.Tables[0].Rows[i]["mukey"].ToString(),
                sddComppct_r = dsSDMTest.Tables[0].Rows[i]["comppct_r"].ToString(),
                sddCompname = dsSDMTest.Tables[0].Rows[i]["compname"].ToString(),
                sddSlope_r = dsSDMTest.Tables[0].Rows[i]["slope_r"].ToString(),
                sddCokey = dsSDMTest.Tables[0].Rows[i]["cokey"].ToString(),
                sddHydricrating = dsSDMTest.Tables[0].Rows[i]["hydricrating"].ToString(),
                sddHydgrp = dsSDMTest.Tables[0].Rows[i]["hydgrp"].ToString(),
                sddHzdept_r = dsSDMTest.Tables[0].Rows[i]["hzdept_r"].ToString(),
                sddHzdepb_r = dsSDMTest.Tables[0].Rows[i]["hzdepb_r"].ToString(),
                sddChkey = dsSDMTest.Tables[0].Rows[i]["chkey"].ToString(),
                sddSandtotal_r = dsSDMTest.Tables[0].Rows[i]["sandtotal_r"].ToString(),
                sddSilttotal_r = dsSDMTest.Tables[0].Rows[i]["silttotal_r"].ToString(),
                sddClaytotal_r = dsSDMTest.Tables[0].Rows[i]["claytotal_r"].ToString(),
                sddOm_r = dsSDMTest.Tables[0].Rows[i]["om_r"].ToString(),
                sddEcec_r = dsSDMTest.Tables[0].Rows[i]["ecec_r"].ToString(),
                sddAwc_r = dsSDMTest.Tables[0].Rows[i]["awc_r"].ToString(),
                sddKffact = dsSDMTest.Tables[0].Rows[i]["kffact"].ToString(),
                sddKwfact = dsSDMTest.Tables[0].Rows[i]["kwfact"].ToString(),
                sddTexdesc = dsSDMTest.Tables[0].Rows[i]["texdesc"].ToString(),
                sddTexture = dsSDMTest.Tables[0].Rows[i]["texture"].ToString(),
                sddStratextsflag = dsSDMTest.Tables[0].Rows[i]["stratextsflag"].ToString(),
                sddRvindicator = dsSDMTest.Tables[0].Rows[i]["rvindicator"].ToString(),
                sddTexcl = dsSDMTest.Tables[0].Rows[i]["texcl"].ToString()
              };
              soilDetails.Add(sSoil);
              //nFirst50 += 1;
            }
            catch
            { throw new Exception("SDM Soils parse details failed."); }
          }
          //}
        }

        SoilAllData sAllData = new SoilAllData();
        sAllData.saComponents = soilData;
        sAllData.saDetails = soilDetails;

        log.Debug("Components: " + soilData.Count.ToString());
        log.Debug("Details: " + soilDetails.Count.ToString());

        log.Info(sMeName + "<<Ending - " + sTrace.GetFrame(0).GetMethod().Name + ">>");

        return sAllData;
      }
      catch (Exception ex)
      {
          log.Fatal(ex);
        // create error info
        SoilAllData sAllData = new SoilAllData();
        List<SoilComponentsData> soilData = new List<SoilComponentsData>();

        SoilComponentsData scInfo = new SoilComponentsData();
        scInfo.scdSSA = "Error";
        scInfo.scdName = "Error: " + ex.Message.ToString();
        soilData.Add(scInfo);
        sAllData.saComponents = soilData;
        sAllData.saDetails = null;
        return sAllData;
      }
    }
    private string getMUKeys(string sBBCoordinates)
    {
      StackTrace sTrace = new StackTrace();
      string sReturn = "";
      string sMUKLStart = "<MapUnitKeyList>";
      string sMUKLEnd = "</MapUnitKeyList>";
      int nMUKLStartLocation = 0;
      int nMUKLEndLocation = 0;
      HttpWebRequest request = null;
      try
      {
        log.Info(sMeName + "<<Starting - " + sTrace.GetFrame(0).GetMethod().Name + ">>");

      //HttpWebRequest request = WebRequest.Create(sQuery) as HttpWebRequest;
      if (ProcessCommon.AppEndPointServicesSDM.EndsWith("SDM"))
      {
        string sQuery = sBBoxQuery + sBBCoordinates;
        request = WebRequest.Create(sQuery) as HttpWebRequest;
      }
      else
      {
        string sQuery = sBBoxFTCDevQuery + sBBCoordinates;
        request = WebRequest.Create(sQuery) as HttpWebRequest;
      }

      using (WebResponse response = request.GetResponse())
      {
        StreamReader stmReader = new StreamReader(response.GetResponseStream());
        string sTmp = stmReader.ReadToEnd();
        stmReader.Close();

        //extract values in MapUnitKeyList
        //<?xml version="1.0" encoding="ISO-8859-1" standalone="yes" ?> 
        //<MapUnitKeyList>'64070','64071','64174','64175','64081','64166','64079','64154'</MapUnitKeyList> 
        
        if (sTmp.Length == 0)
        {
          return sReturn;
        }

        nMUKLStartLocation = sTmp.IndexOf(sMUKLStart);
        nMUKLEndLocation = sTmp.IndexOf(sMUKLEnd);

        if (nMUKLStartLocation == 0 || nMUKLEndLocation == 0 || nMUKLEndLocation < nMUKLStartLocation)
        {
          return sReturn;
        }

        sReturn = sTmp.Substring(nMUKLStartLocation + sMUKLStart.Length, nMUKLEndLocation - (sMUKLStart.Length + nMUKLStartLocation));
        }
      }
      catch (Exception ex)
      {
        //StackTrace sTrace = new StackTrace();
        //WriteToErrorFile(sMeName, sPathName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", ex);
        //throw ex;
      }
        log.Info(sMeName + "<<Ending - " + sTrace.GetFrame(0).GetMethod().Name + ">>");
      return sReturn;
    }

    #endregion

    private void getAppSettings(string name)
    {
        try
        {
            log.Info(sMeName + "<<Starting - " + this.GetType().Name + name + ">>");
            ProcessCommon.GetAppSettings();
            log.Info(sMeName + "<<Ending - getAppSettings>>");
        }
        catch (Exception ex)
        {
            log.Fatal(ex);
        }
    }
  }
}

#region Not Used

#endregion
