//---------------------------------------------------
//Summary
//NTTManagementsService - Web service for APEX mapping.
//---------------------------------------------------
//Revision History
//Rev#  Date     Who   Change history
// 002  02/06/14 HAC   Add date and time to error message;
//                      use stringbuilder in debug message.
// 001  02/03/12 HAC   Get parameters from web.config.
//---------------------------------------------------

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;

using NTTManagementsService.ProcessComn;

namespace NTTManagementsService.LogHandlr
{
  public static class LogHandler
  {
    private static string sMeName = "LogHandler";

    public static void WriteToDebugFile(string sMessage, int nLevel = 1, int nCharIndent = 0)
    {
      //  Config file entries
      //  <!--   Writing to a debug log file  -->
      //  0 - no debug logging; 1 - navigation; 2 - more detail; 3 - verbose detail; 4 - everything
      //  <add key="AppDebug" value="0"/>
      //  N - nutrient; C - carbon; B - both
      //  <add key="AppDebugType" value="N"/>
      //  <add key="AppDebugFile" value="NTTDebugLog"/>
      //  <add key="AppDebugLocation" value="E:\NTTTestLocation\DebugLogs"/>

      string sDebugPath = "";
      string sDebugFile = "";
      string sTemp = "";
      StringBuilder sbtemp = new StringBuilder();
      DateTime dtNow = DateTime.Now;

      try
      {
        if (ProcessCommon.nAppDebug == 0) return;
        if (nLevel > ProcessCommon.nAppDebug) return;

        sDebugPath = ProcessCommon.sAppDebugLocation;
        if (!Directory.Exists(sDebugPath)) { Directory.CreateDirectory(sDebugPath); }

        sDebugFile = ProcessCommon.sAppDebugFile;
        if (!sDebugFile.EndsWith(".log")) { sDebugFile += ".log"; }
        sDebugFile = ProcessCommon.SafeBSlashPathEndString(sDebugPath) + String.Format("{0:yyMMdd}", dtNow) + sDebugFile.ToString();

        sTemp = new String('-', nCharIndent) + sMessage.ToString();
        sbtemp.Remove(0, sbtemp.Length);
        sbtemp.AppendFormat("{0} {1} {2}", dtNow.ToShortDateString(), dtNow.ToLongTimeString(), sTemp.ToString());

        //had to use this to create a new file otherwise
        //error file is being used by another process
        if (!File.Exists(sDebugFile))
        {
          sbtemp.Append(Environment.NewLine);
          File.WriteAllText(sDebugFile, sbtemp.ToString());
        }
        else
        {
          using (StreamWriter swLog = File.AppendText(sDebugFile))
          {
            swLog.WriteLine(sbtemp.ToString());
          }
        }
      }
      catch (Exception ex)
      {
        StackTrace sTrace = new StackTrace();
        LogHandler.WriteToErrorFile(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", ex);
      }
    }

    public static void WriteToErrorFile(string sModule, string sFunction, string sMessage, System.Exception exInner)
    {
      //  Config file entries
      //  <add key="AppLogErrors" value="Y"/>
      //  <add key="AppLogErrorFile" value="NTTErrorLog"/>
      //  <add key="AppLogErrorLocation" value="E:\NTTTestLocation\ErrorLogs"/>

      string sErrorPath = "";
      string sErrorFile = "";
      string sTemp = "";
      StringBuilder sbDetails = new StringBuilder();
      DateTime dtNow = DateTime.Now;

      try
      {
        if (ProcessCommon.sAppLogErrors.ToLower() != "y") return;

        sErrorPath = ProcessCommon.sAppLogErrorLocation;
        if (!Directory.Exists(sErrorPath)) { Directory.CreateDirectory(sErrorPath); }

        sErrorFile = ProcessCommon.sAppLogErrorFile;
        if (!sErrorFile.EndsWith(".log")) { sErrorFile += ".log"; }
        sErrorFile = ProcessCommon.SafeBSlashPathEndString(sErrorPath) + String.Format("{0:yyMMdd}", dtNow) + sErrorFile.ToString();

        sbDetails.Remove(0, sbDetails.Length);
        sbDetails.AppendFormat("{0} {1} {2} ", dtNow.ToShortDateString(), dtNow.ToLongTimeString(), sTemp.ToString());
        sbDetails.AppendFormat("**ERROR** Reported by: {0} + {1}{2}", sModule.ToString(), sFunction.ToString(), Environment.NewLine);
        sbDetails.AppendFormat("{0}{1}", sMessage.ToString(), Environment.NewLine);
        if (exInner != null)
        {
          sbDetails.AppendFormat(" Error Details:{0}", Environment.NewLine);
          sbDetails.AppendFormat("{0}{1}", exInner.Message, Environment.NewLine);

          if (exInner.InnerException != null)
          {
            sbDetails.AppendFormat(" InnerException Details:{0}", Environment.NewLine);
            sbDetails.AppendFormat("{0}{1}", exInner.InnerException.Message, Environment.NewLine);

            sbDetails.AppendFormat(" InnerException Source:{0}", Environment.NewLine);
            sbDetails.AppendFormat("{0}{1}", exInner.InnerException.Source, Environment.NewLine);
          }
          else
          {
            sbDetails.Append(">>> Error Detail not available <<<" + Environment.NewLine);
          }

        }
        sbDetails.Append(Environment.NewLine);

        //had to use this to create a new file otherwise
        //error file is being used by another process
        if (!File.Exists(sErrorFile))
        {
          sTemp += Environment.NewLine;
          File.WriteAllText(sErrorFile, sbDetails.ToString());
        }
        else
          using (StreamWriter swLog = File.AppendText(sErrorFile))
          {
            swLog.WriteLine(sbDetails.ToString());
          }
      }
      catch (Exception ex)
      {
      }
    }

    private static string getStack(Exception ex)
    {
      string sTemp = "";
      int nLineNbr = 0;
      int nLineNbrEnd = 0;
      int nFileName = 0;
      int nMethod = 0;
      int nMethodEnd = 0;
      StringBuilder sbStack = new StringBuilder();

      try
      {
        if (ex != null)
        {

        }
      }
      catch (Exception ex1)
      {
        StackTrace sTrace = new StackTrace();
        LogHandler.WriteToErrorFile(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", ex1);
      }
      return sTemp;
    }

  }
}

