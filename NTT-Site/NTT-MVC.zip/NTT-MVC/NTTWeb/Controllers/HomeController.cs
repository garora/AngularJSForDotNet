﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace NTT.Web.Controllers
{
    public class HomeController : Controller
    {
        private static log4net.ILog _log;
        public static log4net.ILog log
        {
            get
            {
                if (_log == null)
                {
                    _log = log4net.LogManager.GetLogger("Error");
                }

                return _log;
            }
        }

        // GET: Home
        public ActionResult Index()
        {
            return View();
        }

		/// <summary>
		/// Display the about page
		/// </summary>
		/// <returns></returns>
		public ActionResult About()
		{
			return View();
		}

		/// <summary>
		/// Display the help page
		/// </summary>
		/// <returns></returns>
		public ActionResult Help()
		{
			return View();
		}

		/// <summary>
		/// Display the contact us page
		/// </summary>
		/// <returns></returns>
		public ActionResult Contact()
		{
			return View();
		}
    }
}