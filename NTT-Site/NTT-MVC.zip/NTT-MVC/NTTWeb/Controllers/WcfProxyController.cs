﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace NTTWeb.Controllers
{
	public class WcfProxyController : Controller, IDisposable
	{
		~WcfProxyController()
		{
			this.Dispose();
		}

		public void Dispose()
		{
			if (webServiceTestingClient != null)
			{
				WebServiceTestingClient.Close();
				webServiceTestingClient = null;
			}
		}

		#region Service Properties
		private static WebServiceTesting.Service1Client webServiceTestingClient = null;
		internal static WebServiceTesting.Service1Client WebServiceTestingClient { get { if (webServiceTestingClient == null) { webServiceTestingClient = new WebServiceTesting.Service1Client(); } return webServiceTestingClient; } }
		#endregion

		[HttpPost]
		public JsonResult TestWcfProxy(string value)
		{
			var intValue = -1;
			int.TryParse(value, out intValue);

			return Json(WebServiceTestingClient.GetDataASDF_1234_TJ_Aaron(intValue), JsonRequestBehavior.AllowGet);
		}
	}
}