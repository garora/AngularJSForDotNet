﻿using NTT.Web.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace NTT.Web.Controllers
{
	public class WcfProxyController : Controller, IDisposable
	{
        private static log4net.ILog _log;
        public static log4net.ILog log
        {
            get
            {
                if (_log == null)
                {
                    _log = log4net.LogManager.GetLogger("Error");
                }

                return _log;
            }
        }

		~WcfProxyController()
		{
			this.Dispose();
		}

		public void Dispose()
		{
			if (webServiceTestingClient != null)
			{
				WebServiceTestingClient.Close();
				webServiceTestingClient = null;
			}
		}

		#region Service Properties
		private static WebServiceTesting.Service1Client webServiceTestingClient = null;
		internal static WebServiceTesting.Service1Client WebServiceTestingClient { get { if (webServiceTestingClient == null) { webServiceTestingClient = new WebServiceTesting.Service1Client(); } return webServiceTestingClient; } }
		#endregion

		[HttpPost]
		public JsonResult TestWcfProxy(string value)
		{
			var intValue = -1;
			int.TryParse(value, out intValue);

			return Json(WebServiceTestingClient.GetDataASDF_1234_TJ_Aaron(intValue), JsonRequestBehavior.AllowGet);
		}

		public JsonResult GetRandomNumber()
		{
			//TODO:LP:TSTUDE:Not the greatest, but just to get past the CSS loading
			RandomNumberGenerator random = new RandomNumberGenerator();
			return Json(random.GetNext(1, 999));
		}
	}
}