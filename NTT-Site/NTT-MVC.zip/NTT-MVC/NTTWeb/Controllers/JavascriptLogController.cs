﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace NTT.Web.Controllers
{
    public class JavascriptLogController : Controller
    {
		private static log4net.ILog _log;
		public static log4net.ILog Log
		{
			get
			{
				if (_log == null)
				{
					_log = log4net.LogManager.GetLogger("Error");
				}

				return _log;
			}
		}

        /// <summary>
        /// A passthrough to log messages from JavaScript
        /// </summary>
        /// <returns></returns>
		[HttpPost]
		public JsonResult LogJs(string message)
        {
			Log.Error(message);
			return Json("Success");
			//return Json("Called LogJs with the folling message " + message);
        }
    }
}