﻿var nttApp = angular.module('nttApp', [
  'ngRoute',
  'nttAppServices',
  'nttAppControllers'
  
]);

//TODO:MP:TSTUDE:research if this is even needed anymore, I may just leave it
//so I do not need to set it up again
nttApp.config(['$routeProvider',
  function ($routeProvider) {
  }]);

//TODO:MP:TSTUDE:move this to a directives directory or file
nttApp.directive('nttTabs', [function () {
	return {
		restrict: 'AE',
		scope: false,
		templateUrl: '/NTT.Web/Scripts/app/views/nttTabs.html',
		link: function (scope, element, attrs) {
			//scope.tabs = scope.$eval(attrs.tabs);

			scope.setActiveTab = function (title) {
				for (var i = 0; i < scope.tabs.length; i++) {
					scope.tabs[i].show = false; // hide all the other tabs 

					if (scope.tabs[i].title === title) {
						scope.tabs[i].show = true; // show the new tab 
					}
				}
			}
		}
	};
}])

var nttAppServices = angular.module('nttAppServices', []);

nttAppServices.controller('nttAppSvcs', ['$scope',
	function ($scope) {
		$scope.nttApp = {};
	}]);

//nttApp.factory('testWcfServiceCall', ['$scope', '$http', function (){//($scope, $http) {
//	return {

//		soapTest: function () {
//			return "Connection to factory service is successful";
//		}

//		////comment
//		//soapTest: function ($http) {
//		//	var soapTestReturnValue = undefined;

//		//	$http({
//		//		method: 'POST',
//		//		url: rootMvcPath + 'WcfProxy/TestWcfProxy',
//		//		data: { value: '999' }
//		//	}).success(function (data, status, headers, config) {
//		//		$scope.soapTestReturnValue = data;
//		//	}).error(function (data, status, headers, config) {
//		//		$scope.soapTestReturnValue = data;
//		//	});

//		//	return soapTestReturnValue;
//		//}
//	}
//}])



var nttAppControllers = angular.module('nttAppControllers', []);

nttAppControllers.controller('nttAppCtrl', ['$scope',
	function ($scope) {
		$scope.nttApp = {};
	}]);

