﻿var nttApp = angular.module('nttApp', [
  //'ngRoute',
  //'xeditable',
  //'ngMockE2E',
  'nttAppDirectives',
  'nttAppFactories',
  'nttAppControllers',
  'ui.bootstrap'
]);

//nttApp.run(function (editableOptions) {
//	editableOptions.theme = 'bs3';// bootstrap3 theme. Can be also 'bs2', 'default'
//});

//// --------------- mock $http requests ----------------------
//nttApp.run(function ($httpBackend) {
//	$httpBackend.whenGET('/groups').respond([
//	  { id: 1, text: 'user' },
//	  { id: 2, text: 'customer' },
//	  { id: 3, text: 'vip' },
//	  { id: 4, text: 'admin' }
//	]);

//	$httpBackend.whenPOST(/\/saveUser/).respond(function (method, url, data) {
//		data = angular.fromJson(data);
//		return [200, { status: 'ok' }];
//	});
//});

////TODO:LP:TSTUDE:This is left here for now because I commented out the route.js file, if needed later
////this can be added in
//nttApp.config(['$routeProvider',
//  function ($routeProvider) {
//  	$routeProvider
//		.when('/', {
//			templateUrl: '/NTT.Web/Scripts/app/Views/project.html',
//			controller: 'projectCtrl'
//		})
//		.when('/aoi', {
//			templateUrl: '/NTT.Web/Scripts/app/Views/aoi.html',
//			controller: 'aoiCtrl'
//		})
//		.when('/soilsLocation', {
//			templateUrl: '/NTT.Web/Scripts/app/Views/soilslocation.html',
//			controller: 'soilsLocationCtrl'
//		})
//		.otherwise({
//			redirectTo: '/'
//		});
//  }]);

var nttAppDirectives = angular.module('nttAppDirectives', []);

nttAppDirectives.controller('nttAppDirectivesController', ['$scope',
	function ($scope) {
		$scope.nttApp = {};
	}]);

var nttAppFactories = angular.module('nttAppFactories', []);

nttAppFactories.controller('nttAppSvcs', ['$scope',
	function ($scope) {
		$scope.nttApp = {};
	}]);

var nttAppControllers = angular.module('nttAppControllers', []);

nttAppControllers.controller('nttAppCtrl', ['$scope',
	function ($scope) {
		$scope.nttApp = {};
	}]);