﻿nttAppDirectives.directive('nttTabs', ['nttTabClick',
	function (nttTabClick) {


		return {
			restrict: 'AE',
			scope: false,
			templateUrl: rootMvcPath + 'Scripts/app/views/nttTabs.html?rn=' + Math.random(),
			link: function (scope, element, attrs) {
				scope.setActiveTab = function (title) {
					for (var i = 0; i < scope.tabs.length; i++) {
						scope.tabs[i].show = false; // hide all the other tabs 

						if (scope.tabs[i].title === title) {
							scope.tabs[i].show = true; // show the new tab 
						}
					}

					nttTabClick.fireTabClickEvent(title);
				}
			}
		};
	}])