﻿nttAppDirectives.directive('nttTabHeader', [
	function () {
		return {
			restrict: 'AE',
			scope: false,
			templateUrl: rootMvcPath + 'Scripts/app/views/nttTabHeader.html?rn=' + Math.random(),
			link: function (scope, element, attrs) {
				scope.tabTitle = attrs.tabtitle;

				scope.about = function () {
					window.open(rootMvcPath + 'Home/About', '_blank');
				};

				scope.help = function () {
					window.open(rootMvcPath + 'Home/Help', '_blank');
				};

				scope.contact = function () {
					window.open(rootMvcPath + 'Home/Contact', '_blank');
				};
			}
		};
	}])