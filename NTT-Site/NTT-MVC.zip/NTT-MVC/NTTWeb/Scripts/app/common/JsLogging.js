﻿//#region README
/*******************************************************************************
jsLogging - Created by Travis Stude

jsLogging is a addon that allows you to create logs from your javascript.  All 
you need to do is pass in a message. The date and time are added automatically.
With the ability to clear and minimize the log display.

DEPRECATED - Refactored to AMD - Please us this in an AMD setup so it works properly.
DEPRECATED - All non DB writing functionality has been removed for this build, logging is always on.

Refactored to Angular - Please use this in an Angular setup so it works properly.
 
**********************
*** IMPLEMENTATION ***
**********************

******************
*** JAVASCRIPT ***
******************

***
*** Add the following in your master page.  NOTE: in MVC this is in the _Layout.chstml
***
<script src="@Url.Content("~/Scripts/Logging/jsLogging.js")" 
    type="text/javascript"></script>
//Make sure the src points to the location of this file

*********************
*** FUNCTIONALITY ***
*********************

The only functionality that this provides is JS logging to DB. 

***********
*** USE ***
***********
To add a log message inject jsLogging to your controller or whatever you are
working with

nttAppControllers.controller('projectCtrl', ['$scope', 'jsLogging',
  function ($scope, jsLogging) {

Example
jsLogging.log("Hello Logging from projectCtrl");

This will automatically add the time of the log with your message at the end.


*******************************************************************************/
//#endregion

nttAppFactories.factory('jsLogging', ['nttCommon', 'ajaxFactory',
	function (nttCommon, ajaxFactory) {
		return {
			logLevel: undefined,
			displayOverride: undefined,

			//Call this and pass in the message you would like to log
			//message: the message you would like to log
			//allow you to printLines and create a log in one line
			//showTime: allows you to turn the time display off for the log
			log: function (message) {//, printLines, showTime) {
				'use strict';

				var now = new Date(),
					nowString = nttCommon.getDateTimeString(now);

				ajaxFactory.jsLog(nowString + " : " + message);
			},
		};
	}]);