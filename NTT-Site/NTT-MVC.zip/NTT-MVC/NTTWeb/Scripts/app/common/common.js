﻿nttAppControllers.factory('nttCommon', [
  function () {
  	return {
  		//Provide an array, the key to search in the array, the value to find
  		//in the array, returns a single object in the array
  		objectFindByKey: function (array, key, value) {
  			"use strict";
  			for (var i = 0; i < array.length; i++) {
  				if (array[i][key] === value) {
  					return array[i];
  				}
  			}
  			return null;
  		},

  		//Check to see if the given value has something set to it
  		hasValue: function (value) {
  			"use strict";
  			if (value != undefined && value != null && value != "") {
  				return true;
  			}
  			return false;
  		},

  		//Check to see if the given value has something set to it
  		hasNumValue: function (value) {
  			"use strict";
  			if (value != undefined && value != null) {
  				return true;
  			}
  			return false;
  		},

  		dateAddMonth: function (d, addMonths) {
  			'use strict';

  			var daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31],
				applyNegative = false;

  			if (addMonths < 0) {
  				applyNegative = true;
  				addMonths = addMonths * -1;
  			}

  			for (var i = addMonths; addMonths != 0; addMonths--) {
  				if (applyNegative) {
  					var dim = d.getMonth() - 1;
  					if (dim < 0) {
  						dim = 11;
  					}
  					d = new Date(d.setDate(d.getDate() - daysInMonth[dim]));
  				}
  				else {
  					var dim = d.getMonth();
  					d = new Date(d.setDate(d.getDate() + daysInMonth[dim]));
  				}
  			}

  			return d;
  		},

  		//convert date to MM/dd/YYYY
  		getDateTimeString: function (d) {
  			"use strict";
  			var month = d.getMonth() + 1,
					day = d.getDate(),
					year = d.getFullYear(),
					hours = d.getHours(),
					minutes = d.getMinutes(),
					seconds = d.getSeconds();

  			return month + "/" + day + "/" + year + " " + hours + ":" + minutes + ":" + seconds;
  		}
  	}
  }]);