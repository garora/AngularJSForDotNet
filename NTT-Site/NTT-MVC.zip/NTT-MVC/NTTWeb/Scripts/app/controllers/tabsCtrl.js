﻿nttAppControllers.controller('tabsCtrl', ['$scope',
  function ($scope) {
  	'use strict';

  	$scope.tabs = [
  	 {
  	 	title: "Project",
  	 	show: true, //show this tab shows by default
  	 	templateUrl: '/NTT.Web/Scripts/app/Views/project.html'
  	 },
  	 {
  	 	title: "Area of Interest",
  	 	show: false,
  	 	templateUrl: '/NTT.Web/Scripts/app/Views/aoi.html'
  	 },
  	 {
  	 	title: "Soils / Location",
  	 	show: false,
  	 	templateUrl: '/NTT.Web/Scripts/app/Views/soilslocation.html'
  	 },
  	 {
  	 	title: "Management",
  	 	show: false,
  	 	templateUrl: '/NTT.Web/Scripts/app/Views/management.html'
  	 },
  	 {
  	 	title: "Define Run",
  	 	show: false,
  	 	templateUrl: '/NTT.Web/Scripts/app/Views/definerun.html'
  	 },
  	 {
  	 	title: "Reports",
  	 	show: false,
  	 	templateUrl: '/NTT.Web/Scripts/app/Views/reports.html'
  	 }
  	];
  }]);