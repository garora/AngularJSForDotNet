﻿nttAppControllers.controller('tabsCtrl', ['$scope', 'nttCommon', 'nttTabClick',
function ($scope, nttCommon, nttTabClick) {
	'use strict';

	$scope.formData = {};
	//So that changes will show up without clearning history
	$scope.randomNumber = Math.random();

	//Main tab data
	$scope.tabs = [
  	 {
  	 	title: 'Project File',
  	 	show: true, //show this tab shows by default
  	 	templateUrl: '/NTT.Web/Scripts/app/Views/project.html?rn=' + $scope.randomNumber,
  	 	formComplete: false
  	 },
  	 {
  	 	title: 'Area of Interest',
  	 	show: false,
  	 	templateUrl: '/NTT.Web/Scripts/app/Views/aoi.html?rn=' + $scope.randomNumber,
  	 	formComplete: false
  	 },
  	 {
  	 	title: 'Soils / Location',
  	 	show: false,
  	 	templateUrl: '/NTT.Web/Scripts/app/Views/soilslocation.html?rn=' + $scope.randomNumber,
  	 	formComplete: false
  	 },
  	 {
  	 	title: 'Management',
  	 	show: false,
  	 	templateUrl: '/NTT.Web/Scripts/app/Views/management.html?rn=' + $scope.randomNumber,
  	 	formComplete: false
  	 },
  	 {
  	 	title: 'Define Run',
  	 	show: false,
  	 	templateUrl: '/NTT.Web/Scripts/app/Views/definerun.html?rn=' + $scope.randomNumber,
  	 	formComplete: false
  	 },
  	 {
  	 	title: 'Reports',
  	 	show: false,
  	 	templateUrl: '/NTT.Web/Scripts/app/Views/reports.html?rn=' + $scope.randomNumber,
  	 	formComplete: false
  	 }
	];

	//Update tab display with the form complete status
	$scope.setFormCompleteStatus = function (formTitle, formStatus) {
		var tabToUpdate = nttCommon.objectFindByKey($scope.tabs, 'title', formTitle);
		tabToUpdate.formComplete = formStatus;
	}
}]);