﻿nttAppControllers.controller('soilsLocationCtrl', ['$scope', 'nttCommon', 'nttTabClick',
  function ($scope, nttCommon, nttTabClick) {
  	$scope.checkFormComplete = function () {
  		if (nttCommon.hasValue($scope.formData.soilsLocation)) {
  			if (nttCommon.hasValue($scope.formData.soilsLocation.mapUnitSymbol) &&
  				nttCommon.hasValue($scope.formData.soilsLocation.acres) &&
  				nttCommon.hasValue($scope.formData.soilsLocation.percent) &&
  				nttCommon.hasValue($scope.formData.soilsLocation.mapUnitName) &&
  				nttCommon.hasValue($scope.formData.soilsLocation.slope) &&
  				nttCommon.hasValue($scope.formData.soilsLocation.ph)) {
  				$scope.setFormCompleteStatus('Soils / Location', true);
  			} else {
  				$scope.setFormCompleteStatus('Soils / Location', false);
  			}
  		}
  		else {
  			$scope.setFormCompleteStatus('Soils / Location', false);
  		}
  	}

  	/*This must be before the addEventHandler*/
  	//Event handler for AOI Tab click
  	$scope.aoiTabClick = function () {
  		//alert("Soils/Location Tab click in soilsLocationCtrl");
  	}

  	/*Recommended, place this at the end of the file*/
  	//Add event handerl to the tab click factory
  	nttTabClick.addEventHandler('Soils / Location', $scope.aoiTabClick);
  }]);