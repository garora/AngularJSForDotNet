﻿nttAppControllers.controller('soilsLocationCtrl', ['$scope',
  function ($scope) {
  	$scope.soilsLocation = "The location of soil is under your feet.";
  }]);