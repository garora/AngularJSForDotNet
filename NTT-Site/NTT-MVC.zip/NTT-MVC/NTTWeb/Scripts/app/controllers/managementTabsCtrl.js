﻿nttAppControllers.controller('managementTabsCtrl', ['$scope', 'nttCommon',
  function ($scope, nttCommon) {
  	'use strict';

  	//$scope.formData = {};
  	//So that changes will show up without clearning history
  	$scope.randomNumber = Math.random();

  	$scope.tabs = [
  	 {
  	 	title: "Baseline",
  	 	show: false, //show this tab shows by default
  	 	templateUrl: '/NTT.Web/Scripts/app/Views/managementBaselineTab.html?rn=' + $scope.randomNumber
  	 },
  	 {
  	 	title: "Alternative",
  	 	show: true,
  	 	templateUrl: '/NTT.Web/Scripts/app/Views/managementAlternativeTab.html?rn=' + $scope.randomNumber
  	 }
  	];
  }]);