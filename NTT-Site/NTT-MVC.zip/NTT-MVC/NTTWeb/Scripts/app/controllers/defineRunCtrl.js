﻿nttAppControllers.controller('defineRunCtrl', ['$scope', 'nttCommon', 'nttTabClick',
  function ($scope, nttCommon, nttTabClick) {
  	$scope.defineRun = "Run for 1 hour";

  	$scope.checkFormComplete = function () {
  		if (nttCommon.hasValue($scope.formData.defineRun)) {
  			if (nttCommon.hasValue($scope.formData.defineRun.checked)) {
  				$scope.setFormCompleteStatus('Define Run', true);
  			} else {
  				$scope.setFormCompleteStatus('Define Run', false);
  			}
  		}
  		else {
  			$scope.setFormCompleteStatus('Define Run', false);
  		}
  	}

  	/*This must be before the addEventHandler*/
  	//Event handler for AOI Tab click
  	$scope.aoiTabClick = function () {
  		//alert("Define Run Tab click in defineRunCtrl");
  	}

  	/*Recommended, place this at the end of the file*/
  	//Add event handerl to the tab click factory
  	nttTabClick.addEventHandler('Define Run', $scope.aoiTabClick);
  }]);