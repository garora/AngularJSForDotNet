﻿nttAppControllers.controller('defineRunCtrl', ['$scope',
  function ($scope) {
  	$scope.defineRun = "Run for 1 hour";
  }]);