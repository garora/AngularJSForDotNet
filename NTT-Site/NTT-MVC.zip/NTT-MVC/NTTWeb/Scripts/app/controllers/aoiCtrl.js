﻿nttAppControllers.controller('aoiCtrl', ['$scope',
  function ($scope) {
  	$scope.aoi = "My interests include AngularJS coding.";
  }]);