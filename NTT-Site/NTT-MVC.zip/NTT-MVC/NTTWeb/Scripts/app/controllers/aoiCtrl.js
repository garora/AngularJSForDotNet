﻿nttAppControllers.controller('aoiCtrl', ['$scope', 'nttCommon', 'nttTabClick',
  function ($scope, nttCommon, nttTabClick) {
  	$scope.aoi = 'This tab will contain a map selection control given to us by '
		+ 'COMET-Farm.  The details will be (...coming soon...).';


  	$scope.checkFormComplete = function () {
  		if (nttCommon.hasValue($scope.formData.aoi)) {
  			if (nttCommon.hasValue($scope.formData.aoi.checked)) {
  				$scope.setFormCompleteStatus('Area of Interest', true);
  			} else {
  				$scope.setFormCompleteStatus('Area of Interest', false);
  			}
  		}
  		else {
  			$scope.setFormCompleteStatus('Area of Interest', false);
  		}
  	}

  	/*This must be before the addEventHandler*/
	//Event handler for AOI Tab click
  	$scope.aoiTabClick = function () {
  		//alert("AOI Tab click in aoiCtrl");
  	}

  	/*Recommended, place this at the end of the file*/
	//Add event handerl to the tab click factory
  	nttTabClick.addEventHandler('Area of Interest', $scope.aoiTabClick);
  }]);