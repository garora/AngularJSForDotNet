﻿nttAppControllers.controller('projectCtrl', ['$scope', '$q', '$http', 'testWcfServiceCall',
  function ($scope, $q, $http, testWcfServiceCall) {
  	'use strict';

  	$scope.projectName = "Automatically created project (this will be a button press later).";

  	var wcfPromise = testWcfServiceCall.soapTest();
  	wcfPromise.then(function (data) {
  		$scope.soapTestReturnValue = data;
  	}, function (data) {
  		$scope.soapTestReturnValue = data;
  	}, function (update) {
  		//TODO:LP:TSTUDE:Create a status factory and push this result to it
  		//alert('Got notification: ' + update);
  	});

  }]);