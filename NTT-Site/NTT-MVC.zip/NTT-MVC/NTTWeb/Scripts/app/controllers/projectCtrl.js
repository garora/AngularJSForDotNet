﻿nttAppControllers.controller('projectCtrl', ['$scope', '$q', '$http', 'testWcfServiceCall', 'nttCommon', 'jsLogging', 'nttTabClick',
  function ($scope, $q, $http, testWcfServiceCall, nttCommon, jsLogging, nttTabClick) {
  	'use strict';

  	

  	$scope.projectName = "Automatically created project (this will be a button press later).";

  	/*var wcfPromise = testWcfServiceCall.soapTest();
  	wcfPromise.then(function (data) {
  		$scope.soapTestReturnValue = data;
  	}, function (data) {
  		$scope.soapTestReturnValue = data;
  	}, function (update) {
  		//TODO:LP:TSTUDE:Create a status factory and push this result to it
  		//alert('Got notification: ' + update);
  	});*/

  	$scope.writeLog = function () {
  		jsLogging.log("Hello Logging from projectCtrl");
  	}

  	$scope.checkFormComplete = function () {
  		if (nttCommon.hasValue($scope.formData.project)) {
  			if (nttCommon.hasValue($scope.formData.project.projectFile) &&
  				nttCommon.hasValue($scope.formData.project.description) &&
  				nttCommon.hasValue($scope.formData.project.updated) &&
  				nttCommon.hasValue($scope.formData.project.created)) {
  				$scope.setFormCompleteStatus('Project File', true);
  			} else {
  				$scope.setFormCompleteStatus('Project File', false);
  			}
  		}
  		else {
  			$scope.setFormCompleteStatus('Project File', false);
  		}
  	}

  	/*This must be before the addEventHandler*/
  	//Event handler for AOI Tab click
  	$scope.aoiTabClick = function () {
  		//alert("project Tab click in projectCtrl");
  	}

  	/*Recommended, place this at the end of the file*/
  	//Add event handerl to the tab click factory
  	nttTabClick.addEventHandler('Project File', $scope.aoiTabClick);
  }]);