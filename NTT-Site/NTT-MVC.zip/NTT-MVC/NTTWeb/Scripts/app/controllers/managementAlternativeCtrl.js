﻿nttAppControllers.controller('managementAlternativeCtrl', ['$scope', 'nttCommon',
	function ($scope, nttCommon) {
		$scope.managementAlternativeEdit = {};
		$scope.currentEditId = undefined;

		//Populate the selected data from the table into the form below the table
		$scope.editData = function (rowId) {
			'use strict';

			$scope.currentEditId = rowId;
			$scope.managementAlternativeEdit = angular.copy($scope.formData.managementAlternative.operations[rowId]);
		}

		//Add a new operation to the table and set it to the current edit
		$scope.addOperation = function () {
			'use strict';

			var now = new Date(),
				newId = getHighestOperationId() + 1;
			$scope.newOperation = {
				id: newId,
				event: '',
				date: now,
				operation: 'New Operation: ' + nttCommon.getDateTimeString(now),
				type: '',
				amount: '',
				depth: ''
			};
			$scope.formData.managementAlternative.operations.push($scope.newOperation);

			$scope.editData(newId);
		};

		//Delete the current selected item in the table, also populated in the form
		$scope.deleteOperation = function () {
			'use strict';
			if (nttCommon.hasNumValue($scope.currentEditId)) {
				$scope.formData.managementAlternative.operations.splice($scope.currentEditId, 1);
				endEdit();
			}
		}

		//Save form to current selected item in the table
		$scope.saveEditOperation = function () {
			'use strict';
			$scope.formData.managementAlternative.operations[$scope.currentEditId] = $scope.managementAlternativeEdit;
			endEdit();
		}

		//Cancel edit on form and leave the state of the table unchanged
		$scope.cancelEditOperation = function () {
			'use strict';
			endEdit();
		}

		//Cancel edit on form and leave the state of the table unchanged
		function endEdit() {
			$scope.managementAlternativeEdit = {};
			$scope.currentEditId = undefined;
		}

		//Find the highest id in the operation list
		function getHighestOperationId() {
			'use strict';
			var idCollection = [];

			for (var i = 0; i < $scope.formData.managementAlternative.operations.length; i++) {
				idCollection.push($scope.formData.managementAlternative.operations[i].id);
			}

			return Math.max.apply(null, idCollection);
		}

		/**************************
		 * Date Picker Methods
		 **************************/
		$scope.today = function () {
			'use strict';
			$scope.managementAlternativeEdit.date = new Date();
		};
		$scope.today();

		$scope.clear = function () {
			'use strict';
			$scope.managementAlternativeEdit.date = null;
		};

		$scope.toggleMin = function () {
			'use strict';
			$scope.minDate = $scope.minDate ? null : nttCommon.dateAddMonth(new Date(), -3);
		};
		$scope.toggleMin();

		$scope.open = function ($event) {
			'use strict';
			$event.preventDefault();
			$event.stopPropagation();

			$scope.opened = true;
		};

		$scope.dateOptions = {
			formatYear: 'yyyy',
			startingDay: 0
		};

		//TODO:MP:TSTUDE:Find out what format they want and hard code
		$scope.formats = ['dd-MMMM-yyyy', 'yyyy/MM/dd', 'dd.MM.yyyy', 'shortDate'];
		$scope.format = $scope.formats[0];

		/**************************
		 * END Date Picker Methods
		 **************************/

		function initializeFormData() {
			if (!nttCommon.hasValue($scope.formData.managementAlternative.operations)) {
				$scope.formData.managementAlternative.operations = [
					{ id: 0, event: '', date: new Date(2015, 0, 30), operation: 'Plow, moldboard', type: '', amount: '', depth: '' },
					{ id: 1, event: 'Till', date: new Date(2015, 1, 15), operation: 'Disk, tandem secondary op.', type: '', amount: '', depth: '' },
					{ id: 2, event: 'Till', date: new Date(2015, 2, 20), operation: 'Disk, tandem tertiary op.', type: '', amount: '', depth: '' }
				];
			}
		}

		$scope.init = function () {
			initializeFormData();
		}
	}]);