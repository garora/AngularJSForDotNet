﻿nttAppControllers.controller('managementCtrl', ['$scope', 'nttCommon', 'nttTabClick',
  function ($scope, nttCommon, nttTabClick) {
  	$scope.formData.managementBaseline = {};
  	$scope.formData.managementAlternative = {};

  	$scope.randomNumber = Math.random();
  	$scope.managementTemplate = '/NTT.Web/Scripts/app/Views/managementBaseline.html?rn=' + $scope.randomNumber;
  	$scope.currentTemplate = 'Baseline';

  	$scope.switchManagementTemplate = function (template) {
  		$scope.currentTemplate = template;
  		if(template == 'Baseline')
  		{
  			$scope.managementTemplate = '/NTT.Web/Scripts/app/Views/managementBaseline.html?rn=' + $scope.randomNumber;
  		}
  		else
  		{
  			$scope.managementTemplate = '/NTT.Web/Scripts/app/Views/managementAlternative.html?rn=' + $scope.randomNumber;
  		}
  	}

  	$scope.checkFormComplete = function () {
  		if (nttCommon.hasValue($scope.formData.management)) {
  			if (nttCommon.hasValue($scope.formData.management.checked)) {
  				$scope.setFormCompleteStatus('Management', true);
  			} else {
  				$scope.setFormCompleteStatus('Management', false);
  			}
  		}
  		else {
  			$scope.setFormCompleteStatus('Management', false);
  		}
  	}

  	/*This must be before the addEventHandler*/
  	//Event handler for AOI Tab click
  	$scope.aoiTabClick = function () {
  		//alert("Management Tab click in managementCtrl");
  	}

  	/*Recommended, place this at the end of the file*/
  	//Add event handerl to the tab click factory
  	nttTabClick.addEventHandler('Management', $scope.aoiTabClick);
}]);