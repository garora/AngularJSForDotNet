﻿nttAppControllers.controller('managementCtrl', ['$scope',
  function ($scope) {
  	$scope.management = "How much management do you want?";
  }]);