﻿nttAppControllers.controller('reportsCtrl', ['$scope',
  function ($scope) {
  	$scope.reports = "beep beep beep";
  }]);