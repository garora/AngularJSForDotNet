﻿nttAppControllers.controller('reportsCtrl', ['$scope', 'nttCommon', 'nttTabClick',
  function ($scope, nttCommon, nttTabClick) {
  	$scope.reports = "beep beep beep";

  	$scope.checkFormComplete = function () {
  		if (nttCommon.hasValue($scope.formData.reports)) {
  			if (nttCommon.hasValue($scope.formData.reports.checked)) {
  				$scope.setFormCompleteStatus('Reports', true);
  			} else {
  				$scope.setFormCompleteStatus('Reports', false);
  			}
  		}
  		else {
  			$scope.setFormCompleteStatus('Reports', false);
  		}
  	}

  	/*This must be before the addEventHandler*/
  	//Event handler for AOI Tab click
  	$scope.aoiTabClick = function () {
  		//alert("reports Tab click in reportsCtrl");
  	}

  	/*Recommended, place this at the end of the file*/
  	//Add event handerl to the tab click factory
  	nttTabClick.addEventHandler('Reports', $scope.aoiTabClick);
  }]);