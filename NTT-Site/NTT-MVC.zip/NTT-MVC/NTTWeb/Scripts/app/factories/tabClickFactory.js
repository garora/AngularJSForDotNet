﻿nttAppControllers.factory('nttTabClick', ['nttCommon',
  function (nttCommon) {
  	return {
		//Add event handler for ntt tab click
		addEventHandler: function (eventName, eventHandler) {
  			if (!nttCommon.hasValue(this.tabClickEventHandlers))
  			{
  				this.tabClickEventHandlers = [];
  			}

  			this.tabEvent = {
  				name: eventName,
				handler: eventHandler
  			}

  			this.tabClickEventHandlers.push(this.tabEvent);
  		},

  		//Fire event for ntt tab click
  		fireTabClickEvent: function (event) {
  			for (var i = 0; i < this.tabClickEventHandlers.length; i++) {
  				if (this.tabClickEventHandlers[i].name === event)
  				{
  					this.tabClickEventHandlers[i].handler();
  				}
  			}
  		}
  	}
  }]);