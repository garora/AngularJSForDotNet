﻿nttAppFactories.factory('testWcfServiceCall', ['$http', '$q',
	function ($http, $q) {
		return {

			//soapTest: function () {
			//	return "Connection to factory service is successful";
			//}

			//comment
			//soapTest: function () {
			//	var deferred = $q.defer();

			//	deferred.notify('Sending post request');

			//	$http({
			//		method: 'POST',
			//		url: rootMvcPath + 'WcfProxy/TestWcfProxy',
			//		data: { value: '999' }
			//	}).success(function (data, status, headers, config) {
			//		deferred.resolve(data);
			//	}).error(function (data, status, headers, config) {
			//		deferred.reject(data);
			//	});

			//	return deferred.promise;
			//}


			soapTest: function () {
				var deferred = $q.defer();

				deferred.notify('Sending post request');

				$http({
					method: 'POST',
					url: rootMvcPath + 'WcfProxy/TestWcfProxy',
					data: { value: '999' }
				}).success(function (data, status, headers, config) {
					deferred.resolve(data);
				}).error(function (data, status, headers, config) {
					deferred.reject(data);
				});

				return deferred.promise;
			}
		};
	}])