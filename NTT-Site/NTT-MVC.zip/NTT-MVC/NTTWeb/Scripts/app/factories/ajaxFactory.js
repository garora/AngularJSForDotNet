﻿nttAppFactories.factory('ajaxFactory', ['$http', '$q',
	function ($http, $q) {
		return {
			//Pass a message from a javascript log that will be written to a database
			jsLog: function (message) {
				var deferred = $q.defer();

				deferred.notify('Sending post request');

				$http({
					method: 'POST',
					url: rootMvcPath + 'JavascriptLog/LogJs',
					data: { message: message }
				}).success(function (data, status, headers, config) {
					deferred.resolve(data);
				}).error(function (data, status, headers, config) {
					deferred.reject(data);
				});

				return deferred.promise;
			}
		};
	}])