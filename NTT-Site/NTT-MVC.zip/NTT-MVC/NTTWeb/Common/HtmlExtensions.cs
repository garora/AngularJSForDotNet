﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace NTT.Web.Common
{
	public static class HtmlExtensions
	{
		static RandomNumberGenerator _rand = new RandomNumberGenerator();

		//TODO:LP:TSTUDE:Add ability to pass a bool allowing for deploy to not add a random number to the path
		/// <summary>
		/// Add the ability to dynamically create the css include
		/// </summary>
		/// <param name="helper"></param>
		/// <param name="path"></param>
		/// <returns></returns>
		public static MvcHtmlString CssInclude(this HtmlHelper helper, string path)
		{
			return MvcHtmlString.Create("<link rel=\"stylesheet\" type=\"text/css\" href=\"" + GetAbsolutePath(AddRandomNumToPath(path)) + "\" /> <!-- Built in C# -->");
		}

		/// <summary>
		/// Add a random number to the path to trick the page into thinking it needs to refresh the 
		/// css. This is helpful for debugging, but should be turned off for release.
		/// </summary>
		/// <param name="path"></param>
		/// <returns></returns>
		private static string AddRandomNumToPath(string path)
		{
			return string.Format("{0}?rn={1}", path, _rand.GetNext(1, 999));
		}

		/// <summary>
		/// Convert the path to work in IIS for MVC
		/// </summary>
		/// <param name="path"></param>
		/// <returns></returns>
		private static string GetAbsolutePath(string path)
		{
			return VirtualPathUtility.ToAbsolute("~/" + path);
		}
	}
}