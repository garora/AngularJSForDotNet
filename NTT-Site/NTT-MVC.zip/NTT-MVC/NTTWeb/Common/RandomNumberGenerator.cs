﻿using System;

namespace NTT.Web.Common
{
    /// <summary>
    /// Provide a common location to create a random number
    /// </summary>
    public class RandomNumberGenerator
    {
        public RandomNumberGenerator()
        {
            Rand = new Random();
        }

        /// <summary>
        /// Use this property so that Random generation does not produce the same number every time
        /// it is called (i.e. initialize only once)
        /// </summary>
        public Random Rand { get; set; }

        /// <summary>
        /// Call this method to return a random number in the min/max range of the parameters
        /// </summary>
        /// <param name="min"></param>
        /// <param name="max"></param>
        /// <returns></returns>
        public int GetNext(int min, int max)
        {
            return Rand.Next(min, max);
        }
    }
}
