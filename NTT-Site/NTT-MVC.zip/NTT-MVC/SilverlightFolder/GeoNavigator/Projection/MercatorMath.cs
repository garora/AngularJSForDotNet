﻿using System;
using System.Windows;

namespace GeoNavigator.Projection
{
    public static class MercatorMath
    {
        #region Static

        public const double kEarthRadius = 6378137;

        // mppEpsilon is the smallest meters-per-pixel to be considered
        // in this case, 1 micron or 1/1,000,000 of a meter
        const double mppEpsilon = 1E-06;

        readonly static double ln2 = Math.Log(2);

        static double earthRadius;
        static double earthCircum;
        static double earthHalfCirc;

        static MercatorMath()
        {
            EarthRadius = kEarthRadius;
        }

        public static double EarthRadius
        {
            get { return earthRadius; }
            set
            {
                earthRadius = value;
                earthCircum = earthRadius * 2.0 * Math.PI;
                earthHalfCirc = earthCircum / 2;
            }
        }

        public static double EarthCircum
        {
            get { return earthCircum; }
        }

        public static double EarthHalfCirc
        {
            get { return earthHalfCirc; }
        }

        public static double DegToRad(double d)
        {
            return d * Math.PI / 180.0;
        }

        public static double RadToDeg(double r)
        {
            return r / Math.PI * 180.0;
        }

        public static double ZoomToArc(int zoom, double size)
        {
            return earthCircum / ((1 << zoom) * size);
        }

        public static double ArcToZoom(double arc, double size)
        {
            return Math.Log(earthCircum / (size * arc)) / ln2;
        }

        public static double LatitudeToMeters(double lat)
        {
			double r = DegToRad(lat);
            double a = Math.Sin(r);
            return earthRadius / 2 * Math.Log((1 + a) / (1 - a));
        }

		public static double MetersToLatitude(double y)
		{
			double a = Math.Exp(y * 2 / earthRadius);
			double r = Math.Asin((a - 1) / (a + 1));
			return RadToDeg(r);
		}

        public static double LatitudeRangeToMeterHeight(double minLat, double maxLat)
        {
            double minSinLat = Math.Sin(DegToRad(minLat));
            double maxSinLat = Math.Sin(DegToRad(maxLat));
            double minY = earthRadius / 2 * Math.Log((1 + minSinLat) / (1 - minSinLat));
            double maxY = earthRadius / 2 * Math.Log((1 + maxSinLat) / (1 - maxSinLat));
            return Math.Abs(maxY - minY);
        }

        public static double LatitudeRangeToArc(double minLat, double maxLat, double scrHeight)
        {
            double minSinLat = Math.Sin(DegToRad(minLat));
            double maxSinLat = Math.Sin(DegToRad(maxLat));
            double minY = earthRadius / 2 * Math.Log((1 + minSinLat) / (1 - minSinLat));
            double maxY = earthRadius / 2 * Math.Log((1 + maxSinLat) / (1 - maxSinLat));
            double height = Math.Abs(maxY - minY);
            return height / scrHeight;
        }

        public static double LatitudeToYAtArc(double lat, double arc)
        {
            return (earthHalfCirc - LatitudeToMeters(lat)) / arc;
        }

        public static double YToLatitudeAtArc(double y, double arc, bool inDegrees)
        {
            double metersY = earthHalfCirc - y * arc;
            double a = Math.Exp(metersY * 2 / earthRadius);
            double lat = Math.Asin((a - 1) / (a + 1));

            if (inDegrees)
                lat = RadToDeg(lat);

            return lat;
        }

        public static double YToLatitudeAtArc(double y, double arc)
        {
            return YToLatitudeAtArc(y, arc, true);
        }

        public static double LongitudeToMeters(double lon)
        {
            return earthRadius * DegToRad(lon);
        }

		public static double MetersToLongitude(double x)
		{
			return RadToDeg(x) / earthRadius;
		}

        public static double LongitudeRangeToMetersWidth(double minLon, double maxLon)
        {
            double minX = earthRadius * DegToRad(minLon);
            double maxX = earthRadius * DegToRad(maxLon);
            return Math.Abs(maxX - minX);
        }

        public static double LongitudeRangeToArc(double minLon, double maxLon, double scrWidth)
        {
            double minX = earthHalfCirc + earthRadius * DegToRad(minLon);
            double maxX = earthHalfCirc + earthRadius * DegToRad(maxLon);
            double width = Math.Abs(maxX - minX);

            return width / scrWidth;
        }

        public static double LongitudeToXAtArc(double lon, double arc)
        {
            return (earthHalfCirc + LongitudeToMeters(lon)) / arc;
        }

        public static double XToLongitudeAtArc(double x, double arc, bool inDegrees)
        {
            double metersX = x * arc - earthHalfCirc;
            double lon = metersX / earthRadius;

            if (inDegrees)
                lon = RadToDeg(lon);

            return lon;
        }

        public static double XToLongitudeAtArc(double x, double arc)
        {
            return XToLongitudeAtArc(x, arc, true);
        }

        public static Point GeographicToProjected(double lon, double lat, double metersPerPixel)
        {
            return new Point(
                LongitudeToXAtArc(lon, metersPerPixel),
                LatitudeToYAtArc(lat, metersPerPixel)
                );
        }

        public static Point ProjectedToGeographic(double x, double y, double metersPerPixel)
        {
            return new Point(
                XToLongitudeAtArc(x, metersPerPixel),
                YToLatitudeAtArc(y, metersPerPixel)
                );
        }

        #endregion
    }
}
