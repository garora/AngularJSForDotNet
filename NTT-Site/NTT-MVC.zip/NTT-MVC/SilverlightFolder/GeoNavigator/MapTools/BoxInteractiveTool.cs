﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

using ESRI.ArcGIS.Client;
using ESRI.ArcGIS.Client.Geometry;
using ESRI.ArcGIS.Client.Symbols;

using Color = System.Windows.Media.Color;
using SolidColorBrush = System.Windows.Media.SolidColorBrush;

using GeoNavigator.StateManagement.EventExtensions;
using GeoNavigator.Symbols;

namespace GeoNavigator.MapTools
{
	public class BoxInteractiveTool : BoxTool
	{
		protected static ControlMarkerSymbol controlDrawSymbol = new ControlMarkerSymbol()
		{
			Stroke = new SolidColorBrush() { Color = Color.FromArgb(255, 255, 255, 0) },
			StrokeThickness = 1d,
			Fill = new SolidColorBrush() { Color = Color.FromArgb(64, 255, 255, 0) },
			Size = 8d
		};

		const double sqrSelectDist = 16d;

		MapPoint moveAnchor;
		Envelope moveExtent;

		Graphic controlMarker;
		bool editable;

		protected virtual void OnMouseMoveNoDrag(object sender, MouseEventArgs e)
		{
			if (!IsEnabled || !editable)
				return;

			Map map = Map;
			if (map == null || extent == null)
				return;

			MapPoint pos = map.ScreenToMap(e.GetPosition(map));

			MapPoint closestCorner = extent.ClosestCorner(map, pos, sqrSelectDist);

			if (closestCorner != null)
				CreateControlPoint(closestCorner);
			else
				ClearControlPoint();
		}

		protected override void OnBeginDrag(object sender, MouseButtonEventArgs e)
		{
			if (!IsEnabled)
				return;

			if (!editable)
			{
				base.OnBeginDrag(sender, e);
				return;
			}

			Map map = Map;
			if (map == null || extent == null)
				return;

			MapPoint mousedownPos = map.ScreenToMap(e.GetPosition(map));
			MapPoint oppcorner = extent.ClosestCorner(map, mousedownPos, sqrSelectDist, true);

			if (oppcorner != null)
			{
				// dragging a corner
				anchor = oppcorner;
				e.Handled = true;
			}
			else
			{
				// remove the controlMarker if it's there
				ClearControlPoint();

				if (extent.Contains(mousedownPos))
				{
					// dragging the entire  box
					moveAnchor = mousedownPos;
					moveExtent = extent.Clone();
					e.Handled = true;
				}
			}
		}

		protected override void OnDrag(object sender, MouseDragEventArgs e)
		{
			Map map = Map;

			MapPoint pos = map.ScreenToMap(e.MoveTo.GetPosition(map));

			if (moveAnchor != null)
			{
				double dx = moveAnchor.X - pos.X;
				double dy = moveAnchor.Y - pos.Y;

				extent.XMin = moveExtent.XMin - dx;
				extent.YMin = moveExtent.YMin - dy;
				extent.XMax = moveExtent.XMax - dx;
				extent.YMax = moveExtent.YMax - dy;
			}
			else
			{
				if (controlMarker != null)
					controlMarker.Geometry = pos;

				base.OnDrag(sender, e);
			}
		}

		protected override void OnEndDrag(object sender, MouseEndDragEventArgs e)
		{
			Map map = Map;

			if (moveAnchor != null)
				moveAnchor = null;
			else
			{
				if (controlMarker != null)
					controlMarker.Geometry = map.ScreenToMap(e.MouseUp.GetPosition(map));

				editable = true;
				base.OnEndDrag(sender, e);
			}
		}

		public virtual void SetExtent(Envelope env, bool editable)
		{
			SetExtent(env);
			this.editable = editable;
		}

		public virtual void SetExtent(Envelope env, Symbol symbol, bool editable)
		{
			SetExtent(env, symbol);
			this.editable = editable;
		}

		void CreateControlPoint(MapPoint pos)
		{
			if (controlMarker != null)
				return;

			controlMarker = new Graphic()
			{
				Geometry = pos,
				Symbol = controlDrawSymbol
			};

			graphicsLayer.Graphics.Add(controlMarker);
		}

		void ClearControlPoint()
		{
			if (controlMarker != null)
			{
				graphicsLayer.Graphics.Remove(controlMarker);
				controlMarker = null;
			}
		}

		public override void Clear()
		{
			ClearControlPoint();
			base.Clear();
		}

		protected override void OnCancelled()
		{
			if (!editable)
				return;

			editable = false;
			base.OnCancelled();
		}

		protected override void OnCompleted()
		{
			if (!editable)
				return;

			editable = false;
			ClearControlPoint();
			base.OnCompleted();
		}

        protected override void AttachToExtender(MapExtender extender)
        {
            extender.MouseMoveNoDrag += new MouseEventHandler(OnMouseMoveNoDrag);
            base.AttachToExtender(extender);
        }

        protected override void DetachFromExtender(MapExtender extender)
        {
            extender.MouseMoveNoDrag -= new MouseEventHandler(OnMouseMoveNoDrag);
            base.DetachFromExtender(extender);
        }
	}
}
