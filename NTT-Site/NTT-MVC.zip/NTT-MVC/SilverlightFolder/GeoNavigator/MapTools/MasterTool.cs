﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;

using ESRI.ArcGIS.Client;

namespace GeoNavigator.MapTools
{
	public class MasterTool : MapTool
	{
		#region Dependency Properties

		#region ToolsProperty

		public static readonly DependencyProperty ToolsProperty = DependencyProperty.Register(
			"Tools",
			typeof(MapToolCollection),
			typeof(MasterTool),
			new PropertyMetadata(OnToolsPropertyChanged));

		static void OnToolsPropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			var tool = d as MasterTool;
			if (tool != null)
			{
				var oldValue = e.OldValue as MapToolCollection;
				var newValue = e.NewValue as MapToolCollection;

				if (oldValue != null)
				{
					oldValue.ResetTools();

					newValue.ToolSet -= new EventHandler<EventArgs<MapTool>>(tool.OnSubToolSet);
					newValue.ToolReset -= new EventHandler<EventArgs<MapTool>>(tool.OnSubToolReset);
				}


				if (newValue != null)
				{
					newValue.ToolSet += new EventHandler<EventArgs<MapTool>>(tool.OnSubToolSet);
					newValue.ToolReset += new EventHandler<EventArgs<MapTool>>(tool.OnSubToolReset);

					newValue.SetTools(tool.Map, tool.MapExtender);
				}

				tool.OnToolsPropertyChanged(oldValue, newValue);
			}
		}

		#endregion

		#endregion

		List<MapTool> enabledTools;

		public MasterTool()
			: base()
		{
			enabledTools = new List<MapTool>();
			Tools = new MapToolCollection();
		}

		public MapToolCollection Tools
		{
			get { return (MapToolCollection)GetValue(ToolsProperty); }
			set { SetValue(ToolsProperty, value); }
		}

		protected virtual void OnSubToolSet(object sender, EventArgs<MapTool> e)
		{
			var subTool = e.Args as SubTool;
			if (subTool != null)
			{
				subTool.Master = this;
				subTool.LayerName = LayerName;
			}
		}

		protected virtual void OnSubToolReset(object sender, EventArgs<MapTool> e)
		{
			var subTool = e.Args as SubTool;
			if (subTool != null)
			{
				subTool.Master = null;
				subTool.LayerName = null;
			}
		}

		protected override void OnEnabled()
		{
			foreach (var tool in enabledTools)
				tool.IsEnabled = true;

			base.OnEnabled();
		}

		protected override void OnDisabled()
		{
			enabledTools.Clear();

			foreach (var tool in Tools)
			{
				if (tool.IsEnabled)
					enabledTools.Add(tool);

				tool.IsEnabled = false;
			}

			base.OnDisabled();
		}

		protected override void OnMapExtenderPropertyChanged(MapExtender oldValue, MapExtender newValue)
		{
			Tools.MapExtender = newValue;
		}

		protected override void OnMapPropertyChanged(Map oldValue, Map newValue)
		{
			Tools.Map = newValue;
		}

		protected override void OnLayerNameChanged(string oldValue, string newValue)
		{
			foreach(var tool in Tools)
				tool.LayerName = newValue;
		}

		protected virtual void OnToolsPropertyChanged(MapToolCollection oldValue, MapToolCollection newValue)
		{
		}
	}
}
