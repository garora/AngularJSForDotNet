﻿using System;

namespace GeoNavigator.MapTools
{
	public class SubTool : MapTool
	{
		// should this be a DependencyProperty?
		public MasterTool Master { get; set; }
	}
}
