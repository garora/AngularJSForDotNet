﻿//using System;

//using ESRI.ArcGIS.Client.Geometry;

//namespace GeoNavigator.MapTools
//{
//    public class BoxToolCompleteEventArgs : EventArgs
//    {
//        public Envelope Extent { get; private set; }

//        public BoxToolCompleteEventArgs(Envelope extent)
//        {
//            if (extent != null)
//                Extent = extent.Clone();
//        }
//    }
//}
