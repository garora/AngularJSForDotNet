﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;

using Geom = ESRI.ArcGIS.Client.Geometry;
using ESRI.ArcGIS.Client;
using ESRI.ArcGIS.Client.Symbols;

namespace GeoNavigator.MapTools
{
    public class MapTool : DependencyObject
    {
		#region Dependency Properties

		#region IdProperty

		public static readonly DependencyProperty IdProperty = DependencyProperty.Register(
			"Id",
			typeof(string),
			typeof(MapTool),
			null
			);

		#endregion

        #region MapExtenderProperty

        public static readonly DependencyProperty MapExtenderProperty = DependencyProperty.Register(
            "MapExtender",
            typeof(MapExtender),
            typeof(MapTool),
            new PropertyMetadata(OnMapExtenderPropertyChanged));

        static void OnMapExtenderPropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            MapTool tool = d as MapTool;
            if (tool != null)
                tool.OnMapExtenderPropertyChanged(e.OldValue as MapExtender, e.NewValue as MapExtender);
        }

        #endregion

        #region MapProperty

        public static readonly DependencyProperty MapProperty = DependencyProperty.Register(
            "Map",
            typeof(Map),
            typeof(MapTool),
            new PropertyMetadata(OnMapPropertyChanged));

        static void OnMapPropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            MapTool tool = d as MapTool;
            if (tool != null)
                tool.OnMapPropertyChanged(e.OldValue as Map, e.NewValue as Map);
        }

        #endregion

        #region LayerNameProperty

        public static readonly DependencyProperty LayerNameProperty = DependencyProperty.Register(
            "LayerName",
            typeof(string),
            typeof(MapTool),
            new PropertyMetadata(OnLayerNamePropertyChanged));

        static void OnLayerNamePropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var tool = d as MapTool;
            if (tool != null)
                tool.OnLayerNameChanged(e.OldValue as string, e.NewValue as string);
        }

		#endregion

		#region IsEnabledProperty

		public static readonly DependencyProperty IsEnabledProperty = DependencyProperty.Register(
			"IsEnabled",
			typeof(bool),
			typeof(MapTool),
			new PropertyMetadata(OnIsEnabledPropertyChanged)
			);

		static void OnIsEnabledPropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			MapTool mapTool = d as MapTool;
			if (mapTool == null)
				return;

			bool oldValue = (bool)e.OldValue;
			bool newValue = (bool)e.NewValue;

			if (oldValue == false) // previously disabled
			{
                if (newValue == true)
                {
                    mapTool.AttachToExtenderInternal(mapTool.MapExtender);
                    mapTool.OnEnabled();
                    if (mapTool.Enabled != null)
                        mapTool.Enabled(mapTool, new EventArgs());
                }
			}
			else // previously enabled
                if (newValue == false)
                {
                    mapTool.DetachFromExtenderInternal(mapTool.MapExtender);
                    mapTool.OnDisabled();
                    if (mapTool.Disabled != null)
                        mapTool.Disabled(mapTool, new EventArgs());
                }
		}

		#endregion

		#region GroupProperty

		public static readonly DependencyProperty GroupProperty = DependencyProperty.Register(
			"Group",
			typeof(string),
			typeof(MapTool),
			new PropertyMetadata(OnGroupPropertyChanged)
			);

		static void OnGroupPropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			MapTool mapTool = d as MapTool;
			if (mapTool == null)
				return;

			string oldValue = (string)e.OldValue;
			string newValue = (string)e.NewValue;

			mapTool.OnGroupPropertyChanged(oldValue, newValue);
		}

		#endregion

        #endregion

        bool attachedToExtender;

		public MapTool()
		{

		}

		public string Id
		{
			get { return (string)GetValue(IdProperty); }
			set { SetValue(IdProperty, value); }
		}

        public MapExtender MapExtender
        {
            get { return (MapExtender)GetValue(MapExtenderProperty); }
            set { SetValue(MapExtenderProperty, value); }
        }

        public Map Map
        {
            get { return (Map)GetValue(MapProperty); }
            set { SetValue(MapProperty, value); }
        }

        public string LayerName
        {
            get { return (string)GetValue(LayerNameProperty); }
            set { SetValue(LayerNameProperty, value); }
		}

		public virtual bool IsEnabled
		{
			get { return (bool)GetValue(IsEnabledProperty); }
			set { SetValue(IsEnabledProperty, value); }
		}

		public virtual string Group
		{
			get { return (string)GetValue(GroupProperty); }
			set { SetValue(GroupProperty, value); }
		}

        public Layer Layer
        {
            get
            {
                Map map = Map;
                if (map == null)
                    return null;

                string layerName = LayerName;
                if (layerName == null)
                    return null;

                return map.Layers[layerName];
            }
		}

		public event EventHandler Enabled;
		protected virtual void OnEnabled()
		{
		}

		public event EventHandler Disabled;
		protected virtual void OnDisabled()
		{
		}

        //protected virtual void OnMapExtenderPropertyChanged(MapExtender oldValue, MapExtender newValue)
        //{
        //}

        protected virtual void OnMapExtenderPropertyChanged(MapExtender oldValue, MapExtender newValue)
        {
            if (IsEnabled)
            {
                DetachFromExtenderInternal(oldValue);
                AttachToExtenderInternal(newValue);
            }
        }

        void AttachToExtenderInternal(MapExtender extender)
        {
            if (!attachedToExtender && extender != null)
            {
                AttachToExtender(extender);
                attachedToExtender = true;
            }
        }

        void DetachFromExtenderInternal(MapExtender extender)
        {
            if (attachedToExtender && extender != null)
            {
                DetachFromExtender(extender);
                attachedToExtender = false;
            }
        }

        protected virtual void AttachToExtender(MapExtender extender)
        {
        }

        protected virtual void DetachFromExtender(MapExtender extender)
        {
        }

        protected virtual void OnMapPropertyChanged(Map oldValue, Map newValue)
        {
		}

		protected virtual void OnLayerNameChanged(string oldValue, string newValue)
		{
		}

		protected virtual void OnGroupPropertyChanged(string oldValue, string newValue)
		{
		}
    }
}
