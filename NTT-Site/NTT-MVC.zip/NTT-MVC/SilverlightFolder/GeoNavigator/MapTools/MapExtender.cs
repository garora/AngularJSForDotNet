﻿using System;
using System.Windows;
using System.Windows.Input;

using GeoNavigator.StateManagement.EventExtensions;

using ESRI.ArcGIS.Client;

namespace GeoNavigator.MapTools
{
	public class MapExtender : EventExtender
	{
		#region Dependency Properties

		#region MapProperty

		public static readonly DependencyProperty MapProperty = DependencyProperty.Register(
			"Map",
			typeof(Map),
			typeof(MapExtender),
			new PropertyMetadata(OnMapPropertyChanged));

		static void OnMapPropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			MapExtender mapExtender = d as MapExtender;
			if (mapExtender != null)
			{
				var oldValue = e.OldValue as Map;
				var newValue = e.NewValue as Map;

				if (mapExtender.Tools != null)
					mapExtender.Tools.Map = newValue;

				mapExtender.OnMapPropertyChanged(oldValue, newValue);
			}
		}

		#endregion

		#region ToolsProperty

		public static readonly DependencyProperty ToolsProperty = DependencyProperty.Register(
			"Tools",
			typeof(MapToolCollection),
			typeof(MapExtender),
			new PropertyMetadata(OnToolsPropertyChanged));

		static void OnToolsPropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			var mapExtender = d as MapExtender;
			if (mapExtender != null)
			{
				var oldValue = e.OldValue as MapToolCollection;
				var newValue = e.NewValue as MapToolCollection;

				if (oldValue != null)
					oldValue.ResetTools();

				if (newValue != null)
					newValue.SetTools(mapExtender.Map, mapExtender);

				mapExtender.OnToolsPropertyChanged(oldValue, newValue);
			}
		}

		#endregion

		#endregion

		public MapExtender()
		{
			Tools = new MapToolCollection() { MapExtender = this };
		}

		public Map Map
		{
			get { return (Map)GetValue(MapProperty); }
			private set { SetValue(MapProperty, value); }
		}

		public MapToolCollection Tools
		{
			get { return (MapToolCollection)GetValue(ToolsProperty); }
			set { SetValue(ToolsProperty, value); }
		}

		protected override void OnContentChanged(object oldContent, object newContent)
        {
			Map = newContent as Map;
		}

		protected virtual void OnMapPropertyChanged(Map oldValue, Map newValue)
		{
		}

		protected virtual void OnToolsPropertyChanged(MapToolCollection oldValue, MapToolCollection newValue)
		{
		}
	}
}
