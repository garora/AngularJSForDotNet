﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using ESRI.ArcGIS.Client;

namespace GeoNavigator.MapTools
{
    public class MapToolCollection : ObservableCollection<MapTool>
    {
        MapExtender mapExtender;
        Map map;

        public MapExtender MapExtender
        {
            get { return mapExtender; }
            set
            {
                mapExtender = value;
                foreach (var tool in tools)
                    tool.MapExtender = mapExtender;
            }
        }

        public Map Map
        {
            get { return map; }
            set
            {
                map = value;
                foreach (var tool in tools)
                    tool.Map = map;
            }
        }

        List<MapTool> tools = new List<MapTool>();

        public MapToolCollection()
        {
		}

		public event EventHandler<EventArgs<MapTool>> ToolSet;
		public event EventHandler<EventArgs<MapTool>> ToolReset;

		public T GetTool<T>(string id) where T : MapTool
		{
			T t;
			foreach (var tool in tools)
				if (tool.Id == id)
				{
					t = tool as T;
					if (t != null)
						return t;
				}

			return null;
		}

		public MapTool this[string id]
		{
			get
			{
				foreach (var tool in tools)
					if (tool.Id == id)
						return tool;

				return null;
			}
		}

		//public T FirstOrEmpty<T>(string id) where T : MapTool, new()
		//{
		//    T t;
		//    foreach (var tool in tools)
		//        if (tool.Id == id)
		//        {
		//            t = tool as T;
		//            if (t != null)
		//                return t;
		//        }

		//    return new T();
		//}

		public void SingleEnable(MapTool tool)
		{
			foreach (MapTool t in tools)
				if(t != tool && t.Group == tool.Group)
					t.IsEnabled = false;

			if(!tool.IsEnabled)
				tool.IsEnabled = true;
		}

		public void SetTools(Map map, MapExtender mapExtender)
		{
			this.map = map;
			this.mapExtender = mapExtender;

			foreach (var tool in tools)
				SetTool(tool);
		}

		public void ResetTools()
		{
			foreach (var tool in tools)
				ResetTool(tool);
		}

		void tool_Enabled(object sender, EventArgs e)
		{
			var tool = sender as MapTool;
			if (tool != null)
				SingleEnable(tool);
		}

        void SetTool(MapTool tool)
        {
			tool.Enabled += new EventHandler(tool_Enabled);
            tool.Map = map;
            tool.MapExtender = mapExtender;

			if (ToolSet != null)
				ToolSet(this, new EventArgs<MapTool>(tool));
        }

        void ResetTool(MapTool tool)
        {
			tool.Enabled -= new EventHandler(tool_Enabled);
            tool.Map = null;
			tool.MapExtender = null;

			if (ToolReset != null)
				ToolReset(this, new EventArgs<MapTool>(tool));
        }

        void AddTool(MapTool tool)
		{
            tools.Add(tool);
            SetTool(tool);
        }

        void RemoveTool(MapTool tool)
		{
            tools.Remove(tool);
            ResetTool(tool);
        }

        protected override void OnCollectionChanged(NotifyCollectionChangedEventArgs e)
        {
            switch (e.Action)
            {
                case NotifyCollectionChangedAction.Add:
                    foreach (MapTool tool in e.NewItems)
                        AddTool(tool);
                    break;

                case NotifyCollectionChangedAction.Remove:
                    foreach (MapTool tool in e.OldItems)
                        RemoveTool(tool);
                    break;

                case NotifyCollectionChangedAction.Replace:
                    foreach (MapTool tool in e.OldItems)
                        RemoveTool(tool);

                    foreach (MapTool tool in e.NewItems)
                        AddTool(tool);
                    break;

                case NotifyCollectionChangedAction.Reset:
                    foreach (MapTool tool in tools)
                        ResetTool(tool);

                    tools.Clear();

                    foreach (MapTool tool in this)
                        AddTool(tool);
                    break;

                default:
                    break;
            }
        }
    }
}
