﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

using ESRI.ArcGIS.Client;
using ESRI.ArcGIS.Client.Geometry;
using ESRI.ArcGIS.Client.Symbols;

using Color = System.Windows.Media.Color;
using SolidColorBrush = System.Windows.Media.SolidColorBrush;

using GeoNavigator.StateManagement.EventExtensions;

namespace GeoNavigator.MapTools
{
	public class BoxTool : MapTool
	{
		public static SimpleFillSymbol defaultDrawSymbol = new SimpleFillSymbol()
		{
			BorderBrush = new SolidColorBrush()
			{
				Color = Color.FromArgb(255, 128, 0, 0)
			},
			BorderThickness = 1,
			Fill = new SolidColorBrush()
			{
				Color = Color.FromArgb(128, 255, 0, 0)
			}
		};

		#region Dependency Properties

		#region DrawSymbolProperty

		public static readonly DependencyProperty DrawSymbolProperty = DependencyProperty.Register(
			"DrawSymbol",
			typeof(FillSymbol),
			typeof(BoxTool),
			new PropertyMetadata(defaultDrawSymbol, OnDrawSymbolPropertyChanged));

		static void OnDrawSymbolPropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
		}

		#endregion

		#endregion

		GraphicsLayer _graphicsLayer;
        
		protected Envelope extent;
		protected Graphic graphic;
		protected MapPoint anchor;

		public event EventHandler Cancelled;
		public event EventHandler<EventArgs<Envelope>> Completed;

		protected virtual void OnKeyDown(object sender, KeyEventArgs e)
		{
			if (!IsEnabled)
				return;

			switch (e.Key)
			{
				case Key.Escape:
					if (extent != null)
					{
						e.Handled = true;
						OnCancelled();
					}
					break;

				case Key.Enter:
					if (extent != null)
					{
						e.Handled = true;
						OnCompleted();
					}
					break;
			}
		}

		protected virtual void OnBeginDrag(object sender, MouseButtonEventArgs e)
		{
			if (!IsEnabled)
				return;

			Map map = Map;

			if (Map == null || graphicsLayer == null)
				return;

			Clear();
			anchor = map.ScreenToMap(e.GetPosition(map));

			graphic = new Graphic()
			{
				Geometry = extent = new Envelope(anchor, anchor)
				{
					SpatialReference = map.SpatialReference == null ? null : map.SpatialReference.Clone()
				},
				Symbol = DrawSymbol
			};

			graphicsLayer.Graphics.Add(graphic);

			e.Handled = true;
		}

		protected virtual void OnDrag(object sender, MouseDragEventArgs e)
		{
			Map map = Map;
			MapPoint p = map.ScreenToMap(e.MoveTo.GetPosition(map));

			graphic.Geometry = extent = new Envelope(anchor, p);
		}

		protected virtual void OnEndDrag(object sender, MouseEndDragEventArgs e)
		{
			Map map = Map;
			MapPoint p = map.ScreenToMap(e.MouseUp.GetPosition(map));

			graphic.Geometry = extent = new Envelope(anchor, p);

			anchor = null;
		}

		protected GraphicsLayer graphicsLayer
		{
			get
			{
				if (_graphicsLayer == null)
					_graphicsLayer = Layer as GraphicsLayer;

				return _graphicsLayer;
			}
		}

		public FillSymbol DrawSymbol
		{
			get { return (FillSymbol)GetValue(DrawSymbolProperty); }
			set { SetValue(DrawSymbolProperty, value); }
		}

		public Envelope Extent
		{
			get { return extent.Clone(); }
		}

		public virtual void SetExtent(Envelope env)
		{
			SetExtent(env, null);
		}

		public void BeginDraw()
		{
			Clear();
		}

		public void EndDraw()
		{
			OnCompleted();
		}

		public void CancelDraw()
		{
			OnCancelled();
		}

		public virtual void SetExtent(Envelope env, Symbol drawSymbol)
		{
			Map map = Map;
			if (map == null)
				return;

			Clear();

			if (drawSymbol == null)
				drawSymbol = DrawSymbol;

			graphic = new Graphic()
			{
				Geometry = extent = new Envelope(env.XMin, env.YMin, env.XMax, env.YMax)
				{
					SpatialReference = map.SpatialReference == null ? null : map.SpatialReference.Clone()
				},
				Symbol = drawSymbol
			};

			graphicsLayer.Graphics.Add(graphic);
		}

        protected override void AttachToExtender(MapExtender extender)
        {
            extender.KeyDown += new KeyEventHandler(OnKeyDown);
            extender.BeginDrag += new MouseButtonEventHandler(OnBeginDrag);
            extender.Drag += new MouseDragEventHandler(OnDrag);
            extender.EndDrag += new MouseEndDragEventHandler(OnEndDrag);
            //extender.MouseMoveNoDrag += new MouseEventHandler(OnMouseMoveNoDrag);
        }

        protected override void DetachFromExtender(MapExtender extender)
        {
            extender.KeyDown -= new KeyEventHandler(OnKeyDown);
            extender.BeginDrag -= new MouseButtonEventHandler(OnBeginDrag);
            extender.Drag -= new MouseDragEventHandler(OnDrag);
            extender.EndDrag -= new MouseEndDragEventHandler(OnEndDrag);
            //extender.MouseMoveNoDrag -= new MouseEventHandler(OnMouseMoveNoDrag);
        }

		//void OnMouseMoveNoDrag(object sender, MouseEventArgs e)
		//{
		//    System.Diagnostics.Debug.WriteLine("MouseMoveNoDrag " + e.GetPosition(Map));
		//}

		protected override void OnLayerNameChanged(string oldValue, string newValue)
		{
			_graphicsLayer = Layer as GraphicsLayer;
		}

        //protected override void OnEnabled()
        //{
        //    AttachToExtenderInternal(MapExtender);
        //    base.OnEnabled();
        //}

		protected override void OnDisabled()
		{
            //DetachFromExtenderInternal(MapExtender);
			//Clear();
			//base.OnDisabled();
		}

		protected virtual void OnCancelled()
		{
			Clear();

			if (Cancelled != null)
				Cancelled(this, new EventArgs());
		}

		protected virtual void OnCompleted()
		{
			if (Completed != null)
				Completed(this, new EventArgs<Envelope>(extent));
		}

		public virtual void Clear()
		{
			if (graphic != null)
				graphicsLayer.Graphics.Remove(graphic);

			graphic = null;
			extent = null;
		}
	}
}
