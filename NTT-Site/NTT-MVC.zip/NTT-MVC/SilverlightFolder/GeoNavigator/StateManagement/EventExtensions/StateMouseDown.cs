﻿using System;
using System.Windows;
using System.Windows.Input;

namespace GeoNavigator.StateManagement.EventExtensions
{
	public class StateMouseDown : State
	{
		public StateMouseDown(EventExtender owner) : base(owner) { }

		StateMouseUp stateMouseUp;
		public MouseButtonEventArgs MouseDownAt { get { return stateMouseUp == null ? null : stateMouseUp.MouseDownAt; } }

		public override bool Enter(State from)
		{
			stateMouseUp = from as StateMouseUp;
			if (stateMouseUp != null)
				return true;

			return false;
		}

		public override void OnMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (stateMouseUp.CanClick)
			{
				OnClick(sender, e);
				e.Handled = true;
			}

			Transfer(stateMouseUp);
		}

		public override void OnMouseMove(object sender, MouseEventArgs e)
		{
			if (stateMouseUp.CanDrag)
			{
				stateMouseUp.ResetDownCount();
				Transfer<StateDragging>();
			}
		}
	}
}
