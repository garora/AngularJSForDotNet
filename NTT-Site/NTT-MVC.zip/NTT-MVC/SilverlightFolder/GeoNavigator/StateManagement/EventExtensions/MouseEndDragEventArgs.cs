﻿using System;
using System.Windows.Input;

namespace GeoNavigator.StateManagement.EventExtensions
{
	public class MouseEndDragEventArgs
	{
		public readonly MouseButtonEventArgs Anchor;
		public readonly MouseButtonEventArgs MouseUp;

		public MouseEndDragEventArgs(MouseButtonEventArgs anchor, MouseButtonEventArgs mouseUp)
		{
			Anchor = anchor;
			MouseUp = mouseUp;
		}
	}
}
