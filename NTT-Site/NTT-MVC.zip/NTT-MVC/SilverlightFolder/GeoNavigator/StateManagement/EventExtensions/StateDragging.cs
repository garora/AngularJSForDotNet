﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace GeoNavigator.StateManagement.EventExtensions
{
	public class StateDragging : State
	{
		public StateDragging(EventExtender owner) : base(owner) { }

		public MouseButtonEventArgs Anchor { get; private set; }

		public override bool Enter(State from)
		{
			var idle = from as StateMouseDown;
			if (idle != null)
			{
				Anchor = idle.MouseDownAt;
				owner.Control.CaptureMouse();
				return true;
			}

			// only allow entrance from the idle state
			return false;
		}

		public override bool Exit(State to)
		{
			owner.Control.ReleaseMouseCapture();
			return true;
		}

		public override void OnMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			OnEndDrag(sender, Anchor, e);
			var mouseUp = Transfer<StateMouseUp>();
			//mouseUp.CanDrag = false;
			e.Handled = true;
		}

		public override void OnMouseMove(object sender, MouseEventArgs e)
		{
			OnDrag(sender, Anchor, e);
		}
	}
}
