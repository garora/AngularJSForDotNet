﻿using System;
using System.Windows.Input;

namespace GeoNavigator.StateManagement.EventExtensions
{
	public class EventExtender : GeoNavigator.StateManagement.Base.StateMachineBase<EventExtender, State>
	{
		public EventExtender()
		{
			MouseLeftButtonDown += new MouseButtonEventHandler(handle_MouseLeftButtonDown);
			MouseLeftButtonUp += new MouseButtonEventHandler(handle_MouseLeftButtonUp);
			MouseMove += new MouseEventHandler(handle_MouseMove);
		}

		public override State[] CreateStates()
		{
			return new State[]
			{
				new StateMouseUp(this),
				new StateMouseDown(this),
				new StateDragging(this)
			};
		}

		public event MouseButtonEventHandler BeginClick;
		public event MouseButtonEventHandler Click;
		public event MouseButtonEventHandler DoubleClick;

		public event MouseButtonEventHandler BeginDrag;
		public event MouseDragEventHandler Drag;
		public event MouseEndDragEventHandler EndDrag;

        public event MouseEventHandler MouseMoveNoDrag;

		public void OnBeginClick(object sender, MouseButtonEventArgs e)
		{
			if (BeginClick != null) BeginClick(sender, e);
		}

		public void OnClick(object sender, MouseButtonEventArgs e)
		{
			if (Click != null) Click(sender, e);
		}

		public void OnDoubleClick(object sender, MouseButtonEventArgs e)
		{
			if (DoubleClick != null) DoubleClick(sender, e);
		}

		public void OnBeginDrag(object sender, MouseButtonEventArgs e)
		{
			if (BeginDrag != null) BeginDrag(sender, e);
		}

		public void OnDrag(object sender, MouseButtonEventArgs anchor, MouseEventArgs e)
		{
			if (Drag != null) Drag(sender, new MouseDragEventArgs(anchor, e));
		}

		public void OnEndDrag(object sender, MouseButtonEventArgs anchor, MouseButtonEventArgs e)
		{
			if (EndDrag != null) EndDrag(sender, new MouseEndDragEventArgs(anchor, e));
		}

        public void OnMouseMoveNoDrag(object sender, MouseEventArgs e)
        {
            if (MouseMoveNoDrag != null) MouseMoveNoDrag(sender, e);
        }

		void handle_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
			if (IsActive) State.OnMouseLeftButtonDown(sender, e);
		}

		void handle_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (IsActive) State.OnMouseLeftButtonUp(sender, e);
		}

		void handle_MouseMove(object sender, MouseEventArgs e)
		{
			if (IsActive) State.OnMouseMove(sender, e);
		}
	}
}
