﻿using System;
using System.Windows.Input;

namespace GeoNavigator.StateManagement.EventExtensions
{
	public delegate void MouseEndDragEventHandler(object sender, MouseEndDragEventArgs e);
}
