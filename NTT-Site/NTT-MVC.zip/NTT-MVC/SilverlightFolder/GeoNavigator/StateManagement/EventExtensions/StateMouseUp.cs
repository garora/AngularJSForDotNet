﻿using System;
using System.Windows;
using System.Windows.Input;

namespace GeoNavigator.StateManagement.EventExtensions
{
	public class StateMouseUp : State
	{
		public StateMouseUp(EventExtender owner) : base(owner) { }

		int downCount;
		DateTime downTime;

		public MouseButtonEventArgs MouseDownAt { get; private set; }

		public bool CanClick { get; private set; }
		public bool CanDrag { get; set; }

		public void ResetDownTime()
		{
			downTime = DateTime.MinValue;
		}

		public void ResetDownCount()
		{
			downCount = 0;
		}

		protected void CheckClickDrag(object sender, MouseButtonEventArgs e)
		{
			CanClick = CanDrag = false;

			OnBeginDrag(sender, e);
			if (e.Handled)
			{
				CanClick = CanDrag = true;
				return;
			}

			OnBeginClick(sender, e);
			if (e.Handled)
				CanClick = true;
		}

		public override void OnMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
			TimeSpan downSpan;

			MouseDownAt = e;
			CheckClickDrag(sender, e);

			if (downCount == 0)
			{
				downTime = DateTime.Now;
				downSpan = TimeSpan.MaxValue;
			}
			else
				downSpan = DateTime.Now - downTime;

			downCount++;

			if (CanClick && downCount > 1 && downSpan <= DoubleClickTime.MaxValue)
			{
				downCount = 0;
				downTime = DateTime.MinValue;
				CanClick = false;
				OnDoubleClick(sender, e);
				e.Handled = true;
			}
			//else
			//{
			//    System.Diagnostics.Debug.WriteLine("CanClick = " + CanClick + ", downCount = " + downCount + ", downSpan = " + downSpan + ", downSpan <= DoubleClickTime.MaxValue = " + (downSpan <= DoubleClickTime.MaxValue));
			//}

			if (downCount > 1)
			{
				downCount = 1;
				downTime = DateTime.Now;
			}

			Transfer<StateMouseDown>();
		}

		public override void OnMouseMove(object sender, MouseEventArgs e)
		{
			// can't double click if the mouse moves between clicks
			ResetDownTime();
            OnMouseMoveNoDrag(sender, e);
		}
	}
}
