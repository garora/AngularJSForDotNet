﻿using System;
using System.Windows;
using System.Windows.Input;

namespace GeoNavigator.StateManagement.EventExtensions
{
	public class State : GeoNavigator.StateManagement.Base.State<EventExtender, State>
	{
		public State(EventExtender owner) : base(owner) { }

		public override bool Enter(State from)
		{
			return true;
		}

		public override bool Exit(State to)
		{
			return true;
		}


		public virtual void OnBeginClick(object sender, MouseButtonEventArgs e)
		{
			owner.OnBeginClick(sender, e);
		}

		public virtual void OnClick(object sender, MouseButtonEventArgs e)
		{
			owner.OnClick(sender, e);
		}

		public virtual void OnDoubleClick(object sender, MouseButtonEventArgs e)
		{
			owner.OnDoubleClick(sender, e);
		}

		public virtual void OnBeginDrag(object sender, MouseButtonEventArgs e)
		{
			owner.OnBeginDrag(sender, e);
		}

		public virtual void OnDrag(object sender, MouseButtonEventArgs anchor, MouseEventArgs e)
		{
			owner.OnDrag(sender, anchor, e);
		}

		public virtual void OnEndDrag(object sender, MouseButtonEventArgs anchor, MouseButtonEventArgs e)
		{
			owner.OnEndDrag(sender, anchor, e);
		}

        public virtual void OnMouseMoveNoDrag(object sender, MouseEventArgs e)
        {
            owner.OnMouseMoveNoDrag(sender, e);
        }

		public virtual void OnMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
		}

		public virtual void OnMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
		}

		public virtual void OnMouseMove(object sender, MouseEventArgs e)
		{
			//UIElement control = owner.Control;
			//if (control != null)
			//    System.Diagnostics.Debug.WriteLine(e.GetPosition(null));
		}
	}
}
