﻿using System;
using System.Windows.Input;

namespace GeoNavigator.StateManagement.EventExtensions
{
	public class MouseDragEventArgs
	{
		public readonly MouseButtonEventArgs Anchor;
		public readonly MouseEventArgs MoveTo;

		public MouseDragEventArgs(MouseButtonEventArgs anchor, MouseEventArgs moveTo)
		{
			Anchor = anchor;
			MoveTo = moveTo;
		}
	}
}
