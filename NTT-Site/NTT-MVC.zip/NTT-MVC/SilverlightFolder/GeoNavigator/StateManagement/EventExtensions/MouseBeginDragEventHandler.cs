﻿//using System;
//using System.Windows.Input;

//namespace GeoNavigator.StateManagement.EventExtensions
//{
//    public delegate void MouseBeginDragEventHandler(object sender, MouseButtonEventArgs e);
//}
