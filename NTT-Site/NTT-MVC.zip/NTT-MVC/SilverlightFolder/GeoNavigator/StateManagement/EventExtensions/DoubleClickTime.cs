﻿using System;

namespace GeoNavigator.StateManagement.EventExtensions
{
	public static class DoubleClickTime
	{
		public static readonly TimeSpan DefaultMaxValue = new TimeSpan(0, 0, 0, 0, 500);

		static TimeSpan maxValue = DefaultMaxValue;

		public static TimeSpan MaxValue
		{
			get { return maxValue; }
			set { maxValue = value; }
		}
	}
}
