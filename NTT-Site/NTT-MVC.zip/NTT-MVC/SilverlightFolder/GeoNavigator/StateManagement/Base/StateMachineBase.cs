﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace GeoNavigator.StateManagement.Base
{
	public abstract class StateMachineBase<T, TState> : ContentControl
		where T : StateMachineBase<T, TState>
		where TState : State<T, TState>
	{
		public static readonly DependencyProperty IsActiveProperty = DependencyProperty.Register(
			"IsActive",
			typeof(bool),
			typeof(StateMachineBase<T, TState>),
			new PropertyMetadata(true, OnIsActivePropertyChanged));

		static void OnIsActivePropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			var handler = d as StateMachineBase<T, TState>;
			if (handler != null)
				handler.OnIsActivePropertyChanged((bool)e.OldValue, (bool)e.NewValue);
		}

		public StateMachineBase()
		{
			HorizontalContentAlignment = HorizontalAlignment.Stretch;
			VerticalContentAlignment = VerticalAlignment.Stretch;

			states = CreateStates();
			if (states.Length > 0)
				State = states[0];
		}

		protected TState[] states;

		public bool IsActive
		{
			get { return (bool)GetValue(IsActiveProperty); }
			set { SetValue(IsActiveProperty, value); }
		}

		public UIElement Control
		{
			get { return Content as UIElement; }
		}

		public TState State { get; set; }
		public TState this[int index] { get { return states[index]; } }

		public abstract TState[] CreateStates();

		public Ts GetState<Ts>()
			where Ts : TState
		{
			// this assumes that there aren't more than 10 states or so
			// if there are more than that, a dictionary should be used

			// for this to work correctly, no state can derive from another 
			// state in states[] - use base classes for states with common
			// functionality instead.

			Ts s;
			foreach (var state in states)
			{
				s = state as Ts;
				if (s != null)
					return s;
			}

			return null;
		}

		public bool SetState<Ts>()
			where Ts : TState
		{
			Ts state = GetState<Ts>();
			if (state == null)
				return false;

			State = state;
			return true;
		}

		protected virtual void OnActivated() { }
		protected virtual void OnDeactivated() { }

		protected virtual void OnIsActivePropertyChanged(bool oldValue, bool newValue)
		{
			if (oldValue == false)
			{
				if (newValue == true)
					OnActivated();
			}
			else if (newValue == false)
				OnDeactivated();
		}
	}
}
