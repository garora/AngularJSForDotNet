﻿using System;

namespace GeoNavigator.StateManagement.Base
{
	public abstract class State<TOwner, TState>
		where TOwner : StateMachineBase<TOwner, TState>
		where TState : State<TOwner, TState>
	{
		protected readonly TOwner owner;

		public State(TOwner owner)
		{
			this.owner = owner;
		}

		public abstract bool Enter(TState from);
		public abstract bool Exit(TState to);

		public virtual T Transfer<T>() where T : TState
		{
			return (T)Transfer(owner.GetState<T>());
		}

		public virtual TState Transfer(TState to)
		{
			if (to == null)
				return null;

			if (!Exit(to))
				return null;

			if (!to.Enter((TState)this))
				return null;

			owner.State = to;
			return to;
		}
	}
}
