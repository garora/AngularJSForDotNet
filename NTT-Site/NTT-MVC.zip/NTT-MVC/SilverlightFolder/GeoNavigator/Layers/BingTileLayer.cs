﻿using System;
using System.Collections.ObjectModel;
using System.Globalization;
using System.ServiceModel;
using System.Text;
using System.Windows;

using ESRI.ArcGIS.Client;
using ESRI.ArcGIS.Client.Geometry;

namespace GeoNavigator.Layers
{
    /// <summary>
    /// This is an UNSUPPORTED layer for retrieving Bing tiles without requiring a token.
    /// </summary>
	public class BingTileLayer : TiledMapServiceLayer
	{
		const string baseUrl = "http://ecn.t{SUBDOMAIN}.tiles.virtualearth.net/tiles/{TYPE}{QUADKEY}.png?g=409&mkt=en-US&shading=hill&n=z";

		static Envelope defaultFullExtent = new Envelope(-20037508.3427892, -20037508.3427892, 20037508.3427892, 20037508.3427892);

		public static readonly DependencyProperty LayerStyleProperty = DependencyProperty.Register(
			"LayerStyle",
			typeof(LayerType),
			typeof(BingTileLayer),
			new PropertyMetadata(LayerType.Road, new PropertyChangedCallback(OnLayerStylePropertyChanged))
			);

		static void OnLayerStylePropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			var layer = d as BingTileLayer;

			switch ((LayerType)e.NewValue)
			{
				case LayerType.Aerial:
					layer.type = "a";
					break;

				case LayerType.AerialWithLabels:
					layer.type = "h";
					break;

				case LayerType.Road:
					layer.type = "r";
					break;
			}

			if (layer.IsInitialized)
				layer.Refresh();
		}

		public static readonly DependencyProperty LodProperty = DependencyProperty.Register(
			"Lod",
			typeof(int),
			typeof(BingTileLayer),
			// 21 appears to be the maximum LOD (for example, in New York City) but some areas of the US only go to 17, so default to 17
			new PropertyMetadata(17, new PropertyChangedCallback(OnLodPropertyChanged))
			);

		static void OnLodPropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			var layer = d as BingTileLayer;
			if (layer == null || !(e.NewValue is int))
				return;

			var lod = (int)e.NewValue;

			layer.lodsBuilt = false;
			layer.BuildLods();
		}

		string[] subdomains = new string[] { "0", "1", "2", "3", "4", "5", "6", "7" };
		string type = "r";
		Envelope fullExtent = defaultFullExtent;
		bool lodsBuilt;

		public BingTileLayer()
		{
			SpatialReference = new SpatialReference(102100);
		}

		public LayerType LayerStyle
		{
			get { return (LayerType)GetValue(LayerStyleProperty); }
			set { SetValue(LayerStyleProperty, value); }
		}

		public int Lod
		{
			get { return (int)GetValue(LodProperty); }
			set { SetValue(LodProperty, value); }
		}

		public override Envelope FullExtent
		{
			get { return fullExtent; }
			protected set { fullExtent = value; }
		}

		public override string GetTileUrl(int level, int row, int col)
		{
			int val;
			var quadkey = new StringBuilder();

			for (int i = level; i >= 0; i--)
			{
				val = 1 << i;
				quadkey.Append(((col & val) >> i) | (((row & val) != 0) ? 2 : 0));
			}

			string subdomain = subdomains[((level + col) + row) % subdomains.Length];

			return new StringBuilder(baseUrl)
				.Replace("{QUADKEY}", quadkey.ToString())
				.Replace("{TYPE}", type)
				.Replace("{SUBDOMAIN}", subdomain)
				.ToString();
		}
		
		void BuildLods()
		{
			if (!lodsBuilt)
			{
				TileInfo = new TileInfo()
				{
					SpatialReference = new SpatialReference(102100),
					Origin = new MapPoint(-20037508.3427892, 20037508.3427892, new SpatialReference(102100)),
					Width = 256,
					Height = 256,
					Lods = new Lod[Lod]
				};

				double resolution = (FullExtent.Width * .5d) / 256d;

				for (int i = 0; i < TileInfo.Lods.Length; i++)
				{
					TileInfo.Lods[i] = new Lod() { Resolution = resolution };
					resolution *= 0.5;
				}

				SetValue(Layer.MaximumResolutionProperty, TileInfo.Lods[0].Resolution);
				SetValue(Layer.MinimumResolutionProperty, TileInfo.Lods[TileInfo.Lods.Length - 1].Resolution);

				lodsBuilt = true;
			}
		}

		public override void Initialize()
		{
			try
			{
				if (!IsInitialized)
					BuildLods();

				base.Initialize();

				InitializationFailure = null;
			}
			catch (Exception ex)
			{
				InitializationFailure = ex;
			}
		}

		public enum LayerType
		{
			Road,
			Aerial,
			AerialWithLabels
		}
	}
}
