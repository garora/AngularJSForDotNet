﻿using System;
using System.Windows;
using System.Windows.Controls;

using ESRI.ArcGIS.Client;

namespace GeoNavigator.Controls
{
	public abstract class MapControl : Control
	{
		#region Dependency Properties

		#region MapProperty

		public static readonly DependencyProperty MapProperty = DependencyProperty.Register(
			"Map",
			typeof(Map),
			typeof(MapControl),
			new PropertyMetadata(OnMapPropertyChanged));

		static void OnMapPropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			MapControl control = d as MapControl;
			if (control != null)
				control.OnMapPropertyChanged(e.OldValue as Map, e.NewValue as Map);
		}

		#endregion

		#region LayerNameProperty

		public static readonly DependencyProperty LayerNameProperty = DependencyProperty.Register(
			"LayerName",
			typeof(string),
			typeof(MapControl),
			new PropertyMetadata(OnLayerNamePropertyChanged));

		static void OnLayerNamePropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			MapControl control = d as MapControl;
			if (control != null)
				control.OnLayerNameChanged(e.OldValue as string, e.NewValue as string);
		}

		#endregion

		#endregion

		public Map Map
		{
			get { return (Map)GetValue(MapProperty); }
			set { SetValue(MapProperty, value); }
		}

		public string LayerName
		{
			get { return (string)GetValue(LayerNameProperty); }
			set { SetValue(LayerNameProperty, value); }
		}

		public Layer Layer
		{
			get
			{
				Map map = Map;
				if (map == null)
					return null;

				string layerName = LayerName;
				if (layerName == null)
					return null;

				return map.Layers[layerName];
			}
		}

		protected virtual void OnMapPropertyChanged(Map oldValue, Map newValue)
		{
		}

		protected virtual void OnLayerNameChanged(string oldValue, string newValue)
		{
		}
	}
}
