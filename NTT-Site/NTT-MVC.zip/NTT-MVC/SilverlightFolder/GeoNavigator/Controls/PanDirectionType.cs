﻿using System;

namespace GeoNavigator.Controls
{
	public enum PanDirectionType
	{
		North,
		South,
		East,
		West
	}
}
