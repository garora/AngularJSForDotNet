﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using ESRI.ArcGIS.Client;
using Envelope = ESRI.ArcGIS.Client.Geometry.Envelope;

namespace GeoNavigator.Controls
{
	public partial class PanBar : UserControl
	{

		#region Dependency Properties

		#region MapProperty

		public static readonly DependencyProperty MapProperty = DependencyProperty.Register(
			"Map",
			typeof(Map),
			typeof(PanBar),
			null);

		#endregion

		#region PanDirectionProperty

		public static DependencyProperty PanDirectionProperty = DependencyProperty.Register(
			"PanDirection",
			typeof(PanDirectionType),
			typeof(PanBar),
			new PropertyMetadata(PanDirectionType.North, OnPanDirectionPropertyChanged));

		static void OnPanDirectionPropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			var panBar = d as PanBar;
			if (panBar != null)
				panBar.OnPanDirectionPropertyChanged((PanDirectionType)e.NewValue);
		}

		#endregion

		#endregion

		// calculations for equilateral triangle
		static double sqrt3 = Math.Sqrt(3);
		static double s = 2.5 * sqrt3;
		static double h = s * sqrt3;

		static double oneThirdCirc = 2d * Math.PI / 3d;
		static double twoThirdCirc = 2d * oneThirdCirc;
		static double radius = (2d / 3d) * 6;
		static double offset = 2d;

		static Point[] equiTriPoints = new Point[]
		{
			new Point(radius, 0d),
			new Point(radius * Math.Cos(oneThirdCirc), radius * Math.Sin(oneThirdCirc)),
			new Point(radius * Math.Cos(twoThirdCirc), radius * Math.Sin(twoThirdCirc)),
		};

		static PanHandler[] panHandlers = new PanHandler[]
		{
			new PanNorthHandler(),
			new PanSouthHandler(),
			new PanEastHandler(),
			new PanWestHandler()
		};

		static SolidColorBrush panBorderFill = new SolidColorBrush()
		{
			Color = "#88888888".HexColor()
		};

		static SolidColorBrush panBorderFillHighlight = new SolidColorBrush()
		{
			Color = "#FF888888".HexColor()
		};

		PathGeometry geom;
		PanHandler panHandler = panHandlers[0];

		public PanBar()
		{
			InitializeComponent();
		}

		public Map Map { get { return GetValue(MapProperty) as Map; } set { SetValue(MapProperty, value); } }
		public PanDirectionType PanDirection { get { return (PanDirectionType)GetValue(PanDirectionProperty); } set { SetValue(PanDirectionProperty, value); } }


		void UserControl_Loaded(object sender, RoutedEventArgs e)
		{
			geom = new PathGeometry() { FillRule = FillRule.EvenOdd };

			//var figure = new PathFigure() { IsClosed = true, IsFilled = true, StartPoint = new Point(0, s * sqrt3) };
			//figure.Segments.Add(new LineSegment() { Point = new Point(s, 0) });
			//figure.Segments.Add(new LineSegment() { Point = new Point(-s, 0) });
			
			var figure = new PathFigure() { IsClosed = true, IsFilled = true, StartPoint = equiTriPoints[0] };
			figure.Segments.Add(new LineSegment() { Point = equiTriPoints[1] });
			figure.Segments.Add(new LineSegment() { Point = equiTriPoints[2] });

			geom.Figures.Add(figure);

			geom.Transform = panHandler.Transform;

			equiTri.Data = geom;
		}

		void OnPanDirectionPropertyChanged(PanDirectionType direction)
		{
			panHandler = panHandlers[(int)direction];
			if (geom != null)
				geom.Transform = panHandler.Transform;
		}

		abstract class PanHandler
		{
			public abstract void Pan(Map map);
			public abstract Transform Transform { get; }

			protected void PanTo(Map map, double dx, double dy)
			{
				map.PanTo(new Envelope(map.Extent.XMin + dx, map.Extent.YMin + dy, map.Extent.XMax + dx, map.Extent.YMax + dy));
			}
		}

		class PanNorthHandler : PanHandler
		{
			public override void Pan(Map map)
			{
				PanTo(map, 0, map.Extent.Height * .5d);
			}

			public override Transform Transform
			{
				get
				{
					var t = new TransformGroup();
					t.Children.Add(new RotateTransform() { Angle = -90d });
					t.Children.Add(new TranslateTransform() { X = radius, Y = offset });
					return t;
				}
			}
		}

		class PanSouthHandler : PanHandler
		{
			public override void Pan(Map map)
			{
				PanTo(map, 0, -map.Extent.Height * .5d);
			}

			public override Transform Transform
			{
				get
				{
					var t = new TransformGroup();
					t.Children.Add(new RotateTransform() { Angle = 90d });
					t.Children.Add(new TranslateTransform() { X = radius, Y = offset });
					return t;
				}
			}
		}

		class PanEastHandler : PanHandler
		{
			public override void Pan(Map map)
			{
				PanTo(map, map.Extent.Width * .5d, 0);
			}

			public override Transform Transform
			{
				get
				{
					var t = new TransformGroup();
					t.Children.Add(new TranslateTransform() { X = offset, Y = radius });
					return t;
				}
			}
		}

		class PanWestHandler : PanHandler
		{
			public override void Pan(Map map)
			{
				PanTo(map, -map.Extent.Width * .5d, 0);
			}

			public override Transform Transform
			{
				get
				{
					var t = new TransformGroup();
					t.Children.Add(new RotateTransform() { Angle = 180d });
					t.Children.Add(new TranslateTransform() { X = offset, Y = radius });
					return t;
				}
			}
		}

		void UserControl_MouseEnter(object sender, MouseEventArgs e)
		{
			panBorder.Background = panBorderFillHighlight;
		}

		void UserControl_MouseLeave(object sender, MouseEventArgs e)
		{
			panBorder.Background = panBorderFill;
		}

		void UserControl_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
			if (Map != null)
				panHandler.Pan(Map);
		}
	}
}
