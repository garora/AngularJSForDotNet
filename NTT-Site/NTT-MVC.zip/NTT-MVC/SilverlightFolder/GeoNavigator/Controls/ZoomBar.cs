﻿using System;
using System.Windows;
using System.Windows.Controls;

using ESRI.ArcGIS.Client;
using Envelope = ESRI.ArcGIS.Client.Geometry.Envelope;

namespace GeoNavigator.Controls
{
	[TemplatePart(Name = "ZoomSlider", Type = typeof(Slider))]
	[TemplatePart(Name = "ZoomInButton", Type = typeof(Button))]
	[TemplatePart(Name = "ZoomOutButton", Type = typeof(Button))]
	[TemplatePart(Name = "ZoomFullExtentButton", Type = typeof(Button))]
	public class ZoomBar : MapControl
	{
		public static readonly DependencyProperty FullExtentProperty = DependencyProperty.Register(
			"FullExtent",
			typeof(Envelope),
			typeof(ZoomBar),
			new PropertyMetadata(OnFullExtentPropertyChanged)
			);

		static void OnFullExtentPropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			var zoomBar = d as ZoomBar;
			if (zoomBar != null)
				zoomBar.OnFullExtentPropertyChanged(e.NewValue as Envelope);
		}

		Slider zoomSlider;
		Button zoomInButton;
		Button zoomOutButton;
		Button zoomFullExtentButton;

		ZoomState zoomState;

		public ZoomBar()
		{
			DefaultStyleKey = typeof(ZoomBar);
		}

		public Envelope FullExtent
		{
			get { return (Envelope)GetValue(FullExtentProperty); }
			set { SetValue(FullExtentProperty, value); }
		}

		public override void OnApplyTemplate()
		{
			base.OnApplyTemplate();

			zoomSlider = GetTemplateChild("ZoomSlider") as Slider;
			zoomInButton = GetTemplateChild("ZoomInButton") as Button;
			zoomOutButton = GetTemplateChild("ZoomOutButton") as Button;
			zoomFullExtentButton = GetTemplateChild("ZoomFullExtentButton") as Button;

			if (zoomSlider != null)
			{
				zoomSlider.Minimum = 0d;
				zoomSlider.Maximum = 1d;
				zoomSlider.SmallChange = .01d;
				zoomSlider.LargeChange = .1d;
				zoomSlider.GotFocus += new RoutedEventHandler(zoomSlider_GotFocus);
				zoomSlider.LostFocus += new RoutedEventHandler(zoomSlider_LostFocus);
				zoomSlider.ValueChanged += new RoutedPropertyChangedEventHandler<double>(zoomSlider_ValueChanged);
				zoomSlider.Visibility = Visibility.Collapsed;
			}

			if (zoomInButton != null)
				zoomInButton.Click += new RoutedEventHandler(zoomInBtn_Click);

			if (zoomOutButton != null)
				zoomOutButton.Click += new RoutedEventHandler(zoomOutBtn_Click);

			if (zoomFullExtentButton != null)
				zoomFullExtentButton.Click += new RoutedEventHandler(zoomExtentBtn_Click);
		}

		void OnFullExtentPropertyChanged(Envelope extent)
		{
			if (Map != null && extent != null)
				Map.Extent = extent;
		}

		protected override void OnMapPropertyChanged(Map oldValue, Map newValue)
		{
			if (oldValue != null)
			{
				oldValue.ExtentChanged -= new EventHandler<ExtentEventArgs>(Map_ExtentChanged);
				oldValue.ExtentChanging -= new EventHandler<ExtentEventArgs>(Map_ExtentChanging);
			}

			if (newValue != null)
			{
				newValue.ExtentChanged += new EventHandler<ExtentEventArgs>(Map_ExtentChanged);
				newValue.ExtentChanging += new EventHandler<ExtentEventArgs>(Map_ExtentChanging);

				var extent = FullExtent;
				if (extent != null)
					newValue.Extent = extent;
			}
		}

		void Map_ExtentChanged(object sender, ExtentEventArgs e)
		{
			if (!double.IsNaN(Map.Resolution) && zoomSlider != null)
			{
				// Map.Resolution returns NaN until after the first ExtentChanged occurs - not sure why this is.
				if (zoomState == ZoomState.Undefined)
				{
					zoomSlider.Visibility = Visibility.Visible;
					zoomSlider.Value = ResolutionToValue(Map.Resolution);
					zoomState = ZoomState.None;
				}
				else
					zoomSlider.Value = ResolutionToValue(Map.Resolution);
			}
		}

		void Map_ExtentChanging(object sender, ExtentEventArgs e)
		{
			if (zoomState == ZoomState.SliderChanging)
				return;

			zoomState = ZoomState.ExtentChanging;

			if (!double.IsNaN(Map.Resolution) && zoomSlider != null)
				zoomSlider.Value = ResolutionToValue(Map.Resolution);
		}

		void zoomInBtn_Click(object sender, RoutedEventArgs e)
		{
			if(Map != null)
				Map.Zoom(Map.ZoomFactor);
		}

		void zoomOutBtn_Click(object sender, RoutedEventArgs e)
		{
			if (Map != null)
				Map.Zoom(1 / Map.ZoomFactor);
		}

		void zoomExtentBtn_Click(object sender, RoutedEventArgs e)
		{
			if (Map != null)
			{
				if (FullExtent != null)
					Map.ZoomTo(FullExtent);
				else
					Map.ZoomTo(Map.Layers.GetFullExtent());
			}
		}

		private void zoomSlider_GotFocus(object sender, RoutedEventArgs e)
		{
			zoomState = ZoomState.SliderChanging;
		}

		private void zoomSlider_LostFocus(object sender, RoutedEventArgs e)
		{
			zoomState = ZoomState.None;
		}

		private void zoomSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
		{
			if (zoomState == ZoomState.ExtentChanging)
			{
				zoomState = ZoomState.None;
				return;
			}

			zoomState = ZoomState.SliderChanging;

			if (!double.IsNaN(Map.Resolution))
				Map.ZoomToResolution(ValueToResolution(zoomSlider.Value));
		}

		double ResolutionToValue(double resolution)
		{
			double max = Math.Log10(Map.MaximumResolution);
			double min = Math.Log10(Map.MinimumResolution);
			double value = 1 - ((Math.Log10(resolution) - min) / (max - min));
			return Math.Min(1, Math.Max(value, 0)); //cap values between 0..1
		}

		double ValueToResolution(double value)
		{
			double max = Math.Log10(Map.MaximumResolution);
			double min = Math.Log10(Map.MinimumResolution);
			double resLog = (1 - value) * (max - min) + min;
			return Math.Pow(10, resLog);
		}

		enum ZoomState
		{
			Undefined,
			None,
			SliderChanging,
			ExtentChanging
		}
	}
}
