﻿using System;

namespace GeoNavigator
{
    /// <summary>
    /// A generic version of event args
    /// </summary>
	public class EventArgs<T> : EventArgs
	{
		T args;

		public EventArgs(T args)
		{
			this.args = args;
		}

		public T Args { get { return args; } }
	}

    /// <summary>
    /// A generic version of event args with 2 parameters
    /// </summary>
	public class EventArgs<T0, T1> : EventArgs
	{
		T0 args0;
		T1 args1;

		public EventArgs(T0 args0, T1 args1)
		{
			this.args0 = args0;
			this.args1 = args1;
		}

		public T0 Args0 { get { return args0; } }
		public T1 Args1 { get { return args1; } }
	}
}
