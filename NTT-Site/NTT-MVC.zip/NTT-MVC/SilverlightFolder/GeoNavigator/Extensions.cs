﻿using System;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

using ESRI.ArcGIS.Client;
using ESRI.ArcGIS.Client.Geometry;

using GeoNavigator.Projection;

namespace GeoNavigator
{
    /// <summary>
    /// Static extensions for various classes
    /// </summary>
	public static class Extensions
	{
        /// <summary>
        /// Does the Envelope contain the point x, y?
        /// </summary>
		public static bool Contains(this Envelope envelope, double x, double y)
		{
			return
				x >= envelope.XMin &&
				x <= envelope.XMax &&
				y >= envelope.YMin &&
				y <= envelope.YMax
				;
		}

        /// <summary>
        /// Does the Envelope contain the MapPoint?
        /// </summary>
		public static bool Contains(this Envelope envelope, MapPoint point)
		{
			return Contains(envelope, point.X, point.Y);
		}

        /// <summary>
        /// Does the Envelope contain the Point?
        /// </summary>
		public static bool Contains(this Envelope envelope, Point point)
		{
			return Contains(envelope, point.X, point.Y);
		}

        /// <summary>
        /// Does the first Envelope contain the other Envelope?
        /// </summary>
		public static bool Contains(this Envelope envelope, Envelope other)
		{
			return
				other.XMin >= envelope.XMin &&
				other.XMax <= envelope.XMax &&
				other.YMin >= envelope.YMin &&
				other.YMax <= envelope.YMax
				;
		}

        /// <summary>
        /// Is the Envelope's width equal or very close to 0?
        /// </summary>
		public static bool HasZeroWidth(this Envelope env)
		{
			return env.XMin.IsZeroInterval(env.XMax);
		}

        /// <summary>
        /// Is the Envelope's height equal or very close to 0?
        /// </summary>
		public static bool HasZeroHeight(this Envelope env)
		{
			return env.YMin.IsZeroInterval(env.YMax);
		}

        /// <summary>
        /// Is the Envelope's width and height equal or very close to 0?
        /// </summary>
		public static bool HasZeroArea(this Envelope env)
		{
			return env.HasZeroWidth() || env.HasZeroHeight();
		}

        /// <summary>
        /// Return the center of the envelope
        /// </summary>
		public static Point Center(this Envelope env)
		{
			return new Point(
				(env.XMin + env.XMax) * .5d,
				(env.YMin + env.YMax) * .5d
				);
		}

        /// <summary>
        /// Find the closest corner of the extent to a MapPoint, where:
        /// 1) the extent is in screen coordinates (i.e. pixels)
        /// 2) the map is in a projected coordinate system (probably Web Mercator, in meters)
        /// 3) the square distance to a corner is within pixelSquareDistance pixels
        /// </summary>
		public static MapPoint ClosestCorner(this Envelope extent, Map map, MapPoint point, double pixelSquareDistance)
		{
			return ClosestCorner(extent, map, point, pixelSquareDistance, false);
		}

        /// <summary>
        /// Find the closest corner of the extent to a MapPoint; if returnOppositeCorner is true,
        /// then return the opposite corner instead
        /// </summary>
		public static MapPoint ClosestCorner(this Envelope extent, Map map, MapPoint point, double pixelSquareDistance, bool returnOppositeCorner)
		{
			Point xy = map.MapToScreen(point);
			Point xmin_ymin = map.MapToScreen(new MapPoint(extent.XMin, extent.YMin, map.SpatialReference));
			Point xmin_ymax = map.MapToScreen(new MapPoint(extent.XMin, extent.YMax, map.SpatialReference));
			Point xmax_ymin = map.MapToScreen(new MapPoint(extent.XMax, extent.YMin, map.SpatialReference));
			Point xmax_ymax = map.MapToScreen(new MapPoint(extent.XMax, extent.YMax, map.SpatialReference));

			double xmin_ymin_distx = xmin_ymin.X - xy.X;
			double xmin_ymin_disty = xmin_ymin.Y - xy.Y;
			if (xmin_ymin_distx * xmin_ymin_distx + xmin_ymin_disty * xmin_ymin_disty <= pixelSquareDistance)
				return returnOppositeCorner ? map.ScreenToMap(xmax_ymax) : map.ScreenToMap(xmin_ymin);

			double xmin_ymax_distx = xmin_ymax.X - xy.X;
			double xmin_ymax_disty = xmin_ymax.Y - xy.Y;
			if (xmin_ymax_distx * xmin_ymax_distx + xmin_ymax_disty * xmin_ymax_disty <= pixelSquareDistance)
				return returnOppositeCorner ? map.ScreenToMap(xmax_ymin) : map.ScreenToMap(xmin_ymax);

			double xmax_ymin_distx = xmax_ymin.X - xy.X;
			double xmax_ymin_disty = xmax_ymin.Y - xy.Y;
			if (xmax_ymin_distx * xmax_ymin_distx + xmax_ymin_disty * xmax_ymin_disty <= pixelSquareDistance)
				return returnOppositeCorner ? map.ScreenToMap(xmin_ymax) : map.ScreenToMap(xmax_ymin);

			double xmax_ymax_distx = xmax_ymax.X - xy.X;
			double xmax_ymax_disty = xmax_ymax.Y - xy.Y;
			if (xmax_ymax_distx * xmax_ymax_distx + xmax_ymax_disty * xmax_ymax_disty <= pixelSquareDistance)
				return returnOppositeCorner ? map.ScreenToMap(xmin_ymin) : map.ScreenToMap(xmax_ymax);

			return null;
		}

        /// <summary>
        /// Convert a MapPoint from WebMercator to NAD83, and return a Point
        /// </summary>
		public static Point WebMercatorToNad83(this MapPoint point)
		{
			return new Point(
				MercatorMath.MetersToLongitude(point.X),
				MercatorMath.MetersToLatitude(point.Y)
				);
		}

        /// <summary>
        /// Convert a MapPoint from NAD83 to WebMercator, and return a Point
        /// </summary>
		public static Point Nad83ToWebMercator(this MapPoint point)
		{
			return new Point(
				MercatorMath.LongitudeToMeters(point.X),
				MercatorMath.LatitudeToMeters(point.Y)
				);
		}

        /// <summary>
        /// Convert a Point from WebMercator to NAD83
        /// </summary>
		public static Point WebMercatorToNad83(this Point point)
		{
			return new Point(
				MercatorMath.MetersToLongitude(point.X),
				MercatorMath.MetersToLatitude(point.Y)
				);
		}

        /// <summary>
        /// Convert a Point from NAD83 to WebMercator
        /// </summary>
		public static Point Nad83ToWebMercator(this Point point)
		{
			return new Point(
				MercatorMath.LongitudeToMeters(point.X),
				MercatorMath.LatitudeToMeters(point.Y)
				);
		}

        /// <summary>
        /// Convert a Envelope from WebMercator to NAD83
        /// </summary>
		public static Envelope WebMercatorToNad83(this Envelope env)
		{
			if (env == null)
				return null;

			return new Envelope(
				MercatorMath.MetersToLongitude(env.XMin),
				MercatorMath.MetersToLatitude(env.YMin),
				MercatorMath.MetersToLongitude(env.XMax),
				MercatorMath.MetersToLatitude(env.YMax)
				);
		}

        /// <summary>
        /// Convert an Envelope from NAD83 to WebMercator
        /// </summary>
		public static Envelope Nad83ToWebMercator(this Envelope env)
		{
			if (env == null)
				return null;

			return new Envelope(
				MercatorMath.LongitudeToMeters(env.XMin),
				MercatorMath.LatitudeToMeters(env.YMin),
				MercatorMath.LongitudeToMeters(env.XMax),
				MercatorMath.LatitudeToMeters(env.YMax)
				);
		}

        /// <summary>
        /// Convert a string hex value (e.g. "#FF0ACD") to a Color structure
        /// </summary>
		public static Color HexColor(this string hex)
		{
			//remove the # at the front
			hex = hex.Replace("#", "");

			byte a = 255;
			byte r = 255;
			byte g = 255;
			byte b = 255;

			int start = 0;

			//handle ARGB strings (8 characters long)
			if (hex.Length == 8)
			{
				a = byte.Parse(hex.Substring(0, 2), NumberStyles.HexNumber);
				start = 2;
			}

			//convert RGB characters to bytes
			r = byte.Parse(hex.Substring(start, 2), NumberStyles.HexNumber);
			g = byte.Parse(hex.Substring(start + 2, 2), NumberStyles.HexNumber);
			b = byte.Parse(hex.Substring(start + 4, 2), NumberStyles.HexNumber);

			return Color.FromArgb(a, r, g, b);
		}

        /// <summary>
        /// Convert the type of one array to another, using a Converter function.
        /// </summary>
        /// <remarks>
        /// For example, an int array can be converted to a string array:
        /// int[] i = { 1, 2, 3 };
        /// string[] s = i.ConvertAll(new Converter<int, string>(e => e.ToString()));
        /// </remarks>
		public static TOutput[] ConvertAll<TInput, TOutput>(this TInput[] array, Converter<TInput, TOutput> converter)
		{
			if (array == null)
				throw new ArgumentNullException("array");

			if (converter == null)
				throw new ArgumentNullException("converter");

			TOutput[] localArray = new TOutput[array.Length];

			for (int i = 0; i < array.Length; i++)
				localArray[i] = converter(array[i]);

			return localArray;
		}

        /// <summary>
        /// Return true if all items in array are equal to all items in self
        /// </summary>
		public static bool AllItemsEqual<T>(this T[] self, T[] array)
		{
            // short-circuit tests
			if (self == null)
			{
				if (array == null)
					return true;
				return false;
			}

			if (array == null)
				return false;

			if (self.Length != array.Length)
				return false;

            // compare each item until an inequality is found
			for (int i = 0; i < self.Length; i++)
			{
				if (self[i] == null)
				{
					if (array[i] != null)
						return false;
				}
				else if (array[i] == null)
					return false;
				else if (!self[i].Equals(array[i]))
					return false;
			}

            // all items are equal
			return true;
		}

        /// <summary>
        /// Find a descendent in the VisualTree, using depth-first search for a descendant by name
        /// </summary>
		public static T Find<T>(this DependencyObject root, string name) where T : DependencyObject
		{
			DependencyObject child;

			for (int i = 0; i < VisualTreeHelper.GetChildrenCount(root); i++)
			{
				child = VisualTreeHelper.GetChild(root, i);

				if (name == child.GetValue(Control.NameProperty) as string)
					return child as T;
				else
				{
					child = Find<T>(child, name);
					if (child != null)
						return child as T;
				}
			}

			return null;
		}


	}
}
