﻿using System;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Media;

using ESRI.ArcGIS.Client.Symbols;

namespace GeoNavigator.Symbols
{
    public class ControlMarkerSymbol : MarkerSymbol
	{
		public static readonly DependencyProperty StrokeProperty = DependencyProperty.Register(
			"Stroke",
			typeof(Brush),
			typeof(ControlMarkerSymbol),
			new PropertyMetadata(new SolidColorBrush() { Color = Colors.Red }, new PropertyChangedCallback(OnStrokePropertyChanged))
			);

		private static void OnStrokePropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			((ControlMarkerSymbol)d).OnPropertyChanged("Stroke");
		}

		public static readonly DependencyProperty StrokeThicknessProperty = DependencyProperty.Register(
			"StrokeThickness",
			typeof(double),
			typeof(ControlMarkerSymbol),
			new PropertyMetadata(1d, new PropertyChangedCallback(OnStrokeThicknessPropertyChanged))
			);

		private static void OnStrokeThicknessPropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			((ControlMarkerSymbol)d).OnPropertyChanged("StrokeThickness");
		}

		public static readonly DependencyProperty FillProperty = DependencyProperty.Register(
			"Fill",
			typeof(Brush),
			typeof(ControlMarkerSymbol),
			new PropertyMetadata(new SolidColorBrush() { Color = Colors.Red }, new PropertyChangedCallback(OnFillPropertyChanged))
			);

		private static void OnFillPropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			((ControlMarkerSymbol)d).OnPropertyChanged("Fill");
		}
        
        public static readonly DependencyProperty SizeProperty = DependencyProperty.Register(
            "Size",
            typeof(double),
            typeof(ControlMarkerSymbol),
            new PropertyMetadata(10.0, new PropertyChangedCallback(OnSizePropertyChanged))
            );

        private static void OnSizePropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            ControlMarkerSymbol symbol = (ControlMarkerSymbol)d;
            symbol.OnPropertyChanged("Size");
			symbol.OnPropertyChanged("OffsetX");
			symbol.OnPropertyChanged("OffsetY");
        }

        public ControlMarkerSymbol()
			: this(typeof(ControlMarkerSymbol).Assembly.GetManifestResourceStream("GeoNavigator.Templates.ControlMarkerSymbol.xaml"))
		{
        }

		protected ControlMarkerSymbol(Stream controlTemplateResourceStream)
		{
			ControlTemplate = XamlReader.Load(new StreamReader(controlTemplateResourceStream).ReadToEnd()) as ControlTemplate;
		}

		public Brush Stroke
		{
			get { return (Brush)base.GetValue(StrokeProperty); }
			set { base.SetValue(StrokeProperty, value); }
		}

		public double StrokeThickness
		{
			get { return (double)base.GetValue(StrokeThicknessProperty); }
			set { base.SetValue(StrokeThicknessProperty, value); }
		}

		public Brush Fill
		{
			get { return (Brush)base.GetValue(FillProperty); }
			set { base.SetValue(FillProperty, value); }
		}

		public double Size
		{
			get { return (double)base.GetValue(SizeProperty); }
			set { base.SetValue(SizeProperty, value); }
		}

		public override double OffsetX
		{
			get { return (this.Size * .5d); }
			set { throw new NotSupportedException(); }
		}

		public override double OffsetY
		{
			get { return (this.Size * .5d); }
			set { throw new NotSupportedException(); }
		}
    }
}
