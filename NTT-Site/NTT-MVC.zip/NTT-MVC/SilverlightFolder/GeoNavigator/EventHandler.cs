﻿using System;

namespace GeoNavigator
{
    /// <summary>
    /// A generic version of EventHandler for both sender and event args
    /// </summary>
	public delegate void EventHandler<TSender, TEventArgs>(TSender sender, TEventArgs e) where TEventArgs : EventArgs;
}
