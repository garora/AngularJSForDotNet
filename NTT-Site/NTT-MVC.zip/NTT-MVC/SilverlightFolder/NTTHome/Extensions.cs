﻿//---------------------------------------------------
//Summary
//Extensions - Constants and other public functions.
//---------------------------------------------------
//ToDo: Fix failed external parameters
//Revision History
//Rev#  Date     Who   Change history
// 001  12/12/11 HAC   Initial C# version.
//---------------------------------------------------

using System;
using System.Globalization; //for NumberStyles
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace NTTHome
{
  public static class Extensions
  {
    //public const string NTTHomeRunParamsFile = "NTTHomeRunParams.xml";
    //public const string sPFTitle = "Project File";
    //public const string sTabPFFirst = "First create or open a Project File.";
    //public const string sTabPFProject = "Create, open or save a Project File (nttsl).";
    //public const string sTabPFAOI = "Select an Area of Interest (AOI).";
    //public const string sTabPFSoilsLocation = "Soils and Location Information.";
    //public const string sTabPFManagement = "Management operations for Baseline and Alternative.";
    //public const string sTabPFDefineRun = "Define parameters and run APEX.";
    //public const string sTabPFReports = "View and print Reports.";
    //public const string sNone = "(none)";

    //public const double nWestBC = -125.02083333;
    //public const double nEastBC = -66.47916757;
    //public const double nNorthBC = 49.9375;
    //public const double nSouthBC = 24.0625;
    //public const double nCellSize = 0.04166667;
    //public const int nNbrRows = 621;
    //public const int nNbrColumns = 1405;

    ////external parameters
    //public const string sAppEndPointServicesSoilsDefaultDev = "BasicHttpBinding_ISoilComponentService_Dev";
    //public const string sAppEndPointServicesNTTHomeDefaultDev = "Service1Soap_Dev";
    ////public const string sAppEndPointServicesNTTHomeDefaultARS = "Service1Soap_ARS";
    //public const string sAppNTTHomeHandlerDefaultDev = @"http://localhost:1866/NTTHomeImage.ashx";
    //public const string sAppNTTHomeHelpHostDefaultDev = "199.156.165.100";
    //public const string sAppNTTHomeWebPageHostDefaultDev = "199.156.165.100";
    //public const string sAppNTTHomeWebPageDefaultDev = "NTTHomeWebT/default.aspx";
    //public const int nYearStartDefault = 1960;
    //public const int nYearEndDefault = 2006;
    //public const string sAppAdminStringDefault = "i am an admin";

    //public static SolidColorBrush sbBGFill = new SolidColorBrush() { Color = "#FFD3D3D3".HexColor() };  //light gray
    //public static SolidColorBrush sbFGFillRed = new SolidColorBrush() { Color = "#FFFF0000".HexColor() };  //red
    //public static SolidColorBrush sbFGFillBlack = new SolidColorBrush() { Color = "#FF000000".HexColor() };  //black

    //public static SolidColorBrush iconNoneBFFill = new SolidColorBrush() { Color = "#FFFFFFE0".HexColor() };  //light yellow
    //public static SolidColorBrush iconPartialBFFill = new SolidColorBrush() { Color = "#FFFFB6C1".HexColor() };  //light pink
    //public static SolidColorBrush iconReadyBFFill = new SolidColorBrush() { Color = "#FF90EE90".HexColor() };  //light green

    /// <summary>
    /// Convert a string hex value (e.g. "#FF0ACD") to a Color structure
    /// </summary>
    public static Color HexColor(this string hex)
    {
      //remove the # at the front
      hex = hex.Replace("#", "");

      byte a = 255;
      byte r = 255;
      byte g = 255;
      byte b = 255;

      int start = 0;

      //handle ARGB strings (8 characters long)
      if (hex.Length == 8)
      {
        a = byte.Parse(hex.Substring(0, 2), NumberStyles.HexNumber);
        start = 2;
      }

      //convert RGB characters to bytes
      r = byte.Parse(hex.Substring(start, 2), NumberStyles.HexNumber);
      g = byte.Parse(hex.Substring(start + 2, 2), NumberStyles.HexNumber);
      b = byte.Parse(hex.Substring(start + 4, 2), NumberStyles.HexNumber);

      return Color.FromArgb(a, r, g, b);
    }

    //public static bool chkDouble(string sVal)
    //{
    //  double nDbl = 0;
    //  try
    //  {
    //    nDbl = Convert.ToDouble(sVal);
    //    return true;
    //  }
    //  catch (Exception ex)
    //  {
    //    return false;
    //  }
    //}

    //public static void TestDouble(string sValue, out bool isDouble, out double nDouble)
    //{
    //  try
    //  {
    //    isDouble = false; nDouble = 0;
    //    isDouble = double.TryParse(sValue, out nDouble);
    //  }
    //  catch (Exception ex)
    //  {
    //    //StackTrace sTrace = new StackTrace();
    //    //WriteToErrorFile(sMeName, sPathName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", ex);
    //    throw ex;
    //  }
    //}

    //public static void TestInteger(string sValue, out bool isInteger, out int nInteger)
    //{
    //  try
    //  {
    //    isInteger = false; nInteger = 0;
    //    isInteger = int.TryParse(sValue, out nInteger);
    //  }
    //  catch (Exception ex)
    //  {
    //    //StackTrace sTrace = new StackTrace();
    //    //WriteToErrorFile(sMeName, sPathName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", ex);
    //    throw ex;
    //  }
    //}

  }
}
