﻿//---------------------------------------------------
//Summary
//CWManSelect - B / A management selection.
//---------------------------------------------------
//Revision History
//Rev#  Date     Who   Change history
// 003  03/26/13 HAC   Fix window title.
// 002  04/23/12 HAC   On selected OK, be sure to return operations details.
// 001  04/19/12 HAC   Initial version.
//---------------------------------------------------

using System;
using System.Collections.Generic;
using System.Diagnostics; //for StackTrace
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data; //needed for PagedCollectionView
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using NTTHome.NTTManagementsService;
using NTTHome.ProcessComn;

namespace NTTHome
{
  public partial class CWManSelect : ChildWindow
  {
    public ViewManOpsData vuManSelected = new ViewManOpsData();
    
    private List<MappedPath> mpPaths = new List<MappedPath>();

    ViewManSelection TaskDs;
    private bool IsAssignedFiltered = false;
    private string sFilterYears = ProcessCommon.sYearsAll;
    private string sFilterCropNbrs = ProcessCommon.sCropsAll;

    ManagementsClient mapClient = null;

    public CWManSelect()
    {
      InitializeComponent();
    }

    private void Page_Loaded(object sender, RoutedEventArgs e)
    {
      try
      {
        this.Title = (ProcessCommon.bIsBaseline == true ? "Baseline Mangement" : "Alternative Mangement");

        mapClient = new ManagementsClient(ProcessCommon.sAppEndPointServicesManagements);

        //row details data on demand
        this.dgSelManagements.LoadingRowDetails +=
          new EventHandler<DataGridRowDetailsEventArgs>(
            delegate(object sender2, DataGridRowDetailsEventArgs e2)
            {
              try
              {
                ViewManOpsData vMan = e2.Row.DataContext as ViewManOpsData;
                if (vMan.movManOps == null)
                {
                  mapClient.GetOperationsDetailsInManagementCompleted +=
              new EventHandler<GetOperationsDetailsInManagementCompletedEventArgs>(
                delegate(object s1, GetOperationsDetailsInManagementCompletedEventArgs e1)
                {
                  try
                  {

                    if (e1.Error == null)
                    { vMan.movManOps = e1.Result; }
                    //Note on the line above:
                    // error: cannot convert type observablecollection to generic.list
                    //r-click NTTManagementsServiceReference and select Configure Service Reference
                    //change the Collection type from observablecollection to generic.list
                  }
                  catch (Exception Ex)
                  {
                    StackTrace sTrace = new StackTrace();
                    //ProcessCommon.doErrorLog(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", Ex);
                    MessageBox.Show("Exception failure: " + Ex.Message.ToString(), sTrace.GetFrame(0).GetMethod().Name, MessageBoxButton.OK);
                  }
                });

                  mapClient.GetOperationsDetailsInManagementAsync(Convert.ToInt32(vMan.movManId));
                }
              }
              catch (Exception Ex)
              {
                StackTrace sTrace = new StackTrace();
                //ProcessCommon.doErrorLog(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", Ex);
                MessageBox.Show("Exception failure: " + Ex.Message.ToString(), sTrace.GetFrame(0).GetMethod().Name, MessageBoxButton.OK);
              }
            });

        this.dgSelManagements.ItemsSource = "";
        this.mpPaths.Clear();

        //get mappings for LMOD paths on the server
        mapClient.GetMappedPathDataCompleted +=
          new EventHandler<GetMappedPathDataCompletedEventArgs>((sender3, args) =>
          {
            try
            {
            if (args.Result != null)
            {
              TaskDs = new ViewManSelection();

              foreach (MappedPath mPa in args.Result)
              {
                mpPaths.Add(mPa);
              }

              mapClient.GetSelectManagementDataCompleted +=
                new EventHandler<GetSelectManagementDataCompletedEventArgs>((sender1, args1) =>
                {
                try
                {
                  if (args1.Result != null)
                  {

                    foreach (SelectManagement smM in args1.Result)
                    {
                      ViewManOpsData vMO = new ViewManOpsData();
                      vMO.movManCmzId = smM.SManCmzId;
                      vMO.movManDuration = smM.SManDuration;
                      vMO.movManId = smM.SManId;
                      vMO.movManName = smM.SManName;
                      vMO.movManPathId = smM.SManPathId;
                      vMO.movManYears = smM.SManYears;
                      vMO.movManCropsNbr = smM.SManCropsNbr;
                      vMO.movManCropsNames = smM.SManCropsNames;
                      vMO.movManCropsDesc = smM.SManCropsDesc;
                      vMO.movManOps = null;
                      //this.moManagements.Add(vMO);
                      //this.vuManSelection.Add(vMO);
                      TaskDs.Add(vMO);
                    }

                    this.tblkCountManagements.Text = string.Format("( Count: {0} )", TaskDs.Count().ToString());
                    this.dgSelManagements.ItemsSource = TaskDs;
                  }
                }
                catch (Exception Ex)
                {
                  StackTrace sTrace = new StackTrace();
                  //ProcessCommon.doErrorLog(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", Ex);
                  MessageBox.Show("Exception failure: " + Ex.Message.ToString(), sTrace.GetFrame(0).GetMethod().Name, MessageBoxButton.OK);
                }
                });
              mapClient.GetSelectManagementDataAsync(ProcessCommon.nSelectedCMZ);
            }
            }
            catch (Exception Ex)
            {
              StackTrace sTrace = new StackTrace();
              //ProcessCommon.doErrorLog(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", Ex);
              MessageBox.Show("Exception failure: " + Ex.Message.ToString(), sTrace.GetFrame(0).GetMethod().Name, MessageBoxButton.OK);
            }
          });
        mapClient.GetMappedPathDataAsync(ProcessCommon.nSelectedCMZ);

      }
      catch (Exception Ex)
      {
        StackTrace sTrace = new StackTrace();
        MessageBox.Show("Exception failure: " + Ex.Message.ToString(), sTrace.GetFrame(0).GetMethod().Name, MessageBoxButton.OK);
      }
    }

    private void btnCancel_Click(object sender, RoutedEventArgs e)
    {
      try
      {
        this.DialogResult = false;
      }
      catch (Exception Ex)
      {
        StackTrace sTrace = new StackTrace();
        MessageBox.Show("Exception failure: " + Ex.Message.ToString(), sTrace.GetFrame(0).GetMethod().Name, MessageBoxButton.OK);
      }
    }

    private void btnOK_Click(object sender, RoutedEventArgs e)
    {
      try
      {
        if (this.vuManSelected.movManOps != null) this.DialogResult = true;

        //load details before returning
        mapClient = new ManagementsClient(ProcessCommon.sAppEndPointServicesManagements);
        mapClient.GetOperationsDetailsInManagementCompleted +=
    new EventHandler<GetOperationsDetailsInManagementCompletedEventArgs>(
      delegate(object s1, GetOperationsDetailsInManagementCompletedEventArgs e1)
      {
        try
        {
        if (e1.Error == null)
        { this.vuManSelected.movManOps = e1.Result; }
        //Note on the line above:
        // error: cannot convert type observablecollection to generic.list
        //r-click NTTManagementsServiceReference and select Configure Service Reference
        //change the Collection type from observablecollection to generic.list

        this.DialogResult = true;
        }
        catch (Exception Ex)
        {
          StackTrace sTrace = new StackTrace();
          //ProcessCommon.doErrorLog(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", Ex);
          MessageBox.Show("Exception failure: " + Ex.Message.ToString(), sTrace.GetFrame(0).GetMethod().Name, MessageBoxButton.OK);
        }
      });
        mapClient.GetOperationsDetailsInManagementAsync(Convert.ToInt32(this.vuManSelected.movManId));
      }
      catch (Exception Ex)
      {
        StackTrace sTrace = new StackTrace();
        MessageBox.Show("Exception failure: " + Ex.Message.ToString(), sTrace.GetFrame(0).GetMethod().Name, MessageBoxButton.OK);
      }
    }

    private void cbxCropNbrs_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      try
      {
        string filter = ((sender as ComboBox).SelectedValue) as string;
        this.sFilterCropNbrs = filter;

        doShowFiltered();
      }
      catch (Exception Ex)
      {
        StackTrace sTrace = new StackTrace();
        MessageBox.Show("Exception failure: " + Ex.Message.ToString(), sTrace.GetFrame(0).GetMethod().Name, MessageBoxButton.OK);
      }
    }

    private void cbxYears_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      try
      {
        string filter = ((sender as ComboBox).SelectedValue) as string;
        this.sFilterYears = filter;

        doShowFiltered();
      }
      catch (Exception Ex)
      {
        StackTrace sTrace = new StackTrace();
        MessageBox.Show("Exception failure: " + Ex.Message.ToString(), sTrace.GetFrame(0).GetMethod().Name, MessageBoxButton.OK);
      }
    }

    private void btnShowDetails_Click(object sender, RoutedEventArgs e)
    {
      try
      {
        DataGridRow row = DataGridRow.GetRowContainingElement(sender as Button);
        row.DetailsVisibility =
          (row.DetailsVisibility == Visibility.Collapsed ?
          Visibility.Visible : Visibility.Collapsed);
      }
      catch (Exception Ex)
      {
        StackTrace sTrace = new StackTrace();
        MessageBox.Show("Exception failure: " + Ex.Message.ToString(), sTrace.GetFrame(0).GetMethod().Name, MessageBoxButton.OK);
      }
    }

    //ToDo: this is not working yet
    private void cbxUseFilters_Click(object sender, RoutedEventArgs e)
    {
      try
      {
        DataGridColumn dcCropNbrs = this.dgSelManagements.Columns[2];
        DataGridColumn dcYears = this.dgSelManagements.Columns[1];
        bool? Selected = this.cbxUseFilters.IsChecked;
        if (Selected == true)
        {
          Style colStyle = this.Resources["dgCropNbrsHeaderStyle"] as Style;
          dcCropNbrs.HeaderStyle = colStyle;
          Style colStyle1 = this.Resources["dgYearsHeaderStyle"] as Style;
          dcYears.HeaderStyle = colStyle1;

          IsAssignedFiltered = true;
          this.sFilterYears = ProcessCommon.sYearsAll;
          this.sFilterCropNbrs = ProcessCommon.sCropsAll;
        }
        else
        {
          dcCropNbrs.HeaderStyle = null;
          dcYears.HeaderStyle = null;
          dgSelManagements.ItemsSource = TaskDs;
          IsAssignedFiltered = false;
        }
      }
      catch (Exception Ex)
      {
        StackTrace sTrace = new StackTrace();
        MessageBox.Show("Exception failure: " + Ex.Message.ToString(), sTrace.GetFrame(0).GetMethod().Name, MessageBoxButton.OK);
      }
    }

    private void doShowFiltered()
    {
      try
      {

        if (this.sFilterCropNbrs == ProcessCommon.sCropsAll && this.sFilterYears == ProcessCommon.sYearsAll)
        {
          this.dgSelManagements.ItemsSource = TaskDs; return;
        }

        if (this.sFilterCropNbrs == ProcessCommon.sCropsAll)
        {
          string sFiltr = this.sFilterYears.Replace(ProcessCommon.sYearsPart, "");
          var Res = from task in TaskDs
                    where task.movManYears == Convert.ToInt32(sFiltr)
                    select task;
          this.dgSelManagements.ItemsSource = Res; return;
        }

        if (this.sFilterYears == ProcessCommon.sYearsAll)
        {
          string sFiltr = this.sFilterCropNbrs.Replace(ProcessCommon.sCropsPart, "");
          var Res = from task in TaskDs
                    where task.movManCropsNbr == Convert.ToInt32(sFiltr)
                    select task;
          this.dgSelManagements.ItemsSource = Res; return;
        }

        string sFiltrY = this.sFilterYears.Replace(ProcessCommon.sYearsPart, "");
        string sFiltrC = this.sFilterCropNbrs.Replace(ProcessCommon.sCropsPart, "");

        var ResBoth = from task in TaskDs
                      where task.movManCropsNbr == Convert.ToInt32(sFiltrC) &&
                        task.movManYears == Convert.ToInt32(sFiltrY)
                      select task;
        this.dgSelManagements.ItemsSource = ResBoth;

      }
      catch (Exception Ex)
      {
        StackTrace sTrace = new StackTrace();
        MessageBox.Show("Exception failure: " + Ex.Message.ToString(), sTrace.GetFrame(0).GetMethod().Name, MessageBoxButton.OK);
      }
    }

    private void dgSelManagements_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      try
      {
        if (this.dgSelManagements.SelectedItem != null)
        {
          this.vuManSelected = (ViewManOpsData)this.dgSelManagements.SelectedItem;
          this.tblkManSelected.Text = this.vuManSelected.movManCropsNames;
        }
      }
      catch (Exception Ex)
      {
        StackTrace sTrace = new StackTrace();
        MessageBox.Show("Exception failure: " + Ex.Message.ToString(), sTrace.GetFrame(0).GetMethod().Name, MessageBoxButton.OK);
      }
    }
  }
}

