//---------------------------------------------------
//Summary
//ManEdit - Management operations edit.
//---------------------------------------------------
//Revision History
//Rev#  Date     Who   Change history
// 001  03/19/13 HAC   Initial version.
//---------------------------------------------------

using System;
using System.Collections.Generic;
using System.Diagnostics; //for StackTrace
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using NTTHome.NTTManagementsService;
using NTTHome.ProcessComn;

namespace NTTHome
{
  public partial class ManEdit : UserControl
  {
    public event EventHandler EditCanceled;
    public event EventHandler EditDeleted;
    public event EventHandler EditSaved;
    public event EventHandler EditAddSaved;

    public ManEdit()
    {
      InitializeComponent();
    }

    #region edit form events
    private void btnManSave_Click(object sender, RoutedEventArgs e)
    {
      try
      {
        if (ProcessCommon.selectedMSData != null)
        {
          foreach (ManagementEditData mDta in ProcessCommon.lstMSDataEdit)
          {
            if (mDta.medDId == ProcessCommon.selectedMSData.medDId)
            {
              mDta.medDAmt = this.tbxMgtAmount.Text;
              mDta.medDDepth = this.tbxMgtAddDepth.Text;
            }
          }
        }

        if (EditSaved != null) EditSaved(this, null);
      }
      catch (Exception Ex)
      {
        StackTrace sTrace = new StackTrace();
        //ProcessCommon.doErrorLog(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", Ex);
        MessageBox.Show("Exception failure: " + Ex.Message.ToString(), sTrace.GetFrame(0).GetMethod().Name, MessageBoxButton.OK);
      }
    }

    private void btnManCancel_Click(object sender, RoutedEventArgs e)
    {
      try
      {
        this.btnManDelete.IsEnabled = true;
        this.tbxMgtType.IsReadOnly = false;
        this.tbxMgtAmount.IsReadOnly = false;
        this.tbxMgtDepth.IsReadOnly = false;

        if (EditCanceled != null) EditCanceled(this, null);
      }
      catch (Exception Ex)
      {
        StackTrace sTrace = new StackTrace();
        //ProcessCommon.doErrorLog(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", Ex);
        MessageBox.Show("Exception failure: " + Ex.Message.ToString(), sTrace.GetFrame(0).GetMethod().Name, MessageBoxButton.OK);
      }
    }

    private void btnManDelete_Click(object sender, RoutedEventArgs e)
    {
      try
      {
        if (EditDeleted != null) EditDeleted(this, null);
      }
      catch (Exception Ex)
      {
        StackTrace sTrace = new StackTrace();
        //ProcessCommon.doErrorLog(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", Ex);
        MessageBox.Show("Exception failure: " + Ex.Message.ToString(), sTrace.GetFrame(0).GetMethod().Name, MessageBoxButton.OK);
      }
    }

    private void tbxMgtEvent_TextChanged(object sender, TextChangedEventArgs e)
    {
      string sEvent = "";
      try
      {
        TextBox tb = (TextBox)sender;
        //happens after binding a selection
        //determine what is being edited and adjust readonly or editable form fields

        this.tbxMgtType.IsReadOnly = true;
        this.tbxMgtAmount.IsReadOnly = true;
        this.tbxMgtDepth.IsReadOnly = true;
        this.btnManDelete.IsEnabled = false;

        if (ProcessCommon.selectedMSData != null)
        {
          sEvent = ProcessCommon.selectedMSData.medDOperCodeDesc.ToLower();
          if (sEvent.StartsWith("plant"))
          {
            this.tbxMgtAmount.IsReadOnly = false;
          }
          else if (sEvent.StartsWith("fert"))
          {
            this.btnManDelete.IsEnabled = true;
            this.tbxMgtType.IsReadOnly = false;
            this.tbxMgtAmount.IsReadOnly = false;
            this.tbxMgtDepth.IsReadOnly = false;
            //need to populate the Type dropdown here
          }
          else if (sEvent.StartsWith("till"))
          {
            this.btnManDelete.IsEnabled = true;
          }
        }
      }
      catch (Exception Ex)
      {
        StackTrace sTrace = new StackTrace();
        //ProcessCommon.doErrorLog(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", Ex);
        MessageBox.Show("Exception failure: " + Ex.Message.ToString(), sTrace.GetFrame(0).GetMethod().Name, MessageBoxButton.OK);
      }
    }

    private void dtpMgtdate_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
    {
      //if (ProcessCommon.selected1stLoading != true) this.btnManSave.IsEnabled = true;
      this.btnManSave.IsEnabled = true;
    }

    private void tbxMgtAmount_TextChanged(object sender, TextChangedEventArgs e)
    {
      try
      {
        //if (ProcessCommon.selected1stLoading != true) this.btnManSave.IsEnabled = true;
        this.btnManSave.IsEnabled = true;
      }
      catch (Exception Ex)
      {
        StackTrace sTrace = new StackTrace();
        //ProcessCommon.doErrorLog(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", Ex);
        MessageBox.Show("Exception failure: " + Ex.Message.ToString(), sTrace.GetFrame(0).GetMethod().Name, MessageBoxButton.OK);
      }
    }

    private void tbxMgtDepth_TextChanged(object sender, TextChangedEventArgs e)
    {
      try
      {
        //if (ProcessCommon.selected1stLoading != true) this.btnManSave.IsEnabled = true;
        this.btnManSave.IsEnabled = true;
      }
      catch (Exception Ex)
      {
        StackTrace sTrace = new StackTrace();
        //ProcessCommon.doErrorLog(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", Ex);
        MessageBox.Show("Exception failure: " + Ex.Message.ToString(), sTrace.GetFrame(0).GetMethod().Name, MessageBoxButton.OK);
      }
    }
    #endregion

    #region edit add events
    private void btnManAdd_Click(object sender, RoutedEventArgs e)
    {
      try
      {
        this.bdrMgtEditForm.Visibility = System.Windows.Visibility.Collapsed;
        this.bdrMgtEditAdd.Visibility = System.Windows.Visibility.Visible;
      }
      catch (Exception Ex)
      {
        StackTrace sTrace = new StackTrace();
        //ProcessCommon.doErrorLog(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", Ex);
        MessageBox.Show("Exception failure: " + Ex.Message.ToString(), sTrace.GetFrame(0).GetMethod().Name, MessageBoxButton.OK);
      }
    }

    private void btnManAddCancel_Click(object sender, RoutedEventArgs e)
    {
      try
      {
        if (EditCanceled != null) EditCanceled(this, null);
      }
      catch (Exception Ex)
      {
        StackTrace sTrace = new StackTrace();
        //ProcessCommon.doErrorLog(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", Ex);
        MessageBox.Show("Exception failure: " + Ex.Message.ToString(), sTrace.GetFrame(0).GetMethod().Name, MessageBoxButton.OK);
      }
    }

    private void btnManAddSave_Click(object sender, RoutedEventArgs e)
    {
      try
      {
        if (this.cbxMgtAddEvent.SelectedItem == null) return;

        APEXOperationCode aocdSelected = (APEXOperationCode)this.cbxMgtAddEvent.SelectedItem;

        ManagementEditData newMSData = new ManagementEditData();
        newMSData.medDId = "999";
        newMSData.medDOperCode = aocdSelected.AOCCode;
        newMSData.medDOperCodeDesc = aocdSelected.AOCNameAbbrev;
        newMSData.medDDate = Convert.ToDateTime(this.dtpMgtAddDate.Text);
        newMSData.medDOper = "New";
        ProcessCommon.addedMSData = newMSData;

        if (EditAddSaved != null) EditAddSaved(this, null);
      }
      catch (Exception Ex)
      {
        StackTrace sTrace = new StackTrace();
        //ProcessCommon.doErrorLog(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", Ex);
        MessageBox.Show("Exception failure: " + Ex.Message.ToString(), sTrace.GetFrame(0).GetMethod().Name, MessageBoxButton.OK);
      }
    }

    private void cbxMgtAddEvent_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      try
      {

      }
      catch (Exception Ex)
      {
        StackTrace sTrace = new StackTrace();
        //ProcessCommon.doErrorLog(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", Ex);
        MessageBox.Show("Exception failure: " + Ex.Message.ToString(), sTrace.GetFrame(0).GetMethod().Name, MessageBoxButton.OK);
      }
    }

    private void cbxMgtAddOperation_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      try
      {

      }
      catch (Exception Ex)
      {
        StackTrace sTrace = new StackTrace();
        //ProcessCommon.doErrorLog(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", Ex);
        MessageBox.Show("Exception failure: " + Ex.Message.ToString(), sTrace.GetFrame(0).GetMethod().Name, MessageBoxButton.OK);
      }
    }

    private void cbxMgtAddType_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      try
      {

      }
      catch (Exception Ex)
      {
        StackTrace sTrace = new StackTrace();
        //ProcessCommon.doErrorLog(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", Ex);
        MessageBox.Show("Exception failure: " + Ex.Message.ToString(), sTrace.GetFrame(0).GetMethod().Name, MessageBoxButton.OK);
      }
    }
    #endregion
  }
}
