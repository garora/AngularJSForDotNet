﻿//---------------------------------------------------
//Summary
//ManMaintenance - Baseline / A view and edit.
//---------------------------------------------------
//Revision History
//Rev#  Date     Who   Change history
// 001  04/19/12 HAC   Initial version.
//---------------------------------------------------

using System;
using System.Collections.Generic;
using System.Diagnostics; //for StackTrace
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using NTTHome.NTTManagementsService;
using NTTHome.ProcessComn;

namespace NTTHome
{
  public partial class ManMaintenance : UserControl
  {
    private ManEdit mEdit = new ManEdit();

    public ManMaintenance()
    {
      InitializeComponent();
    }

    private void Page_Loaded(object sender, RoutedEventArgs e)
    {
      try
      {
        if (ProcessCommon.bIsBaseline == true)
        { this.tblkMANInfo.Text = "Baseline Management"; }
        else
        { this.tblkMANInfo.Text = "Alternative Management"; }

        mEdit.EditCanceled += (s, ev) =>
        {
          //this causes the binding to fail on 1st Cancel click
          //this.ManagementGrid.ItemsSource = "";
          //ProcessCommon.lstMSDataEdit = ProcessCommon.lstMSDataEditPrevious;
          //this.ManagementGrid.ItemsSource = ProcessCommon.lstMSDataEdit;

          //still causes the binding to fail on 1st Cancel click
          this.EditManagementPanel.DataContext = "";
          ProcessCommon.lstMSDataEdit = ProcessCommon.Clone(ProcessCommon.lstMSDataEditPrevious); //must use deep clone
          this.ManagementGrid.ItemsSource = "";
          this.ManagementGrid.ItemsSource = ProcessCommon.lstMSDataEdit;

          ResetEditing();
        };
        mEdit.EditDeleted += (s, ev) =>
        {
          try
          {
            foreach (ManagementEditData msData in ProcessCommon.lstMSDataEditPrevious)
            {
              if (msData.medDId == ProcessCommon.selectedMSData.medDId)
              {
                ProcessCommon.lstMSDataEditPrevious.Remove(msData); break;
              }
            }
            
            this.ManagementGrid.ItemsSource = "";
            ProcessCommon.lstMSDataEdit = ProcessCommon.Clone(ProcessCommon.lstMSDataEditPrevious); //must use deep clone
            this.ManagementGrid.ItemsSource = ProcessCommon.lstMSDataEdit;

            ResetEditing();
          }
          catch (Exception Ex)
          {
            StackTrace sTrace = new StackTrace();
            MessageBox.Show("Exception failure: " + Ex.Message.ToString(), sTrace.GetFrame(0).GetMethod().Name, MessageBoxButton.OK);
          }
        };
        mEdit.EditSaved += (s, ev) =>
        {
          try
          {
            //observable binding is not updating the grid automatically??
            //ManagementEditData - INotifyPropertyChanged seems to be working
            if (ProcessCommon.bIsBaseline == true)
            {
              ProcessCommon.lstMSDataBase = ProcessCommon.Clone(ProcessCommon.lstMSDataEdit); //must use deep clone
            }
            else
            {
              ProcessCommon.lstMSDataAlt = ProcessCommon.Clone(ProcessCommon.lstMSDataEdit); //must use deep clone
            }

            this.ManagementGrid.ItemsSource = "";
            this.ManagementGrid.ItemsSource = ProcessCommon.lstMSDataEdit;
            ResetEditing();
          }
          catch (Exception Ex)
          {
            StackTrace sTrace = new StackTrace();
            MessageBox.Show("Exception failure: " + Ex.Message.ToString(), sTrace.GetFrame(0).GetMethod().Name, MessageBoxButton.OK);
          }
        };
        mEdit.EditAddSaved += (s, ev) =>
        {
          try
          {
            //ProcessCommon.lstMSDataEdit.Add(ProcessCommon.addedMSData);
            int nLocation = 0;
            bool bAddFound = false;
            foreach (ManagementEditData msData in ProcessCommon.lstMSDataEdit)
            {
              if (ProcessCommon.addedMSData.medDDate <= msData.medDDate)
              {
                ProcessCommon.lstMSDataEdit.Insert(nLocation, ProcessCommon.addedMSData);
                bAddFound = true; break;
              }
              nLocation += 1;
            }
            if (bAddFound == false) ProcessCommon.lstMSDataEdit.Add(ProcessCommon.addedMSData);

            ResetEditing();
          }
          catch (Exception Ex)
          {
            StackTrace sTrace = new StackTrace();
            MessageBox.Show("Exception failure: " + Ex.Message.ToString(), sTrace.GetFrame(0).GetMethod().Name, MessageBoxButton.OK);
          }
        };
        this.EditManagementPanel.Children.Add(mEdit);

        this.EditManagementPanel.DataContext = ProcessCommon.emptyMSData;

        this.mEdit.cbxMgtAddEvent.DisplayMemberPath = "AOCNameAbbrev";
        this.mEdit.cbxMgtAddEvent.ItemsSource = ProcessCommon.lstAOCodesData;
        this.mEdit.cbxMgtAddEvent.SelectedIndex = 0;

        ProcessCommon.lstSelectOperations = new List<MappedOperation>();
        MappedOperation mONone = new MappedOperation { AOpId = "0", LOpId = "0", LOpName = "", AOpCode = "", AOpCodeDesc = "", AOpEqp = "", AOpName = ProcessCommon.sNone };
        ProcessCommon.lstSelectOperations.Add(mONone);

        this.mEdit.cbxMgtAddOperation.DisplayMemberPath = "AOpName";
        this.mEdit.cbxMgtAddOperation.ItemsSource = ProcessCommon.lstSelectOperations;
        this.mEdit.cbxMgtAddOperation.SelectedIndex = 0;

        //for now, show none but Fertilize is all we will allow for selection - fix this
        this.mEdit.cbxMgtAddType.DisplayMemberPath = "AOpName";
        this.mEdit.cbxMgtAddType.ItemsSource = ProcessCommon.lstSelectOperations;
        this.mEdit.cbxMgtAddType.SelectedIndex = 0;

        ResetEditing();
        ShowSelected();

      }
      catch (Exception Ex)
      {
        StackTrace sTrace = new StackTrace();
        MessageBox.Show("Exception failure: " + Ex.Message.ToString(), sTrace.GetFrame(0).GetMethod().Name, MessageBoxButton.OK);
      }
    }

    #region Events
    private void btnManSelect_Click(object sender, RoutedEventArgs e)
    {
      try
      {
        if (ProcessCommon.nSelectedCMZ > 0)
        {
          CWManSelect cwMan = new CWManSelect();
          cwMan.Closed += new EventHandler(cwMan_Closed);
          //cwMan.Title = "Path: " + lmVSelected.lmvPaName;
          cwMan.Show();
        }
      }
      catch (Exception Ex)
      {
        StackTrace sTrace = new StackTrace();
        MessageBox.Show("Exception failure: " + Ex.Message.ToString(), sTrace.GetFrame(0).GetMethod().Name, MessageBoxButton.OK);
      }
    }

    private void cwMan_Closed(object sender, EventArgs e)
    {
      try
      {
        CWManSelect cw = (CWManSelect)sender;

        if (cw.DialogResult == true)
        {
          //save selected management
          if (ProcessCommon.bIsBaseline == true)
          { 
            ProcessCommon.vuManSelectedBase = cw.vuManSelected;

            //build binding data for editing
            //assign unique id for now - should be coming from source data
            ProcessCommon.lstMSDataBase.Clear();
            int nCnt = 0;
            foreach (LMODManagementOperationDetail mDd in ProcessCommon.vuManSelectedBase.movManOps)
            {
              ManagementEditData mEData = new ManagementEditData();
              nCnt += 1;
              mEData.medDId = nCnt.ToString();
              mEData.medDCropId = mDd.LManOpCropId;
              mEData.medDDate = Convert.ToDateTime(mDd.LManOpDate);
              mEData.medDOpId = mDd.LManOpId;
              mEData.medDManId = mDd.LManOpManId;
              mEData.medDOper = mDd.LManOpOper;
              mEData.medDOperId = mDd.LManOpOperId;
              string sOperId = string.Format("{0, 3:000}", mDd.LManOpOperId);

              var mapOp = (from mO in ProcessCommon.lstMpOperations
                           where mO.LOpId == sOperId
                           select mO).Take(1).SingleOrDefault();
              if (mapOp != null)
              {
                mEData.medDOperCodeDesc = mapOp.AOpCodeDesc;
                mEData.medDOperCode = mapOp.LOpId;
                if (mEData.medDOperCodeDesc.ToLower().StartsWith("plant")) mEData.medDCrop = mDd.LManOpCrop;
              }
              ProcessCommon.lstMSDataBase.Add(mEData);
            }
          }
          else
          { 
            ProcessCommon.vuManSelectedAlt = cw.vuManSelected;

            //build binding data for editing
            //assign unique id for now - should be coming from source data
            ProcessCommon.lstMSDataAlt.Clear();
            int nCnt = 0;
            foreach (LMODManagementOperationDetail mDd in ProcessCommon.vuManSelectedAlt.movManOps)
            {
              ManagementEditData mEData = new ManagementEditData();
              nCnt += 1;
              mEData.medDId = nCnt.ToString();
              mEData.medDCropId = mDd.LManOpCropId;
              mEData.medDDate = Convert.ToDateTime(mDd.LManOpDate);
              mEData.medDOpId = mDd.LManOpId;
              mEData.medDManId = mDd.LManOpManId;
              mEData.medDOper = mDd.LManOpOper;
              mEData.medDOperId = mDd.LManOpOperId;
              string sOperId = string.Format("{0, 3:000}", mDd.LManOpOperId);

              var mapOp = (from mO in ProcessCommon.lstMpOperations
                           where mO.LOpId == sOperId
                           select mO).Take(1).SingleOrDefault();
              if (mapOp != null)
              {
                mEData.medDOperCodeDesc = mapOp.AOpCodeDesc;
                mEData.medDOperCode = mapOp.LOpId;
                if (mEData.medDOperCodeDesc.ToLower().StartsWith("plant")) mEData.medDCrop = mDd.LManOpCrop;
              }
              ProcessCommon.lstMSDataAlt.Add(mEData);
            }
          }

          ShowSelected();
        }
      }
      catch (Exception Ex)
      {
        StackTrace sTrace = new StackTrace();
        MessageBox.Show("Exception failure: " + Ex.Message.ToString(), sTrace.GetFrame(0).GetMethod().Name, MessageBoxButton.OK);
      }
    }

    private void ShowSelected()
    {
      ViewManOpsData vuMan = null;
      try
      {
        //use common data source for editing
        if (ProcessCommon.bIsBaseline == true)
        { 
          vuMan = ProcessCommon.vuManSelectedBase;
          ProcessCommon.lstMSDataEdit = ProcessCommon.Clone(ProcessCommon.lstMSDataBase); //must use deep clone
        }
        else
        { 
          vuMan = ProcessCommon.vuManSelectedAlt;
          ProcessCommon.lstMSDataEdit = ProcessCommon.Clone(ProcessCommon.lstMSDataAlt); //must use deep clone
        }

        this.grdMANInfo.DataContext = vuMan;
        this.ManagementGrid.ItemsSource = "";
        this.ManagementGrid.ItemsSource = ProcessCommon.lstMSDataEdit;
      }
      catch (Exception Ex)
      {
        StackTrace sTrace = new StackTrace();
        MessageBox.Show("Exception failure: " + Ex.Message.ToString(), sTrace.GetFrame(0).GetMethod().Name, MessageBoxButton.OK);
      }
    }

    #endregion

    private void ResetEditing()
    {
      try
      {
        this.mEdit.btnManAdd.Visibility = System.Windows.Visibility.Visible;
        this.mEdit.btnManDelete.Visibility = System.Windows.Visibility.Collapsed;
        this.mEdit.btnManSave.Visibility = System.Windows.Visibility.Collapsed;
        this.mEdit.btnManCancel.Visibility = System.Windows.Visibility.Collapsed;

        this.mEdit.bdrMgtEditAdd.Visibility = System.Windows.Visibility.Collapsed;
        this.mEdit.bdrMgtEditForm.Visibility = System.Windows.Visibility.Visible;

        this.EditManagementPanel.DataContext = ProcessCommon.emptyMSData;
      }
      catch (Exception Ex)
      {
        StackTrace sTrace = new StackTrace();
        //ProcessCommon.doErrorLog(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", Ex);
        MessageBox.Show("Exception failure: " + Ex.Message.ToString(), sTrace.GetFrame(0).GetMethod().Name, MessageBoxButton.OK);
      }
    }

    private void AllowEditing()
    {
      try
      {
        this.mEdit.btnManAdd.Visibility = System.Windows.Visibility.Collapsed;
        this.mEdit.btnManDelete.Visibility = System.Windows.Visibility.Visible;
        this.mEdit.btnManSave.Visibility = System.Windows.Visibility.Visible;
        this.mEdit.btnManCancel.Visibility = System.Windows.Visibility.Visible;
        this.mEdit.btnManSave.IsEnabled = false;
        this.mEdit.btnManCancel.IsEnabled = true;
        this.mEdit.btnManDelete.IsEnabled = true;
        this.EditManagementPanel.DataContext = (ManagementEditData)this.ManagementGrid.SelectedItem;
      }
      catch (Exception Ex)
      {
        StackTrace sTrace = new StackTrace();
        //ProcessCommon.doErrorLog(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", Ex);
        MessageBox.Show("Exception failure: " + Ex.Message.ToString(), sTrace.GetFrame(0).GetMethod().Name, MessageBoxButton.OK);
      }
    }

    private void ManagementGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      try
      {
        //save the original data
        ProcessCommon.lstMSDataEditPrevious = ProcessCommon.Clone(ProcessCommon.lstMSDataEdit); //must use deep clone
        ProcessCommon.selectedMSData = (ManagementEditData)this.ManagementGrid.SelectedItem;

        AllowEditing();
      }
      catch (Exception Ex)
      {
        StackTrace sTrace = new StackTrace();
        //ProcessCommon.doErrorLog(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", Ex);
        MessageBox.Show("Exception failure: " + Ex.Message.ToString(), sTrace.GetFrame(0).GetMethod().Name, MessageBoxButton.OK);
      }
    }
  }
}
