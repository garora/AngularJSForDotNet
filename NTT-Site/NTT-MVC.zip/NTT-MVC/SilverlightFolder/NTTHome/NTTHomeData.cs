//---------------------------------------------------
//Summary
//NTTHome - Data.
//---------------------------------------------------
//Revision History
//Rev#  Date     Who   Change history
// 006  03/18/13 HAC   Add ManagementSampleData; remove OpEvent.
// 005  01/31/12 HAC   Save bounding box coordinates returned values.
// 004  01/17/12 HAC   New param nhRPEndPointServicesSoils.
// 003  01/10/12 HAC   Remove 'Home' navigation menu item on web page;
//                      fix xaml to allow GN to pan (no root scrollviewer).
// 002  12/27/11 HAC   New ProjectFileData.
// 001  12/22/11 HAC   New params in NTTHomeRunParams.xml file.
//---------------------------------------------------

using System;
using System.Collections.Generic; //needed for List
using System.Collections.ObjectModel; //needed for ObservableCollection
using System.ComponentModel; //reguired for INotifyPropertyChanged
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using NTTHome.NTTManagementsService;
using NTTHome.ProcessComn;

namespace NTTHome
{
  public class NTTHomeData
  {
  }

  public class SBarFieldData : INotifyPropertyChanged
  {
    //must contain all of the bindings for the status bar
    private SolidColorBrush sSBarStatusBGColor;
    private SolidColorBrush sSBarStatusFGColor;
    //icon BG colors
    private SolidColorBrush sSBarBGColorIconP;
    private SolidColorBrush sSBarBGColorIconA;
    private SolidColorBrush sSBarBGColorIconS;
    private SolidColorBrush sSBarBGColorIconM;
    private SolidColorBrush sSBarBGColorIconD;
    private SolidColorBrush sSBarBGColorIconR;
    private string sSBarStatus = "";
    private string sSBarProjFileName = "";

    public SolidColorBrush SBarStatusBGColor
    {
      get { return this.sSBarStatusBGColor; }
      set
      {
        if (value != this.sSBarStatusBGColor)
        { this.sSBarStatusBGColor = value; NotifyPropertyChanged("SBarStatusBGColor"); }
      }
    }
    public SolidColorBrush SBarStatusFGColor
    {
      get { return this.sSBarStatusFGColor; }
      set
      {
        if (value != this.sSBarStatusFGColor)
        { this.sSBarStatusFGColor = value; NotifyPropertyChanged("SBarStatusFGColor"); }
      }
    }
    public SolidColorBrush SBarBGColorIconP
    {
      get { return this.sSBarBGColorIconP; }
      set
      {
        if (value != this.sSBarBGColorIconP)
        { this.sSBarBGColorIconP = value; NotifyPropertyChanged("SBarBGColorIconP"); }
      }
    }
    public SolidColorBrush SBarBGColorIconA
    {
      get { return this.sSBarBGColorIconA; }
      set
      {
        if (value != this.sSBarBGColorIconA)
        { this.sSBarBGColorIconA = value; NotifyPropertyChanged("SBarBGColorIconA"); }
      }
    }
    public SolidColorBrush SBarBGColorIconS
    {
      get { return this.sSBarBGColorIconS; }
      set
      {
        if (value != this.sSBarBGColorIconS)
        { this.sSBarBGColorIconS = value; NotifyPropertyChanged("SBarBGColorIconS"); }
      }
    }
    public SolidColorBrush SBarBGColorIconM
    {
      get { return this.sSBarBGColorIconM; }
      set
      {
        if (value != this.sSBarBGColorIconM)
        { this.sSBarBGColorIconM = value; NotifyPropertyChanged("SBarBGColorIconM"); }
      }
    }
    public SolidColorBrush SBarBGColorIconD
    {
      get { return this.sSBarBGColorIconD; }
      set
      {
        if (value != this.sSBarBGColorIconD)
        { this.sSBarBGColorIconD = value; NotifyPropertyChanged("SBarBGColorIconD"); }
      }
    }
    public SolidColorBrush SBarBGColorIconR
    {
      get { return this.sSBarBGColorIconR; }
      set
      {
        if (value != this.sSBarBGColorIconR)
        { this.sSBarBGColorIconR = value; NotifyPropertyChanged("SBarBGColorIconR"); }
      }
    }
    public string SBarStatus
    {
      get { return this.sSBarStatus; }
      set
      {
        if (value != this.sSBarStatus)
        { this.sSBarStatus = value; NotifyPropertyChanged("SBarStatus"); }
      }
    }
    public string SBarProjFileName
    {
      get { return this.sSBarProjFileName; }
      set
      {
        if (value != this.sSBarProjFileName)
        { this.sSBarProjFileName = value; NotifyPropertyChanged("SBarProjFileName"); }
      }
    }

    public event PropertyChangedEventHandler PropertyChanged;
    private void NotifyPropertyChanged(String info)
    {
      if (PropertyChanged != null)
      {
        PropertyChanged(this, new PropertyChangedEventArgs(info));
      }
    }
  }

  public class ProjectFileData : INotifyPropertyChanged
  {
    private string spfFileName = "";
    private string spfDescription = "";
    private string spfDateCreated = "";
    private string spfDateLastUpdated = "";
    private string spfStatus = "";
    private string spfAreaAOI = "";
    private string spfAreaManagement = "";
    private string spfAreaDefineRun = "";
    private string spfAreaReports = "";

    public string pfFileName
    {
      get { return this.spfFileName; }
      set
      {
        if (value != this.spfFileName)
        { 
          this.spfFileName = value; 
          NotifyPropertyChanged("pfFileName"); 
        }
      }
    }
    public string pfDescription
    {
      get { return this.spfDescription; }
      set
      {
        if (value != this.spfDescription)
        { this.spfDescription = value; NotifyPropertyChanged("pfDescription"); }
      }
    }
    public string pfDateCreated
    {
      get { return this.spfDateCreated; }
      set
      {
        if (value != this.spfDateCreated)
        { this.spfDateCreated = value; NotifyPropertyChanged("pfDateCreated"); }
      }
    }
    public string pfDateLastUpdated
    {
      get { return this.spfDateLastUpdated; }
      set
      {
        if (value != this.spfDateLastUpdated)
        { this.spfDateLastUpdated = value; NotifyPropertyChanged("pfDateLastUpdated"); }
      }
    }
    public string pfStatus
    {
      get { return this.spfStatus; }
      set
      {
        if (value != this.spfStatus)
        { this.spfStatus = value; NotifyPropertyChanged("pfStatus"); }
      }
    }
    public string pfAreaAOI
    {
      get { return this.spfAreaAOI; }
      set
      {
        if (value != this.spfAreaAOI)
        { this.spfAreaAOI = value; NotifyPropertyChanged("pfAreaAOI"); }
      }
    }
    public string pfAreaManagement
    {
      get { return this.spfAreaManagement; }
      set
      {
        if (value != this.spfAreaManagement)
        { this.spfAreaManagement = value; NotifyPropertyChanged("pfAreaManagement"); }
      }
    }
    public string pfAreaDefineRun
    {
      get { return this.spfAreaDefineRun; }
      set
      {
        if (value != this.spfAreaDefineRun)
        { this.spfAreaDefineRun = value; NotifyPropertyChanged("pfAreaDefineRun"); }
      }
    }
    public string pfAreaReports
    {
      get { return this.spfAreaReports; }
      set
      {
        if (value != this.spfAreaReports)
        { this.spfAreaReports = value; NotifyPropertyChanged("pfAreaReports"); }
      }
    }
    //public List<LMODManagementOperationDetail> pfMgtDetailBData { get; set; }

    public event PropertyChangedEventHandler PropertyChanged;
    private void NotifyPropertyChanged(String info)
    {
      if (PropertyChanged != null)
      {
        PropertyChanged(this, new PropertyChangedEventArgs(info));
      }
    }
  }

  public class LocationData
  {
    public string aoiLat { get; set; }
    public string aoiLong { get; set; }
    public string aoiXMin { get; set; }
    public string aoiXMax { get; set; }
    public string aoiYMin { get; set; }
    public string aoiYMax { get; set; }
    public string aoiState { get; set; }
    public string aoiCounty { get; set; }
    public string aoiZip { get; set; }
    public string aoiCmz { get; set; }
    public string aoiAcres { get; set; }
    public double aoiXMinVal { get; set; }
    public double aoiXMaxVal { get; set; }
    public double aoiYMinVal { get; set; }
    public double aoiYMaxVal { get; set; }
  }

  public class SoilEditData : INotifyPropertyChanged
  {
    private const double nPHMin = 0;
    private const double nPHMax = 14;
    private const double nSlopeMin = 0;
    private const double nSlopeMax = 15;

    //INotifyPropertyChanged implementation
    public event PropertyChangedEventHandler PropertyChanged;
    private void RaisePropertyChanged(PropertyChangedEventArgs e)
    {
      if (PropertyChanged != null)
        PropertyChanged(this, e);
    }
    
    public string sedSSA { get; set; }
    public string sedSymbol { get; set; }
    public string sedName { get; set; }
    public string sedAcres { get; set; }
    public string sedPercent { get; set; }

    private string sSlope;
    public string sedSlope
    {
      get { return sSlope; }
      set
      {
        string OldVal = sSlope;
        string sFormatted = "";
        try
        {
          double nNbr = Convert.ToDouble(value);
          //if valid, format to proper decimal alignment
          if (nNbr < nSlopeMin || nNbr > nSlopeMax)
          { throw new Exception("Must be a number between " + nSlopeMin.ToString("0.0") + " and " + nSlopeMax.ToString("0.0") + "."); }
          sFormatted = nNbr.ToString("0.0");
        }
        catch
        {
          throw new Exception("Must be a number between " + nSlopeMin.ToString("0.0") + " and " + nSlopeMax.ToString("0.0") + ".");
        }

        if (OldVal != sFormatted)
        {
          sSlope = sFormatted;
          RaisePropertyChanged(new PropertyChangedEventArgs("sedSlope"));
        }
      }
    }

    private string sPH;
    public string sedPH
    {
      get { return sPH; }
      set
      {
        string OldVal = sPH;
        string sFormatted = "";
        //if (value.Length != 10)
        //  throw new Exception("Phone Number has to be exactly 10 digits");
        try
        {
        double nNbr = Convert.ToDouble(value);
        if (nNbr < nPHMin || nNbr > nPHMax)
        { throw new Exception("Must be a number between " + nPHMin.ToString("0.0") + " and " + nPHMax.ToString("0.0") + "."); }
          sFormatted = nNbr.ToString("0.0");
        }
        catch
        {
          throw new Exception("Must be a number between " + nPHMin.ToString("0.0") + " and " + nPHMax.ToString("0.0") + ".");
        }

        if (OldVal != sFormatted)
        {
          sPH = sFormatted;
          RaisePropertyChanged(new PropertyChangedEventArgs("sedPH"));
        }
      }
    }
  }

  public class ViewManSelection : ObservableCollection<ViewManOpsData>
  {
    //public List<string> vmsCropNbrs { get; set; } //did not allow 'add' below.

    List<string> _vmsCropNbrs = new List<string>();
    public List<string> vmsCropNbrs
    {
      get { return _vmsCropNbrs; }
      set { _vmsCropNbrs = value; }
    }

    List<string> _vmsYears = new List<string>();
    public List<string> vmsYears
    {
      get { return _vmsYears; }
      set { _vmsYears = value; }
    }

    public ViewManSelection() //this works but dynamic does not???
    {

      vmsCropNbrs.Add(ProcessCommon.sCropsAll);
      vmsCropNbrs.Add(ProcessCommon.sCropsPart + "1");
      vmsCropNbrs.Add(ProcessCommon.sCropsPart + "2");
      vmsCropNbrs.Add(ProcessCommon.sCropsPart + "3");
      vmsCropNbrs.Add(ProcessCommon.sCropsPart + "4");

      vmsYears.Add(ProcessCommon.sYearsAll);
      vmsYears.Add(ProcessCommon.sYearsPart + "1");
      vmsYears.Add(ProcessCommon.sYearsPart + "2");
      vmsYears.Add(ProcessCommon.sYearsPart + "3");
      vmsYears.Add(ProcessCommon.sYearsPart + "4");
      vmsYears.Add(ProcessCommon.sYearsPart + "5");
      vmsYears.Add(ProcessCommon.sYearsPart + "6");
      vmsYears.Add(ProcessCommon.sYearsPart + "7");
    }
  }

  public class ViewManOpsData : INotifyPropertyChanged
  {
    //INotifyPropertyChanged implementation
    public event PropertyChangedEventHandler PropertyChanged;
    private void RaisePropertyChanged(PropertyChangedEventArgs e)
    {
      if (PropertyChanged != null)
        PropertyChanged(this, e);
    }

    public string movManCmzId { get; set; }
    public string movManDuration { get; set; }
    public string movManId { get; set; }
    public string movManName { get; set; }
    public string movManPathId { get; set; }
    public int movManYears { get; set; }
    public int movManCropsNbr { get; set; }
    public string movManCropsNames { get; set; }
    public string movManCropsDesc { get; set; }


    //public List<LMODManagementOperationDetail> movManOps { get; set; }

    private List<LMODManagementOperationDetail> lmovManOps;
    public List<LMODManagementOperationDetail> movManOps
    {
      get { return lmovManOps; }
      set
      {
        List<LMODManagementOperationDetail> OldVal = lmovManOps;
        if (OldVal != value)
        {
          lmovManOps = value;
          RaisePropertyChanged(new PropertyChangedEventArgs("movManOps"));
        }
      }
    }
  }

  //public class OperationEvent : INotifyPropertyChanged
  //{
  //  //INotifyPropertyChanged implementation
  //  public event PropertyChangedEventHandler PropertyChanged;
  //  private void RaisePropertyChanged(PropertyChangedEventArgs e)
  //  {
  //    if (PropertyChanged != null)
  //      PropertyChanged(this, e);
  //  }

  //  public OperationEvent()
  //  {
  //  }

  //  private string _oeCropname;
  //  public string oeCropname
  //  {
  //    get { return _oeCropname; }
  //    set
  //    {
  //      string OldVal = _oeCropname;
  //      if (OldVal != value)
  //      {
  //        _oeCropname = value;
  //        RaisePropertyChanged(new PropertyChangedEventArgs("oeCropname"));
  //      }
  //    }
  //  }

  //  private DateTime _oeDate;
  //  public DateTime oeDate
  //  {
  //    get { return _oeDate; }
  //    set
  //    {
  //      DateTime OldVal = _oeDate;
  //      if (OldVal != value)
  //      {
  //        _oeDate = value;
  //        RaisePropertyChanged(new PropertyChangedEventArgs("oeDate"));
  //      }
  //    }
  //  }

  //  private string _oeOperation;
  //  public string oeOperation
  //  {
  //    get { return _oeOperation; }
  //    set
  //    {
  //      string OldVal = _oeOperation;
  //      if (OldVal != value)
  //      {
  //        _oeOperation = value;
  //        RaisePropertyChanged(new PropertyChangedEventArgs("oeOperation"));
  //      }
  //    }
  //  }

  //  //need to test null value changes
  //  private string _oeCrop;
  //  public string oeCrop
  //  {
  //    get { return _oeCrop; }
  //    set
  //    {
  //      string OldVal = _oeCrop;
  //      if (OldVal != value)
  //      {
  //        _oeCrop = value;
  //        RaisePropertyChanged(new PropertyChangedEventArgs("oeCrop"));
  //      }
  //    }
  //  }

  //  private double? _oeAmount;
  //  public double? oeAmount
  //  {
  //    get { return _oeAmount; }
  //    set
  //    {
  //      _oeAmount = value;
  //      RaisePropertyChanged(new PropertyChangedEventArgs("oeAmount"));
  //    }
  //  }

  //  private double? _oeDepth;
  //  public double? oeDepth
  //  {
  //    get { return _oeDepth; }
  //    set
  //    {
  //      _oeDepth = value;
  //      RaisePropertyChanged(new PropertyChangedEventArgs("oeDepth"));
  //    }
  //  }

  //  private bool _InError = default(bool);

  //  public bool InError
  //  {
  //    get
  //    {
  //      return _InError;
  //    }

  //    set
  //    {
  //      if (value != _InError)
  //      {
  //        _InError = value;
  //        if (PropertyChanged != null)
  //          PropertyChanged(this, new PropertyChangedEventArgs("InError"));
  //      }

  //    }
  //  }
  //}

  public class StatesNames
  {
    public string stName { get; set; }
    public string stAbbrevName { get; set; }
  }

  public class ManagementEditData : INotifyPropertyChanged
  {
    private const int nAmtMin = 0;
    private const int nAmtMax = 500;
    private const int nDepthMin = 1;
    private const int nDepthMax = 500;

    //INotifyPropertyChanged implementation
    public event PropertyChangedEventHandler PropertyChanged;
    private void RaisePropertyChanged(PropertyChangedEventArgs e)
    {
      if (PropertyChanged != null)
        PropertyChanged(this, e);
    }

    public string medDId { get; set; }
    public string medDCrop { get; set; }
    public int? medDCropId { get; set; }
    public int medDOpId { get; set; }
    public int medDManId { get; set; }
    public string medDOper { get; set; }
    public int medDOperId { get; set; }
    public string medDOperCode { get; set; }
    public string medDOperCodeDesc { get; set; }

    private DateTime dtDDate;
    public DateTime medDDate
    {
      get { return dtDDate; }
      set
      {
        DateTime OldVal = dtDDate;
        try
        {
          //how to verify that user entry as a string is a valid date???
          //DateTime dtVal = Convert.ToDateTime(value);
        }
        catch
        {
          throw new Exception("Must be a valid date.");
        }

        if (OldVal != value)
        {
          dtDDate = value;
          RaisePropertyChanged(new PropertyChangedEventArgs("msdDDate"));
        }
      }
    }

    private string sAmt;
    public string medDAmt
    {
      get { return sAmt; }
      set
      {
        string OldVal = sAmt;
        string sFormatted = "";
        try
        {
          //only check when plant or fert
          if (medDOper.ToLower().StartsWith("plant") || medDOper.ToLower().StartsWith("fert"))
          {
            double nNbr = Convert.ToDouble(value);
            //if valid, format to proper decimal alignment
            if (nNbr < nAmtMin || nNbr > nAmtMax)
            { throw new Exception("Must be a number between " + nAmtMin.ToString() + " and " + nAmtMax.ToString() + "."); }
            sFormatted = nNbr.ToString();
          }
        }
        catch
        {
          throw new Exception("Must be a number between " + nAmtMin.ToString() + " and " + nAmtMax.ToString() + ".");
        }

        if (OldVal != sFormatted)
        {
          sAmt = sFormatted;
          RaisePropertyChanged(new PropertyChangedEventArgs("msdDAmt"));
        }
      }
    }

    private string sDepth;
    public string medDDepth
    {
      get { return sDepth; }
      set
      {
        string OldVal = sDepth;
        string sFormatted = "";
        try
        {
          //only check when fert
          if (medDOper.ToLower().StartsWith("fert"))
          {
            double nNbr = Convert.ToDouble(value);
            if (nNbr < nDepthMin || nNbr > nDepthMax)
            { throw new Exception("Must be a number between " + nDepthMin.ToString() + " and " + nDepthMax.ToString() + "."); }
            sFormatted = nNbr.ToString();
          }
        }
        catch
        {
          throw new Exception("Must be a number between " + nDepthMin.ToString() + " and " + nDepthMax.ToString() + ".");
        }

        if (OldVal != sFormatted)
        {
          sDepth = sFormatted;
          RaisePropertyChanged(new PropertyChangedEventArgs("msdDDepth"));
        }
      }
    }
  }

  public class NTTHomeRunParams
  {
    public string nhRPKey { get; set; }
    public string nhRPDebug { get; set; }
    public string nhRPDebugFile { get; set; }
    public string nhRPLogLocation { get; set; }
    public string nhRPLogErrors { get; set; }
    public string nhRPLogErrorFile { get; set; }
    public string nhRPStartyear { get; set; }
    public string nhRPEndyear { get; set; }
    public string nhRPAdminString { get; set; }
    public string nhRPWaitSecondsPerYear { get; set; } //format #,# - seconds @ yr, show gt seconds
    public string nhRPEndPointServicesSoils { get; set; }
    public string nhRPEndPointServicesManagements { get; set; }
    public string nhRPNTTDesc { get; set; }
    public string nhRPNTTDate { get; set; }
  }

}
