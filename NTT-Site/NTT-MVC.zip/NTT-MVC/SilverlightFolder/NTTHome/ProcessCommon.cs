//---------------------------------------------------
//Summary
//NTTHome - Common routines.
//---------------------------------------------------
//Revision History
//Rev#  Date     Who   Change history
// 001  01/11/13 HAC   Initial version.
//---------------------------------------------------

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel; //for Observable collection
using System.Diagnostics;
using System.Globalization; //for NumberStyles
using System.IO;  //required for Stream
using System.Linq;
using System.Text; //for StringBuilder
using System.Windows.Media; //for color
using System.Xml.Serialization; //required add reference

using NTTHome.NTTManagementsService;

//using NTTHome.Controls;

namespace NTTHome.ProcessComn
{
  public static class ProcessCommon
  {
    private static string sMeName = "ProcessCommon";

    public const string NTTHomeRunParamsFile = "NTTHomeRunParams.xml";
    public const string sPFTitle = "Project File";
    public const string sTabPFFirst = "First create or open a Project File.";
    public const string sTabPFProject = "Create, open or save a Project File (nttsl).";
    public const string sTabPFAOI = "Select an Area of Interest (AOI).";
    public const string sTabPFSoilsLocation = "Soils and Location Information.";
    public const string sTabPFManagement = "Management operations for Baseline and Alternative.";
    public const string sTabPFDefineRun = "Define parameters and run APEX.";
    public const string sTabPFReports = "View and print Reports.";
    public const string sNone = "(none)";
    public const string sSelectOne = "(Select one)";

    public const double nWestBC = -125.02083333;
    public const double nEastBC = -66.47916757;
    public const double nNorthBC = 49.9375;
    public const double nSouthBC = 24.0625;
    public const double nCellSize = 0.04166667;
    public const int nNbrRows = 621;
    public const int nNbrColumns = 1405;

    //external parameters
    public const string sAppEndPointServicesManagementsDefaultDev = "BasicHttpBinding_IManagements_Dev";
    public const string sAppEndPointServicesSoilsDefaultDev = "BasicHttpBinding_ISoilComponentService_Dev";
    //public const string sAppEndPointServicesNTTHomeDefaultDev = "Service1Soap_Dev";
    //public const string sAppNTTHomeHandlerDefaultDev = @"http://localhost:1866/NTTHomeImage.ashx";
    //public const string sAppNTTHomeHelpHostDefaultDev = "199.156.165.100";
    //public const string sAppNTTHomeWebPageHostDefaultDev = "199.156.165.100";
    //public const string sAppNTTHomeWebPageDefaultDev = "NTTHomeWebT/default.aspx";
    public const string sYearStartDefault = "1960";
    public const string sYearEndDefault = "2006";
    public const string sAppAdminStringDefault = "i am an admin";

    public static string sAppNTTDesc = "";
    public static string sAppNTTDate = "";
    public static string sAppEndPointServicesManagements = "";
    public static string sAppEndPointServicesSoils = "";
    public static string sYearStart = "";
    public static string sYearEnd = "";
    public static int nYearStart = 0;
    public static int nYearEnd = 0;
    public static string sAppAdminString = "";

    public static NTTHomeRunParams saveRunParams = new NTTHomeRunParams();

    public static SolidColorBrush sbBGFill = new SolidColorBrush() { Color = "#FFD3D3D3".HexColor() };  //light gray
    public static SolidColorBrush sbFGFillRed = new SolidColorBrush() { Color = "#FFFF0000".HexColor() };  //red
    public static SolidColorBrush sbFGFillBlack = new SolidColorBrush() { Color = "#FF000000".HexColor() };  //black

    public static SolidColorBrush iconNoneBFFill = new SolidColorBrush() { Color = "#FFFFFFE0".HexColor() };  //light yellow
    public static SolidColorBrush iconPartialBFFill = new SolidColorBrush() { Color = "#FFFFB6C1".HexColor() };  //light pink
    public static SolidColorBrush iconReadyBFFill = new SolidColorBrush() { Color = "#FF90EE90".HexColor() };  //light green

    public static string sCropsAll = "#Crops-All";
    public static string sYearsAll = "#Years-All";
    public static string sCropsPart = "#Crops-";
    public static string sYearsPart = "#Years-";

    public static bool bIsBaseline = true;
    public static int nSelectedCMZ = 0;
    public static ViewManOpsData vuManSelectedBase = new ViewManOpsData();
    public static ViewManOpsData vuManSelectedAlt = new ViewManOpsData();
    public static List<APEXOperationCode> lstAOCodesData = new List<APEXOperationCode>();
    public static List<MappedOperation> lstMpOperations = new List<MappedOperation>();

    public static ObservableCollection<ManagementEditData> lstMSDataBase = new ObservableCollection<ManagementEditData>();
    public static ObservableCollection<ManagementEditData> lstMSDataAlt = new ObservableCollection<ManagementEditData>();

    public static ObservableCollection<ManagementEditData> lstMSDataEdit = new ObservableCollection<ManagementEditData>();
    public static ObservableCollection<ManagementEditData> lstMSDataEditPrevious = new ObservableCollection<ManagementEditData>();

    public static ManagementEditData emptyMSData = new ManagementEditData();
    public static ManagementEditData selectedMSData = new ManagementEditData();
    public static ManagementEditData addedMSData = new ManagementEditData();

    public static List<MappedOperation> lstSelectOperations = null;

    //public static List<LMODManagementOperationDetail> vuManSelectedDetailBase = null;

    private static string sValue;

    //WQI below

    //public const string WQIRunParamsFile = "WQIRunParams.xml";

    //public const string sSelectOne = "(Select one)";
    //public const string sNone = "(none)";
    //public const string ClimateLocFolder = "ClimateSource";
    //public const string ClimateStatesFile = "WQIStates.xml";
    //public const string ClimateFile = "Climate.xml";
    //public const string StateParamLocFolder = "StateParamSource";
    //public const string StateParamFile = "-StateParams.xml";
    //public const int CPSelectionsMax = 3;

    //public static char[] SValSplit = { '|' };
    //public static char[] SParamSplit = { '~' };
    //public const string NoFertApplied = "No fertilizer applied";
    //public static bool bNoFertApplied = false;

    //public static WQIData.SelectionData SInteractionSlopeSelectedData = null;
    //public static WQIData.SelectionDataIrrigation SInteractionHSSelectedData = null;
    //public static WQIData.SelectionDataIrrigation SInteractionKFSelectedData = null;

    //public static string sSessionId = "";
    //public static ReportData RReportData = null;

    //public static List<WQIData.BGColorInfo> BGColors = new List<WQIData.BGColorInfo>();

    //public static WQIData WQIcontext = null; //common params
    //public static WQIData WQIcontextGlobal = null;
    //public static WQIData WQIcontextState = null;

    //public static string WQIVersionAndDate = "";
    //public static string WQIVersionOnly = "";
    //public static string WQIVerDateOnly = "";

    //make changes here before production build
    //public static string sAppEndPointServices = "BasicHttpBinding_IService1_Dev"; //initial value only
    //public static string sAppEndPointServices = "BasicHttpBinding_IService1_TestServer"; //live value test server
    //public static string sAppEndPointServices = "BasicHttpBinding_IService1_ARS"; //live value ARS server
    //public static string sAppHelpURL = "199.156.165.100/wqihelp/"; //initial value only test server
    //public static string sAppHelpURL = "199.133.175.81/wqihelp/"; //initial value only ARS server
    //public static string sAppClientDebug = "0"; //initial value only
    //public static string sAppClientLogErrors = "1"; //initial value only
    //end changes here before production build

    //private static string sValue;

    //default colors
    //public static SolidColorBrush colorBGFillLGray = new SolidColorBrush() { Color = "#FFD3D3D3".HexColor() };  //light gray
    //public static SolidColorBrush colorBGFillLYellow = new SolidColorBrush() { Color = "#FFFFFFE0".HexColor() };  //light yellow
    //public static SolidColorBrush colorBGFillLPink = new SolidColorBrush() { Color = "#FFFFB6C1".HexColor() };  //light pink

    //public static SolidColorBrush sbFGFillTotRed = new SolidColorBrush() { Color = "#FFFF0000".HexColor() };
    //public static SolidColorBrush sbFGFillTotPink = new SolidColorBrush() { Color = "#FFFF677E".HexColor() };
    //public static SolidColorBrush sbFGFillTotYellow = new SolidColorBrush() { Color = "#FFFEF76E".HexColor() };
    //public static SolidColorBrush sbFGFillTotLGreen = new SolidColorBrush() { Color = "#FFC4DF9B".HexColor() };
    //public static SolidColorBrush sbFGFillTotGreen = new SolidColorBrush() { Color = "#FF00E100".HexColor() };

    //red or pink only
    //public static SolidColorBrush sbFGFillTotPink = new SolidColorBrush() { Color = "#FFFFB6C1".HexColor() };
    //public static SolidColorBrush sbFGFillTotYellow = new SolidColorBrush() { Color = "#FFFFB6C1".HexColor() };
    //public static SolidColorBrush sbFGFillTotLGreen = new SolidColorBrush() { Color = "#FFFFB6C1".HexColor() };
    //public static SolidColorBrush sbFGFillTotGreen = new SolidColorBrush() { Color = "#FFFFB6C1".HexColor() };


    /// <summary>
    /// Convert a string hex value (e.g. "#FF0ACD") to a Color structure
    /// </summary>
    public static Color HexColor(this string hex)
    {
      //remove the # at the front
      hex = hex.Replace("#", "");

      byte a = 255;
      byte r = 255;
      byte g = 255;
      byte b = 255;

      int start = 0;

      //handle ARGB strings (8 characters long)
      if (hex.Length == 8)
      {
        a = byte.Parse(hex.Substring(0, 2), NumberStyles.HexNumber);
        start = 2;
      }

      //convert RGB characters to bytes
      r = byte.Parse(hex.Substring(start, 2), NumberStyles.HexNumber);
      g = byte.Parse(hex.Substring(start + 2, 2), NumberStyles.HexNumber);
      b = byte.Parse(hex.Substring(start + 4, 2), NumberStyles.HexNumber);

      return Color.FromArgb(a, r, g, b);
    }

    public static string SafeBSlashPathEndString(string strValue)
    {
      sValue = strValue;
      try
      {

        if (!strValue.EndsWith("\\"))
        {
          sValue = strValue.ToString() + "\\";
          return sValue;
        }
        else { return sValue; }
      }
      catch (Exception Ex)
      {
        StackTrace sTrace = new StackTrace();
        //doErrorLog(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", Ex);
        //throw ex;
        return sValue;
      }
    }

    public static bool chkDouble(string sVal)
    {
      double nDbl = 0;
      try
      {
        nDbl = Convert.ToDouble(sVal);
        return true;
      }
      catch (Exception ex)
      {
        return false;
      }
    }

    public static void TestDouble(string sValue, out bool isDouble, out double nDouble)
    {
      try
      {
        isDouble = false; nDouble = 0;
        isDouble = double.TryParse(sValue, out nDouble);
      }
      catch (Exception Ex)
      {
        StackTrace sTrace = new StackTrace();
        //doErrorLog(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", Ex);
        //throw ex;
        isDouble = false; nDouble = 0;
      }
    }

    public static void TestInteger(string sValue, out bool isInteger, out int nInt)
    {
      try
      {
        isInteger = false; nInt = 0;
        isInteger = int.TryParse(sValue, out nInt);
      }
      catch (Exception Ex)
      {
        StackTrace sTrace = new StackTrace();
        //doErrorLog(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", Ex);
        //throw ex;
        isInteger = false; nInt = 0;
      }
    }

    public static string GetMonthName(DateTime givenDate)
    {
      try
      {
      var formatInfoinfo = new DateTimeFormatInfo();
      string[] monthName = formatInfoinfo.MonthNames;
      return monthName[givenDate.Month - 1];
      }
      catch (Exception Ex)
      {
        StackTrace sTrace = new StackTrace();
        //doErrorLog(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", Ex);
        //throw ex;
        return "";
      }
    }

    public static string GetMonthName(int nMonth)
    {
      try
      {
      var formatInfoinfo = new DateTimeFormatInfo();
      string[] monthName = formatInfoinfo.MonthNames;
      return monthName[nMonth];
      }
      catch (Exception Ex)
      {
        StackTrace sTrace = new StackTrace();
        //doErrorLog(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", Ex);
        //throw ex;
        return "";
      }
    }

    /// <summary>
    /// Extension to perform a deep Copy of the object specified.
    /// </summary>
    /// <typeparam name="T">The type of object being copied.</typeparam>
    /// <param name="source">The object instance to copy.</param>
    /// <returns>The copied object.</returns>
    public static T Clone<T>(this T source)
    {
      try
      {

      // Don't serialize a null object, simply return the default for that object
      if (Object.ReferenceEquals(source, null))
      {
        return default(T);
      }
      XmlSerializer serializer = new XmlSerializer(source.GetType());
      Stream stream = new MemoryStream();
      using (stream)
      {
        serializer.Serialize(stream, source);
        stream.Seek(0, SeekOrigin.Begin);
        return (T)serializer.Deserialize(stream);
      }
      }
      catch (Exception Ex)
      {
        StackTrace sTrace = new StackTrace();
        //doErrorLog(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", Ex);
        //throw ex;
        return default(T);
      }
    }

    #region DebugErrorLogging

    //public static void doDebugLog(ClientLogData cldDebug)
    //{
    //  int nAppDebuglevel = 0;
    //  int nLevel = 0;
    //  string sTmp = "";
    //  int nInteger;
    //  bool isInteger;
    //  try
    //  {
    //    sTmp = ""; sTmp = ProcessCommon.sAppClientDebug;
    //    ProcessCommon.TestInteger(sTmp, out isInteger, out nInteger);
    //    if (isInteger == true) { nAppDebuglevel = nInteger; } else { nAppDebuglevel = 0; }

    //    sTmp = ""; sTmp = cldDebug.CLDLevel;
    //    ProcessCommon.TestInteger(sTmp, out isInteger, out nInteger);
    //    if (isInteger == true) { nLevel = nInteger; } else { nLevel = 0; }

    //    if (nAppDebuglevel == 0) return;
    //    if (nLevel > nAppDebuglevel) return;

    //    cldDebug.CLDId = ProcessCommon.sSessionId;

    //    Service1Client clientDebug = new Service1Client(ProcessCommon.sAppEndPointServices);
    //    clientDebug.ClientDebugCompleted +=
    //      new EventHandler<System.ComponentModel.AsyncCompletedEventArgs>((s, a) =>
    //      {
    //        //refresh
    //      });
    //    clientDebug.ClientDebugAsync(cldDebug);
    //  }
    //  catch (Exception Ex)
    //  {
    //    StackTrace sTrace = new StackTrace();
    //    doErrorLog(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", Ex);
    //    //MessageBox.Show("Exception failure: " + Ex.Message.ToString(), sTrace.GetFrame(0).GetMethod().Name, MessageBoxButton.OK);
    //  }
    //}

    //public static void doErrorLog(string sMeName, string sMethodName, string sMsgType, System.Exception eX)
    //{
    //  StringBuilder sbDetails = new StringBuilder();
    //  try
    //  {
    //    if (ProcessCommon.sAppClientLogErrors == "0") return;

    //    ClientLogData cldDebug = new ClientLogData();
    //    cldDebug.CLDId = ProcessCommon.sSessionId;
    //    cldDebug.CLDModule = sMeName;
    //    cldDebug.CLDFunction = sMethodName;

    //    if (eX != null)
    //    {
    //      sbDetails.AppendFormat(" Error Details:{0}", Environment.NewLine);
    //      sbDetails.AppendFormat("{0}{1}", eX.Message, Environment.NewLine);

    //      if (eX.InnerException != null)
    //      {
    //        sbDetails.AppendFormat(" InnerException Details:{0}", Environment.NewLine);
    //        sbDetails.AppendFormat("{0}{1}", eX.InnerException.Message, Environment.NewLine);


    //        //not available in Silverlight
    //        //sbDetails.AppendFormat(" InnerException Source:{0}", Environment.NewLine);
    //        //sbDetails.AppendFormat("{0}{1}", eX.InnerException.Source, Environment.NewLine);
    //      }
    //      else
    //      {
    //        sbDetails.Append(">>> Error Detail not available <<<" + Environment.NewLine);
    //      }
    //    }
    //    else
    //    {
    //      sbDetails.Append(">>> Error Detail not available <<<" + Environment.NewLine);
    //    }
    //    cldDebug.CLDMsg = sbDetails.ToString();

    //    Service1Client clientError = new Service1Client(ProcessCommon.sAppEndPointServices);
    //    clientError.ClientErrorCompleted +=
    //      new EventHandler<System.ComponentModel.AsyncCompletedEventArgs>((s, a) =>
    //      {
    //        if (a.Error != null)  //does not get here when service is not available
    //        {
    //          //handle error with msg???
    //        }
    //      });
    //    clientError.ClientErrorAsync(cldDebug);
    //  }
    //  catch (Exception Ex)
    //  {
    //    //StackTrace sTrace = new StackTrace();
    //    //doErrorLog(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", Ex);
    //    //MessageBox.Show("Exception failure: " + Ex.Message.ToString(), sTrace.GetFrame(0).GetMethod().Name, MessageBoxButton.OK);
    //  }
    //}
    #endregion

  }
}