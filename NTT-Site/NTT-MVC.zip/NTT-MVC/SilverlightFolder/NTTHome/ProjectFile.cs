﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Xml.Linq;
using System.Xml.Serialization; //required add reference

using NTTHome.Controls;

namespace NTTHome
{
  public class ProjectFile
  {
    private ProjectFileData pfileData = null;
    public ProjectFileData PFileData
    {
      get { return pfileData; }
      set { pfileData = value; }
    }

    public string FileOpen()
    {
      OpenFileDialog sfd = new OpenFileDialog();
      string sReturn = "";
      string sFileName = "";
      string sTmp = "";
      try
      {
        sfd.Filter = "NTTSL files (*.nttsl)|*.nttsl";
        sfd.FilterIndex = 1;
        sfd.Multiselect = false;
        System.Nullable<Boolean> bResult = sfd.ShowDialog();
        if (bResult == true)
        {
          //use external file name for internal file name - just change it.
          sFileName = sfd.File.ToString().Trim(); //user entered file name
          System.IO.Stream fsRead = sfd.File.OpenRead();
          using (StreamReader srRead = new StreamReader(fsRead))
          {
            sTmp = srRead.ReadToEnd();
            srRead.Close();
          }
          XDocument docProjectFromFile = new XDocument();
          docProjectFromFile = XDocument.Parse(sTmp.ToString());

          List<ProjectFileData> pfData = (from pfinfo in docProjectFromFile.Descendants("PFFileNfo")
            select new ProjectFileData()
            {
              pfFileName = pfinfo.Element("pfFileName").Value,
              pfDescription = pfinfo.Element("pfDescription").Value,
              pfDateCreated = pfinfo.Element("pfDateCreated").Value,
              pfDateLastUpdated = pfinfo.Element("pfDateLastUpdated").Value,
              pfStatus= pfinfo.Element("pfStatus").Value,
              pfAreaAOI = pfinfo.Element("pfAreaAOI").Value,
              pfAreaManagement = pfinfo.Element("pfAreaManagement").Value, 
              pfAreaDefineRun = pfinfo.Element("pfAreaDefineRun").Value,
              pfAreaReports = pfinfo.Element("pfFAreaReports").Value
            }).ToList();
          pfileData = pfData.ElementAt(0);
          PFileData.pfFileName = sFileName.ToString().Trim();
        }
        sReturn = "OK";
      }
      catch (Exception ex)
      {
        //StackTrace sTrace = new StackTrace();
        //AHATMisc.WriteToErrorFile(sMeName, MapPath(""), sTrace.GetFrame(0).GetMethod().Name, "Exception failure", ex);
        sReturn = "Error: " + ex.ToString();
      }
      return sReturn;
    }

    public string FileSave()
    {
      SaveFileDialog sfd = new SaveFileDialog();
      System.IO.Stream objText = null;
      System.IO.StreamWriter objTextW = null;
      string sReturn = "";
      string sTmp = "";
      try
      {
        sfd.Filter = "NTTSL files | *.nttsl";
        sfd.DefaultExt = "nttsl";
        //known issue: cannot specify default file name in SaveFileDialog
        System.Nullable<Boolean> bResult = sfd.ShowDialog();
        if (bResult == true)
        {
          pfileData.pfFileName = sfd.SafeFileName.ToString().Trim(); //user entered file name
          if (pfileData.pfDateCreated.Length == 0) pfileData.pfDateCreated = DateTime.Now.ToString();
          pfileData.pfDateLastUpdated = DateTime.Now.ToString();

          // create project file info

          //orig project file save code - can remove later
          //XDocument docpfFileInfo = new XDocument();
          //XDeclaration xdPFFI = new XDeclaration("1.0", "utf-8", "yes");
          //docpfFileInfo.Declaration = xdPFFI;

          //XElement xPFFIDetail = new XElement("PFFileInfo");
          //XElement oPFFIDetail = new XElement("PFFileNfo");
          //oPFFIDetail.Add(new XElement("pfFileName", pfileData.pfFileName.ToString()));
          //oPFFIDetail.Add(new XElement("pfDescription", pfileData.pfDescription.ToString()));
          //oPFFIDetail.Add(new XElement("pfDateCreated", pfileData.pfDateCreated.ToString()));
          //oPFFIDetail.Add(new XElement("pfDateLastUpdated", pfileData.pfDateLastUpdated.ToString()));
          //oPFFIDetail.Add(new XElement("pfStatus", pfileData.pfStatus.ToString()));
          //oPFFIDetail.Add(new XElement("pfAreaAOI", pfileData.pfAreaAOI.ToString()));
          //oPFFIDetail.Add(new XElement("pfAreaManagement", pfileData.pfAreaManagement.ToString()));
          //oPFFIDetail.Add(new XElement("pfAreaDefineRun", pfileData.pfAreaDefineRun.ToString()));
          //oPFFIDetail.Add(new XElement("pfFAreaReports", pfileData.pfAreaReports.ToString()));

          //xPFFIDetail.Add(oPFFIDetail);
          //docpfFileInfo.Add(xPFFIDetail);

          //objText = sfd.OpenFile();
          //objTextW = new StreamWriter(objText);

          //objTextW.WriteLine("<AllData>"); //xml single root
          //objTextW.WriteLine(docpfFileInfo.ToString()); //internal file info
          ////objTextW.WriteLine(sTmp.ToString); // returned climate detail
          //objTextW.WriteLine("</AllData>"); //xml single root

          //objTextW.Flush(); objTextW.Close(); objText.Close();
          //sReturn = "OK";

          XmlSerializer serializer = new XmlSerializer(typeof(ProjectFileData));

          objText = sfd.OpenFile();
          objTextW = new StreamWriter(objText);
          serializer.Serialize(objTextW, pfileData);
          objTextW.Flush(); objTextW.Close(); objText.Close();

          //ToDo: use this name to identify the saved file name
         string sProjectFileName = sfd.SafeFileName.ToString().Trim(); //user entered file name

          sReturn = "OK";
        }
      }
      catch (Exception ex)
      {
        //StackTrace sTrace = new StackTrace();
        //AHATMisc.WriteToErrorFile(sMeName, MapPath(""), sTrace.GetFrame(0).GetMethod().Name, "Exception failure", ex);
        sReturn = "Error: " + ex.ToString();
      }
      finally
      {
        if (objTextW != null) objTextW.Close();
        if (objText != null) objText.Close();
      }
      return sReturn;
    }
  }
}

//Private Sub btnPFNew_Click(ByVal sender As Object, ByVal e As System.Windows.RoutedEventArgs) Handles btnPFNew.Click
  //  Dim sfd As SaveFileDialog = New SaveFileDialog
  //  Dim objText As System.IO.Stream = Nothing
  //  Dim objTextW As System.IO.StreamWriter = Nothing
  //  Try
  //    sfd.Filter = "NTTSL files | *.nttsl"
  //    sfd.DefaultExt = "nttsl"
  //    Dim bResult As System.Nullable(Of Boolean) = sfd.ShowDialog
  //    If bResult = True Then

  //      Me.PFileInfo.PFFileName = sfd.SafeFileName.ToString '//user entered file name
  //      Me.PFileInfo.PFDateCreated = DateTime.Now.ToString
  //      Me.PFileInfo.PFDateLastUpdated = DateTime.Now.ToString

  //      '// create project file info
  //      Dim docpfFileInfo As New XDocument
  //      Dim xdPFFI As New XDeclaration("1.0", "utf-8", "yes")
  //      docpfFileInfo.Declaration = xdPFFI

  //      Dim xPFFIDetail As New XElement("PFFileInfo")

  //      Dim oPFFIDetail As New XElement("PFFileNfo")
  //      oPFFIDetail.Add(New XElement("pfFileName", Me.PFileInfo.PFFileName.ToString))
  //      oPFFIDetail.Add(New XElement("pfDescription", Me.PFileInfo.PFDescription.ToString))
  //      oPFFIDetail.Add(New XElement("pfDateCreated", Me.PFileInfo.PFDateCreated.ToString))
  //      oPFFIDetail.Add(New XElement("pfDateLastUpdated", Me.PFileInfo.PFDateLastUpdated.ToString))
  //      oPFFIDetail.Add(New XElement("pfStatus", Me.PFileInfo.PFStatus.ToString))
  //      oPFFIDetail.Add(New XElement("pfAreaAOI", Me.PFileInfo.PFAreaAOI.ToString))
  //      oPFFIDetail.Add(New XElement("pfAreaManagementN", Me.PFileInfo.PFAreaManagementN.ToString))
  //      oPFFIDetail.Add(New XElement("pfAreaManagementC", Me.PFileInfo.PFAreaManagementC.ToString))
  //      oPFFIDetail.Add(New XElement("pfAreaDefineRun", Me.PFileInfo.PFAreaDefineRun.ToString))
  //      oPFFIDetail.Add(New XElement("pfFAreaReports", Me.PFileInfo.PFAreaReports.ToString))
  //      xPFFIDetail.Add(oPFFIDetail)

  //      docpfFileInfo.Add(xPFFIDetail)

  //      objText = sfd.OpenFile()
  //      objTextW = New StreamWriter(objText)

  //      objTextW.WriteLine("<AllData>") '//xml single root
  //      objTextW.WriteLine(docpfFileInfo.ToString) '//internal file info
  //      'objTextW.WriteLine(sTmp.ToString) '// returned climate detail
  //      objTextW.WriteLine("</AllData>") '//xml single root

  //      objTextW.Flush() : objTextW.Close()
  //      objText.Close()

  //      '//bind here before status change
  //      Me.PFileInfo.PFStatus = "(new file)"
  //      Me.gridPFile.DataContext = ""
  //      Me.gridPFile.DataContext = PFileInfo

  //      Me.mCurStateProjectFile = theStateProjectFile.StateNew

  //    End If
  //  Catch ex As Exception
  //    Dim msgBResult As MessageBoxResult = MessageBox.Show(ex.Message.ToString, "Error: btnPFNew_Click Failed Information", MessageBoxButton.OK)
  //  Finally
  //    If Not objTextW Is Nothing Then objTextW.Close()
  //    If Not objText Is Nothing Then objText.Close()
  //  End Try
  //End Sub

  //Private Sub btnPFOpen_Click(ByVal sender As Object, ByVal e As System.Windows.RoutedEventArgs) Handles btnPFOpen.Click
  //  Dim sfd As OpenFileDialog = New OpenFileDialog
  //  Dim sTmp As String = String.Empty
  //  Try
  //    sfd.Filter = "NTTSL files (*.nttsl)|*.nttsl"
  //    sfd.FilterIndex = 1
  //    sfd.Multiselect = False
  //    Dim bResult As System.Nullable(Of Boolean) = sfd.ShowDialog
  //    If bResult = True Then

  //      Dim fsRead As System.IO.Stream = sfd.File.OpenRead

  //      Using srRead As New System.IO.StreamReader(fsRead)
  //        sTmp = srRead.ReadToEnd
  //        srRead.Close()
  //      End Using

  //      Dim docProjectFromFile As New XDocument
  //      docProjectFromFile = XDocument.Parse(sTmp.ToString)

  //      '//validate file contents
  //      Dim fprojectvalid = From pfinfo In docProjectFromFile.Descendants("PFFileNfo") _
  //      Select New SLDesignData.ProjectFileInfo(pfinfo.Element("pfFileName").Value, pfinfo.Element("pfDescription").Value, pfinfo.Element("pfDateCreated").Value, pfinfo.Element("pfDateLastUpdated").Value, pfinfo.Element("pfStatus").Value, pfinfo.Element("pfAreaAOI").Value, pfinfo.Element("pfAreaManagementN").Value, pfinfo.Element("pfAreaManagementC").Value, pfinfo.Element("pfAreaDefineRun").Value, pfinfo.Element("pfFAreaReports").Value)

  //      If fprojectvalid Is Nothing Then
  //        'Throw an exception
  //        'Throw New ApplicationException("File info not valid.")
  //      End If

  //      fsRead.Close()

  //      '//check file internal and external names to be the same???
  //      Me.PFileInfo.PFFileName = sfd.File.Name.ToString '//user selected file name

  //      For Each fpinfos In fprojectvalid
  //        'Me.PFileInfo.PFFileName = fpinfos.PFFileName.ToString
  //        Me.PFileInfo.PFDescription = fpinfos.PFDescription.ToString
  //        Me.PFileInfo.PFDateCreated = fpinfos.PFDateCreated.ToString
  //        Me.PFileInfo.PFDateLastUpdated = fpinfos.PFDateLastUpdated.ToString
  //        Me.PFileInfo.PFStatus = fpinfos.PFStatus.ToString
  //        Me.PFileInfo.PFAreaAOI = fpinfos.PFAreaAOI.ToString
  //        Me.PFileInfo.PFAreaManagementN = fpinfos.PFAreaManagementN.ToString
  //        Me.PFileInfo.PFAreaManagementC = fpinfos.PFAreaManagementC.ToString
  //        Me.PFileInfo.PFAreaDefineRun = fpinfos.PFAreaDefineRun.ToString
  //        Me.PFileInfo.PFAreaReports = fpinfos.PFAreaReports.ToString
  //      Next

  //      '//bind here before status change

  //      Me.eChkChangeProjectFile = False

  //      Me.PFileInfo.PFStatus = "(open file)"
  //      Me.gridPFile.DataContext = ""
  //      Me.gridPFile.DataContext = PFileInfo

  //      Me.mCurStateProjectFile = theStateProjectFile.StateOpen

  //    End If
  //  Catch ex As Exception
  //    Dim msgBResult As MessageBoxResult = MessageBox.Show(ex.Message.ToString, "Error: btnPFOpen_Click Failed Information", MessageBoxButton.OK)
  //  End Try
  //End Sub

  //Private Sub btnPFSaveAs_Click(ByVal sender As Object, ByVal e As System.Windows.RoutedEventArgs) Handles btnPFSaveAs.Click
  //  Dim sfd As SaveFileDialog = New SaveFileDialog
  //  Dim objText As System.IO.Stream = Nothing
  //  Dim objTextW As System.IO.StreamWriter = Nothing
  //  Try
  //    sfd.Filter = "NTTSL files | *.nttsl"
  //    sfd.DefaultExt = "nttsl"
  //    Dim bResult As System.Nullable(Of Boolean) = sfd.ShowDialog
  //    If bResult = True Then

  //      Me.PFileInfo.PFFileName = sfd.SafeFileName.ToString '//user entered file name
  //      If Me.PFileInfo.PFDateCreated.Length = 0 Then Me.PFileInfo.PFDateCreated = DateTime.Now.ToString
  //      Me.PFileInfo.PFDateLastUpdated = DateTime.Now.ToString

  //      '// create project file info
  //      Dim docpfFileInfo As New XDocument
  //      Dim xdPFFI As New XDeclaration("1.0", "utf-8", "yes")
  //      docpfFileInfo.Declaration = xdPFFI

  //      Dim xPFFIDetail As New XElement("PFFileInfo")

  //      Dim oPFFIDetail As New XElement("PFFileNfo")
  //      oPFFIDetail.Add(New XElement("pfFileName", Me.PFileInfo.PFFileName.ToString))
  //      oPFFIDetail.Add(New XElement("pfDescription", Me.PFileInfo.PFDescription.ToString))
  //      oPFFIDetail.Add(New XElement("pfDateCreated", Me.PFileInfo.PFDateCreated.ToString))
  //      oPFFIDetail.Add(New XElement("pfDateLastUpdated", Me.PFileInfo.PFDateLastUpdated.ToString))
  //      oPFFIDetail.Add(New XElement("pfStatus", Me.PFileInfo.PFStatus.ToString))
  //      oPFFIDetail.Add(New XElement("pfAreaAOI", Me.PFileInfo.PFAreaAOI.ToString))
  //      oPFFIDetail.Add(New XElement("pfAreaManagementN", Me.PFileInfo.PFAreaManagementN.ToString))
  //      oPFFIDetail.Add(New XElement("pfAreaManagementC", Me.PFileInfo.PFAreaManagementC.ToString))
  //      oPFFIDetail.Add(New XElement("pfAreaDefineRun", Me.PFileInfo.PFAreaDefineRun.ToString))
  //      oPFFIDetail.Add(New XElement("pfFAreaReports", Me.PFileInfo.PFAreaReports.ToString))
  //      xPFFIDetail.Add(oPFFIDetail)

  //      docpfFileInfo.Add(xPFFIDetail)

  //      objText = sfd.OpenFile()

  //      objTextW = New StreamWriter(objText)

  //      objTextW.WriteLine("<AllData>") '//xml single root
  //      objTextW.WriteLine(docpfFileInfo.ToString) '//internal file info
  //      'objTextW.WriteLine(sTmp.ToString) '// returned climate detail
  //      objTextW.WriteLine("</AllData>") '//xml single root

  //      objTextW.Flush() : objTextW.Close()
  //      objText.Close()

  //      '//bind here before status change
  //      Me.PFileInfo.PFStatus = "(file saved)"


  //      Me.eChkChangeProjectFile = False

  //      Me.gridPFile.DataContext = ""
  //      Me.gridPFile.DataContext = PFileInfo

  //      Me.mCurStateProjectFile = theStateProjectFile.StateSaved

  //    End If
  //  Catch ex As Exception
  //    Dim msgBResult As MessageBoxResult = MessageBox.Show(ex.Message.ToString, "Error: btnPFSaveAs_Click Failed Information", MessageBoxButton.OK)
  //  Finally
  //    If Not objTextW Is Nothing Then objTextW.Close()
  //    If Not objText Is Nothing Then objText.Close()
  //  End Try
  //End Sub

  //Private Sub btnPFClose_Click(ByVal sender As Object, ByVal e As System.Windows.RoutedEventArgs) Handles btnPFClose.Click
  //  Try
  //    '//bind here before status change
  //    Me.PFileInfo.PFFileName = "(none)" : Me.PFileInfo.PFDescription = ""
  //    Me.PFileInfo.PFDateCreated = "" : Me.PFileInfo.PFDateLastUpdated = ""
  //    Me.PFileInfo.PFStatus = "(no project file)" : Me.PFileInfo.PFAreaAOI = "No"
  //    Me.PFileInfo.PFAreaManagementN = "No" : Me.PFileInfo.PFAreaManagementC = "No"
  //    Me.PFileInfo.PFAreaDefineRun = "No" : Me.PFileInfo.PFAreaReports = "No"

  //    Me.eChkChangeProjectFile = False

  //    Me.gridPFile.DataContext = ""
  //    Me.gridPFile.DataContext = PFileInfo

  //    Me.mCurStateProjectFile = theStateProjectFile.StateMissing

  //  Catch ex As Exception
  //    Dim msgBResult As MessageBoxResult = MessageBox.Show(ex.Message.ToString, "Error: btnPFClose_Click Failed Information", MessageBoxButton.OK)
  //  End Try
  //End Sub

  //Private Sub btnPFCancel_Click(ByVal sender As Object, ByVal e As System.Windows.RoutedEventArgs) Handles btnPFCancel.Click
  //  Try
  //    '//bind here before status change
  //    Me.PFileInfo.PFFileName = "(none)" : Me.PFileInfo.PFDescription = ""
  //    Me.PFileInfo.PFDateCreated = "" : Me.PFileInfo.PFDateLastUpdated = ""
  //    Me.PFileInfo.PFStatus = "(no project file)" : Me.PFileInfo.PFAreaAOI = "No"
  //    Me.PFileInfo.PFAreaManagementN = "No" : Me.PFileInfo.PFAreaManagementC = "No"
  //    Me.PFileInfo.PFAreaDefineRun = "No" : Me.PFileInfo.PFAreaReports = "No"

  //    Me.eChkChangeProjectFile = False

  //    Me.gridPFile.DataContext = ""
  //    Me.gridPFile.DataContext = PFileInfo

  //    Me.mCurStateProjectFile = theStateProjectFile.StateMissing

  //  Catch ex As Exception
  //    Dim msgBResult As MessageBoxResult = MessageBox.Show(ex.Message.ToString, "Error: btnPFCancel_Click Failed Information", MessageBoxButton.OK)
  //  End Try
  //End Sub

