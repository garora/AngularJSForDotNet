﻿//---------------------------------------------------
//Summary
//Nutrient Tracking Tool (NTT) - NTTHome tabbed Silverlight page.
//---------------------------------------------------
//Revision History
//Rev#  Date     Who   Change history
// 001  12/12/11 HAC   Initial C# version.
//---------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace NTTHome
{
  public partial class App : Application
  {

    public App()
    {
      this.Startup += this.Application_Startup;
      this.Exit += this.Application_Exit;
      this.UnhandledException += this.Application_UnhandledException;

      InitializeComponent();
    }

    // Properties set in HTML (in the tag <param name="initParams" />)
    // Id allows multiple instances of this app to appear in the same web page and be referenced
    // individually
    public string Id { get; set; }
    // The javascript function to call when the silverlight app has been fully loaded
    public string OnLoad { get; set; }
    // The javascript function to call when an AOI has been completed
    public string OnAOIDrawn { get; set; }
    // The javascript function to call export in new window
    public string jsWindow { get; set; }

    // utility function to get a param out of a dictionary, if it exists
    // (TryGetValue doesn't work with properties...)
    string GetParam(Dictionary<string, string> dict, string name)
    {
      if (dict.ContainsKey(name))
        return dict[name];

      return null;
    }

    private void Application_Startup(object sender, StartupEventArgs e)
    {
      // make keys case insensitive
      var dict = new Dictionary<string, string>();
      foreach (var key in e.InitParams.Keys)
        dict[key.ToLower()] = e.InitParams[key];

      // set property values to what was passed in via initParams
      Id = GetParam(dict, "id");
      OnLoad = GetParam(dict, "onload");
      OnAOIDrawn = GetParam(dict, "onaoidrawn");
      jsWindow = GetParam(dict, "jswindow");

      this.RootVisual = new MainPage();
    }

    private void Application_Exit(object sender, EventArgs e)
    {

    }

    private void Application_UnhandledException(object sender, ApplicationUnhandledExceptionEventArgs e)
    {
      // If the app is running outside of the debugger then report the exception using
      // the browser's exception mechanism. On IE this will display it a yellow alert 
      // icon in the status bar and Firefox will display a script error.
      if (!System.Diagnostics.Debugger.IsAttached)
      {

        // NOTE: This will allow the application to continue running after an exception has been thrown
        // but not handled. 
        // For production applications this error handling should be replaced with something that will 
        // report the error to the website and stop the application.
        e.Handled = true;
        Deployment.Current.Dispatcher.BeginInvoke(delegate { ReportErrorToDOM(e); });
      }
    }

    private void ReportErrorToDOM(ApplicationUnhandledExceptionEventArgs e)
    {
      try
      {
        string errorMsg = e.ExceptionObject.Message + e.ExceptionObject.StackTrace;
        errorMsg = errorMsg.Replace('"', '\'').Replace("\r\n", @"\n");

        System.Windows.Browser.HtmlPage.Window.Eval("throw new Error(\"Unhandled Error in Silverlight Application " + errorMsg + "\");");
      }
      catch (Exception)
      {
      }
    }
  }
}
