﻿//---------------------------------------------------
//Summary
//Nutrient Tracking Tool (NTT) - NTTHome tabbed Silverlight page.
//---------------------------------------------------
//Revision History
//Rev#  Date     Who   Change history
// 001  12/12/11 HAC   Initial C# version.
//---------------------------------------------------

using System;
using System.Windows.Controls;

namespace NTTHome.Controls
{
	/// <summary>
	/// A radio button that can be turned into a toggle button if Toggleable is set to true
	/// </summary>
	public class MenuToggleButton : RadioButton
	{
		bool defaultValue = true;
		public bool Toggleable { get; set; }

		public bool DefaultValue { get { return defaultValue; } set { defaultValue = value; } }

		protected override void OnToggle()
		{
			if (Toggleable)
				IsChecked = !IsChecked;
			else
				IsChecked = defaultValue;
		}
	}
}
