﻿//---------------------------------------------------
//Summary
//Nutrient Tracking Tool (NTT) - NTTHome tabbed Silverlight page.
//---------------------------------------------------
//ToDo: Fix failed external parameters (is this done?)
//ToDo: Fix 'Loading soils...' message.
//Revision History
//Rev#  Date     Who   Change history
// 015  03/27/13 HAC   Add B/A selection and basic editing;
//                      need to restrict access w/o an AOI selection.
// 014  01/18/13 HAC   Add external AppEndPointServices for ManagementsService;
//                      changes to external parameters into Process Common.
// 013  01/18/13 HAC   New management editing from prototype added.
// 012  01/25/13 HAC   Use XmlSerializer to save project files.
// 011  01/11/13 HAC   Add Management Baseline/Alternative tab;
//                      try-catch for everything.
// 010  01/31/12 HAC   Calculate area in acres using bounding box coordinates;
//                      bind location data in GetSDMSoilComponents - needs to have a 'loading...' msg.
// 009  01/17/12 HAC   Dynamic service references by name;
//                      adjust height of soils grid and allow scrolling.
// 008  01/13/12 HAC   Soils/Location tab Soils grid/edit;
//                      NTTSoilsService reference;
//                      call service from boxTool_Completed.
// 007  01/11/12 HAC   New Admin tab based on run param 'AdminString' matching value;
// 006  01/10/12 HAC   Soils/Location tab AOI info;
//                      bind to new LocationData elements.
// 005  12/27/11 HAC   Project File tab buttons and form fields.
// 004  12/23/11 HAC   New jsWindow javascript funtion for resizable export window.
// 003  12/22/11 HAC   New params in NTTHomeRunParams.xml file;
//                      new code for formState events.
// 002  12/22/11 HAC   New Controls StatusBar;
//                      new ProcessCommon.cs.
// 001  12/12/11 HAC   Initial C# version.
//---------------------------------------------------

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel; //ObservableCollection
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Windows;
using System.Windows.Browser;
using System.Windows.Controls;
using System.Windows.Data; //BindingExpressions
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Reflection; //needed for Assembly
using System.Windows.Shapes;
using System.Xml.Linq;

//using NTTHome.Controls;
using NTTHome.NTTManagementsService;
using NTTHome.NTTSoilsService;
using NTTHome.ProcessComn;

using ESRI.ArcGIS.Client.Geometry;
using ESRI.ArcGIS.Client.Symbols;

using GeoNavigator;
using GeoNavigator.Layers;
using GeoNavigator.MapTools;
using GeoNavigator.Projection;

namespace NTTHome
{
  public partial class MainPage : UserControl
  {
    private const string sMeName = "MainPage";

    //external parameters
    //private string sAppEndPointServicesSoils = "";
    //private string sAppEndPointServicesNTTHome = "";
    //private string sAppNTTHomeHandler = "";
    //private string sAppNTTHomeHelpHost = "";
    //private string sAppNTTHomeWebPageHost = "";
    //private string sAppNTTHomeWebPage = "";
    //private int nYearStart = 1960;
    //private int nYearEnd = 2006;
    //private string sAppAdminString = "";

    //private NTTHomeRunParams saveRunParams = new NTTHomeRunParams();
    private ProjectFileData savePFData = new ProjectFileData();
    private SBarFieldData saveSBarData = new SBarFieldData();
    private LocationData saveLocData = new LocationData();
    private List<SoilEditData> saveSoilData = new List<SoilEditData>();
    private List<StatesNames> staNames = null;

    ManagementsClient mapClient = null;

    public enum formState
    {
      StateInitial = 1,
      StateNew = 2,
      StateOpen = 3,
      StateCanceled = 4,
      StateChanged = 5,
      StateSaved = 6
    }

    public formState mCurrentFormState
    {
      get { return eCurrentFormState; }
      private set
      {
        eCurrentFormState = value;
        setFormState(eCurrentFormState);
      }
    }

    private formState eCurrentFormState;
    private formState mPreviousFormState;
    
    //AOI
    // string names for the Draw and Finish buttons - these can be changed from javascript
    const string drawAOIStringDefault = "Draw AOI";
    const string finishAOIStringDefault = "Finish AOI";

    // cache the boxTool from the mapExtender
    BoxInteractiveTool boxTool;
    BoxInteractiveTool BoxTool
    {
      get
      {
        if (boxTool == null)
          boxTool = mapExtender.Tools["boxTool"] as BoxInteractiveTool;

        return boxTool;
      }
    }

    // cache a reference to the main application
    App mainApp;
    App MainApp
    {
      get
      {
        if (mainApp == null)
          mainApp = ((App)App.Current);

        return mainApp;
      }
    }

    public MainPage()
    {
      InitializeComponent();
      Loaded += Page_Loaded;

      //doGetRunParams();

      //set initial values
      mCurrentFormState = formState.StateInitial;

      //AOI
      // register this page as accessible via javascript
      HtmlPage.RegisterScriptableObject("MapPage", this);

      // set the button text values to their default values
      // (can be overridden in javascript after the page has fully loaded)
      drawAOIText.Text = drawAOIStringDefault;
      finishAOIText.Text = finishAOIStringDefault;

      drawAOIBtn.Click += new RoutedEventHandler(drawAOIBtn_Click);
      finishAOIBtn.Click += new RoutedEventHandler(finishAOIBtn_Click);

      BoxTool.Completed += new EventHandler<EventArgs<Envelope>>(boxTool_Completed);
    }

    private void Page_Loaded(object sender, RoutedEventArgs e)
    {
      try
      {
        //test network connection
        //string sTmp = testNetworkDemo(); //always returns true in vpc

        //test error logging
        //int nZero = 0;
        //double nAmt = 25 / nZero;

        //ClientLogData cldDebug = new ClientLogData();
        //cldDebug.CLDMsg = "<<Starting - Page_Loaded>>"; cldDebug.CLDLevel = "2"; cldDebug.CLDIndent = "0";
        //ProcessCommon.doDebugLog(cldDebug);

        initMgtBOrA();
        doGetRunParams();
      }
      catch (Exception Ex)
      {
        StackTrace sTrace = new StackTrace();
        //ProcessCommon.doErrorLog(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", Ex);
        MessageBox.Show("Exception failure: " + Ex.Message.ToString(), sTrace.GetFrame(0).GetMethod().Name, MessageBoxButton.OK);
      }
    }

    private void initMgtBOrA()
    {
      try
      {
        //test code
        ProcessCommon.nSelectedCMZ = 68;  //CMZ 65 has id of 68

        Type type = this.GetType();
        Assembly assembly = type.Assembly;
        UserControl newPage = (UserControl)assembly.CreateInstance(type.Namespace + ".ManMaintenance");

        ProcessCommon.bIsBaseline = true;
        //set empty initially
        ViewManOpsData mtyVMan = new ViewManOpsData() { movManCmzId = "", movManCropsNames = "(None)", movManCropsDesc = "", movManCropsNbr = 0, movManDuration = "", movManId = "", movManName = "", movManOps = null, movManPathId = "", movManYears = 0 };

        ProcessCommon.vuManSelectedBase = mtyVMan;
        ProcessCommon.vuManSelectedAlt = mtyVMan;

        // Show the page.
        this.bdrPlaceholderBase.Child = newPage;
      }
      catch (Exception Ex)
      {
        StackTrace sTrace = new StackTrace();
        //ProcessCommon.doErrorLog(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", Ex);
        MessageBox.Show("Exception failure: " + Ex.Message.ToString(), sTrace.GetFrame(0).GetMethod().Name, MessageBoxButton.OK);
      }
    }
    #region tabEvents

    private void tabControl1_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      try
      {
        //require a project file on all initial tabs
        if (savePFData.pfFileName == ProcessCommon.sNone)
        {
          if (sender is TabControl)
          {
            if ((sender as TabControl).SelectedIndex > 0)
            {
              MessageBoxResult msgBResult = MessageBox.Show(ProcessCommon.sTabPFFirst, "Missing Project File.", MessageBoxButton.OK);
              this.tabControl1.SelectedIndex = 0;
              //for testing to go directly to the management tab
              //this.tabProject.IsSelected = true;
            }
          }
        }
      }
      catch (Exception Ex)
      {
        StackTrace sTrace = new StackTrace();
        //ProcessCommon.doErrorLog(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", Ex);
        MessageBox.Show("Exception failure: " + Ex.Message.ToString(), sTrace.GetFrame(0).GetMethod().Name, MessageBoxButton.OK);
      }
    }

    #endregion

    #region ProjectFileEvents

    private void btnPFNew_Click(object sender, RoutedEventArgs e)
    {
      try
      {
        mCurrentFormState = formState.StateNew;
      }
      catch (Exception Ex)
      {
        StackTrace sTrace = new StackTrace();
        //ProcessCommon.doErrorLog(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", Ex);
        MessageBox.Show("Exception failure: " + Ex.Message.ToString(), sTrace.GetFrame(0).GetMethod().Name, MessageBoxButton.OK);
      }
    }
    private void btnPFOpen_Click(object sender, RoutedEventArgs e)
    {
      string sResult = "";
      try
      {
        ProjectFile pfFile = new ProjectFile();
        pfFile.PFileData = savePFData;
        sResult = pfFile.FileOpen();
        if (sResult == "OK")
        {
         // savePFData = pfFile.PFileData; //this does not work-no binding changes
          savePFData.pfFileName = pfFile.PFileData.pfFileName;
          savePFData.pfDescription = pfFile.PFileData.pfDescription;
          savePFData.pfDateCreated = pfFile.PFileData.pfDateCreated;
          savePFData.pfDateLastUpdated = pfFile.PFileData.pfDateLastUpdated;

          mCurrentFormState = formState.StateOpen;
        }
      }
      catch (Exception Ex)
      {
        StackTrace sTrace = new StackTrace();
        //ProcessCommon.doErrorLog(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", Ex);
        MessageBox.Show("Exception failure: " + Ex.Message.ToString(), sTrace.GetFrame(0).GetMethod().Name, MessageBoxButton.OK);
      }
    }
    private void btnPFClose_Click(object sender, RoutedEventArgs e)
    {
      try
      {
        //To do: check if changes were made before closing
        mCurrentFormState = formState.StateCanceled;
      }
      catch (Exception Ex)
      {
        StackTrace sTrace = new StackTrace();
        //ProcessCommon.doErrorLog(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", Ex);
        MessageBox.Show("Exception failure: " + Ex.Message.ToString(), sTrace.GetFrame(0).GetMethod().Name, MessageBoxButton.OK);
      }
    }
    private void btnPFCancel_Click(object sender, RoutedEventArgs e)
    {
      try
      {
        //To do: if changes were made, use msg box to verify
        mCurrentFormState = formState.StateCanceled;
      }
      catch (Exception Ex)
      {
        StackTrace sTrace = new StackTrace();
        //ProcessCommon.doErrorLog(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", Ex);
        MessageBox.Show("Exception failure: " + Ex.Message.ToString(), sTrace.GetFrame(0).GetMethod().Name, MessageBoxButton.OK);
      }
    }
    private void btnPFSave_Click(object sender, RoutedEventArgs e)
    {
      string sResult = "";
      try
      {
        ProjectFile pfFile = new ProjectFile();
        //this.savePFData.pfMgtDetailBData = ProcessCommon.vuManSelectedDetailBase;
        pfFile.PFileData = savePFData;
        sResult = pfFile.FileSave();
        if (sResult == "OK")
        {
          savePFData = pfFile.PFileData;
          mCurrentFormState = formState.StateSaved;
        }
        else
        {
          //msg box with error here
        }
      }
      catch (Exception Ex)
      {
        StackTrace sTrace = new StackTrace();
        //ProcessCommon.doErrorLog(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", Ex);
        MessageBox.Show("Exception failure: " + Ex.Message.ToString(), sTrace.GetFrame(0).GetMethod().Name, MessageBoxButton.OK);
      }
    }
    private void btnPFSaveAs_Click(object sender, RoutedEventArgs e)
    {
      try
      {
      }
      catch (Exception Ex)
      {
        StackTrace sTrace = new StackTrace();
        //ProcessCommon.doErrorLog(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", Ex);
        MessageBox.Show("Exception failure: " + Ex.Message.ToString(), sTrace.GetFrame(0).GetMethod().Name, MessageBoxButton.OK);
      }
    }

    #endregion

    #region SoilsLocationEvents

    private void btnSoilSave_Click(object sender, RoutedEventArgs e)
    {
      try
      {
      //clear validation errors
      this.vsValidationSummary.Errors.Clear();

      var bindingExpressions = gridSoilEdit.Children.OfType<TextBox>().
        Select((tbx) => tbx.GetBindingExpression(TextBox.TextProperty));
      foreach (BindingExpression be in bindingExpressions) be.UpdateSource();

      //gridSoilEdit.DataContext = ""; //cannot uncommment this - errors will not show???
      }
      catch (Exception Ex)
      {
        StackTrace sTrace = new StackTrace();
        //ProcessCommon.doErrorLog(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", Ex);
        MessageBox.Show("Exception failure: " + Ex.Message.ToString(), sTrace.GetFrame(0).GetMethod().Name, MessageBoxButton.OK);
      }
    }

    private void btnSoilCancel_Click(object sender, RoutedEventArgs e)
    {
      try
      {
      //clear validation errors
      this.vsValidationSummary.Errors.Clear();
      gridSoilEdit.DataContext = "";

      //reset to original data
      //lstSoilData = origSoilData; //just a link

      //this.SoilsGrid.ItemsSource = lstSoilData;
      }
      catch (Exception Ex)
      {
        StackTrace sTrace = new StackTrace();
        //ProcessCommon.doErrorLog(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", Ex);
        MessageBox.Show("Exception failure: " + Ex.Message.ToString(), sTrace.GetFrame(0).GetMethod().Name, MessageBoxButton.OK);
      }
    }

    private void SoilsGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      try
      {
      //set the datacontext of the form to the selected soil
      gridSoilEdit.DataContext = (SoilEditData)SoilsGrid.SelectedItem;
      }
      catch (Exception Ex)
      {
        StackTrace sTrace = new StackTrace();
        //ProcessCommon.doErrorLog(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", Ex);
        MessageBox.Show("Exception failure: " + Ex.Message.ToString(), sTrace.GetFrame(0).GetMethod().Name, MessageBoxButton.OK);
      }
    }

    void svcNttSoils_GetSDMSoilComponents(object sender, GetSDMSoilComponentsCompletedEventArgs e)
    {
      string sTmp = "";
      double nDouble;
      bool isDouble;
      int nAcresTotal = 0;
      try
      {
        if (e.Error == null)
        {
          //List<SoilComponentsData> scData = e.Result;
          ObservableCollection<SoilComponentsData> scData = e.Result;

          sTmp = ""; sTmp = saveLocData.aoiAcres;
          ProcessCommon.TestDouble(sTmp, out isDouble, out nDouble);
          if (isDouble) { nAcresTotal = Convert.ToInt32(nDouble); } else { nAcresTotal = 200; }
          if (nAcresTotal < 1) nAcresTotal = 200;

          int nNbr = scData.Count;
          double nAcres = nAcresTotal / nNbr;
          double nPct = (nAcres / nAcresTotal) * 100;
          foreach (SoilComponentsData sComp in scData)
          {
            //sComp.scAcres = String.Format("{0:N2}", Math.Round(nAcres, 2));
            //sComp.scPercent = String.Format("{0:N2}", Math.Round(nPct, 2));
            SoilEditData sDta = new SoilEditData();
            sDta.sedSymbol = sComp.scdSymbol;
            sDta.sedName = sComp.scdName;
            sDta.sedAcres = String.Format("{0:N2}", Math.Round(nAcres, 2));
            sDta.sedPercent = String.Format("{0:N2}", Math.Round(nPct, 2));
            sDta.sedSlope = sComp.scdSlope;
            sDta.sedPH = sComp.scdPH;
            sDta.sedSSA = sComp.scdSSA;
            if (saveLocData.aoiState.Length == 0)
            {
              if (sComp.scdSSA.Length > 2)
              {
                saveLocData.aoiState = sComp.scdSSA.Substring(0, 2);
                foreach (StatesNames stNa in staNames)
                {
                  if (stNa.stAbbrevName == saveLocData.aoiState)
                  {
                    saveLocData.aoiState = stNa.stName;
                    break;
                  }
                }
              }
            }
            this.saveSoilData.Add(sDta);
          }

          this.tabSoilsLocation.DataContext = "";
          this.tabSoilsLocation.DataContext = saveLocData;
          this.tabSoilsLocation.IsSelected = true;

          this.SoilsGrid.ItemsSource = "";
          this.SoilsGrid.ItemsSource = this.saveSoilData;

          //string sTmp = "";
        }
        else
        { 
          //this.lblResults.Content = "Error!"; 
        }
      }
      catch (Exception Ex)
      {
        StackTrace sTrace = new StackTrace();
        //ProcessCommon.doErrorLog(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", Ex);
        MessageBox.Show("Exception failure: " + Ex.Message.ToString(), sTrace.GetFrame(0).GetMethod().Name, MessageBoxButton.OK);
      }
    }

    void svcNttSoils_GetCMZ(object sender, GetCMZCompletedEventArgs e)
    {
      string sTmp = "";
      try
      {
        if (e.Error == null)
        {
          sTmp = e.Result;

          XDocument xmlFromWai = new XDocument();
          xmlFromWai = XDocument.Parse(sTmp.ToString());

          this.saveLocData.aoiCmz = xmlFromWai.Elements().ElementAt(0).Value.Replace("CMZ ID", "");
          this.tabSoilsLocation.DataContext = "";
          this.tabSoilsLocation.DataContext = saveLocData;
        }
        else
        {
          //this.lblResults.Content = "Error!"; 
        }
      }
      catch (Exception Ex)
      {
        StackTrace sTrace = new StackTrace();
        //ProcessCommon.doErrorLog(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", Ex);
        MessageBox.Show("Exception failure: " + Ex.Message.ToString(), sTrace.GetFrame(0).GetMethod().Name, MessageBoxButton.OK);
      }
    }

    #endregion

    #region ManagementEvents
    private void tabMgtBorA_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      try
      {
        if (sender is TabControl)
        {
          if (this.bdrPlaceholderBase != null)
          {
            if ((sender as TabControl).SelectedIndex == 0)
            {
              Type type = this.GetType();
              Assembly assembly = type.Assembly;
              UserControl newPage = (UserControl)assembly.CreateInstance(type.Namespace + ".ManMaintenance");

              ProcessCommon.bIsBaseline = true;

              // Show the page.
              this.bdrPlaceholderBase.Child = newPage;
            }
            else
            {
              Type type = this.GetType();
              Assembly assembly = type.Assembly;
              UserControl newPage = (UserControl)assembly.CreateInstance(type.Namespace + ".ManMaintenance");

              ProcessCommon.bIsBaseline = false;

              // Show the page.
              this.bdrPlaceholderAlt.Child = newPage;
            }
          }
        }
      }
      catch (Exception Ex)
      {
        StackTrace sTrace = new StackTrace();
        //ProcessCommon.doErrorLog(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", Ex);
        MessageBox.Show("Exception failure: " + Ex.Message.ToString(), sTrace.GetFrame(0).GetMethod().Name, MessageBoxButton.OK);
      }
    }

    #endregion

    #region form state

    private void setFormState(formState currentState)
    {
      try
      {
        switch (currentState)
        {
          case formState.StateInitial:
            {
              initialStatusBar();
              initialProjectFile();
              initialTabs();
              mPreviousFormState = formState.StateInitial;
              break;
            }
          case formState.StateNew:
            {
              //entry fields
              this.tbxPFDesc.IsEnabled = true;
              //adjust buttons
              this.btnPFNew.IsEnabled = false;
              this.btnPFOpen.Visibility = Visibility.Collapsed;
              this.btnPFCancel.Visibility = Visibility.Visible;
              this.btnPFSave.Visibility = Visibility.Visible;
              //adjust text
              this.tbKPFTitle.Text = ProcessCommon.sPFTitle + " (New)";
              this.tbxPFFilename.Text = "";
              this.tbxPFDesc.Text = "";
              this.tbxPFDesc.Focus();
              //status bar
              saveSBarData.SBarProjFileName = "(New)";
              //tooltips
              ToolTipService.SetToolTip(this.tabAOI, ProcessCommon.sTabPFAOI);
              ToolTipService.SetToolTip(this.tabSoilsLocation, ProcessCommon.sTabPFSoilsLocation);
              ToolTipService.SetToolTip(this.tabManagement, ProcessCommon.sTabPFManagement);
              ToolTipService.SetToolTip(this.tabDefineRun, ProcessCommon.sTabPFDefineRun);
              ToolTipService.SetToolTip(this.tabReports, ProcessCommon.sTabPFReports);

              mPreviousFormState = formState.StateNew;
              break;
            }
          case formState.StateOpen:
            {
              this.tabProject.DataContext = "";
              this.tabProject.DataContext = savePFData;

              //entry fields
              this.tbxPFDesc.IsEnabled = true;
              //adjust buttons
              this.btnPFNew.Visibility = Visibility.Collapsed;
              this.btnPFOpen.Visibility = Visibility.Collapsed;
              this.btnPFCancel.Visibility = Visibility.Visible;
              this.btnPFSave.Visibility = Visibility.Visible;
              //adjust text
              this.tbKPFTitle.Text = ProcessCommon.sPFTitle + " (Open)";
              //status bar
              saveSBarData.SBarProjFileName = savePFData.pfFileName;
              //tooltips
              ToolTipService.SetToolTip(this.tabAOI, ProcessCommon.sTabPFAOI);
              ToolTipService.SetToolTip(this.tabSoilsLocation, ProcessCommon.sTabPFSoilsLocation);
              ToolTipService.SetToolTip(this.tabManagement, ProcessCommon.sTabPFManagement);
              ToolTipService.SetToolTip(this.tabDefineRun, ProcessCommon.sTabPFDefineRun);
              ToolTipService.SetToolTip(this.tabReports, ProcessCommon.sTabPFReports);

              //admin tab visible
              if (this.tbxPFDesc.Text.ToLower().Contains(ProcessCommon.sAppAdminString.ToLower()))
              { this.tabAdmin.Visibility = System.Windows.Visibility.Visible; }
              else
              { this.tabAdmin.Visibility = System.Windows.Visibility.Collapsed; }

              mPreviousFormState = formState.StateOpen;
              break;
            }
          case formState.StateCanceled:
            {
              //initialProjectFile();  //did not change bindings
              savePFData.pfFileName = ProcessCommon.sNone;
              savePFData.pfDescription = "";
              savePFData.pfDateCreated = "";
              savePFData.pfDateLastUpdated = "";
              savePFData.pfStatus = "";
              savePFData.pfAreaAOI = "";
              savePFData.pfAreaManagement = "";
              savePFData.pfAreaDefineRun = "";
              savePFData.pfAreaReports = "";
              //adjust buttons
              this.btnPFNew.Visibility = Visibility.Visible; this.btnPFNew.IsEnabled = true;
              this.btnPFOpen.Visibility = Visibility.Visible; this.btnPFOpen.IsEnabled = true;
              this.btnPFCancel.Visibility = Visibility.Collapsed;
              this.btnPFClose.Visibility = Visibility.Collapsed;
              this.btnPFSave.Visibility = Visibility.Collapsed;
              this.btnPFSaveAs.Visibility = Visibility.Collapsed;
              //entry fields
              this.tbxPFFilename.IsEnabled = false;
              this.tbxPFDesc.IsEnabled = false;
              this.tbxPFCreated.IsEnabled = false;
              this.tbxPFLastUpdated.IsEnabled = false;
              this.tbKPFTitle.Text = ProcessCommon.sPFTitle;
              //status bar
              saveSBarData.SBarProjFileName = savePFData.pfFileName;
              //tooltips
              initialTabs();

              this.tabProject.DataContext = "";
              this.tabProject.DataContext = savePFData;

              mPreviousFormState = formState.StateCanceled;
              break;
            }
          case formState.StateChanged:
            {
              mPreviousFormState = formState.StateChanged;
              break;
            }
          case formState.StateSaved:
            {
              //admin tab visible
              if (this.tbxPFDesc.Text.ToLower().Contains(ProcessCommon.sAppAdminString.ToLower()))
              { this.tabAdmin.Visibility = System.Windows.Visibility.Visible; }
              else
              { this.tabAdmin.Visibility = System.Windows.Visibility.Collapsed; }

              mPreviousFormState = formState.StateSaved;
              break;
            }
        }
      }
      catch (Exception Ex)
      {
        StackTrace sTrace = new StackTrace();
        //ProcessCommon.doErrorLog(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", Ex);
        MessageBox.Show("Exception failure: " + Ex.Message.ToString(), sTrace.GetFrame(0).GetMethod().Name, MessageBoxButton.OK);
      }
    }

    private void initialStatusBar()
    {
      try
      {
        saveSBarData = (new SBarFieldData
        {
          SBarStatusBGColor = ProcessCommon.sbBGFill,
          SBarStatusFGColor = ProcessCommon.sbFGFillRed,
          SBarBGColorIconP = ProcessCommon.iconNoneBFFill,
          SBarBGColorIconA = ProcessCommon.iconNoneBFFill,
          SBarBGColorIconS = ProcessCommon.iconNoneBFFill,
          SBarBGColorIconM = ProcessCommon.iconNoneBFFill,
          SBarBGColorIconD = ProcessCommon.iconNoneBFFill,
          SBarBGColorIconR = ProcessCommon.iconNoneBFFill,
          SBarStatus = "Ready.",
          SBarProjFileName = ProcessCommon.sNone
        });
        this.pgSBarGrid.DataContext = saveSBarData;
      }
      catch (Exception Ex)
      {
        StackTrace sTrace = new StackTrace();
        //ProcessCommon.doErrorLog(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", Ex);
        MessageBox.Show("Exception failure: " + Ex.Message.ToString(), sTrace.GetFrame(0).GetMethod().Name, MessageBoxButton.OK);
      }
    }

    private void initialProjectFile()
    {
      try
      {
        savePFData = (new ProjectFileData
        {
          pfFileName = ProcessCommon.sNone,
          pfDescription = "",
          pfDateCreated = "",
          pfDateLastUpdated = "",
          pfStatus = "",
          pfAreaAOI = "",
          pfAreaManagement = "",
          pfAreaDefineRun = "",
          pfAreaReports = ""
        });
        
        this.tabProject.DataContext = savePFData;
        //adjust buttons
        this.btnPFNew.Visibility = Visibility.Visible; this.btnPFNew.IsEnabled = true;
        this.btnPFOpen.Visibility = Visibility.Visible; this.btnPFOpen.IsEnabled = true;
        this.btnPFCancel.Visibility = Visibility.Collapsed;
        this.btnPFClose.Visibility = Visibility.Collapsed;
        this.btnPFSave.Visibility = Visibility.Collapsed; 
        this.btnPFSaveAs.Visibility = Visibility.Collapsed;
        //entry fields
        this.tbxPFFilename.IsEnabled = false; 
        this.tbxPFDesc.IsEnabled = false;
        this.tbxPFCreated.IsEnabled = false; 
        this.tbxPFLastUpdated.IsEnabled = false;
        this.tbKPFTitle.Text = ProcessCommon.sPFTitle;
      }
      catch (Exception Ex)
      {
        StackTrace sTrace = new StackTrace();
        //ProcessCommon.doErrorLog(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", Ex);
        MessageBox.Show("Exception failure: " + Ex.Message.ToString(), sTrace.GetFrame(0).GetMethod().Name, MessageBoxButton.OK);
      }
    }

    private void initialTabs()
    {
      try
      {
        ToolTipService.SetToolTip(this.tabProject, ProcessCommon.sTabPFProject);
        ToolTipService.SetToolTip(this.tabAOI, ProcessCommon.sTabPFFirst);
        ToolTipService.SetToolTip(this.tabSoilsLocation, ProcessCommon.sTabPFFirst);
        ToolTipService.SetToolTip(this.tabManagement, ProcessCommon.sTabPFFirst);
        ToolTipService.SetToolTip(this.tabDefineRun, ProcessCommon.sTabPFFirst);
        ToolTipService.SetToolTip(this.tabReports, ProcessCommon.sTabPFFirst);
        this.tabAdmin.Visibility = System.Windows.Visibility.Collapsed;
      }
      catch (Exception Ex)
      {
        StackTrace sTrace = new StackTrace();
        //ProcessCommon.doErrorLog(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", Ex);
        MessageBox.Show("Exception failure: " + Ex.Message.ToString(), sTrace.GetFrame(0).GetMethod().Name, MessageBoxButton.OK);
      }
    }

    #endregion

    #region run params

    private void doGetRunParams()
    {
      string sURI = "";
      string sURIPath = "";
      try
      {
        sURI = System.Windows.Application.Current.Host.Source.AbsoluteUri;
        sURIPath = sURI.Substring(0, sURI.LastIndexOf("/") + 1) + ProcessCommon.NTTHomeRunParamsFile.ToString().Trim();

        WebClient wcRunParams = new WebClient();
        wcRunParams.OpenReadCompleted += wcRunParams_OpenReadCompleted;
        wcRunParams.OpenReadAsync(new Uri(sURIPath, UriKind.Absolute));
      }
      catch (Exception Ex)
      {
        StackTrace sTrace = new StackTrace();
        //ProcessCommon.doErrorLog(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", Ex);
        MessageBox.Show("Exception failure: " + Ex.Message.ToString(), sTrace.GetFrame(0).GetMethod().Name, MessageBoxButton.OK);
      }
    }

    private void wcRunParams_OpenReadCompleted(object sender, OpenReadCompletedEventArgs e)
    {
      string sTmp = "";
      int nStartYr = 0; int nEndYr = 0;
      int nInteger;
      bool isInteger;
      bool bAllOk = true;
      try
      {
        if (e.Error == null) 
        {
          using (Stream s = e.Result)
          {
            XDocument xDoc = XDocument.Load(s);
            List<NTTHomeRunParams> savRunParams = (from rparam in xDoc.Descendants("NTTHomeRunParams")
              select new NTTHomeRunParams()
              {                
                nhRPKey = rparam.Element("AppKey").Value,
                nhRPDebug = rparam.Element("AppDebug").Value,
                nhRPDebugFile = rparam.Element("AppDebugFile").Value,
                nhRPLogLocation = rparam.Element("AppLogLocation").Value,
                nhRPLogErrors = rparam.Element("AppLogErrors").Value,
                nhRPLogErrorFile = rparam.Element("AppLogErrorFile").Value,
                nhRPStartyear = rparam.Element("AppStartyear").Value,
                nhRPEndyear = rparam.Element("AppEndyear").Value,
                nhRPAdminString = rparam.Element("AppAdminString").Value,
                nhRPWaitSecondsPerYear = rparam.Element("AppWaitSecondsPerYear").Value,
                nhRPEndPointServicesSoils = rparam.Element("AppEndPointServicesSoils").Value,
                nhRPEndPointServicesManagements = rparam.Element("AppEndPointServicesManagements").Value,
                nhRPNTTDesc = rparam.Element("AppNTTDesc").Value,
                nhRPNTTDate = rparam.Element("AppNTTDate").Value
              }).ToList();

            if (savRunParams != null)
            {
              //validate values
              ProcessCommon.saveRunParams = savRunParams.ElementAt(0);

              //service references, etc.
              ProcessCommon.sAppEndPointServicesSoils = (ProcessCommon.saveRunParams.nhRPEndPointServicesSoils.Length > 0 ? ProcessCommon.saveRunParams.nhRPEndPointServicesSoils : ProcessCommon.sAppEndPointServicesSoilsDefaultDev);
              ProcessCommon.sAppEndPointServicesManagements = (ProcessCommon.saveRunParams.nhRPEndPointServicesManagements.Length > 0 ? ProcessCommon.saveRunParams.nhRPEndPointServicesManagements : ProcessCommon.sAppEndPointServicesManagementsDefaultDev);
              ProcessCommon.sAppNTTDesc = (ProcessCommon.saveRunParams.nhRPNTTDesc.Length > 0 ? ProcessCommon.saveRunParams.nhRPNTTDesc : "n/a");
              ProcessCommon.sAppNTTDate = (ProcessCommon.saveRunParams.nhRPNTTDate.Length > 0 ? ProcessCommon.saveRunParams.nhRPNTTDate : "n/a");
              ProcessCommon.sYearStart = (ProcessCommon.saveRunParams.nhRPStartyear.Length > 0 ? ProcessCommon.saveRunParams.nhRPStartyear : ProcessCommon.sYearStartDefault);
              ProcessCommon.sYearEnd = (ProcessCommon.saveRunParams.nhRPEndyear.Length > 0 ? ProcessCommon.saveRunParams.nhRPEndyear : ProcessCommon.sYearEndDefault);
              ProcessCommon.sAppAdminString = (ProcessCommon.saveRunParams.nhRPAdminString.Length > 0 ? ProcessCommon.saveRunParams.nhRPAdminString : ProcessCommon.sAppAdminStringDefault);

              bAllOk = true;
              if (ProcessCommon.saveRunParams.nhRPKey.ToLower() != "run") { bAllOk = false; }
              sTmp = ""; sTmp = ProcessCommon.sYearStart;
              ProcessCommon.TestInteger(sTmp, out isInteger, out nInteger);
              if (isInteger) { nStartYr = nInteger; } else { bAllOk = false; }
              sTmp = ""; sTmp = ProcessCommon.sYearEnd;
              ProcessCommon.TestInteger(sTmp, out isInteger, out nInteger);
              if (isInteger) { nEndYr = nInteger; } else { bAllOk = false; }

              if (bAllOk == true)
              { if (nEndYr < nStartYr) { bAllOk = false; } }

              if (bAllOk == true)
              {
                ProcessCommon.nYearStart = nStartYr;
                ProcessCommon.nYearEnd = nEndYr;
              }
              else
              {
                ProcessCommon.nYearStart = Convert.ToInt32(ProcessCommon.sYearStartDefault);
                ProcessCommon.nYearEnd = Convert.ToInt32(ProcessCommon.sYearEndDefault);
              }
            }
          }

          //get all APEX operation codes
          mapClient = new ManagementsClient(ProcessCommon.sAppEndPointServicesManagements);
          mapClient.GetTillageCodesDataCompleted +=
            new EventHandler<GetTillageCodesDataCompletedEventArgs>((sender1, args) =>
            {
              try
              {
                if (args.Result != null)
                {
                  ProcessCommon.lstAOCodesData = (from cData in args.Result orderby cData.AOCNameAbbrev where cData.AOCActive.ToLower() == "y" select cData).ToList();
                  APEXOperationCode sd1 = new APEXOperationCode() {AOCId = "0", AOCCode = "",AOCName = "", AOCNameAbbrev = ProcessCommon.sSelectOne, AOCActive = "Y" };
                  ProcessCommon.lstAOCodesData.Insert(0, sd1);
                }
              }
              catch (Exception Ex)
              {
                StackTrace sTrace = new StackTrace();
                MessageBox.Show("Exception failure: " + Ex.Message.ToString(), sTrace.GetFrame(0).GetMethod().Name, MessageBoxButton.OK);
              }
            });

          mapClient.GetTillageCodesDataAsync();

          //get mappings for APEX operations on the server
          mapClient.GetMappedOperationDataCompleted +=
          new EventHandler<GetMappedOperationDataCompletedEventArgs>((sender1, args) =>
          {
              try
              {
                if (args.Result != null)
                {
                  foreach (MappedOperation mOp in args.Result)
                  {
                    sTmp = ""; sTmp = mOp.AOpId;
                    ProcessCommon.TestInteger(sTmp, out isInteger, out nInteger);
                    if (isInteger) { mOp.AOpId = string.Format("{0, 3:000}", nInteger); }
                    sTmp = ""; sTmp = mOp.LOpId;
                    ProcessCommon.TestInteger(sTmp, out isInteger, out nInteger);
                    if (isInteger) { mOp.LOpId = string.Format("{0, 3:000}", nInteger); }
                    ProcessCommon.lstMpOperations.Add(mOp);
                  }
                }
              }
              catch (Exception Ex)
              {
                StackTrace sTrace = new StackTrace();
                MessageBox.Show("Exception failure: " + Ex.Message.ToString(), sTrace.GetFrame(0).GetMethod().Name, MessageBoxButton.OK);
              }
          });
          mapClient.GetMappedOperationDataAsync();
        }

        this.staNames = new List<StatesNames>
      {
        new StatesNames{stName="Alabama", stAbbrevName="AL"},
        new StatesNames{stName="Alaska", stAbbrevName="AK"},
        new StatesNames{stName="Arizona", stAbbrevName="AZ"},
        new StatesNames{stName="Arkansas", stAbbrevName="AR"},
        new StatesNames{stName="California", stAbbrevName="CA"},
        new StatesNames{stName="Colorado", stAbbrevName="CO"},
        new StatesNames{stName="Connecticut", stAbbrevName="CT"},
        new StatesNames{stName="Delaware", stAbbrevName="DE"},
        new StatesNames{stName="Florida", stAbbrevName="FL"},
        new StatesNames{stName="Georgia", stAbbrevName="GA"},
        new StatesNames{stName="Hawaii", stAbbrevName="HI"},
        new StatesNames{stName="Idaho", stAbbrevName="ID"},
        new StatesNames{stName="Illinois", stAbbrevName="IL"},
        new StatesNames{stName="Indiana", stAbbrevName="IN"},
        new StatesNames{stName="Iowa", stAbbrevName="IA"},
        new StatesNames{stName="Kansas", stAbbrevName="KS"},
        new StatesNames{stName="Kentucky", stAbbrevName="KY"},
        new StatesNames{stName="Louisiana", stAbbrevName="LA"},
        new StatesNames{stName="Maine", stAbbrevName="ME"},
        new StatesNames{stName="Maryland", stAbbrevName="MD"},
        new StatesNames{stName="Massachusetts", stAbbrevName="MA"},
        new StatesNames{stName="Michigan", stAbbrevName="MI"},
        new StatesNames{stName="Minnesota", stAbbrevName="MN"},
        new StatesNames{stName="Mississippi", stAbbrevName="MS"},
        new StatesNames{stName="Missouri", stAbbrevName="MO"},
        new StatesNames{stName="Montana", stAbbrevName="MT"},
        new StatesNames{stName="Nebraska", stAbbrevName="NE"},
        new StatesNames{stName="Nevada", stAbbrevName="NV"},
        new StatesNames{stName="New Hampshire", stAbbrevName="NH"},
        new StatesNames{stName="New Jersey", stAbbrevName="NJ"},
        new StatesNames{stName="New Mexico", stAbbrevName="NM"},
        new StatesNames{stName="New York", stAbbrevName="NY"},
        new StatesNames{stName="North Carolina", stAbbrevName="NC"},
        new StatesNames{stName="North Dakota", stAbbrevName="ND"},
        new StatesNames{stName="Ohio", stAbbrevName="OH"},
        new StatesNames{stName="Oklahoma", stAbbrevName="OK"},
        new StatesNames{stName="Oregon", stAbbrevName="OR"},
        new StatesNames{stName="Pennsylvania", stAbbrevName="PA"},
        new StatesNames{stName="Philippine Islands", stAbbrevName="PI"},
        new StatesNames{stName="Puerto Rico", stAbbrevName="PR"},
        new StatesNames{stName="Rhode Island", stAbbrevName="RI"},
        new StatesNames{stName="South Carolina", stAbbrevName="SC"},
        new StatesNames{stName="South Dakota", stAbbrevName="SD"},
        new StatesNames{stName="Tennessee", stAbbrevName="TN"},
        new StatesNames{stName="Texas", stAbbrevName="TX"},
        new StatesNames{stName="Utah", stAbbrevName="UT"},
        new StatesNames{stName="Vermont", stAbbrevName="VT"},
        new StatesNames{stName="Virgin Islands", stAbbrevName="VI"},
        new StatesNames{stName="Virginia", stAbbrevName="VA"},
        new StatesNames{stName="Washington", stAbbrevName="WA"},
        new StatesNames{stName="West Virginia", stAbbrevName="WV"},
        new StatesNames{stName="Wisconsin", stAbbrevName="WI"},
        new StatesNames{stName="Wyoming", stAbbrevName="WY"}
      };
      
      }
      catch (Exception Ex)
      {
        StackTrace sTrace = new StackTrace();
        //ProcessCommon.doErrorLog(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", Ex);
        MessageBox.Show("Exception failure: " + Ex.Message.ToString(), sTrace.GetFrame(0).GetMethod().Name, MessageBoxButton.OK);
        //set defaults on error
        //sAppEndPointServicesNTTHome = ProcessCommon.sAppEndPointServicesNTTHomeDefaultDev;
        //sAppNTTHomeHandler = ProcessCommon.sAppNTTHomeHandlerDefaultDev;
        //sAppNTTHomeHelpHost = ProcessCommon.sAppNTTHomeHelpHostDefaultDev;
        //sAppNTTHomeWebPageHost = ProcessCommon.sAppNTTHomeWebPageHostDefaultDev;
        //sAppNTTHomeWebPage = ProcessCommon.sAppNTTHomeWebPageDefaultDev;
        //nYearStart = ProcessCommon.nYearStartDefault;
        //nYearEnd = ProcessCommon.nYearEndDefault;
      }
    }
    #endregion

    #region Calcs
    private string computeBoundingBoxArea()
    {
      try
      {
        double nConstantLat = 6076.8;
        double nConstantLong = 6079;

        //double xMax = -120.13691501271839;  //xls Long 2
        //double xMin = -120.14144169955853;  //xls Long 1
        //double xMax = Math.Abs(-120.13691501271839);  //xls Long 2
        //double xMin = Math.Abs(-120.14144169955853);  //xls Long 1
        //double yMax = 36.760282177203536;  //xls Lat 2
        //double yMin = 36.756676158793148;  //xls Lat 1

        double xMax = Math.Abs(saveLocData.aoiXMaxVal);  //xls Long 2
        double xMin = Math.Abs(saveLocData.aoiXMinVal);  //xls Long 1
        double yMax = saveLocData.aoiYMaxVal;  //xls Lat 2
        double yMin = saveLocData.aoiYMinVal;  //xls Lat 1

        double xDiff = xMin - xMax;
        double yDiff = yMax - yMin;

        //=(B7*B4*COS(((B10+B11)/2)*PI()/180))*60 //xls ft Long
        //=(B12*B3)*60 //xls ft Lat
        //=(B8*B13)/9/4840 //xls area

        double ftLong = (xDiff * nConstantLong * Math.Cos(((yMin + yMax) / 2) * Math.PI / 180)) * 60;

        double ftLat = (yDiff * nConstantLat) * 60;

        double bbArea = ((ftLong * ftLat) / 9) / 4840;
        return bbArea.ToString("#,###.#");
      }
      catch (Exception Ex)
      {
        StackTrace sTrace = new StackTrace();
        //ProcessCommon.doErrorLog(sMeName, sTrace.GetFrame(0).GetMethod().Name, "Exception failure", Ex);
        MessageBox.Show("Exception failure: " + Ex.Message.ToString(), sTrace.GetFrame(0).GetMethod().Name, MessageBoxButton.OK);
        return "";
      }
    }

    #endregion

    #region AOI

    [ScriptableMember]
    public string Id
    {
      get { return MainApp.Id; }
      set { MainApp.Id = value; }
    }

    [ScriptableMember]
    public string DrawAOIString
    {
      get { return drawAOIText.Text; }
      set { drawAOIText.Text = value ?? drawAOIStringDefault; }
    }

    [ScriptableMember]
    public string FinishAOIString
    {
      get { return finishAOIText.Text; }
      set { finishAOIText.Text = value ?? finishAOIStringDefault; }
    }

    // DrawAOI allows javascript to draw an AOI (as opposed to the user drawing one)
    [ScriptableMember]
    public void DrawAOI(double lon1, double lat1, double lon2, double lat2)
    {
      Envelope env = new ESRI.ArcGIS.Client.Geometry.Envelope(lon1, lat1, lon2, lat2);
      BoxTool.SetExtent(env.Nad83ToWebMercator());
    }

    // This version allows the user to edit the AOI drawn via javascript
    [ScriptableMember]
    public void DrawAOI(double lon1, double lat1, double lon2, double lat2, bool editable)
    {
      Envelope env = new ESRI.ArcGIS.Client.Geometry.Envelope(lon1, lat1, lon2, lat2);
      BoxTool.SetExtent(env.Nad83ToWebMercator(), editable);
    }

    // This version allows javascript to draw an aoi using custom colors
    [ScriptableMember]
    public void DrawAOI(double lon1, double lat1, double lon2, double lat2, double opacity, string fillColor, string borderColor, double borderThickness)
    {
      DrawAOI(lon1, lat1, lon2, lat2, opacity, fillColor, borderColor, borderThickness, false);
    }

    // This version allows the user to edit the AOI drawn via javascript and with custom colors
    [ScriptableMember]
    public void DrawAOI(double lon1, double lat1, double lon2, double lat2, double opacity, string fillColor, string borderColor, double borderThickness, bool editable)
    {
      Envelope env = new ESRI.ArcGIS.Client.Geometry.Envelope(lon1, lat1, lon2, lat2);

      Symbol drawSymbol = new FillSymbol()
      {
        BorderBrush = new SolidColorBrush(borderColor.HexColor()),
        BorderThickness = borderThickness,
        Fill = new SolidColorBrush(fillColor.HexColor()) { Opacity = opacity }
      };

      BoxTool.SetExtent(env.Nad83ToWebMercator(), drawSymbol, editable);

      if (editable)
      {
        BoxTool.IsEnabled = true;
        drawAOIBtn.Visibility = Visibility.Collapsed;
        finishAOIBtn.Visibility = Visibility.Visible;
      }
    }

    // set the extent of the map
    [ScriptableMember]
    public void SetViewExtent(double lon1, double lat1, double lon2, double lat2)
    {
      Map.Extent = new Envelope(
        MercatorMath.LongitudeToMeters(lon1),
        MercatorMath.LatitudeToMeters(lat1),
        MercatorMath.LongitudeToMeters(lon2),
        MercatorMath.LatitudeToMeters(lat2)
        );
    }

    // get the current extent
    [ScriptableMember]
    public Envelope GetViewExtent()
    {
      return Map.Extent.WebMercatorToNad83();
    }

    // get the current AOI extent, if there is one
    [ScriptableMember]
    public Envelope GetAOI()
    {
      if (BoxTool == null || BoxTool.Extent == null)
        return null;

      return BoxTool.Extent.WebMercatorToNad83();
    }

    // set the default color of the AOI to be drawn
    [ScriptableMember]
    public void SetColor(string fillColor, string borderColor, double borderThickness)
    {
      BoxTool.DrawSymbol = new FillSymbol()
      {
        BorderBrush = new SolidColorBrush(borderColor.HexColor()),
        BorderThickness = borderThickness,
        Fill = new SolidColorBrush(fillColor.HexColor())
      };
    }

    // allow the user to draw an AOI
    [ScriptableMember]
    public void EnableAOIDraw()
    {
      finishAOIBtn.Visibility = Visibility.Collapsed;
      drawAOIBtn.Visibility = Visibility.Visible;
      toolsBorder.Visibility = Visibility.Collapsed;
    }

    // prevent the user from drawing an AOI
    [ScriptableMember]
    public void DisableAOIDraw()
    {
      BoxTool.CancelDraw();
      BoxTool.IsEnabled = false;
      toolsBorder.Visibility = Visibility.Collapsed;
    }

    // clear the existing AOI
    [ScriptableMember]
    public void ClearAOI()
    {
      BoxTool.Clear();
    }

    // hide all controls (i.e. just show the map)
    [ScriptableMember]
    public void HideControls()
    {
      toolBarPanel.Visibility = Visibility.Collapsed;
      panGrid.Visibility = Visibility.Collapsed;
    }

    // show all controls
    [ScriptableMember]
    public void ShowControls()
    {
      toolBarPanel.Visibility = Visibility.Visible;
      panGrid.Visibility = Visibility.Visible;
    }

    // call a javascript function
    bool InvokeJS(string name, params object[] args)
    {
      if (name == null)
        return false;

      try
      {
        // make sure this runs on the UI thread, otherwise a System.ExecutionEngineException might occur
        Dispatcher.BeginInvoke(() => HtmlPage.Window.Invoke(name, args));
        return true;
      }
      catch
      {
        return false;
      }
    }

    // tell javascript that the app has fully loaded
    void UserControl_Loaded(object sender, RoutedEventArgs e)
    {
      InvokeJS(MainApp.OnLoad, this);
    }

    // when a user has completed drawing an AOI:
    private void boxTool_Completed(object sender, EventArgs<Envelope> e)
    {
      // 1) disable the tool
      BoxTool.IsEnabled = false;
      // 2) convert the envelope from Web Mercator to NAD83
      var env = e.Args.WebMercatorToNad83();
      if (env != null)
      {
        // 3) tell javascript that an AOI has been completed (and pass the coordinates)
        //MessageBox.Show("The results are:\n" + "XMin:" + env.XMin.ToString(), "Debugging Message", MessageBoxButton.OK);
        //don't show in browser
        //InvokeJS(MainApp.OnAOIDrawn, env.XMin, env.YMin, env.XMax, env.YMax);

        this.saveLocData = new LocationData();
        this.saveSoilData.Clear();

        this.saveLocData.aoiXMinVal = env.XMin;
        this.saveLocData.aoiXMaxVal = env.XMax;
        this.saveLocData.aoiYMinVal = env.YMin;
        this.saveLocData.aoiYMaxVal = env.YMax;
        this.saveLocData.aoiXMin = env.XMin.ToString("###.###"); //e.g. -122.203 West
        this.saveLocData.aoiXMax = env.XMax.ToString("###.###"); //e.g. -121.956 East
        this.saveLocData.aoiYMin = env.YMin.ToString("###.###"); //e.g. 43.26 South
        this.saveLocData.aoiYMax = env.YMax.ToString("###.###"); //e.g. 43.43 North
        this.saveLocData.aoiState = ""; this.saveLocData.aoiCounty = "";
        this.saveLocData.aoiZip = ""; this.saveLocData.aoiCmz = "";

        this.saveLocData.aoiAcres = computeBoundingBoxArea();

        //compute centroid and show results
        double nXCent = (env.XMin + env.XMax) / 2;
        double nYCent = (env.YMin + env.YMax) / 2;

        this.saveLocData.aoiLat = nYCent.ToString();
        this.saveLocData.aoiLong = nXCent.ToString();

        //moved to GetSDMSoilComponents completed
        //this.tabSoilsLocation.DataContext = "";
        //this.tabSoilsLocation.DataContext = this.saveLocData;
        //this.tabSoilsLocation.IsSelected = true;

        //e.g. sBBoxCoordinates = "-123.504,45.38,-123.46,45.41"
        //                         (West),(South),(East),(North)         
        //                         (XMin),(YMin),(XMax),(YMax)         

        //get soils for view/edit
        //SoilComponentServiceClient svcNttSoils = new SoilComponentServiceClient();
        SoilComponentServiceClient svcNttSoils = new SoilComponentServiceClient(ProcessCommon.sAppEndPointServicesSoils.ToString());
        ManagementsClient svcMgmtClient = new ManagementsClient(ProcessCommon.sAppEndPointServicesManagements.ToString());

        svcNttSoils.GetSDMSoilComponentsCompleted += new
          EventHandler<GetSDMSoilComponentsCompletedEventArgs>(svcNttSoils_GetSDMSoilComponents);
        //svcNttSoils.GetSDMSoilComponentsAsync("-123.504", "45.38", "-123.46", "45.41"); //test code
        svcNttSoils.GetSDMSoilComponentsAsync(env.XMin.ToString(), env.YMin.ToString(), env.XMax.ToString(), env.YMax.ToString());
        //get CMZ location

        //svcNttSoils.GetCMZCompleted += new
        //  EventHandler<GetCMZCompletedEventArgs>(svcNttSoils_GetCMZ);
        svcMgmtClient.GetCMZCompleted += new EventHandler<GetCMZCompletedEventArgs>(svcNttSoils_GetCMZ);

        //svcNttSoils.GetCMZAsync("45.341185", "-122.662405"); //test code
        //Custom tool warning: Cannot import wsdl:portTypesvcNttSoils.GetCMZAsync(nYCent.ToString(), nXCent.ToString());
        svcMgmtClient.GetCMZAsync(nYCent.ToString(), nXCent.ToString());
      }
    }

    // begin drawing an AOI
    void drawAOIBtn_Click(object sender, RoutedEventArgs e)
    {
      BoxTool.IsEnabled = true;
      BoxTool.BeginDraw();
      drawAOIBtn.Visibility = Visibility.Collapsed;
      finishAOIBtn.Visibility = Visibility.Visible;
    }

    // finish drawing an AOI
    void finishAOIBtn_Click(object sender, RoutedEventArgs e)
    {
      BoxTool.EndDraw();
      BoxTool.IsEnabled = false;
      finishAOIBtn.Visibility = Visibility.Collapsed;
      drawAOIBtn.Visibility = Visibility.Visible;
    }

    // set the BingTileLayer to the appropriate imagery for the given selection
    private void roadsRadio_Checked(object sender, RoutedEventArgs e)
    {
      if (Map != null)
        ((BingTileLayer)Map.Layers["BingTileLayer"]).LayerStyle = BingTileLayer.LayerType.Road;
    }

    private void aerialRadio_Checked(object sender, RoutedEventArgs e)
    {
      if (Map != null)
        ((BingTileLayer)Map.Layers["BingTileLayer"]).LayerStyle = BingTileLayer.LayerType.Aerial;
    }

    private void hybridRadio_Checked(object sender, RoutedEventArgs e)
    {
      if (Map != null)
        ((BingTileLayer)Map.Layers["BingTileLayer"]).LayerStyle = BingTileLayer.LayerType.AerialWithLabels;
    }

    #endregion
  
  }
}

//

    //private void Page_Loaded(object sender, RoutedEventArgs e)
    //{
    //  try
    //  {
    //    //set initial values

    //    Type type = this.GetType();
    //    Assembly assembly = type.Assembly;
    //    UserControl newPage = (UserControl)assembly.CreateInstance(type.Namespace + ".ManMaintenance");

    //    ProcessCommon.bIsBaseline = true;
    //    //set empty initially
    //    ViewManOpsData mtyVMan = new ViewManOpsData() { movManCmzId = "", movManCropsNames = "(None)", movManCropsDesc = "", movManCropsNbr = 0, movManDuration = "", movManId = "", movManName = "", movManOps = null, movManPathId = "", movManYears = 0 };  

    //    ProcessCommon.vuManSelectedBase = mtyVMan;
    //    ProcessCommon.vuManSelectedAlt = mtyVMan;

    //    ProcessCommon.opEvents.Add(new OpEvent
    //    {
    //      opEventName = "Plant",
    //      opEventTypes = "5,6"
    //    });
    //    ProcessCommon.opEvents.Add(new OpEvent
    //    {
    //      opEventName = "Till",
    //      opEventTypes = "0"
    //    });
    //    ProcessCommon.opEvents.Add(new OpEvent
    //    {
    //      opEventName = "Fertilize",
    //      opEventTypes = "9"
    //    });
    //    ProcessCommon.opEvents.Add(new OpEvent
    //    {
    //      opEventName = "Irrigate",
    //      opEventTypes = "8"
    //    });
    //    ProcessCommon.opEvents.Add(new OpEvent
    //    {
    //      opEventName = "Pesticide",
    //      opEventTypes = "7"
    //    });
    //    ProcessCommon.opEvents.Add(new OpEvent
    //    {
    //      opEventName = "Harvest",
    //      opEventTypes = "2,3"
    //    });
    //    ProcessCommon.opEvents.Add(new OpEvent
    //    {
    //      opEventName = "Kill",
    //      opEventTypes = "1"
    //    });

    //    // Show the page.
    //    this.bdrPlaceholderBase.Child = newPage;
    //  }
    //  catch (Exception Ex)
    //  {
    //    StackTrace sTrace = new StackTrace();
    //    MessageBox.Show("Exception failure: " + Ex.Message.ToString(), sTrace.GetFrame(0).GetMethod().Name, MessageBoxButton.OK);
    //  }

    //}



    //private void tabControl1_SelectionChanged(object sender, SelectionChangedEventArgs e)
    //{
    //  try
    //  {
    //    if (sender is TabControl)
    //    {
    //      if (this.bdrPlaceholderBase != null)
    //      {
    //        if ((sender as TabControl).SelectedIndex == 0)
    //        {
    //          Type type = this.GetType();
    //          Assembly assembly = type.Assembly;
    //          UserControl newPage = (UserControl)assembly.CreateInstance(type.Namespace + ".ManMaintenance");

    //          ProcessCommon.bIsBaseline = true;

    //          // Show the page.
    //          this.bdrPlaceholderBase.Child = newPage;
    //        }
    //        else
    //        {
    //          Type type = this.GetType();
    //          Assembly assembly = type.Assembly;
    //          UserControl newPage = (UserControl)assembly.CreateInstance(type.Namespace + ".ManMaintenance");

    //          ProcessCommon.bIsBaseline = false;

    //          // Show the page.
    //          this.bdrPlaceholderAlt.Child = newPage;
    //        }
    //      }
    //    }
    //  }
    //  catch (Exception Ex)
    //  {
    //    StackTrace sTrace = new StackTrace();
    //    MessageBox.Show("Exception failure: " + Ex.Message.ToString(), sTrace.GetFrame(0).GetMethod().Name, MessageBoxButton.OK);
    //  }
    //}
